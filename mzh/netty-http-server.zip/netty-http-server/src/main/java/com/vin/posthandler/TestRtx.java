//package com.vin.posthandler;
//
//import java.io.IOException;
//import java.net.SocketAddress;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.concurrent.TimeUnit;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import com.vin.config.Processor;
//import com.vin.output.Output;
//import com.vin.util.ArgOption;
//import com.vin.util.ProcessorUtils;
//
//import io.netty.bootstrap.Bootstrap;
//import io.netty.channel.ChannelFutureListener;
//import io.netty.channel.ChannelHandlerContext;
//import io.netty.channel.ChannelInitializer;
//import io.netty.channel.ChannelOption;
//import io.netty.channel.EventLoopGroup;
//import io.netty.channel.nio.NioEventLoopGroup;
//import io.netty.channel.socket.SocketChannel;
//import io.netty.channel.socket.nio.NioSocketChannel;
//import io.netty.handler.codec.http.FullHttpRequest;
//import io.netty.handler.codec.http.HttpObjectAggregator;
//import io.netty.handler.codec.http.HttpRequestEncoder;
//import io.netty.handler.codec.http.HttpResponseDecoder;
//import io.netty.handler.codec.http.multipart.HttpDataFactory;
//import io.netty.handler.codec.http.multipart.HttpPostRequestDecoder;
//import io.netty.handler.codec.http.multipart.InterfaceHttpData;
//import io.netty.handler.codec.http.multipart.MixedAttribute;
//import io.netty.handler.timeout.ReadTimeoutHandler;
//
///**
// * 开发测试类
// * 
// * @author mazhanghui
// *
// */
//public class TestRtx implements Processor {
//
//	private static final Logger LOGGER = LoggerFactory.getLogger(TestRtx.class);
//
//	private static final List<ArgOption> HEADER_ARG_OPTIONs = Arrays.asList(new ArgOption("App-Key", false),
//			new ArgOption("AppKey", false), new ArgOption("Nonce", true), new ArgOption("Timestamp", true),
//			new ArgOption("Signature", true));
//
//	@Override
//	public Output process(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
//			throws APIException {
//
//		return null;
//	}
//
//	@Override
//	public void processRequest(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
//			throws APIException {
//		LOGGER.info("========>> incomming post request TestRtc.");
//
//		final Map<String, String> headers = new HashMap<>(HEADER_ARG_OPTIONs.size());
//		for (ArgOption t : HEADER_ARG_OPTIONs) {
//			ProcessorUtils.addHeader(request, headers, t);
//		}
//
////		Map<String, String> headers = ProcessorUtils.getHeadersValue(request, HEADER_ARG_OPTIONs);
//		HttpPostRequestDecoder decoder = new HttpPostRequestDecoder(factory, request);
//		InterfaceHttpData tokenData = decoder.getBodyHttpData("token");
//		InterfaceHttpData roomIdData = decoder.getBodyHttpData("roomId");
//		InterfaceHttpData userIdData = decoder.getBodyHttpData("userId");
//		String appKey = headers.get("App-Key") == null ? headers.get("AppKey") : headers.get("App-Key");
//		String nonce = headers.get("Nonce");
//		String timestamp = headers.get("Timestamp");
//		String signature = headers.get("Signature");
//
//		// 必须做非空判断
//		MixedAttribute attrToken = (MixedAttribute) tokenData;
//		MixedAttribute attrRoomId = (MixedAttribute) roomIdData;
//		MixedAttribute attrUserId = (MixedAttribute) userIdData;
//		String token = "";
//		String roomId = "";
//		String userId = "";
//
//		if (attrToken == null || attrRoomId == null || attrUserId == null) {
//			decoder.destroy();
//			throw new ParameterException("body parameter: token,roomId,userId is required.");
//		} else {
//			try {
//				roomId = attrRoomId.getValue();
//				userId = attrUserId.getValue();
//				token = attrToken.getValue();
//			} catch (IOException e) {
//				decoder.destroy();
//				throw new ParameterException("token is required.");
//			}
//		}
//
//		// 鉴权前的数据准备
//
//		LOGGER.info("========>> incomming post request TestRtc. appKey=" + appKey + ",nonce=" + nonce + ",timestramp="
//				+ timestamp + ",signature=" + signature + ",roomId=" + roomId + ",userId=" + userId + ",token="
//				+ token);
//
//		decoder.destroy();
//
//		// 验签
//		if (StringUtil.isEmpty(appKey)) {
//			throw new ParameterException("appKey is required.");
//		}
//
//		long appId = AppIdMapper.string2long(appKey);
//		ProcessorUtils.validationSignature(nonce, timestamp, signature, appId);
//
////		SCMessage msg = new SCPublish().setAppId(appId).setTargetResourceId("").setMethod("AndroidPush");
////		msg.setAppMessage("");
////		new TestRtxActor().fCluster.routeMessage(RouteMessage.wrap(msg));
//		try {
//			// TODO 转发请求 akka
//			sendToAkkaSignal(appId, "parameter 1");
//		} catch (Exception e1) {
//			e1.printStackTrace();
//		}
//		// netty 转发 http 请求
////		try {
////			FullHttpRequest httpRequest = new DefaultFullHttpRequest(HttpVersion.HTTP_1_1, HttpMethod.POST, "/rtc/room/query.json",
////					Unpooled.wrappedBuffer("content body".getBytes("UTF-8")));
////
////			// 将 请求中的 Header 添加到被用来转发的新构造出来的 http request 中
////			for (Map.Entry<String, String> entry : headers.entrySet()) {
////				httpRequest.headers().set(entry.getKey(), entry.getValue());
////			}
////
////			httpRequest.headers().set(HttpHeaders.Names.HOST, "127.0.0.1");
////			httpRequest.headers().set(HttpHeaders.Names.CONNECTION, HttpHeaders.Values.KEEP_ALIVE);
////			httpRequest.headers().set(HttpHeaders.Names.CONTENT_LENGTH, httpRequest.content().readableBytes());
////			httpRequest.headers().set(HttpHeaders.Names.CONTENT_TYPE, "application/json");
////
////			// 需要查数据库，获取转发的地址
////			return sendPostRequest(ctx, request, new InetSocketAddress("172.29.203.18", 19101), new TestRtxOutput());
////		} catch (UnsupportedEncodingException e) {
////			e.printStackTrace();
////			LOGGER.error("----netty send http request UnsupportedEncodingException:" + e.getMessage(), e);
////		}
//		
//	}
//	
//	private static int sendToAkkaSignal(Long appId, String word) throws Exception {
//		int code = 500;
//		String method = ProcessorUtils.getMethod(appId, "AndroidPush");
//		String clusterName = AppClusterMapper.getClusterOfApp(appId);
//		
//		LOGGER.info("===> send to akka, clusterName=" + clusterName);// clusterName=SandBox
//		
//		ActorRef ar = ApiUtils.getApiActor(clusterName);
//		SSRequest msg = new SSRequest();
//		msg.setAppMessage(new Object[] { appId, clusterName, word });
//		msg.setAppId(appId);
//		msg.setMethod(method);
//		msg.setTargetResourceId(String.valueOf(appId));
//		Future<Object> f = Patterns.ask(ar, RouteMessage.wrap(msg), 5000);
//		try {
//			code = (Integer) Await.result(f, Duration.create(5, TimeUnit.SECONDS));
//		} catch (Exception e) {
//			LOGGER.error("delete sensitive ,code=" + code + "   appId=" + appId, e.getMessage());
//			throw new Exception();
//		}
//
//		return code;
//	}
//
//	private Output sendPostRequest(ChannelHandlerContext ctx, FullHttpRequest postRequest, SocketAddress address,
//			TestRtxOutput output) {
//		Bootstrap b = new Bootstrap();
//		EventLoopGroup workerGroup = new NioEventLoopGroup(1);
//		b.group(workerGroup).channel(NioSocketChannel.class).option(ChannelOption.SO_KEEPALIVE, true)
//				.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000).handler(new ChannelInitializer<SocketChannel>() {
//					@Override
//					public void initChannel(SocketChannel ch) {
//						ch.pipeline().addLast(new ReadTimeoutHandler(10)).addLast(new HttpResponseDecoder())
//								.addLast(new HttpObjectAggregator(1024 * 1024 * 1024))
//								.addLast(new HttpRequestEncoder());
////								.addLast(nettyHttpHandler);
//						LOGGER.info("---sendPostRequest--initChannel");
//					}
//				});
//
//		b.connect(address).addListener((ChannelFutureListener) future -> {
//			if (!future.isSuccess()) {
////				TotalMeter.addCascadeClientTimeout();
////				HttpExcutorService.getExecutorThreadByIdentity(identity).submit(() -> {
////					httpCallback.handleResponse(false, "connect failure");
////
////				});
//				LOGGER.info("---sendPostRequest--connect--failed");
//				// 连接失败
//				output.setCode(501);
//				return;
//			} else {
//				LOGGER.info("---sendPostRequest--connect--success");
//			}
//
//			future.channel().writeAndFlush(postRequest).addListener(channelFuture -> {
//				if (!channelFuture.isSuccess()) {
////					HttpExcutorService.getExecutorThreadByIdentity(identity).submit(() -> {
////						httpCallback.handleResponse(false, "write failure");
////					});
//					// 发送数据失败
//					LOGGER.error("---sendPostRequest writeAndFlush error.");
//
//					output.setCode(502);
//				} else {
//					LOGGER.info("---sendPostRequest writeAndFlush success.");
//				}
//			});
//		});
//		return output;
//	}
//
//}
