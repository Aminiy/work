package com.vin.util;

//import com.rcloud.api.rtc.bootstrap.Bootstrap;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpHeaders.Names;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpVersion;
import io.netty.util.CharsetUtil;

public class RtcApiUtil {

	public static String getRequestFormat(FullHttpRequest request) {
		String format = "js";
		if (request.getUri().indexOf(".xml") > 0) {
			format = "xml";
		} else if (request.getUri().indexOf(".json") > 0) {
			format = "json";
		}
		return format;
	}

	public static void sendHttpResponse(Channel channel, String responseBody, String format) {
		ByteBuf buf = null;
		FullHttpResponse response = null;

		buf = Unpooled.copiedBuffer(responseBody, CharsetUtil.UTF_8);
		response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.OK, buf);

		// json,xml
		if ("json".equalsIgnoreCase(format) || "js".equalsIgnoreCase(format)) {
			response.headers().set(Names.CONTENT_TYPE, "application/json; charset=UTF-8");
		} else if ("xml".equalsIgnoreCase(format)) {
			response.headers().set(Names.CONTENT_TYPE, "text/xml; charset=UTF-8");
		} else {
			response.headers().set(Names.CONTENT_TYPE, "text/plain; charset=UTF-8");
		}

//		response.headers().set("p", Bootstrap.node);
		response.headers().set(Names.CONTENT_LENGTH, buf.readableBytes());
		response.headers().add("connection", "close");
		// 增加跨域
		response.headers().add("Access-Control-Allow-Origin", "*");
		response.headers().add("Access-Control-Allow-Methods", "*");
		response.headers().add("Access-Control-Allow-Headers", "*");

		ChannelFuture future = channel.writeAndFlush(response);
		future.addListener(ChannelFutureListener.CLOSE);
	}
}
