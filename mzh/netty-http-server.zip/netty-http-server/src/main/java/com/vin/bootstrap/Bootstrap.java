package com.vin.bootstrap;

import com.vin.netty.server.NettyHttpServer;

//import com.rcloud.cluster.FCloudCluster;

public class Bootstrap {

//	public static FCloudCluster fCluster;
	public static String node;
	public static String group = "CNODE";

	public static void main(String[] args) throws Exception {
		int port = 8090;
		node = args[0];

		if (args.length > 1) {
			port = Integer.parseInt(args[1]);
		}

		if (args.length > 2) {
			group = args[2];
		}

		// 加入到集群中
//		fCluster = FCloudCluster.joinAsMember(node, "CNODE");
		new NettyHttpServer(port).run();
	}
}
