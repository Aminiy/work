package com.vin.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.QueryStringDecoder;
import io.netty.handler.codec.http.multipart.HttpPostRequestDecoder;
import io.netty.handler.codec.http.multipart.InterfaceHttpData;
import io.netty.handler.codec.http.multipart.InterfaceHttpData.HttpDataType;
import io.netty.handler.codec.http.multipart.MixedAttribute;

//import play.mvc.Http;

/**
 * Created with IntelliJ IDEA. User: srp Date: 14-6-25 Time: 下午5:06
 */

public final class ProcessorUtils {
//	private static final Logger logger = LoggerFactory.getLogger(ProcessorUtils.class);
//	private static ZkClusterQuarantine zk = ZkClusterQuarantine.getInstance("/quarantine", APIConfig.zkaddr);
	
    public static Map<String, List<String>> getGetDataValue(
        QueryStringDecoder decoder, List<ArgOption> bodyArgs)
        throws Exception {
        Map<String, List<String>> args = new HashMap<String, List<String>>(bodyArgs.size());
        for (final ArgOption bodyArgOption : bodyArgs) {
            addGetBody(decoder, args, bodyArgOption);
        }
        return args;
    }

    public static void addGetBody(QueryStringDecoder decoder,
        Map<String, List<String>> args, final ArgOption bodyArgOption)
        throws Exception {
        List<String> value = getOneGetParameter(decoder,
            bodyArgOption.getName());
        if ((bodyArgOption.getType() == ArgType.REQUIRED) && (value == null)) {
            throw new Exception(bodyArgOption.getName()
                + " is required.");
        }
        args.put(bodyArgOption.getName(), value);
    }

    public static List<String> getOneGetParameter(QueryStringDecoder decoder,
        String key) {
        List<String> lst = decoder.parameters().get(key);
        if (lst != null && lst.size() > 0) {
            return lst;
        } else {
            return null;
        }
    }

    public static String getQueryStringValue(QueryStringDecoder decoder,
        String key) {
        String value = "";
        List<String> lst = decoder.parameters().get(key);
        if (lst != null && lst.size() > 0) {
            value = lst.get(0);
        }
        return value;
    }

    public static Map<String, String> getPostDataValue(
        HttpPostRequestDecoder decoder, List<ArgOption> bodyArgs)
        throws Exception {
        Map<String, String> args = new HashMap<String, String>(bodyArgs.size());
        for (final ArgOption bodyArgOption : bodyArgs) {
            addPostBody(decoder, args, bodyArgOption);
        }
        return args;
    }

    public static void addPostBody(HttpPostRequestDecoder decoder,
        Map<String, String> args, final ArgOption bodyArgOption)
        throws Exception {
        String value = getOnePostParameter(decoder,
            bodyArgOption.getName());
        if ((bodyArgOption.getType() == ArgType.REQUIRED) && (value == null)) {
            throw new Exception(bodyArgOption.getName()
                + " is required.");
        }
        args.put(bodyArgOption.getName(), value);
    }

    public static String getOnePostParameter(HttpPostRequestDecoder decoder,
        final String key) {
        String value = null;
        List<InterfaceHttpData> lst = decoder.getBodyHttpDatas(key);
        if (lst != null && lst.size() > 0) {
            if (lst.get(0).getHttpDataType() == HttpDataType.Attribute) {
                MixedAttribute attribute = (MixedAttribute) lst.get(0);
                try {
                    value = attribute.getValue();
                } catch (IOException e) {
                    return null;
                }
            }
        }
        return value;
    }

    public static Map<String, String> getHeadersValue(
        FullHttpRequest request, List<ArgOption> headerArgOptions)
        throws Exception {
        Map<String, String> args = new HashMap<String, String>(headerArgOptions.size());
        for (final ArgOption headerArgOption : headerArgOptions) {
            addHeader(request, args, headerArgOption);
        }
        return args;
    }

    public static void addHeader(FullHttpRequest request,
        final Map<String, String> header, final ArgOption headerArgOption)
        throws Exception {
        String value = request.headers().get(headerArgOption.getName());
        if ((headerArgOption.getType() == ArgType.REQUIRED) && (value == null)) {
            throw new Exception(headerArgOption.getName()
                + " is required.");
        }
        header.put(headerArgOption.getName(), value);
    }
    
//	public static AppInfo validationSignature(String nonce, String timestamp, String signature, long appId)
//			throws APIException, ParamException, RCSignatureException {
//		AppInfo appInfo = AppInfoCacheUtil.getAppInfo(appId, false);
//		if (appInfo == null) {
//			throw new APPException("App-Key is not exist.");
//		}
//		String secret = appInfo.getAppSecret();
//		StringBuilder toSign = new StringBuilder(secret).append(nonce).append(timestamp);
//		String sign = CodecNCrypto.hexSHA1(toSign.toString());
//		if (!StringUtils.equalsIgnoreCase(sign, signature)) {
//			appInfo = AppInfoCacheUtil.getAppInfo(appId, true);
//			StringBuilder toSign1 = new StringBuilder(appInfo.getAppSecret()).append(nonce).append(timestamp);
//			if (!StringUtils.equalsIgnoreCase(CodecNCrypto.hexSHA1(toSign1.toString()), signature)) {
//				throw new RCSignatureException("check signature failed.");
//			}
//		}
//
//		if (appInfo.getState().equals(AppState.DELETED) || appInfo.getState().equals(AppState.BLOCKED)) {
//			logger.info(appId + "_validationSignature: App-Key is blocked/deleted");
//			throw new ParamException("App-Key is blocked/deleted.");
//		}
//
//		return appInfo;
//	}
    
//	public static String getMethod(long appId, String method) {
//		String method1 = zk.checkQuarantineMethod(appId, method);
//		if (!StringUtils.isEmpty(method1)) {
//			return method1;
//		}
//		return method;
//	}
	 
}
