//package com.vin.posthandler;
//
//import java.io.IOException;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.concurrent.TimeUnit;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import io.netty.channel.ChannelHandlerContext;
//import io.netty.handler.codec.http.FullHttpRequest;
//import io.netty.handler.codec.http.multipart.HttpDataFactory;
//import io.netty.handler.codec.http.multipart.HttpPostRequestDecoder;
//import io.netty.handler.codec.http.multipart.InterfaceHttpData;
//import io.netty.handler.codec.http.multipart.MixedAttribute;
//
///**
// * RTC 房间信息查询
// * 
// * @author mazhanghui
// *
// */
//public class RoomQuery implements Processor {
//	private static final Logger LOGGER = LoggerFactory.getLogger(RoomQuery.class);
//
//	private static final List<ArgOption> HEADER_ARG_OPTIONs = Arrays.asList(new ArgOption("App-Key", false),
//			new ArgOption("AppKey", false), new ArgOption("Nonce", true), new ArgOption("Timestamp", true),
//			new ArgOption("Signature", true));
//
//	@Override
//	public Output process(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
//			throws APIException {
//		LOGGER.info("========>> incomming post request RoomQuery - process.");
//		return new Output();
//	}
//
//	
//	@Override
//	public void processRequest(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
//			throws APIException {
//		LOGGER.info("========>> incomming post request RoomQuery - processRequest.");
//
//		final Map<String, String> headers = new HashMap<>(HEADER_ARG_OPTIONs.size());
//		for (ArgOption t : HEADER_ARG_OPTIONs) {
//			ProcessorUtils.addHeader(request, headers, t);
//		}
//
//		String appKey = headers.get("App-Key") == null ? headers.get("AppKey") : headers.get("App-Key");
//		String nonce = headers.get("Nonce");
//		String timestamp = headers.get("Timestamp");
//		String signature = headers.get("Signature");
//
//		HttpPostRequestDecoder decoder = new HttpPostRequestDecoder(factory, request);
//		InterfaceHttpData roomIdData = decoder.getBodyHttpData("roomId");
//		InterfaceHttpData userIdData = decoder.getBodyHttpData("userId");
//		
//		MixedAttribute attrRoomId = (MixedAttribute) roomIdData;
//		MixedAttribute attrUserId = (MixedAttribute) userIdData;
//		String roomId = "";
//		String userId = "";
//
//		if (attrRoomId == null) {
//			decoder.destroy();
//			RtcApiUtil.sendHttpResponse(ctx.channel(), "roomId is required", "json");
//			throw new ParameterException("body parameter: roomId is required.");
//		} else {
//			try {
//				roomId = attrRoomId.getValue();
//				userId = attrUserId.getValue();
//			} catch (IOException e) {
//				decoder.destroy();
//				RtcApiUtil.sendHttpResponse(ctx.channel(), "Server internal error", "json");
//				LOGGER.error("parse roomId,userId parameter exception=" + e.getMessage(), e);
//			}
//		}
//
//		// 验签
//		long appId = AppIdMapper.string2long(appKey);
//		ProcessorUtils.validationSignature(nonce, timestamp, signature, appId);
//
//		// 发送查询信令请求到 IMSignal - akka
//		String responseBody = "";
//		Object[] result = new Object[] {};
//		try {
//			result = sendToAkkaSignal(appId, roomId, userId);
//			responseBody = (String)result [0];
//		} catch (Exception e) {
//			e.printStackTrace();
//			LOGGER.error("send to signal get exception=" + e.getMessage(), e);
//			responseBody = e.getMessage() != null ? e.getMessage() : "Server intenal error.";
//		}
//
//		// 收到IMSignal应答后，返回应答
//		RtcApiUtil.sendHttpResponse(ctx.channel(), responseBody, "json");
//	}
//	
//	private static Object[] sendToAkkaSignal(Long appId, String roomId, String userId) throws Exception {
//		Object[] result = new Object[] {};
//		// SSRequest -> onmessage
//		SSRequest request = new SSRequest();
//		request.setAppId(appId);
//		request.setMethod("rtcQueryRoomData");
//		request.setAppMessage(new Object[] { appId, roomId, userId});
//		request.setTargetResourceId(roomId);
//
//		String nodeAddr = Bootstrap.fCluster.getZkClusterSites()
//				.findNodeForClusterNMethodNResource(FCloudCluster.fCluster.getClusterName(), "rtcQueryRoomData", roomId)
//				.getAkkaAddr();
//
//		Future<Object> f = Patterns.ask(FCloudCluster.fCluster.getActorSystem().actorSelection(nodeAddr),
//				RouteMessage.wrap(request), 5000);
//		result = (Object[]) Await.result(f, Duration.create(5, TimeUnit.SECONDS));
//		
//		return result;
//
////		CSQueryAck ack = (CSQueryAck) Await.result(f, Duration.create(5, TimeUnit.SECONDS));
////		Bootstrap.cluster.routeMessage(RouteMessage.wrap(request), ActorRef.noSender());
////		FCloudCluster.fCluster.routeMessage(RouteMessage.wrap(request), ActorRef.noSender());
//	}
//
////	private static Object[] sendToAkkaSignal_CSMessage(Long appId, String token, String roomId) throws Exception {
////		Object[] result = new Object[] {};
////		// CSMessage -> onAppMessage
////		CSMessage request = new CSMessage();
////		request.setAppId(appId);
////		request.setMethod("rtcRInfo");// rtcQueryRoomData rtcRInfo
////		request.setAppMessage(new Object[] { appId, token, roomId });
////		request.setTargetResourceId(roomId);
////
////		String nodeAddr = Bootstrap.fCluster.getZkClusterSites()
////				.findNodeForClusterNMethodNResource(Bootstrap.fCluster.getClusterName(), "rtcRInfo", roomId)
////				.getAkkaAddr();
////
////		LOGGER.info("========>> nodeAddr=" + nodeAddr);
////
////		Future<Object> f = Patterns.ask(FCloudCluster.fCluster.getActorSystem().actorSelection(nodeAddr),
////				RouteMessage.wrap(request), 5000);
////		result = (Object[]) Await.result(f, Duration.create(5, TimeUnit.SECONDS));
////		return result;
////	}
//
//	// api - play 方式 - 不推荐使用
////	private static Object[] sendToAkkaSignal_Play(Long appId, String token, String roomId) throws Exception {
////		Object[] result = new Object[] {};
////
////		String method = ProcessorUtils.getMethod(appId, "rtcRInfo");
////		String clusterName = AppClusterMapper.getClusterOfApp(appId);
////		ActorRef ar = ApiUtils.getApiActor(clusterName);
////		SSRequest msg = new SSRequest();
////		msg.setAppMessage(new Object[] { appId, token, roomId });
////		msg.setAppId(appId);
////		msg.setMethod(method);
////		msg.setTargetResourceId(String.valueOf(roomId));
////		Future<Object> f = Patterns.ask(ar, RouteMessage.wrap(msg), 5000);
////		try {
////			// 此处signal返回值是什么呢 ？
////			result = (Object[]) Await.result(f, Duration.create(5, TimeUnit.SECONDS));
////		} catch (Exception e) {
////			LOGGER.error("rtc room info query ,result=" + result + ",appId=" + appId + ",roomId=" + roomId,
////					e.getMessage());
////			throw new Exception();
////		}
////
////		return result;
////	}
//
//
//	/**
//	 * 设置聊天室消息回填
//	 */
////    public static void loadMsgFromHistory(long appId, String chatroomId, String logId) {
////        try {
////            byte[] bytes = new byte[0];
////            Modules.HistoryMsgInput.Builder builder = Modules.HistoryMsgInput.newBuilder();
////
////            builder.setCount(150);
////            builder.setOrder(0);
////            builder.setTargetId(chatroomId);
////            builder.setTime(0);
////            bytes = builder.build().toByteArray();
////
////            SSRequest;
////            // onappmessage
////            CSMessage query = new CSMessage();
////            query.setAppMessage(bytes);
////
////            query.setAppId(appId);
////            query.setMethod("qryCHMsg");
////            query.setRequesterId(chatroomId);
////            query.setTargetResourceId(chatroomId);
////            query.setPackageName(logId);
////            query.setClientOs("CTRMM");
////            query.setDeviceId(MonitorClientManager.NODEID);
////            query.setProtocolVersion("2.5");
////            query.setSdkVersion("0.0.1");
////            query.setConnectedTerminalCount(1);
////            query.setQosFlags(0);
////            query.setSendTime(System.currentTimeMillis());
////            String returnMethod = "excuteQryCHMsgAck";
////            //处理专属
//////            String exclusiveId = Environments.getExclusiveId();
//////            if (!StringUtil.isEmpty(exclusiveId) && !exclusiveId.equals("0")){
//////                returnMethod += "_" + exclusiveId;
//////            }
////            String node = Bootstrap.cluster.routeMessage(RouteMessage.wrap(query), returnMethod);
////        } catch (Exception e) {
////            LOGGER.error("[queryMsgFromHistory]geturl error.", e);
////        }
////
////    }
//
//}
