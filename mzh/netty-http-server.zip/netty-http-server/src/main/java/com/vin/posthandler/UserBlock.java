//package com.vin.posthandler;
//
//import java.io.IOException;
//import java.io.UnsupportedEncodingException;
//import java.net.InetSocketAddress;
//import java.net.SocketAddress;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.concurrent.TimeUnit;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import com.vin.config.Processor;
//import com.vin.output.Output;
//import com.vin.util.ArgOption;
//import com.vin.util.ProcessorUtils;
//
//import io.netty.bootstrap.Bootstrap;
//import io.netty.buffer.Unpooled;
//import io.netty.channel.ChannelFutureListener;
//import io.netty.channel.ChannelHandlerContext;
//import io.netty.channel.ChannelInitializer;
//import io.netty.channel.ChannelOption;
//import io.netty.channel.EventLoopGroup;
//import io.netty.channel.nio.NioEventLoopGroup;
//import io.netty.channel.socket.SocketChannel;
//import io.netty.channel.socket.nio.NioSocketChannel;
//import io.netty.handler.codec.http.DefaultFullHttpRequest;
//import io.netty.handler.codec.http.FullHttpRequest;
//import io.netty.handler.codec.http.HttpHeaders;
//import io.netty.handler.codec.http.HttpMethod;
//import io.netty.handler.codec.http.HttpObjectAggregator;
//import io.netty.handler.codec.http.HttpRequestEncoder;
//import io.netty.handler.codec.http.HttpResponseDecoder;
//import io.netty.handler.codec.http.HttpVersion;
//import io.netty.handler.codec.http.multipart.HttpDataFactory;
//import io.netty.handler.codec.http.multipart.HttpPostRequestDecoder;
//import io.netty.handler.codec.http.multipart.InterfaceHttpData;
//import io.netty.handler.codec.http.multipart.MixedAttribute;
//import io.netty.handler.timeout.ReadTimeoutHandler;
//
///**
// * RTC 封禁用户接口
// * 
// * 功能点: 1: 将用户按 roomId 封禁; 2: 全局封禁该用户
// * 
// * @author mazhanghui
// *
// */
//public class UserBlock implements Processor {
//
//	private static final Logger LOGGER = LoggerFactory.getLogger(UserBlock.class);
//
//	private static final List<ArgOption> HEADER_ARG_OPTIONs = Arrays.asList(new ArgOption("App-Key", false),
//			new ArgOption("AppKey", false), new ArgOption("Nonce", true), new ArgOption("Timestamp", true),
//			new ArgOption("Signature", true));
//
//	@Override
//	public Output process(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
//			throws APIException {
//		LOGGER.info("========>> incomming post request UserBlock.");
//
//		// 取 Header 和 Body 数据
//		final Map<String, String> headers = new HashMap<String, String>(HEADER_ARG_OPTIONs.size());
//		for (ArgOption t : HEADER_ARG_OPTIONs) {
//			ProcessorUtils.addHeader(request, headers, t);
//		}
//
//		String appKey = headers.get("App-Key") == null ? headers.get("AppKey") : headers.get("App-Key");
//		String nonce = headers.get("Nonce");
//		String timestamp = headers.get("Timestamp");
//		String signature = headers.get("Signature");
//
//		HttpPostRequestDecoder decoder = new HttpPostRequestDecoder(factory, request);
//		InterfaceHttpData roomIdData = decoder.getBodyHttpData("roomId");
//		InterfaceHttpData userIdData = decoder.getBodyHttpData("userId");
//		InterfaceHttpData blockTypeData = decoder.getBodyHttpData("blockType");
//		InterfaceHttpData minuteData = decoder.getBodyHttpData("minute");
//
//		MixedAttribute attrRoomId = (MixedAttribute) roomIdData;// 全局封禁无此参数
//		MixedAttribute attrUserId = (MixedAttribute) userIdData;
//		MixedAttribute attrblockType = (MixedAttribute) blockTypeData;
//		MixedAttribute attrMinute = (MixedAttribute) minuteData;
//
//		int minute = 0;
//		int blockType = 0;
//		String roomId = "";
//		String userId = "";
//
//		if (attrUserId == null || attrblockType == null || attrMinute == null) {
//			decoder.destroy();
//			throw new Exception("body parameter: roomId,userId,blockType,minute is required.");
//		} else {
//			try {
//				if (attrRoomId != null) {
//					roomId = attrRoomId.getValue();
//				}
//
//				userId = attrUserId.getValue();
//				blockType = Integer.parseInt(attrblockType.getValue());
//				minute = Integer.parseInt(attrMinute.getValue());
//			} catch (IOException e) {
//				decoder.destroy();
//				throw new Exception("parse body parameter exception.");
//			}
//		}
//
//		Output output = new Output();
//		output.setDesc("ok");
//
//		// 验签
//		long appId = 0;
//		
//		// 发送封禁请求到 IMSignal - akka
//		int code = -1;
//		try {
//			String mediaServerAddr = "";
//
//			Object[] result = sendToAkkaSignal(appId, roomId, userId, blockType, minute);
//
//			if (result != null && result.length == 1) {
//				output.setCode((int) result[0]);
//				LOGGER.info("========>> UserBlock received response from signal code:" + result[0]);
//				return output;
//			}
//
//			if (result != null && result.length == 3) {
//				code = (int) result[0];
//				mediaServerAddr = (String) result[1];
//			}
//
//			if (!StringUtil.isEmpty(mediaServerAddr)) {
//				String ip = mediaServerAddr.split(":")[0];
//				int port = Integer.valueOf(mediaServerAddr.split(":")[1]);
//
//				try {
//					
//					JsonObject gson = new JsonObject();
//					gson.addProperty("userId", userId);
//					gson.addProperty("minute", minute);
//					gson.addProperty("blockType", blockType);
//					
//					if (!StringUtil.isEmpty(roomId)) {
//						gson.addProperty("roomId", roomId);
//					}
//					
//					FullHttpRequest httpRequest = new DefaultFullHttpRequest(HttpVersion.HTTP_1_1, HttpMethod.POST,
//							"/rtc/user/block",
//							Unpooled.wrappedBuffer(gson.toString().getBytes("UTF-8")));
//
//					// 将请求中的 Header 添加到被用来转发的新构造出来的 http request 中
//					for (Map.Entry<String, String> entry : headers.entrySet()) {
//						if (entry.getValue() != null) {
//							httpRequest.headers().set(entry.getKey(), entry.getValue());
//						}
//					}
//
//					httpRequest.headers().set(HttpHeaders.Names.CONNECTION, HttpHeaders.Values.KEEP_ALIVE);
//					httpRequest.headers().set(HttpHeaders.Names.CONTENT_LENGTH, httpRequest.content().readableBytes());
//					httpRequest.headers().set(HttpHeaders.Names.CONTENT_TYPE, "application/json");
//					httpRequest.headers().set("Token", token);
//					httpRequest.headers().set("RoomId", roomId);
//					httpRequest.headers().set("RoomType", 1);// 1:音视频; 2:直播
//
//					sendPostRequest(ctx, httpRequest, new InetSocketAddress(ip, port));
//
//				} catch (UnsupportedEncodingException e) {
//					e.printStackTrace();
//					LOGGER.error("----netty send http request UnsupportedEncodingException:" + e.getMessage(), e);
//					output.setCode(500);
//					output.setDesc("Server internal exception.");
//				}
//			} else {
//				LOGGER.error("----UserBlock mediaServerAddr from signal is null");
//			}
//
//		} catch (Exception e1) {
//			e1.printStackTrace();
//			code = 500;
//			LOGGER.error("----netty send akka request signal Exception:" + e1.getMessage() + ",appId=" + appId
//					+ ",roomgId=" + roomId + ",userId=" + userId, e1);
//		}
//
//		// 封禁，不需要等 mediaServer 应答，依据 Signal 应答结果返回即可
//		output.setCode(code);
//		return output;
//	}
//
//	/**
//	 * 发送请求到 rtc.signal
//	 * 
//	 * @param appId
//	 * @param roomId    封禁类型为 2 全局封禁时，此参数为空
//	 * @param userId
//	 * @param blockType 1: 按房间roomId 封禁用户, 2: 全局封禁用户
//	 * @param minutes   封禁时长（分钟）
//	 * @return
//	 * @throws Exception
//	 */
//	private static Object[] sendToAkkaSignal(Long appId, String roomId, String userId, int blockType, int minutes)
//			throws Exception {
//		Object[] result = new Object[] {};
//		
//		SSRequest request = new SSRequest();
//		request.setAppId(appId);
//		request.setMethod("rtcUserBlock");// rtcQueryRoomData rtcRInfo,
//		request.setAppMessage(new Object[] { appId, userId, roomId, blockType, minutes });
//		if(blockType == 2) {
//			// 全局封禁按 userId 路由
//			request.setTargetResourceId(userId);
//		} else {
//			// 房间封禁按 roomId 路由
//			request.setTargetResourceId(roomId);
//		}
//		
//		String nodeAddr = com.rcloud.api.rtc.bootstrap.Bootstrap.fCluster.getZkClusterSites()
//				.findNodeForClusterNMethodNResource(com.rcloud.api.rtc.bootstrap.Bootstrap.fCluster.getClusterName(),
//						"rtcUserBlock", userId)
//				.getAkkaAddr();
//
//		try {
//			Future<Object> f = Patterns.ask(
//					com.rcloud.api.rtc.bootstrap.Bootstrap.fCluster.getActorSystem().actorSelection(nodeAddr),
//					RouteMessage.wrap(request), 5000);
//			result = (Object[]) Await.result(f, Duration.create(5, TimeUnit.SECONDS));
//		} catch (Exception e) {
//			e.printStackTrace();
//			LOGGER.error("appId=" + appId + ",userId=" + userId + ",roomId=" + roomId
//					+ "========>> request to rtc.Signal exception ===" + e.getMessage(), e);
//		}
//
//		return result;
//	}
//
//	private void sendPostRequest(ChannelHandlerContext ctx, FullHttpRequest request, SocketAddress address) {
//		Bootstrap b = new Bootstrap();
//		EventLoopGroup workerGroup = new NioEventLoopGroup(1);
//		b.group(workerGroup).channel(NioSocketChannel.class).option(ChannelOption.SO_KEEPALIVE, true)
//				.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000).handler(new ChannelInitializer<SocketChannel>() {
//					@Override
//					public void initChannel(SocketChannel ch) {
//						ch.pipeline().addLast(new ReadTimeoutHandler(10)).addLast(new HttpResponseDecoder())
//								.addLast(new HttpObjectAggregator(1024 * 1024 * 1024))
//								.addLast(new HttpRequestEncoder());
//					}
//				});
//
//		b.connect(address).addListener((ChannelFutureListener) future -> {
//			if (!future.isSuccess()) {
//				// 连接失败
//				LOGGER.info("---sendPostRequest--connect--failed");
//				return;
//			} else {
////				LOGGER.info("---sendPostRequest--connect--success");
//			}
//
//			future.channel().writeAndFlush(request).addListener(channelFuture -> {
//				if (!channelFuture.isSuccess()) {
//					// 发送数据失败
//					LOGGER.error("---sendPostRequest writeAndFlush error.");
//				} else {
////					LOGGER.info("---sendPostRequest writeAndFlush success.");
//				}
//			});
//		});
//	}
//	
//	@Override
//	public void processRequest(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
//			throws APIException {
//		LOGGER.info("---UserBlock received request, but do nothing ----");
//		
//		RtcApiUtil.sendHttpResponse(ctx.channel(), "received request, but do nothing", "json");
//	}
//}
