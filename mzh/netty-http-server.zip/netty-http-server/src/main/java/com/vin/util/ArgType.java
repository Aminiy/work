package com.vin.util;

public enum ArgType {
	OPTIONAL, REQUIRED
}