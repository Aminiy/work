//package com.vin.exception;
//
//import com.rcloud.error.APIException;
//import com.rcloud.error.AppError;
//
//public class RtcException extends APIException {
//
//	private static final long serialVersionUID = -7116036147729341504L;
//
//	public RtcException(int code, String url, String message) {
//		super(message);
//		this.error = new com.rcloud.error.Error(code, code, url, message);
//	}
//
//	public RtcException(String message) {
//		super(message);
//		this.error = new AppError("/", message);
//	}
//
//	@Override
//	public Throwable fillInStackTrace() {
//		return this;
//	}
//}
