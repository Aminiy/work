package com.vin.config;

import java.util.HashMap;

public class RouteUrlConfig {

	public static HashMap<String, String> postUrlMaps = new HashMap<String, String>();
	public static HashMap<String, String> AsyPostUrlMaps = new HashMap<String, String>();
	public static HashMap<String, String> getUrlMaps = new HashMap<String, String>();

	static {
		// 同步处理回应答
		postUrlMaps.put("/testrtc", "com.rcloud.api.rtc.postprocessor.TestRtx");
		postUrlMaps.put("/rtc/user/block", "com.rcloud.api.rtc.postprocessor.UserBlock");
		postUrlMaps.put("/rtc/user/unblock", "com.rcloud.api.rtc.postprocessor.UserUnBlock");
		postUrlMaps.put("/rtc/room/join", "com.rcloud.api.rtc.postprocessor.UserJoinRoom");
		postUrlMaps.put("/rtc/ping2", "com.rcloud.api.rtc.postprocessor.Ping");

		// 异步回应答
		AsyPostUrlMaps.put("/rtc/record/start", "com.rcloud.api.rtc.postprocessor.RecordStart");
		AsyPostUrlMaps.put("/rtc/record/stop", "com.rcloud.api.rtc.postprocessor.RecordStop");
		AsyPostUrlMaps.put("/rtc/room/query", "com.rcloud.api.rtc.postprocessor.RoomQuery");
		
//		postUrlMaps.put("/navi", "com.rcloud.api.rtc.postprocessor.Navi");

		// http get method
//		getUrlMaps.put("/navi", "com.rcloud.api.rtc.getprocessor.Navi");
//		getUrlMaps.put("/cometnavi", "com.rcloud.api.rtc.getprocessor.CometNavi");
//		getUrlMaps.put("/ping", "com.rcloud.api.rtc.getprocessor.Ping");
	}
}
