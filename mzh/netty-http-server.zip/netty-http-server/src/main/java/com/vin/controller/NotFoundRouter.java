package com.vin.controller;

//import play.mvc.Controller;
//import play.mvc.SimpleResult;
//import com.rcloud.error.Error;

/**
 * Created with IntelliJ IDEA. User: srp Date: 14-3-19 Time: 涓婂崍10:59
 */
public class NotFoundRouter {

}
/*
public class NotFoundRouter  extends Controller{

    public static SimpleResult error(){
        Error error = new Error(404,404,request().uri(),"Not a valid API.");
        if (request().uri().contains("xml")){
            return notFound(error.toXML());
        }
        return notFound(error.toJsonObject());
    }
}
*/
