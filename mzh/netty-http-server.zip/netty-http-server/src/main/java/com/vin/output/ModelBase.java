package com.vin.output;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created with IntelliJ IDEA. User: srp Date: 14-3-18 Time: 上午10:29
 */
public abstract class ModelBase {

	protected static transient ObjectMapper mapper = new ObjectMapper();
	protected transient Logger logger = LoggerFactory.getLogger(this.getClass());

	public String toString() {
		try {
			return mapper.writeValueAsString(this);
		} catch (JsonProcessingException e) {
			return "";
		}
	}
}
