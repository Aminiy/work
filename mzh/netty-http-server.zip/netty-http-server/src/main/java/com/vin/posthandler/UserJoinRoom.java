//package com.vin.posthandler;
//
//import java.io.IOException;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.concurrent.TimeUnit;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import com.vin.config.Processor;
//import com.vin.output.Output;
//import com.vin.util.ArgOption;
//import com.vin.util.ProcessorUtils;
//import com.vin.util.RtcApiUtil;
//
//import io.netty.channel.ChannelHandlerContext;
//import io.netty.handler.codec.http.FullHttpRequest;
//import io.netty.handler.codec.http.multipart.HttpDataFactory;
//import io.netty.handler.codec.http.multipart.HttpPostRequestDecoder;
//import io.netty.handler.codec.http.multipart.InterfaceHttpData;
//import io.netty.handler.codec.http.multipart.MixedAttribute;
//
///**
// * 开发过程中的辅助测试的接口
// * 
// * @author mazhanghui
// */
//public class UserJoinRoom implements Processor {
//
//	private static final Logger LOGGER = LoggerFactory.getLogger(UserBlock.class);
//
//	private static final List<ArgOption> HEADER_ARG_OPTIONs = Arrays.asList(new ArgOption("App-Key", false),
//			new ArgOption("AppKey", false), new ArgOption("Nonce", true), new ArgOption("Timestamp", true),
//			new ArgOption("Signature", true));
//
//	@Override
//	public Output process(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
//			throws APIException {
//		LOGGER.info("========>> incomming post request UserJoinRoom.");
//
//		// 取 Header 和 Body 数据
//		final Map<String, String> headers = new HashMap<String, String>(HEADER_ARG_OPTIONs.size());
//		for (ArgOption t : HEADER_ARG_OPTIONs) {
//			ProcessorUtils.addHeader(request, headers, t);
//		}
//
//		String appKey = headers.get("App-Key") == null ? headers.get("AppKey") : headers.get("App-Key");
//		String nonce = headers.get("Nonce");
//		String timestamp = headers.get("Timestamp");
//		String signature = headers.get("Signature");
//		String token = headers.get("Token");// 混合云校验用
//
//		HttpPostRequestDecoder decoder = new HttpPostRequestDecoder(factory, request);
//		InterfaceHttpData roomIdData = decoder.getBodyHttpData("roomId");
//		InterfaceHttpData userIdData = decoder.getBodyHttpData("userId");
//		InterfaceHttpData userNameData = decoder.getBodyHttpData("userName");
//		MixedAttribute attrRoomId = (MixedAttribute) roomIdData;// 全局封禁无此参数
//		MixedAttribute attrUserId = (MixedAttribute) userIdData;
//		MixedAttribute attrUserName = (MixedAttribute) userNameData;
//		String roomId = "";
//		String userId = "";
//		String userName = "";
//		
//		if (attrRoomId == null || attrUserId == null || attrUserName == null) {
//			decoder.destroy();
//			throw new ParameterException("body parameter: roomId,userId,userName is required.");
//		} else {
//			try {
//				roomId = attrRoomId.getValue();
//				userId = attrUserId.getValue();
//				userName = attrUserName.getValue();
//				
//			} catch (IOException e) {
//				decoder.destroy();
//				throw new ParameterException("parse body parameter exception.");
//			}
//		}
//
//		Output output = new Output();
//		output.setDesc("ok");
//
//		// 验签
//		long appId = 0;
//
//		// TODO 发送封禁请求到 IMSignal - akka
//		int code = -1;
//		try {
//			Object[] result = sendToAkkaSignal(appId, roomId, userId, userName);
//
//			if (result != null) {
//				code = (int)result[0];
//			}
//
//			LOGGER.info("========>> UserJoinRoom received response, result length=" + result.length + ",code=" + code);
//		} catch (Exception e1) {
//			e1.printStackTrace();
//			LOGGER.error("---- send request to akka signal Exception:" + e1.getMessage() + ",appId=" + appId
//					+ ",token=" + token + ",roomgId=" + roomId + ",userId=" + userId, e1);
//			code = 500;
//		}
//
//		output.setCode(code);
//		return output;
//	}
//
//	@Override
//	public void processRequest(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
//			throws APIException {
//		
//		RtcApiUtil.sendHttpResponse(ctx.channel(), "TODO", "json");
//	}
//	
//	
//	/**
//	 * 发送请求到 rtc.signal
//	 * 
//	 * @param appId
//	 * @param roomId 封禁类型为 2 全局封禁时，此参数为空
//	 * @param userId
//	 * 
//	 * @return
//	 * @throws Exception
//	 */
////	private static Object[] sendToAkkaSignal(Long appId, String roomId, String userId, String userName)
////			throws Exception {
////		Object[] result = new Object[] {};
////		
////		SSRequest request = new SSRequest();
////		request.setAppId(appId);
////		request.setMethod("userJoinRoom");
////		request.setAppMessage(new Object[] { appId, userId, roomId, userName });
////		request.setTargetResourceId(roomId);
////
////		String nodeAddr = com.rcloud.api.rtc.bootstrap.Bootstrap.fCluster.getZkClusterSites()
////				.findNodeForClusterNMethodNResource(com.rcloud.api.rtc.bootstrap.Bootstrap.fCluster.getClusterName(),
////						"userJoinRoom", roomId)
////				.getAkkaAddr();
////
////		LOGGER.info("=====>> Signal nodeAddr=" + nodeAddr);
////
////		try {
////			Future<Object> f = Patterns.ask(
////					com.rcloud.api.rtc.bootstrap.Bootstrap.fCluster.getActorSystem().actorSelection(nodeAddr),
////					RouteMessage.wrap(request), 5000);
////
////			result = (Object[]) Await.result(f, Duration.create(5, TimeUnit.SECONDS));
////		} catch (Exception e) {
////			e.printStackTrace();
////			LOGGER.error("appId=" + appId + ",userId=" + userId + ",roomId=" + roomId
////					+ "========>> request to rtc.Signal exception ===" + e.getMessage(), e);
////		}
////
////		return result;
////	}
//
//}
