package com.vin.output;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("result")
//public abstract class Output extends ModelBase {
public class Output extends ModelBase {

	protected int code = 200;
	protected String desc= "";
	
	@JsonIgnore
	private String callBack;

	@JsonIgnore
	public String getCallBack() {
		return callBack;
	}

	@JsonIgnore
	public void setCallBack(String call) {
		this.callBack = call;
	}

	public String toJson() {
		return toString();
	}

	public String toXML() {
		XStream xstream = new XStream();
		xstream.processAnnotations(this.getClass());
		return xstream.toXML(this);
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	
}
