package com.vin.config;

import com.vin.output.Output;

import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.multipart.HttpDataFactory;

public interface Processor {

	/**
	 * 同步方法，请求分发处统一处理应答给调用者
	 * 
	 * @param ctx
	 * @param request
	 * @param factory
	 * @return
	 * @throws APIException
	 */
	Output process(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory) throws Exception;
	
	/**
	 * 该接口需要 Handler 里自己返回应答给调用者
	 * 
	 * @param ctx
	 * @param request
	 * @param factory
	 * @throws APIException
	 */
	void processRequest(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory) throws Exception;
}
