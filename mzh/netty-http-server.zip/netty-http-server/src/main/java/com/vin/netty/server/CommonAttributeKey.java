package com.vin.netty.server;

import io.netty.util.AttributeKey;

public class CommonAttributeKey {

    @SuppressWarnings("deprecation")
    public static final AttributeKey<Long> CREATE_SESSON_TIME = new AttributeKey<>(
        "STATE.create_session_time");

    @SuppressWarnings("deprecation")
    public static final AttributeKey<Long> RECEIVE_HTTP_REQUEST_TIME = new AttributeKey<>(
        "STATE.receive_http_time");
}
