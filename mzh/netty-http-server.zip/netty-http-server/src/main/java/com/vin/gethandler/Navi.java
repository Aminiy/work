package com.vin.gethandler;
//package com.rcloud.api.rtc.getprocessor;
//
//import com.rcloud.api.models.app.AppState;
//import com.rcloud.api.rtc.Processor;
//import com.rcloud.api.rtc.exception.RtcException;
//import com.rcloud.api.rtc.io.NaviDarkInfo;
//import com.rcloud.api.rtc.io.NaviInfoJsOutput;
//import com.rcloud.api.rtc.io.NaviPushDarkInfo;
//import com.rcloud.api.rtc.io.Output;
//import com.rcloud.api.rtc.model.StandAloneNaviApConfig;
//import com.rcloud.api.rtc.util.APIConfig;
//import com.rcloud.api.rtc.util.APManager;
//import com.rcloud.api.rtc.util.AppInfoCacheUtil;
//import com.rcloud.api.rtc.util.MultiCMPUtil;
//import com.rcloud.api.rtc.util.NaviMapper;
//import com.rcloud.api.rtc.util.NaviType;
//import com.rcloud.api.rtc.util.StandAloneNaviMapper;
//import com.rcloud.api.rtc.util.UserAgentUtil;
//import com.rcloud.api.rtc.util.AppInfoCacheUtil.NaviAppInfo;
//import com.rcloud.api.token.Token;
//import com.rcloud.error.APIException;
//import com.rcloud.error.TokenException;
//import com.rcloud.utils.AppIdMapper;
//import cz.mallat.uasparser.UserAgentInfo;
//import io.netty.channel.ChannelHandlerContext;
//import io.netty.handler.codec.http.FullHttpRequest;
//import io.netty.handler.codec.http.QueryStringDecoder;
//import io.netty.handler.codec.http.multipart.HttpDataFactory;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//import java.util.Random;
//import org.apache.commons.lang.StringUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//public class Navi implements Processor {
//
//	private static final Logger LOGGER = LoggerFactory.getLogger(Navi.class);
//
//	static {
//		NaviDarkInfo.reload();
//		NaviPushDarkInfo.reload();
//	}
//
//	@Override
//	public Output process(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
//			throws APIException {
//		// 是GET请求
//		QueryStringDecoder decoder = new QueryStringDecoder(request.getUri());
//
//		List<String> tokens = decoder.parameters().get("token");
//		List<String> callBacks = decoder.parameters().get("callBack");
//		List<String> appIds = decoder.parameters().get("appId");
//		List<String> versions = decoder.parameters().get("v");
//
//		if (tokens == null || tokens.size() == 0) {
//			throw new RtcException("token parameter is required.");
//		}
//
//		if (callBacks == null || callBacks.size() == 0) {
//			throw new RtcException("callBack parameter is required.");
//		}
//
//		if (appIds == null || appIds.size() == 0) {
//			throw new RtcException("appId parameter is required.");
//		}
//
//		final long appId = AppIdMapper.string2long(appIds.get(0));
//		final String tokenString = tokens.get(0);
//
//		if (StringUtils.isBlank(tokenString) || tokenString.length() < 5) {
//			LOGGER.error("Token error,appId=" + appId);
//			throw new TokenException("Token is not exist.");
//		}
//
//		NaviAppInfo appInfo = AppInfoCacheUtil.getNaviAppInfo(appId, false);
//		// 获取全局配置
//		NaviAppInfo globalInfo = AppInfoCacheUtil.getNaviAppInfo(0l, false);
//		if (appInfo == null) {
//			throw new RtcException("AppId is not exist.");
//		}
//		if (globalInfo != null) {
//			if (null == appInfo.onlineLogServer || "".equals(appInfo.onlineLogServer)) {
//				appInfo.onlineLogServer = globalInfo.onlineLogServer;
//			}
//			if (null == appInfo.offlineLogServer || "".equals(appInfo.offlineLogServer)) {
//				appInfo.offlineLogServer = globalInfo.offlineLogServer;
//			}
//		}
//		if (appInfo.state == AppState.BLOCKED || appInfo.state == AppState.DELETED) {
//			throw new TokenException("app blocked");
//		}
//
//		Token token = null;
//		try {
//			token = Token.fromTokenString(appInfo.secureKey, tokenString);
//		} catch (TokenException e) {
//			LOGGER.error("NaviGet - Token parse error,appId={}, token={}", appId, tokenString);
//			appInfo = AppInfoCacheUtil.getNaviAppInfo(appId, true);
//			throw new TokenException("Your token is not valid.");
//		}
//
//		if (token.userId == null || token.userId.trim().length() == 0) {
//			throw new TokenException("Your token'uid is not valid.");
//		}
//
//		if (!token.appId.equals(appInfo.appKey)) {
//			throw new RtcException("AppId mismatch.");
//		}
//
//		String sdkVersion = null;
//		if (versions != null && versions.size() > 0) {
//			sdkVersion = versions.get(0);
//		}
//
//		final String userId = token.userId;
//
//		/**
//		 * 客户端IP
//		 */
//		String clientIp = MultiCMPUtil.getClientIp(ctx, request);
//		String host = MultiCMPUtil.getHost(request);
//		// 标记该用户是否使用AP点接入
//		boolean isUsedAP = false;
//		// AP点的ID
//		String CURRENT_APID = request.headers().get("REMOTE_AP_ID");
//		String remote = request.headers().get("REMOTE_ADDR");
//		String isHttps = request.headers().get("NAV_REMOTE_IS_HTTPS");
//		String userAgent = request.headers().get("User-Agent");
//		NaviInfoJsOutput output = null;
//		UserAgentInfo userAgentInfo = null;
//		if (appInfo.TokenLifespan > 0) {
//			Long tokenLifespan = appInfo.TokenLifespan;
//			if (tokenLifespan > 0 && System.currentTimeMillis() - token.tokenTime > tokenLifespan) {
//				try {
//					userAgentInfo = UserAgentUtil.uasParser.parse(userAgent);
//				} catch (IOException e) {
//					LOGGER.error("UserAgen parse error appid=" + appId + " userId=" + userId + " error=" + e);
//				}
//				MultiCMPUtil.writeMonitor(ctx, appId, clientIp, userId, sdkVersion, "ws", CURRENT_APID, true, host,
//						userAgentInfo, isHttps);
//				throw new TokenException("Your token is expired.");
//			}
//		}
//
//		output = new NaviInfoJsOutput(appInfo, userId, NaviType.NAVI.getName());
//		output.setMonitor(AppInfoCacheUtil.getSdkUploadSwtich(appInfo, "", "", userId));
//		output.setCallBack(callBacks.get(0));
//
//		if (!APManager.checkIpIsvalid(output.getServer())) {
//			LOGGER.error(
//					"can't get navi server for appid=" + appId + " userId=" + userId + " server=" + output.getServer());
//
//			if (APIConfig.getIsSupportTcpProxy()) {// 应对极端情况下，cmp 节点公网地址配置异常，无法获取对应公网地址，直接返回代理地址
//				// 默认 http
//				String globalCDNWebsocketProxy = APIConfig.getGloablCDNWebsocketProxyAddr();
//				if (isHttps != null && isHttps.equals("1")) {
//					globalCDNWebsocketProxy = APIConfig.getGloablCDNWebsocketsProxyAddr();
//				}
//
//				if (StringUtils.isNotBlank(globalCDNWebsocketProxy)) {
//					if (globalCDNWebsocketProxy.contains(",")) {
//						String[] arr = globalCDNWebsocketProxy.split(",");
//						if (arr != null && arr.length > 0) {
//							output.setServer(arr[0]);
//							String[] bsArr = Arrays.copyOfRange(arr, 1, arr.length);
//							output.setBackupServer(MultiCMPUtil.builderBackupSever(bsArr));
//						}
//					} else {
//						output.setServer(globalCDNWebsocketProxy);
//					}
//					if (APManager.checkIpIsvalid(output.getServer())) {
//						return output;
//					}
//				}
//			}
//
//			throw new RtcException("can't get navi server.");
//		} else {
//			String server = output.getServer();
//			String[] servers = server.split(":");
//			if (servers != null && servers.length >= 2) {
//				String serverNew = servers[0];
//				String directCMPIP = serverNew;
//				String portNew = servers[1];
//				String backupServer = servers[0];
//				String backupPort = NaviMapper.getWsApPort(server);
//
//				if (!output.isAlone()) {
//					// 非独立部署
//					if (isHttps != null && isHttps.equals("1")) {
//						// https
//						LOGGER.info("https request: appid=" + appId + " userId=" + userId);
//						String domain = NaviMapper.getDomain(server);
//
//						if (!StringUtils.isBlank(domain)) {
//							serverNew = domain;
//						}
//					} else {
//						// http
//						String wsPort = NaviMapper.getWsPort(server);
//						if (!StringUtils.isBlank(wsPort)) {
//							portNew = wsPort;
//						}
//
//						/*
//						 * if (HoleNavis.isOpen()) { //黑洞打开,返回黑洞地址
//						 * output.setServer(HoleNavis.getHoleForUserId(userId)); return output; }
//						 */
//
//						// 海外用户将cmp地址替换为海外节点ip
//						if (!StringUtils.isEmpty(remote) && appInfo.isOpenAp) {
//							isUsedAP = true;
//							APManager.putAPAddr(CURRENT_APID, remote);
//							serverNew = remote;
//							// String wsApPort = NaviMapper.getWsApPort(server);
//							if (!StringUtils.isBlank(backupPort)) {
//								portNew = backupPort;
//							}
//
//							backupPort = wsPort;
//						}
//					}
//				} else {
//					// 独立部署
//					String wsPort = StandAloneNaviMapper.getWsPort(server);
//					backupPort = StandAloneNaviMapper.getWsApPort(server);
//
//					if (!StringUtils.isBlank(wsPort)) {
//						portNew = wsPort;
//					}
//
//					StandAloneNaviApConfig apConfig = StandAloneNaviMapper.getDatacenterForAppId(appId);
//					if (apConfig != null && !apConfig.isAbroad()) {
//						// 表示独立部署在国外
//						String[] apIps = apConfig.getApIps();
//						if (StringUtils.isEmpty(remote) && (apIps != null && apIps.length > 0)) {
//							// 国内用户,且有ap配置的，返回ap地址
//							// 独立部署在国外,国内用户且配置有ap的
//							LOGGER.debug("Standalone abroad,domestic user,get ap. appId={}", appId);
//							int number = new Random().nextInt(apIps.length);
//							serverNew = apIps[number];
//							// String apPort = StandAloneNaviMapper.getWsApPort(server);
//
//							if (!StringUtils.isBlank(backupPort)) {
//								portNew = backupPort;
//							}
//						} else {
//							// 独立部署在国外,国外用户，或者没有配置ap的,那么国外用户的cmp配置本身就为海外ip，所以不需要修改
//							LOGGER.debug("Standalone abroad,foreign user,appId={}", appId);
//						}
//					} else {
//						// 表示独立部署在国内
//						LOGGER.debug("Standalone domestic,foreign user, appId={}", appId);
//
//						/*
//						 * if (HoleNavis.isOpen()) {// 黑洞打开,返回黑洞地址
//						 * output.setServer(HoleNavis.getHoleForUserId(userId)); return output; }
//						 */
//
//						if (!StringUtils.isEmpty(remote) && appInfo.isOpenAp) {
//							// 国外用户需要优化海外ip
//							serverNew = remote;
//							String wsApPort = StandAloneNaviMapper.getWsApPort(server);
//
//							if (!StringUtils.isBlank(wsApPort)) {
//								portNew = wsApPort;
//							}
//
//						} else {
//							// 国内用户
//							// 独立部署在国内，那么国内用户的cmp配置不需要修改
//						}
//					}
//				}
//
//				output.setServer(serverNew + ":" + portNew);
//
//				if (isHttps != null && isHttps.equals("1")) {
//					// 理论上：SSL 下没有备用链路可以下发
//
//					/**
//					 * 兼容逻辑：SSL下发备用链路 背景： 1.原来SSL的时候也下发了的备用链路，但链路是IP:PORT形态的，对SSL是不可用的（BUG） 2.WebSDK
//					 * 在使用SSL的时候没有检查该链路是否为空，导致连接失败报错 3.客户WPS使用的是WebSDK，因为SSL的时候下发的是备用链路是null，导致了前端出错
//					 * 总结：综上所以，增加 兼容逻辑，SSL下发备用链路，避免老版本WebSDK报错 PS：目前新版本的WebSDK，洪达已经修改。
//					 */
//
//					output.setBackupServer(backupServer + ":" + backupPort);
//				} else {
//					output.setBackupServer(backupServer + ":" + backupPort);
//				}
//				// ==============================================================================
//				// 是否支持多CMP的版本
//				// 注：此处不考虑Standalone AP的情况，目前不支持多链路
//				// ==============================================================================
//				if (!output.isAlone() && MultiCMPUtil.isSupportWebSDKMultiCMPBaseOnAP(sdkVersion)) {
//					if (isUsedAP) {
//						String wsPort = NaviMapper.getWsPort(server);
//						String wsApPort = NaviMapper.getWsApPort(server);
//
//						List<String> backupApIPs = APManager.calcUserBackupAPAddress(appId, userId, CURRENT_APID);
//						if (backupApIPs != null && backupApIPs.size() > 0) {
//							if (StringUtils.isNotBlank(wsApPort) && StringUtils.isNotBlank(wsPort)) {
//								if (APManager.checkIsSpecialLine(CURRENT_APID)) {
//									// 此時，BackupServer放的是直連地址，Server放的是AP地址
//									String directwsAddr = output.getBackupServer();
//									String apAddr = output.getServer();
//									output.setServer(directwsAddr);
//
//									List<String> ips = new ArrayList<>();
//									ips.add(apAddr);
//									for (String ip : backupApIPs) {
//										ips.add(ip + ":" + wsApPort);
//									}
//									ips.add(directCMPIP + ":" + wsApPort);
//
//									String[] ss = ips.toArray(new String[ips.size()]);
//
//									String backupAPServer = MultiCMPUtil.builderBackupSever(ss);
//									output.setBackupServer(backupAPServer);
//								} else {
//									List<String> ips = new ArrayList<>();
//									for (String ip : backupApIPs) {
//										ips.add(ip + ":" + wsApPort);
//									}
//									ips.add(output.getBackupServer());
//									ips.add(directCMPIP + ":" + wsApPort);
//
//									String[] ss = ips.toArray(new String[ips.size()]);
//									String backupAPServer = MultiCMPUtil.builderBackupSever(ss);
//									output.setBackupServer(backupAPServer);
//								}
//							}
//						} else {
//							// 用户从AP点接入，但是该AP点没有备用的AP
//							if (StringUtils.isNotBlank(wsApPort) && StringUtils.isNotBlank(wsPort)) {
//								if (APManager.checkIsSpecialLine(CURRENT_APID)) {
//									// 此時，BackupServer放的是直連地址，Server放的是AP地址
//									String directwsAddr = output.getBackupServer();
//									String apAddr = output.getServer();
//									output.setServer(directwsAddr);
//
//									String backupAPServer = MultiCMPUtil.builderBackupSever(apAddr,
//											directCMPIP + ":" + wsApPort);
//									output.setBackupServer(backupAPServer);
//								} else {
//									String backupAPServer = MultiCMPUtil.builderBackupSever(output.getBackupServer(),
//											directCMPIP + ":" + wsApPort);
//									output.setBackupServer(backupAPServer);
//								}
//							}
//						}
//					} else {
//						// 针对直连用户
//						if (isHttps != null && isHttps.equals("1")) {
//							// 使用SSL的方式，不能支持多CMP链路
//						} else {
//							String idcAPAddr = APManager.calcUserIDCApAddress(appId, userId);
//							String wsApPort = NaviMapper.getWsApPort(server);
//							if (StringUtils.isNotBlank(idcAPAddr) && StringUtils.isNotBlank(wsApPort)) {
//								String backupAPServer = MultiCMPUtil.builderBackupSever(output.getBackupServer(),
//										idcAPAddr + ":" + wsApPort);
//								output.setBackupServer(backupAPServer);
//							}
//						}
//					}
//					/**
//					 * 导航返回代理地址
//					 */
//					if (APIConfig.getIsSupportTcpProxy()) {
//						if (isHttps != null && isHttps.equals("1")) {
//							String globalCDNWebsocketsProxy = APIConfig.getGloablCDNWebsocketsProxyAddr();
//							if (StringUtils.isNotBlank(globalCDNWebsocketsProxy)) {
//								output.setBackupServer(globalCDNWebsocketsProxy);
//							}
//						} else {
//							String globalCDNWebsocketProxy = APIConfig.getGloablCDNWebsocketProxyAddr();
//							if (StringUtils.isNotBlank(globalCDNWebsocketProxy)) {
//								output.setBackupServer(MultiCMPUtil.builderBackupSever(output.getBackupServer(),
//										globalCDNWebsocketProxy));
//							}
//						}
//					}
//				}
//				// -------------------------------------------------------------------------------------
//			} else {
//				LOGGER.error(output.getServer() + " is not mapped! check zkconf!");
//			}
//		}
//		try {
//			userAgentInfo = UserAgentUtil.uasParser.parse(userAgent);
//		} catch (IOException e) {
//			LOGGER.error("UserAgen parse error appid=" + appId + " userId=" + userId + " error=" + e);
//		}
//		LOGGER.info(appId + "_" + userId + "\t" + clientIp + "\t" + sdkVersion + "\t" + output.getServer() + ","
//				+ output.getBackupServer() + "," + appInfo.grpMsgUpLimitCount + "," + userAgentInfo.getUaName());
//		MultiCMPUtil.writeMonitor(ctx, appId, clientIp, userId, sdkVersion, "ws", CURRENT_APID, false, host,
//				userAgentInfo, isHttps);
//
//		return output;
//	}
//
//}
