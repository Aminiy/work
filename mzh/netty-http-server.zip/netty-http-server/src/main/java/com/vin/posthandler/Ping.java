package com.vin.posthandler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vin.config.Processor;
import com.vin.output.Output;
import com.vin.util.RtcApiUtil;

import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.multipart.HttpDataFactory;

/**
 * 测试类
 * 
 * @author mazhanghui
 *
 */
public class Ping implements Processor {

	private static final Logger LOGGER = LoggerFactory.getLogger(Ping.class);

	public Output process(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
			throws Exception {
		LOGGER.info("========>> received incomming post request: Ping.");
		//
		Output out = new Output();
		out.setDesc("success");
		return out;
	}

	public void processRequest(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
			throws Exception {
		RtcApiUtil.sendHttpResponse(ctx.channel(), "hello", "json");
	}

}
