package com.vin.netty.server;

import static io.netty.handler.codec.http.HttpResponseStatus.BAD_REQUEST;
import static io.netty.handler.codec.http.HttpVersion.HTTP_1_1;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpHeaders.Names;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpObject;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpVersion;
import io.netty.handler.codec.http.multipart.DefaultHttpDataFactory;
import io.netty.handler.codec.http.multipart.HttpDataFactory;
import io.netty.util.CharsetUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vin.config.RouteUrlConfig;
import com.vin.controller.HttpController;
import com.vin.output.Output;
import com.vin.util.RtcApiUtil;

public class NettyHttpServerHandler extends SimpleChannelInboundHandler<HttpObject> {

	private static final Logger logger = LoggerFactory.getLogger(NettyHttpServerHandler.class);

	private static final HttpDataFactory factory = new DefaultHttpDataFactory(DefaultHttpDataFactory.MINSIZE); // Disk

	private static final String callFormat = "%s(%s);";

//	public static String getResult(final com.rcloud.error.Error e, final String format) {
//		if ("json".equalsIgnoreCase(format) || "js".equalsIgnoreCase(format)) {
//			return e.toJsonObject().toString();
//		} else if ("xml".equalsIgnoreCase(format)) {
//			return e.toXML();
//		}
//		return "Error format";
//	}

	private static void sendBadHttpResponse(ChannelHandlerContext ctx, DefaultFullHttpResponse res) {
		ByteBuf buf = null;
		buf = Unpooled.copiedBuffer(res.getStatus().toString(), CharsetUtil.UTF_8);
		res.content().writeBytes(buf);
		buf.release();
//		res.headers().set("p", Bootstrap.node);
		res.headers().add("connection", "close");
		ChannelFuture f = ctx.channel().writeAndFlush(res);
		f.addListener(ChannelFutureListener.CLOSE);
	}

	private static void closeOnFlush(Channel ch) {
		if (ch.isActive()) {
			ch.writeAndFlush(Unpooled.EMPTY_BUFFER).addListener(ChannelFutureListener.CLOSE);
		}
	}

	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
		ctx.channel().attr(CommonAttributeKey.CREATE_SESSON_TIME).set(System.currentTimeMillis());
	}

	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {

	}

	@Override
	protected void channelRead0(ChannelHandlerContext ctx, HttpObject msg) throws Exception {
		try {
			if (msg instanceof FullHttpRequest) {
				ctx.channel().attr(CommonAttributeKey.RECEIVE_HTTP_REQUEST_TIME).set(System.currentTimeMillis());
				messageReceived(ctx, (FullHttpRequest) msg);
			} else {
				sendBadHttpResponse(ctx, new DefaultFullHttpResponse(HTTP_1_1, BAD_REQUEST));
				closeOnFlush(ctx.channel());
			}
		} catch (Exception ex) {
			logger.error("recv msg error!", ex);
			sendBadHttpResponse(ctx, new DefaultFullHttpResponse(HTTP_1_1, BAD_REQUEST));
		}
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		ctx.channel().close();
		logger.error("exceptionCaught ctx close", cause);
	}

	public void messageReceived(ChannelHandlerContext ctx, FullHttpRequest request) throws Exception {
		if (!request.getDecoderResult().isSuccess()) {
			sendBadHttpResponse(ctx, new DefaultFullHttpResponse(HTTP_1_1, BAD_REQUEST));
			return;
		}

		String format = "js";
		if (request.getUri().indexOf(".xml") > 0) {
			format = "xml";
		} else if (request.getUri().indexOf(".json") > 0) {
			format = "json";
		}

		if (request.getMethod().equals(HttpMethod.GET)) {
			try {
				Output output = HttpController.get(ctx, request, factory, format);
				writeResponse(ctx.channel(), output, format);
			} catch (Exception e) {
//				writeErrorResponse(ctx.channel(), e.getError(), format);
			}
		} else if (request.getMethod().equals(HttpMethod.POST)) {
			try {
				String reqUrl = request.getUri().substring(0, request.getUri().indexOf("."));
				if (RouteUrlConfig.postUrlMaps.get(reqUrl.toLowerCase()) != null) {
					// 同步post请求,统一回应答
					Output output = HttpController.post(ctx, request, factory, format);
					writeResponse(ctx.channel(), output, format);
				} else if (RouteUrlConfig.AsyPostUrlMaps.get(reqUrl.toLowerCase()) != null) {
					// 异步 post handler 自己处理应答
					HttpController.postAsyRequest(ctx, request, factory, format);
				} else {
					RtcApiUtil.sendHttpResponse(ctx.channel(), "not found request uri", "json");
				}
				
			} catch (Exception e) {
//				writeErrorResponse(ctx.channel(), 500, format);
			}
		}
	}

//	private void writeErrorResponse(Channel channel, com.rcloud.error.Error e, String format) {
//		ByteBuf buf = null;
//		FullHttpResponse response = null;
//		switch (e.getCode()) {
//		case 200:
//			buf = Unpooled.copiedBuffer("json".equalsIgnoreCase(format) ? e.toString()
//					: e.toXML().replace("\n", "").replace(" ", "") + "    ", CharsetUtil.UTF_8);
//			response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.OK, buf);
//			break;
//		case 401:
//			buf = Unpooled.copiedBuffer(getResult(e, format), CharsetUtil.UTF_8);
//			response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.FORBIDDEN, buf);
//			break;
//		case 403:
//			buf = Unpooled.copiedBuffer(getResult(e, format), CharsetUtil.UTF_8);
//			response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.UNAUTHORIZED, buf);
//			break;
//		case 404:
//			buf = Unpooled.copiedBuffer(getResult(e, format), CharsetUtil.UTF_8);
//			response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.NOT_FOUND, buf);
//			break;
//		case 2007:
//			buf = Unpooled.copiedBuffer(getResult(e, format), CharsetUtil.UTF_8);
//			response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.FORBIDDEN, buf);
//			break;
//		default:
//			buf = Unpooled.copiedBuffer(getResult(e, format), CharsetUtil.UTF_8);
//			response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.OK, buf);
//			break;
//		}
//
//		// json,xml
//		if ("json".equalsIgnoreCase(format) || "js".equalsIgnoreCase(format)) {
//			response.headers().set(Names.CONTENT_TYPE, "application/json; charset=UTF-8");
//		} else if ("xml".equalsIgnoreCase(format)) {
//			response.headers().set(Names.CONTENT_TYPE, "text/xml; charset=UTF-8");
//		} else {
//			response.headers().set(Names.CONTENT_TYPE, "text/plain; charset=UTF-8");
//		}
////		response.headers().set("p", Bootstrap.node);
//		response.headers().set(Names.CONTENT_LENGTH, buf.readableBytes());
//		response.headers().add("connection", "close");
//		// 增加跨域
//		response.headers().add("Access-Control-Allow-Origin", "*");
//		response.headers().add("Access-Control-Allow-Methods", "*");
//		response.headers().add("Access-Control-Allow-Headers", "*");
//		ChannelFuture future = channel.writeAndFlush(response);
//		future.addListener(ChannelFutureListener.CLOSE);
//	}

	private void writeResponse(Channel channel, Output out, String format) {
		ByteBuf buf = null;
		FullHttpResponse response = null;

		String okStr;
		if ("json".equalsIgnoreCase(format)) {
			okStr = out.toJson();
		} else if ("js".equalsIgnoreCase(format)) {
			okStr = out.toJson();
			String call = out.getCallBack();
			if (call != null && call.length() > 0) {
				okStr = String.format(callFormat, call, okStr);
			}
		} else {
			okStr = out.toXML().replace("\n", "").replace(" ", "") + "    ";
		}

		buf = Unpooled.copiedBuffer(okStr, CharsetUtil.UTF_8);
		response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.OK, buf);

		// json,xml
		if ("json".equalsIgnoreCase(format) || "js".equalsIgnoreCase(format)) {
			response.headers().set(Names.CONTENT_TYPE, "application/json; charset=UTF-8");
		} else if ("xml".equalsIgnoreCase(format)) {
			response.headers().set(Names.CONTENT_TYPE, "text/xml; charset=UTF-8");
		} else {
			response.headers().set(Names.CONTENT_TYPE, "text/plain; charset=UTF-8");
		}

//		response.headers().set("p", Bootstrap.node);
		response.headers().set(Names.CONTENT_LENGTH, buf.readableBytes());
		response.headers().add("connection", "close");
		// 增加跨域
		response.headers().add("Access-Control-Allow-Origin", "*");
		response.headers().add("Access-Control-Allow-Methods", "*");
		response.headers().add("Access-Control-Allow-Headers", "*");

		ChannelFuture future = channel.writeAndFlush(response);
		future.addListener(ChannelFutureListener.CLOSE);
	}
	
}
