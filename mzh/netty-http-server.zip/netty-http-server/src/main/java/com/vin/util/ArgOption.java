package com.vin.util;

/**
 * Created with IntelliJ IDEA. User: srp Date: 14-6-25 Time: 下午3:45
 */
@SuppressWarnings("ClassWithoutLogger")
public class ArgOption {

	private final String name;
	private final ArgType type;

	@SuppressWarnings("BooleanParameter")
	public ArgOption(final String name, final boolean required) {
		this.name = name;
		type = required ? ArgType.REQUIRED : ArgType.OPTIONAL;
	}

	public String getName() {
		return name;
	}

	public ArgType getType() {
		return type;
	}

	@Override
	public String toString() {
		return "Arg{" + "name='" + name + '\'' + ", type=" + type + '}';
	}
}
