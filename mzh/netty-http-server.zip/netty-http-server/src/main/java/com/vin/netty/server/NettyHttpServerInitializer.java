package com.vin.netty.server;

import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpRequestDecoder;
import io.netty.handler.codec.http.HttpResponseEncoder;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;

public class NettyHttpServerInitializer extends
    ChannelInitializer<SocketChannel> {

    @Override
    protected void initChannel(SocketChannel ch) throws Exception {
        // TODO Auto-generated method stub
        ChannelPipeline pipeline = ch.pipeline();

		/*
		if (NettyHttpServer.isSSL) {
			SSLEngine engine = SecureChatSslContextFactory.getServerContext()
					.createSSLEngine();
			engine.setNeedClientAuth(true); // ssl双向认证
			engine.setUseClientMode(false);
			engine.setWantClientAuth(true);
			engine.setEnabledProtocols(new String[] { "SSLv3" });
			pipeline.addLast("ssl", new SslHandler(engine));
		}
		*/
        pipeline.addLast(new ReadTimeoutHandler(6));
        pipeline.addLast(new WriteTimeoutHandler(6));
        pipeline.addLast("decoder", new HttpRequestDecoder());
        pipeline.addLast("aggregator", new HttpObjectAggregator(65535));
        pipeline.addLast("encoder", new HttpResponseEncoder());
        pipeline.addLast("handler", new NettyHttpServerHandler());
    }

}

