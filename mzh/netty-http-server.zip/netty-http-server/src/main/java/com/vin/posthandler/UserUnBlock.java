//package com.vin.posthandler;
//
//import java.io.IOException;
//import java.io.UnsupportedEncodingException;
//import java.net.InetSocketAddress;
//import java.net.SocketAddress;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.concurrent.TimeUnit;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import com.google.gson.JsonObject;
//import com.rcloud.api.rtc.Processor;
//import com.rcloud.api.rtc.io.ArgOption;
//import com.rcloud.api.rtc.io.Output;
//import com.rcloud.api.rtc.util.ProcessorUtils;
//import com.rcloud.api.rtc.util.RtcApiUtil;
//import com.rcloud.cluster.FCloudCluster;
//import com.rcloud.error.APIException;
//import com.rcloud.error.ParameterException;
//import com.rcloud.inner.messages.RouteMessage;
//import com.rcloud.inner.messages.SSRequest;
//import com.rcloud.utils.AppIdMapper;
//import com.rcloud.utils.StringUtil;
//
//import akka.pattern.Patterns;
//import io.netty.bootstrap.Bootstrap;
//import io.netty.buffer.Unpooled;
//import io.netty.channel.ChannelFutureListener;
//import io.netty.channel.ChannelHandlerContext;
//import io.netty.channel.ChannelInitializer;
//import io.netty.channel.ChannelOption;
//import io.netty.channel.EventLoopGroup;
//import io.netty.channel.nio.NioEventLoopGroup;
//import io.netty.channel.socket.SocketChannel;
//import io.netty.channel.socket.nio.NioSocketChannel;
//import io.netty.handler.codec.http.DefaultFullHttpRequest;
//import io.netty.handler.codec.http.FullHttpRequest;
//import io.netty.handler.codec.http.HttpHeaders;
//import io.netty.handler.codec.http.HttpMethod;
//import io.netty.handler.codec.http.HttpObjectAggregator;
//import io.netty.handler.codec.http.HttpRequestEncoder;
//import io.netty.handler.codec.http.HttpResponseDecoder;
//import io.netty.handler.codec.http.HttpVersion;
//import io.netty.handler.codec.http.multipart.HttpDataFactory;
//import io.netty.handler.codec.http.multipart.HttpPostRequestDecoder;
//import io.netty.handler.codec.http.multipart.InterfaceHttpData;
//import io.netty.handler.codec.http.multipart.MixedAttribute;
//import io.netty.handler.timeout.ReadTimeoutHandler;
//import scala.concurrent.Await;
//import scala.concurrent.Future;
//import scala.concurrent.duration.Duration;
//
///**
// * RTC 解除封禁用户
// * 
// * @author mazhanghui
// * 
// */
//public class UserUnBlock implements Processor {
//
//	private static final Logger LOGGER = LoggerFactory.getLogger(UserUnBlock.class);
//
//	private static final List<ArgOption> HEADER_ARG_OPTIONs = Arrays.asList(new ArgOption("App-Key", false),
//			new ArgOption("AppKey", false), new ArgOption("Nonce", true), new ArgOption("Timestamp", true),
//			new ArgOption("Signature", true));
//
//	@Override
//	public Output process(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
//			throws APIException {
//
//		// 取 Header 和 Body 数据
//		final Map<String, String> headers = new HashMap<>(HEADER_ARG_OPTIONs.size());
//		for (ArgOption t : HEADER_ARG_OPTIONs) {
//			ProcessorUtils.addHeader(request, headers, t);
//		}
//
//		String appKey = headers.get("App-Key") == null ? headers.get("AppKey") : headers.get("App-Key");
//		String nonce = headers.get("Nonce");
//		String timestamp = headers.get("Timestamp");
//		String signature = headers.get("Signature");
//
//		HttpPostRequestDecoder decoder = new HttpPostRequestDecoder(factory, request);
//		InterfaceHttpData roomIdData = decoder.getBodyHttpData("roomId");// 可选参数
//		InterfaceHttpData userIdData = decoder.getBodyHttpData("userId");
//		InterfaceHttpData blockTypeData = decoder.getBodyHttpData("blockType");
//		MixedAttribute attrRoomId = (MixedAttribute) roomIdData;
//		MixedAttribute attrUserId = (MixedAttribute) userIdData;
//		MixedAttribute attrblockType = (MixedAttribute) blockTypeData;
//		int blockType = 1; // 1: 解除用户当前房间的封禁; 2: 解除用户全局封禁
//		String roomId = "";// 解除封禁类型为 1 时必须包含 roomId
//		String userId = "";
//
//		if (attrblockType == null || attrUserId == null) {
//			decoder.destroy();
//			LOGGER.error("attrblockType or attrUserId is null.");
//			throw new ParameterException("body parameter: roomId,userId is required.");
//		} else {
//			try {
//				userId = attrUserId.getValue();
//				blockType = Integer.parseInt(attrblockType.getValue());
//
//				if (attrRoomId != null) {
//					roomId = attrRoomId.getValue();
//				}
//			} catch (IOException e) {
//				decoder.destroy();
//				LOGGER.error("parse body parameter exception:" + e.getMessage(), e);
//				throw new ParameterException("parse body parameter exception.");
//			}
//		}
//
//		Output output = new Output();
//		output.setDesc("ok");
//
//		int code = 0;
//		long appId = 0;
//		Object[] result;
//		try {
//			// 验签
//			appId = AppIdMapper.string2long(appKey);
//			ProcessorUtils.validationSignature(nonce, timestamp, signature, appId);
//
//			String rtcToken = "";
//			String mediaServerAddr = "";
//			
//			// 转发请求
//			result = sendToAkkaSignal(appId, blockType, roomId, userId);
//			
//			if (result != null) {
//				code = (int) result[0];
//
//				if (result.length > 1) {
//					mediaServerAddr = (String) result[1];
//					rtcToken = (String) result[2];
//				}
//			} else {
//				code = 500;
//				LOGGER.error("========>> UserUnBlock send http request to mediatorServer.not received response.");
//			}
//
//			// send request to mediaServer
//			if (!StringUtil.isEmpty(mediaServerAddr)) {
//				String ip = mediaServerAddr.split(":")[0];
//				int port = Integer.valueOf(mediaServerAddr.split(":")[1]);
//
//				JsonObject gson = new JsonObject();
//				gson.addProperty("userId", userId);
//				gson.addProperty("blockType", blockType);
//				
//				if (!StringUtil.isEmpty(roomId)) {
//					gson.addProperty("roomId", roomId);
//				}
//				
//				try {
//					FullHttpRequest httpRequest = new DefaultFullHttpRequest(HttpVersion.HTTP_1_1, HttpMethod.POST,
//							"/rtc/user/unblock",
//							Unpooled.wrappedBuffer(gson.toString().getBytes("UTF-8")));
//
//					// 将请求中的 Header 添加到被用来转发的新构造出来的 http request 中
//					for (Map.Entry<String, String> entry : headers.entrySet()) {
//						if (entry.getValue() != null) {
//							httpRequest.headers().set(entry.getKey(), entry.getValue());
//						}
//					}
//
//					httpRequest.headers().set(HttpHeaders.Names.CONNECTION, HttpHeaders.Values.KEEP_ALIVE);
//					httpRequest.headers().set(HttpHeaders.Names.CONTENT_LENGTH, httpRequest.content().readableBytes());
//					httpRequest.headers().set(HttpHeaders.Names.CONTENT_TYPE, "application/json");
//					httpRequest.headers().set("Token", rtcToken);
//					httpRequest.headers().set("RoomId", roomId);
//					httpRequest.headers().set("RoomType", 1);// 1:音视频; 2:直播
//
////					LOGGER.info("========>> send http post request to mediaServer unblock user.");
//					sendPostRequest(ctx, httpRequest, new InetSocketAddress(ip, port));
//
//				} catch (UnsupportedEncodingException e) {
//					e.printStackTrace();
//					LOGGER.error("----netty send http request UnsupportedEncodingException:" + e.getMessage(), e);
//					output.setCode(500);
//					output.setDesc("Server internal exception.");
//				}
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			output.setCode(500);
//			output.setDesc("failture");
//
//			LOGGER.error("unblock user, appId=" + appId + ",userId=" + userId + ",roomId=" + roomId + ",exception="
//					+ e.getMessage(), e);
//		}
//		
//		// 解封禁，不需要等 mediaServer 应答，依据 Signal 应答结果返回即可
//		output.setCode(code);
//		return output;
//	}
//
//	/**
//	 * 
//	 * @param appId
//	 * @param blockType 1:按roomId封禁; 2: 全局封禁
//	 * @param roomId
//	 * @param userId
//	 * @return
//	 * @throws Exception
//	 */
//	private static Object[] sendToAkkaSignal(Long appId, int blockType, String roomId, String userId)
//			throws Exception {
//		
//		Object[] result = new Object[] {};
//		// CSMessage -> onAppMessage
//		SSRequest request = new SSRequest();
//		request.setAppId(appId);
//		request.setMethod("rtcUserUnBlock");
//		request.setAppMessage(new Object[] { appId, blockType, roomId, userId });
//		if (blockType == 2) {
//			request.setTargetResourceId(userId);
//		} else {
//			request.setTargetResourceId(roomId);
//		}
//
//		String nodeAddr = FCloudCluster.fCluster.getZkClusterSites()
//				.findNodeForClusterNMethodNResource(FCloudCluster.fCluster.getClusterName(), "rtcUserUnBlock", roomId)
//				.getAkkaAddr();
//
//		Future<Object> f = Patterns.ask(FCloudCluster.fCluster.getActorSystem().actorSelection(nodeAddr),
//				RouteMessage.wrap(request), 5000);
//
//		result = (Object[]) Await.result(f, Duration.create(5, TimeUnit.SECONDS));
//
//		return result;
//	}
//	
//	private void sendPostRequest(ChannelHandlerContext ctx, FullHttpRequest request, SocketAddress address) {
//		Bootstrap b = new Bootstrap();
//		EventLoopGroup workerGroup = new NioEventLoopGroup(1);
//		b.group(workerGroup).channel(NioSocketChannel.class).option(ChannelOption.SO_KEEPALIVE, true)
//				.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000).handler(new ChannelInitializer<SocketChannel>() {
//					@Override
//					public void initChannel(SocketChannel ch) {
//						ch.pipeline().addLast(new ReadTimeoutHandler(10)).addLast(new HttpResponseDecoder())
//								.addLast(new HttpObjectAggregator(1024 * 1024 * 1024))
//								.addLast(new HttpRequestEncoder());
//					}
//				});
//
//		b.connect(address).addListener((ChannelFutureListener) future -> {
//			if (!future.isSuccess()) {
//				LOGGER.info("---sendPostRequest--connect--failed");
//				return;
//			} else {
////				LOGGER.info("---sendPostRequest--connect--success");
//			}
//
//			future.channel().writeAndFlush(request).addListener(channelFuture -> {
//				if (!channelFuture.isSuccess()) {
//					// 发送数据失败
//					LOGGER.error("---sendPostRequest writeAndFlush error.");
//				} else {
//					LOGGER.info("---sendPostRequest writeAndFlush success.");
//				}
//			});
//		});
//	}
//
//	@Override
//	public void processRequest(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
//			throws APIException {
//		RtcApiUtil.sendHttpResponse(ctx.channel(), "use old way now", "json");
//	}
//
//}
