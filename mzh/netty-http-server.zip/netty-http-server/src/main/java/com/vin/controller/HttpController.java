package com.vin.controller;

import com.vin.config.Processor;
import com.vin.config.RouteUrlConfig;
import com.vin.output.Output;

import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.multipart.HttpDataFactory;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HttpController {

	private static final Logger logger = LoggerFactory.getLogger(HttpController.class);
	
	// 同步处理应答 post 请求集合
	public static final Map<String, Processor> postProcessorHashMap = new HashMap<String, Processor>();
	// 异步处理应答 post 请求集合
	public static final Map<String, Processor> AsyPostProcessorHashMap = new HashMap<String, Processor>();
	
	public static final Map<String, Processor> getProcessorHashMap = new HashMap<String, Processor>();

	static {
		initSyncPostProcessors(postProcessorHashMap);
		initAsyPostProcessors(AsyPostProcessorHashMap);
		initGetProcessors(getProcessorHashMap);
	}

	private static void initSyncPostProcessors(Map<String, Processor> map) {
		Iterator<Map.Entry<String, String>> iterator = RouteUrlConfig.postUrlMaps.entrySet().iterator();
		while (iterator.hasNext()) {
			try {
				Map.Entry<String, String> entry = iterator.next();
				map.put(entry.getKey().toLowerCase(),
						(Processor) Class.forName(entry.getValue()).getConstructor().newInstance());
				System.out.println("init syncPostProcessors add " + entry.getKey().toLowerCase());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	private static void initAsyPostProcessors(Map<String, Processor> map) {
		Iterator<Map.Entry<String, String>> iterator = RouteUrlConfig.AsyPostUrlMaps.entrySet().iterator();
		while (iterator.hasNext()) {
			try {
				Map.Entry<String, String> entry = iterator.next();
				map.put(entry.getKey().toLowerCase(),
						(Processor) Class.forName(entry.getValue()).getConstructor().newInstance());
				System.out.println("init AsyPostProcessors add " + entry.getKey().toLowerCase());
				logger.info("init AsyPostProcessors add " + entry.getKey().toLowerCase());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	private static void initGetProcessors(Map<String, Processor> map) {
		Iterator<Map.Entry<String, String>> iterator = RouteUrlConfig.getUrlMaps.entrySet().iterator();
		while (iterator.hasNext()) {
			try {
				Map.Entry<String, String> entry = iterator.next();
				map.put(entry.getKey().toLowerCase(),
						(Processor) Class.forName(entry.getValue()).getConstructor().newInstance());
				System.out.println("init GetProcessors add " + entry.getKey().toLowerCase());
				logger.info("init GetProcessors add " + entry.getKey().toLowerCase());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	

	public static Output post(ChannelHandlerContext ctx, FullHttpRequest req, HttpDataFactory factory, String format)
			throws Exception {
		long begin = System.currentTimeMillis();

		Output out = new Output();
		out.setCode(404);
		String reqUrl = req.getUri().substring(0, req.getUri().indexOf("."));
//		Timer.Context timer = null;
		try {
			if (!"json".equalsIgnoreCase(format) && !"xml".equalsIgnoreCase(format)) {
				throw new Exception( "url format not found, only support json,xml. request format=" + format);
			}
			String method = RouteUrlConfig.postUrlMaps.get(reqUrl.toLowerCase());
			if (method != null) {
				// 监控用的计时器 ？
//				timer = SimpleMetricClientUtils.getInstance().startNaviMetrics("POST", method);
				Processor processor = postProcessorHashMap.get(reqUrl.toLowerCase());
				if (processor != null) {
					out = processor.process(ctx, req, factory);
					logger.info(reqUrl + ":" + (System.currentTimeMillis() - begin) + "ms");
				}
			} else {
				throw new Exception("post request method not found this uri method=" + method);
//				throw new RtcException(404, req.getUri(), "post request method not found this uri method=" + method);
			}
		} catch (final Exception e) {
			e.printStackTrace();
		} finally {
//			if (timer != null) {
//				timer.stop();
//			}
		}
		return out;
	}
	
	/**
	 * 该接口需要 Handler 里自己处理给客户端的应答
	 * 
	 * @param ctx
	 * @param req
	 * @param factory
	 * @param format
	 * @throws APIException
	 */
	public static void postAsyRequest(ChannelHandlerContext ctx, FullHttpRequest req, HttpDataFactory factory, String format)
			throws Exception {
		
		long begin = System.currentTimeMillis();

		String reqUrl = req.getUri().substring(0, req.getUri().indexOf("."));
//		Timer.Context timer = null;
		try {
			if (!"json".equalsIgnoreCase(format) && !"xml".equalsIgnoreCase(format)) {
//				throw new RtcException(404, req.getUri(), "url format not found, only support json,xml. request format=" + format);
			}
			String method = RouteUrlConfig.AsyPostUrlMaps.get(reqUrl.toLowerCase());
			if (method != null) {
//				timer = SimpleMetricClientUtils.getInstance().startNaviMetrics("POST", method);
				Processor processor = AsyPostProcessorHashMap.get(reqUrl.toLowerCase());
				if (processor != null) {
					processor.processRequest(ctx, req, factory);
//					logger.info(reqUrl + ":" + (System.currentTimeMillis() - begin) + "ms");
				}
			} else {
				throw new Exception("post request method not found this uri method=" + method);
			}
		}  catch (final Exception e) {
			e.printStackTrace();
		} finally {
//			if (timer != null) {
//				timer.stop();
//			}
		}
	}
	

	public static Output get(ChannelHandlerContext ctx, FullHttpRequest req, HttpDataFactory factory, String format)
			throws Exception {
		long begin = System.currentTimeMillis();
		Output out = new Output();
		out.setCode(404);
		String reqUrl = req.getUri().substring(0, req.getUri().indexOf("."));
//		Timer.Context timer = null;
		try {
			if (!"json".equalsIgnoreCase(format) && !"xml".equalsIgnoreCase(format) && !"js".equalsIgnoreCase(format)) {
//				throw new RtcException(404, req.getUri(), "url format not found");
			}

			if ("js".equalsIgnoreCase(format)) {
				int callBacks = req.getUri().indexOf("&callBack");
				if (callBacks <= 0) {
//					throw new RtcException(403, req.getUri(), "callBack parameter is required.");
				}
			}

			String method = RouteUrlConfig.getUrlMaps.get(reqUrl.toLowerCase());
			if (method != null) {
//				timer = SimpleMetricClientUtils.getInstance().startNaviMetrics("GET", method);
				final Processor processor = getProcessorHashMap.get(reqUrl.toLowerCase());
				if (processor != null) {
					out = processor.process(ctx, req, factory);
//					logger.info(reqUrl + ":" + (System.currentTimeMillis() - begin) + "ms");
				}
			} else {
//				throw new RtcException(404, req.getUri(), "request method not found");
			}
		} catch (final Exception e) {
			e.printStackTrace();
		} finally {
//			if (timer != null) {
//				timer.stop();
//			}
		}
		return out;
	}

}
