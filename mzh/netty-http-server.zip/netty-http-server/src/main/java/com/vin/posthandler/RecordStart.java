//package com.vin.posthandler;
//
//import java.io.UnsupportedEncodingException;
//import java.net.InetSocketAddress;
//import java.net.SocketAddress;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import com.vin.config.Processor;
//import com.vin.util.ArgOption;
//
//import io.netty.bootstrap.Bootstrap;
//import io.netty.buffer.Unpooled;
//import io.netty.channel.ChannelFutureListener;
//import io.netty.channel.ChannelHandlerContext;
//import io.netty.channel.ChannelInitializer;
//import io.netty.channel.ChannelOption;
//import io.netty.channel.EventLoopGroup;
//import io.netty.channel.nio.NioEventLoopGroup;
//import io.netty.channel.socket.SocketChannel;
//import io.netty.channel.socket.nio.NioSocketChannel;
//import io.netty.handler.codec.http.DefaultFullHttpRequest;
//import io.netty.handler.codec.http.FullHttpRequest;
//import io.netty.handler.codec.http.HttpHeaders;
//import io.netty.handler.codec.http.HttpMethod;
//import io.netty.handler.codec.http.HttpObjectAggregator;
//import io.netty.handler.codec.http.HttpRequestEncoder;
//import io.netty.handler.codec.http.HttpResponseDecoder;
//import io.netty.handler.codec.http.HttpVersion;
//import io.netty.handler.codec.http.multipart.HttpDataFactory;
//import io.netty.handler.timeout.ReadTimeoutHandler;
//
///**
// * RTC - 开始云录像
// * 
// * 客户-->api-->recordServer
// * 
// * @author mazhanghui
// */
//public class RecordStart implements Processor {
//	private static final Logger LOGGER = LoggerFactory.getLogger(RecordStart.class);
//
//	private static final List<ArgOption> HEADER_ARG_OPTIONs = Arrays.asList(new ArgOption("App-Key", false),
//			new ArgOption("AppKey", false), new ArgOption("Nonce", true), new ArgOption("Timestamp", true),
//			new ArgOption("Signature", true), new ArgOption("RoomId", true), new ArgOption("SessionId", true));
//
//	@Override
//	public Output process(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
//			throws APIException {
//		LOGGER.info("========>> incomming post request RecordStart - process.");
//		return new Output();
//	}
//
//	@Override
//	public void processRequest(ChannelHandlerContext ctx, FullHttpRequest request, HttpDataFactory factory)
//			throws APIException {
//		LOGGER.info("========>> incomming post request RecordStart - processRequest.");
//
//		final Map<String, String> headers = new HashMap<>(HEADER_ARG_OPTIONs.size());
//		for (ArgOption t : HEADER_ARG_OPTIONs) {
//			ProcessorUtils.addHeader(request, headers, t);
//		}
//
//		String appKey = headers.get("App-Key");
//		String nonce = headers.get("Nonce");
//		String timestamp = headers.get("Timestamp");
//		String signature = headers.get("Signature");
//		String roomId = headers.get("RoomId");
//		String sessionId = headers.get("SessionId");
//
//		LOGGER.info("RecordStart >> appKey=" + appKey + ",nonce=" + nonce + ",timestamp=" + timestamp + ",signature="
//				+ signature + ",roomId=" + roomId + ",sessionId=" + sessionId);
//		// 验签
//
////		String body = "";
////		if (request.content().isReadable()) {
////			body = request.content().toString(CharsetUtil.UTF_8);
////		}
////		LOGGER.info("RecordStart >> body=" + body + ",request uri=" + request.getUri());
////
////		if (StringUtil.isEmpty(body)) {
////			RtcApiUtil.sendHttpResponse(ctx.channel(), "body is null", "json");
////			throw new ParameterException("body is null");
////		}
//
//		AppInfoDBCache appInfoCache = AppInfoCacheManager.getAppInfo(AppInfoDBCache.class, appId);
//		String recordAddr = appInfoCache.rtcCloudRecordAddr;
//
//		if (StringUtil.isEmpty(recordAddr)) {
//			RtcApiUtil.sendHttpResponse(ctx.channel(), "record Address is null", "json");
//			throw new ParameterException("record Address from db is null");
//		}
//		// 发送前的数据解析
//		String ip;
//		int port;
//		String ipAndPort = "";
//		String domain = "";
//		if (recordAddr.contains("@")) {
//			ipAndPort = recordAddr.split("@")[0];
//		} else if (recordAddr.contains("&F")) {
//			domain = recordAddr.split("&F")[0];
//		}
//
//		if (!StringUtil.isEmpty(ipAndPort)) {
//			// 优先使用 ipAndPort
//			ip = ipAndPort.split(":")[0];
//			port = Integer.parseInt(ipAndPort.split(":")[1]);
//		} else {
//			ip = domain.split(":")[0];// 域名
//			port = Integer.parseInt(domain.split(":")[1]);
//		}
//
//		JsonObject json = new JsonObject();
//		json.addProperty("sessionId", sessionId);
//
//		JsonObject gson = new JsonObject();
//		// 发送录像开始请求到 recordServer - HTTP
//		try {
//			FullHttpRequest httpRequest = new DefaultFullHttpRequest(HttpVersion.HTTP_1_1, HttpMethod.POST,
//					"/rtc/record/start", Unpooled.wrappedBuffer(json.toString().getBytes("UTF-8")));
//
//			// 将 请求中的 Header 添加到被用来转发的新构造出来的 http request 中
//			for (Map.Entry<String, String> entry : headers.entrySet()) {
//				if (entry.getValue() != null)
//					httpRequest.headers().set(entry.getKey(), entry.getValue());
//			}
//
//			httpRequest.headers().set(HttpHeaders.Names.CONNECTION, HttpHeaders.Values.KEEP_ALIVE);
//			httpRequest.headers().set(HttpHeaders.Names.CONTENT_LENGTH, httpRequest.content().readableBytes());
//			httpRequest.headers().set(HttpHeaders.Names.CONTENT_TYPE, "application/json");
//			httpRequest.headers().set("AppKey", appKey);
//			httpRequest.headers().set("Room-Id", roomId);
//
//			String format = RtcApiUtil.getRequestFormat(httpRequest);// json, xml
//
//			// 异步里返回应答数据给客户
//			
//			sendPostRequest(ctx, httpRequest, new InetSocketAddress(ip, port), format, gson);
//
//		} catch (UnsupportedEncodingException e) {
//			e.printStackTrace();
//			LOGGER.error("----netty send http request UnsupportedEncodingException:" + e.getMessage(), e);
//			RtcApiUtil.sendHttpResponse(ctx.channel(), "send http request UnsupportedEncodingException", "json");
//		} catch (Exception e) {
//			LOGGER.error("----netty send http request Exception:" + e.getMessage(), e);
//			RtcApiUtil.sendHttpResponse(ctx.channel(), "send http request Exception", "json");
//		}
//
//	}
//
//	private void sendPostRequest(ChannelHandlerContext ctx, FullHttpRequest postRequest, SocketAddress address,
//			String format, JsonObject gson) throws Exception {
//		Bootstrap b = new Bootstrap();
//		EventLoopGroup workerGroup = new NioEventLoopGroup(1);
//		b.group(workerGroup).channel(NioSocketChannel.class).option(ChannelOption.SO_KEEPALIVE, true)
//				.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 5000).handler(new ChannelInitializer<SocketChannel>() {
//					@Override
//					public void initChannel(SocketChannel ch) {
//						ch.pipeline().addLast(new ReadTimeoutHandler(10)).addLast(new HttpResponseDecoder())
//								.addLast(new HttpObjectAggregator(1024 * 1024 * 1024))
//								.addLast(new HttpRequestEncoder());
//					}
//				});
//
//		b.connect(address).addListener((ChannelFutureListener) future -> {
//			if (!future.isSuccess()) {
//				LOGGER.info("---sendPostRequest--connect--failed");
//
//				// 连接失败
//				gson.addProperty("code", 500);
//				RtcApiUtil.sendHttpResponse(ctx.channel(), "connect to remote ip failed", format);
//				return;
//			} else {
////				LOGGER.info("---sendPostRequest--connect--success");
//			}
//
//			future.channel().writeAndFlush(postRequest).addListener(channelFuture -> {
//				if (!channelFuture.isSuccess()) {
//					// 发送数据失败
//					LOGGER.error("---sendPostRequest writeAndFlush error.");
//					gson.addProperty("code", 500);
//					RtcApiUtil.sendHttpResponse(ctx.channel(), "send http request failed!", format);
//				} else {
////					LOGGER.info("---sendPostRequest writeAndFlush success.");
//					gson.addProperty("code", 200);
//					RtcApiUtil.sendHttpResponse(ctx.channel(), gson.toString(), format);
//				}
//			});
//		});
//	}
//
//}
