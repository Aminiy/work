package com.allstar.exception;

public class CinDatabaseConnectionException extends Exception
{
	private static final long serialVersionUID = 503520267649483257L;

	public CinDatabaseConnectionException()
	{
		super("CinDatabaseConnectionException");
	}
}
