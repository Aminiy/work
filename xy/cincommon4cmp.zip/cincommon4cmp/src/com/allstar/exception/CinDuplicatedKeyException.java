package com.allstar.exception;

public class CinDuplicatedKeyException extends Exception
{
	private static final long serialVersionUID = 503520267649483257L;

	public CinDuplicatedKeyException()
	{
		super("CinDuplicatedKeyException");
	}
}
