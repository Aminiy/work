package com.allstar.cinconfig.cintestenvotpwhitelist;

import java.util.ArrayList;
import java.util.List;

import com.allstar.cinconfig.CinSecondaryConfigInterface;
import com.allstar.cinstack.message.CinMessage;

/**
 * Development Environment Verification Code Landing Whitelist <Regardless of the development environment or the production environment, as long as the switch is turned on, users in the whitelist can use the universal OTP login>
 * 
 * @version 1.0.0
 * @date November 5, 2014 at 11:47:35
 * @see New features
 */
public class CinTestENVOTPWhiteListConfig extends CinSecondaryConfigInterface
{
	private static CinSecondaryConfigInterface _instance;
	private static List<String> testEnvOTPReceiverWhiteList = new ArrayList<String>();

	// Constructor
	public CinTestENVOTPWhiteListConfig()
	{
		_tableName = "cin_testenvotpwhitelist";
	}

	public static void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new CinTestENVOTPWhiteListConfig();
			_instance.updateConfig();
		}
	}

	@Override
	protected void setValues(List<CinMessage> configlist)
	{
		testEnvOTPReceiverWhiteList.clear();
		for (CinMessage m : configlist)
		{
			testEnvOTPReceiverWhiteList.add(m.getHeader((byte) 1).getString());
		}

		System.out.println("----->>>testEnvOTPReceiverWhiteList:" + testEnvOTPReceiverWhiteList.size());
	}

	public static List<String> getEnabledRegionList()
	{
		return testEnvOTPReceiverWhiteList;
	}
}
