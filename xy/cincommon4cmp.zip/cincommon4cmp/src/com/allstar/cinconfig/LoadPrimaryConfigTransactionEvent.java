package com.allstar.cinconfig;

import com.allstar.cinconfig.cinalarmnumber.CinAlarmNumberConfig;
import com.allstar.cinstack.handler.codec.CinMessageReader;
import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionEvent;

/**
 * Configuration module callback request CinCeter access level configuration entity class
 * 
 * 
 */
public class LoadPrimaryConfigTransactionEvent implements CinTransactionEvent
{

	@Override
	public void onResponseReceived(CinTransaction trans)
	{
		CinResponse response = trans.getResponse();
		CinConfigResult lock = (CinConfigResult) ((Object[]) trans.getAttachment())[0];
		String moduleName = (String) ((Object[]) trans.getAttachment())[1];
		CinConfigInterface config = (CinConfigInterface) ((Object[]) trans.getAttachment())[2];
		try
		{
			synchronized (lock)
			{
				if (trans.getResponse().getStatusCode() == CinResponseCode.OK)
				{
					CinConfigEntity configtable = new CinConfigEntity();
					CinMessageReader reader = new CinMessageReader();
					for (CinBody body : trans.getResponse().getBodys())
					{
						CinMessage configItem = reader.load(body.getValue());
						String configName = configItem.getHeader(CinConfig.ConfigName).getString();
						String configValue = configItem.getBody().getString();
						configtable.put(configName, configValue);
					}
					config.setValues(configtable);
					lock.setRet(true);
					config.setIsFirstLoad(false);
					System.out.println("loadPrimaryConfig onResponseOK:" + trans.getRequest() + "\r\n" + response);
				}
				else
				{
					StringBuilder sb = new StringBuilder("loadPrimaryConfig OnResponseNotOK.");
					sb.append("ServiceName:");
					sb.append(CinConfigure.serviceName);
					sb.append(".ComputerName:");
					sb.append(CinConfigure.computerName);
					sb.append(".ModuleName:");
					sb.append(moduleName);
					CinAlarmNumberConfig.sendAlarmSms(sb.toString());
					System.out.println("loadTable onResponseNotOK:" + trans.getRequest() + "\r\n" + response);
				}
				lock.notify();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			StringBuilder sb = new StringBuilder("loadPrimaryConfig Exception.");
			sb.append("ServiceName:");
			sb.append(CinConfigure.serviceName);
			sb.append(".ComputerName:");
			sb.append(CinConfigure.computerName);
			sb.append(".ModuleName:");
			sb.append(moduleName);
			sb.append("\r\n request:");
			sb.append(trans.getRequest());
			sb.append("\r\n response:");
			sb.append(trans.getResponse());
			System.out.println(sb.toString());
			CinAlarmNumberConfig.sendAlarmSms("loadPrimaryConfig Exception:" + "serviceName:" + CinConfigure.serviceName + ".ComputerName:" + CinConfigure.computerName);
			synchronized (lock)
			{
				lock.notify();
			}
		}
	}

	@Override
	public void onRequestSentFailed(CinTransaction transaction)
	{
		CinConfigResult lock = (CinConfigResult) ((Object[]) transaction.getAttachment())[0];
		String moduleName = (String) ((Object[]) transaction.getAttachment())[1];
		try
		{
			StringBuilder sb = new StringBuilder("loadPrimaryConfig onSendFailed.");
			synchronized (lock)
			{

				sb.append("ServiceName:");
				sb.append(CinConfigure.serviceName);
				sb.append(".ComputerName:");
				sb.append(CinConfigure.computerName);
				sb.append(".ModuleName:");
				sb.append(moduleName);
				sb.append("\r\n request:");
				sb.append(transaction.getRequest());

				lock.notify();

			}
			System.out.println(sb.toString());
			CinAlarmNumberConfig.sendAlarmSms("loadPrimaryConfig onSendFailed :" + "serviceName:" + CinConfigure.serviceName + ".ComputerName:" + CinConfigure.computerName);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			CinAlarmNumberConfig.sendAlarmSms("loadPrimaryConfig onSendFailed Exception:" + "serviceName:" + CinConfigure.serviceName + ".ComputerName:" + CinConfigure.computerName);
			synchronized (lock)
			{
				lock.notify();
			}

		}
	}

	@Override
	public void onRequestSentTimeout(CinTransaction transaction)
	{
		CinConfigResult lock = (CinConfigResult) ((Object[]) transaction.getAttachment())[0];
		String moduleName = (String) ((Object[]) transaction.getAttachment())[1];
		try
		{
			StringBuilder sb = new StringBuilder("loadPrimaryConfig onTimeout.");
			synchronized (lock)
			{
				sb.append("ServiceName:");
				sb.append(CinConfigure.serviceName);
				sb.append(".ComputerName:");
				sb.append(CinConfigure.computerName);
				sb.append(".ModuleName:");
				sb.append(moduleName);
				sb.append("\r\n request:");
				sb.append(transaction.getRequest());

				lock.notify();
			}
			System.out.println(sb.toString());
			CinAlarmNumberConfig.sendAlarmSms("loadPrimaryConfig onTimeout :" + "serviceName:" + CinConfigure.serviceName + ".ComputerName:" + CinConfigure.computerName);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			CinAlarmNumberConfig.sendAlarmSms("loadPrimaryConfig onTimeout Exception:" + "serviceName:" + CinConfigure.serviceName + ".ComputerName:" + CinConfigure.computerName);
			synchronized (lock)
			{
				lock.notify();
			}
		}
	}
}
