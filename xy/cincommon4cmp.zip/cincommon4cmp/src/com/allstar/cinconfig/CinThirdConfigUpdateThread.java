package com.allstar.cinconfig;

/**
 * Update the secondary configuration thread
 * 
 * 
 */
public class CinThirdConfigUpdateThread extends Thread
{
	CinThirdConfigInterface _config;

	CinThirdConfigUpdateThread(CinThirdConfigInterface config)
	{
		_config = config;
	}

	@Override
	public void run()
	{
		_config.loadConfig();
	}
}
