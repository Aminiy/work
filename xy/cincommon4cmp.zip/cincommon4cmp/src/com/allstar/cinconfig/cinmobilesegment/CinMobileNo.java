package com.allstar.cinconfig.cinmobilesegment;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import com.allstar.cinutil.CinTextUtil;

public class CinMobileNo
{
	private String _prefix;

	private String _value;

	private boolean _isValidMobileNo = false;

	public String getPrefix()
	{
		return _prefix;
	}

	public boolean isValidMobileNo()
	{
		return _isValidMobileNo;
	}

	public String getValue()
	{
		return _value;
	}

	@Override
	public String toString()
	{
		if (!_isValidMobileNo)
			return CinTextUtil.EmptyString;

		StringBuffer sb = new StringBuffer();
		if (!_prefix.equals(CinTextUtil.EmptyString))
			sb.append(_prefix);
		else
			sb.append(CinMobileRegular.getDefaultPrefix());
		sb.append(_value);
		return sb.toString();
	}

	public CinMobileNo(String mobileno)
	{
		this(mobileno, null);
	}

	public CinMobileNo(String mobileno, String prefix)
	{
		try
		{
			// Parameter Check
			// Parameter check
			if (null == mobileno || "".equals(mobileno.trim()) || mobileno.trim().length() < 5)
			{
				return;
			}

			// Remove the space and format the mobile to start with '+'.
			// Format numbers as '+'
			mobileno = mobileno.trim();
			if (mobileno.startsWith("00"))
			{
				mobileno = "+" + mobileno.substring(2);
			}

			// <Prefix, Mobile>_<"+91","7081052186">
			// Cache all possible country prefix and number correspondences
			Map<String, String> possiblePrefix = new HashMap<String, String>();
			if (!mobileno.startsWith("+"))
			{
				if (prefix == null)
				{
					possiblePrefix.put(CinMobileRegular.getDefaultPrefix(), mobileno);
				}
				else if (CinMobileRegular.prefixAllowed(prefix))
				{
					possiblePrefix.put(prefix, mobileno);
				}
				else
				{
					return;
				}
			}
			else
			{
				// At present, the longest prefix is ​​4 digits
				for (int i = 2; i < 6; i++)
				{
					prefix = mobileno.substring(0, i);
					if (CinMobileRegular.prefixAllowed(prefix))
					{
						possiblePrefix.put(prefix, mobileno.substring(i));
					}
				}
			}

			// Traverse the Map in a variety of possible encounter the first one is correct exit
			if (!possiblePrefix.isEmpty())
			{
				Iterator<Entry<String, String>> it = possiblePrefix.entrySet().iterator();
				while (!_isValidMobileNo && it.hasNext())
				{
					Entry<String, String> e = it.next();
					_prefix = e.getKey();
					_value = e.getValue();
					_isValidMobileNo = CinMobileRegular.checkRegular(_prefix, _value);
				}
			}

			// If all verification fails, reset the variable value
			if (!_isValidMobileNo)
			{
				_prefix = null;
				_value = null;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			System.out.println("The Paremters is mobileno: " + mobileno + " prefix is: " + prefix);
			_isValidMobileNo = false;
			_value = null;
			_prefix = null;
		}
	}
}
