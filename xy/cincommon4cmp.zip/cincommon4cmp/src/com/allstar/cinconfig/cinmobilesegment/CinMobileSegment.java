package com.allstar.cinconfig.cinmobilesegment;

public class CinMobileSegment
{
	public long start;

	public long end;

	public boolean isOwnCarrier(long mobileno)
	{
		return (mobileno >= start) && (mobileno < end);
	}
}
