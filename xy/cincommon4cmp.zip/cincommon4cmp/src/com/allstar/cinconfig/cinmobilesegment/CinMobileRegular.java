package com.allstar.cinconfig.cinmobilesegment;

import java.util.HashMap;
import java.util.List;

import com.allstar.cinconfig.CinSecondaryConfigInterface;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinutil.CinUtil;

public class CinMobileRegular extends CinSecondaryConfigInterface
{
	private final static String defaultPrefix = "+91";
	
	private static CinSecondaryConfigInterface _instance;
	private static HashMap<String, String> default_regular = new HashMap<String, String>();
	private static HashMap<String, Byte> prefixmap = new HashMap<String, Byte>();
	

	public static void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new CinMobileRegular();
			_instance.updateConfig();
		}
	}

	public CinMobileRegular()
	{
		_tableName = "cin_mobileno_regular";
	}

	@Override
	protected void setValues(List<CinMessage> configlist)
	{
		for (CinMessage m : configlist)
		{
			String defaultPrefix = m.getHeader((byte) 0x02).getString();
			default_regular.put(defaultPrefix, m.getHeader((byte) 0x03).getString());
			prefixmap.put(defaultPrefix, m.getHeader((byte) 0x04).getValue()[0]);
		}
	}

	public static boolean checkRegular(String prefix, String value)
	{
		return default_regular.containsKey(prefix) && CinUtil.checkRegular(default_regular.get(prefix), value);
	}

	public static String getDefaultPrefix()
	{
		return defaultPrefix;
	}

	public static boolean prefixAllowed(String prefix)
	{
		return default_regular.containsKey(prefix);
	}

	public static boolean hasPrefix(String prefix)
	{
		return prefixmap.containsKey(prefix);
	}

	public static byte getPrefix(String prefix)
	{
		return prefixmap.get(prefix);
	}

}
