package com.allstar.cinconfig.cinmobilesegment;

import java.util.ArrayList;
import java.util.List;

import com.allstar.cinconfig.CinSecondaryConfigInterface;
import com.allstar.cinstack.message.CinMessage;

public class CinMobileSegmentConfig extends CinSecondaryConfigInterface
{
	private static List<CinMobileSegment> segmentlist = new ArrayList<CinMobileSegment>();

	public CinMobileSegmentConfig()
	{
		_tableName = "cin_mobilesegment";
	}

	@Override
	protected void setValues(List<CinMessage> configlist)
	{
		segmentlist.clear();

		for (CinMessage m : configlist)
		{
			CinMobileSegment seg = new CinMobileSegment();
			seg.start = m.getHeader((byte) 1).getInt64();
			seg.end = m.getHeader((byte) 2).getInt64();
			segmentlist.add(seg);
		}

	}

	private static CinSecondaryConfigInterface _instance;

	public static void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new CinMobileSegmentConfig();
			_instance.updateConfig();
		}
	}

	public static boolean isOwnCarrier(long mobileno)
	{
		for (CinMobileSegment s : segmentlist)
		{
			if (s.isOwnCarrier(mobileno))
				return true;
		}
		return false;
	}
}
