package com.allstar.cinconfig.cinmobilesegment;

import java.util.HashMap;


// Defined as shown in the
// https://en.wikipedia.org/wiki/List_of_country_calling_codes
public class CinDialPrefix
{
	private static HashMap<String, String> _countryMap = new HashMap<String, String>();

	static
	{
		_countryMap.put(1 + "", null);// USA CANADA
		_countryMap.put(7 + "", null);// RUSSIA

		_countryMap.put(20 + "", null);// AGYPT
		_countryMap.put(27 + "", null);// SOUTH AFRICA

		for (int i = 210; i <= 299; i++)
		{
			_countryMap.put(i + "", null);// AFRICA
		}

		for (int i = 30; i <= 34; i++)
		{
			_countryMap.put(i + "", null);// EUROPE
		}

		for (int i = 350; i <= 359; i++)
		{
			_countryMap.put(i + "", null);// EUROPE
		}

		_countryMap.put(36 + "", null);// EUROPE

		for (int i = 38; i <= 49; i++)
		{
			_countryMap.put(i + "", null);// EUROPE
		}

		for (int i = 370; i <= 389; i++)
		{
			_countryMap.put(i + "", null);// EUROPE
		}

		for (int i = 420; i <= 429; i++)
		{
			_countryMap.put(i + "", null);// EUROPE
		}

		for (int i = 51; i <= 58; i++)
		{
			_countryMap.put(i + "", null);
		}

		for (int i = 500; i <= 509; i++)
		{
			_countryMap.put(i + "", null);
		}

		for (int i = 590; i <= 599; i++)
		{
			_countryMap.put(i + "", null);
		}

		for (int i = 60; i <= 66; i++)
		{
			_countryMap.put(i + "", null);
		}

		for (int i = 670; i <= 699; i++)
		{
			_countryMap.put(i + "", null);
		}

		_countryMap.put(81 + "", null);
		_countryMap.put(82 + "", null);
		_countryMap.put(84 + "", null);
		_countryMap.put(86 + "", null);

		for (int i = 850; i <= 859; i++)
		{
			_countryMap.put(i + "", null);
		}
		_countryMap.put(880 + "", null);
		_countryMap.put(886 + "", null);

		for (int i = 90; i <= 95; i++)
		{
			_countryMap.put(i + "", null);
		}

		for (int i = 960; i <= 977; i++)
		{
			_countryMap.put(i + "", null);
		}

		_countryMap.put(98 + "", null);

		for (int i = 992; i <= 998; i++)
		{
			_countryMap.put(i + "", null);
		}

	}

	public static boolean isExist(String prefix)
	{
		return _countryMap.containsKey(prefix);
	}

}
