package com.allstar.cinconfig;

import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionCreatedEvent;
import com.allstar.cinutil.CinCounter;

/**
 * Each service to monitor CinCenter requests for service system resources occupancy
 * 
 * 
 */
public class MonitorTransactionCreated implements CinTransactionCreatedEvent
{

	@Override
	public void onCinTransactionCreated(CinTransaction trans)
	{
		CinRequest request = trans.getRequest();
		CinResponse response = new CinResponse(request);
		response.addBody(new CinBody(CinCounter.getAllCounterInfo()));
		trans.sendResponse(response);
	}

}
