package com.allstar.cinconfig;

import java.util.Set;

import com.allstar.cinutil.CinEnhancedHashMap;

/**
 * Class for Configuration entity
 * 
 * 
 */
public class CinConfigEntity
{
	private CinEnhancedHashMap<String, String> _configtable;

	/**
	 * The constructor
	 */
	public CinConfigEntity()
	{
		_configtable = new CinEnhancedHashMap<String, String>();
	}

	/**
	 * Add the key/value pair objects
	 * 
	 * @param key
	 * @param value
	 */
	public void put(String key, String value)
	{
		_configtable.put(key, value);
	}

	/**
	 * Access to key corresponding to the configuration values
	 * 
	 * @param key
	 * @return Value of the configuration in string format
	 */
	public String get(String key)
	{
		return _configtable.get(key);
	}

	/**
	 * Access to key corresponding configuration values, if there is no return
	 * to the default value
	 * 
	 * @param key
	 * @param defaultvalue
	 * @return Value of the configuration in string format, if no value found,
	 *         the default value should be taken
	 */
	public String get(String key, String defaultvalue)
	{
		return _configtable.get(key, defaultvalue);
	}

	public Set<String> getKeySet()
	{
		return _configtable.keySet();
	}
}
