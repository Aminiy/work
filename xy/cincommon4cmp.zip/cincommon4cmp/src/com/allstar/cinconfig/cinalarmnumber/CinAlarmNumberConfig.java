package com.allstar.cinconfig.cinalarmnumber;

import java.util.ArrayList;
import java.util.List;

import com.allstar.cinconfig.CinSecondaryConfigInterface;
import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.event.CinSmsEvent;

/**
 * The secondary configuration - alarm message entity class
 * 
 * 
 */
public class CinAlarmNumberConfig extends CinSecondaryConfigInterface
{
	private static CinSecondaryConfigInterface _instance;
	private static List<Long> _numbers = new ArrayList<Long>();

	public static void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new CinAlarmNumberConfig();
			_instance.updateConfig();
		}
	}

	public CinAlarmNumberConfig()
	{
		_tableName = "cin_alarmnumber";
	}

	@Override
	protected void setValues(List<CinMessage> configlist)
	{
		_numbers.clear();
		for (CinMessage msg : configlist)
		{
			_numbers.add(msg.getHeader((byte) 0x01).getInt64());
		}
	}

	/**
	 * Send alarm SMS messages
	 * 
	 * @param msg
	 */
	public static void sendAlarmSms(String msg)
	{
		try
		{
			CinRequest req = new CinRequest(CinRequestMethod.SMS);
			req.addHeader(new CinHeader(CinHeaderType.From, 999));
			req.addHeader(new CinHeader(CinHeaderType.Event, CinSmsEvent.MTWITHChildNR));
			req.addBody(new CinBody(msg));
			for (Long num : _numbers)
			{
				CinRequest tosend = req.clone();
				CinRouter.setRoute(tosend, CinServiceName.SmsAdapter);
				tosend.addHeader(new CinHeader(CinHeaderType.To, num.longValue()));
				CinStack.instance().createTransaction(tosend).sendRequest();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
