package com.allstar.cinconfig;

import java.util.List;

import com.allstar.cinconfig.cinalarmnumber.CinAlarmNumberConfig;
import com.allstar.cinstack.handler.codec.CinMessageReader;
import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionEvent;

/**
 * Configuration module request CinCeter secondary configuration for callback
 * entity class
 * 
 * 
 */
public class LoadSecondaryConfigTransactionEvent implements CinTransactionEvent
{
	@Override
	public void onResponseReceived(CinTransaction trans)
	{
		CinResponse response = trans.getResponse();
		CinConfigResult lock = (CinConfigResult) ((Object[]) trans.getAttachment())[0];
		@SuppressWarnings("unchecked")
		List<CinMessage> msglist = (List<CinMessage>) ((Object[]) trans.getAttachment())[1];
		CinSecondaryConfigInterface config = (CinSecondaryConfigInterface) ((Object[]) trans.getAttachment())[2];
		try
		{
			synchronized (lock)
			{
				if (trans.getResponse().getStatusCode() == CinResponseCode.OK)
				{
					for (CinBody body : trans.getResponse().getBodys())
					{
						CinMessage msg = CinMessageReader.parse(body.getValue());
						msglist.add(msg);
					}

					config.setValues(msglist);
					lock.setRet(true);
					config.setIsFirstLoad(false);
					System.out.println("loadSecondaryConfig onResponseOK:" + trans.getRequest() + "\r\n" + response);
				}
				else
				{
					StringBuilder sb = new StringBuilder("loadSecondaryConfig onResponseNotOK:");
					sb.append("ServiceName:");
					sb.append(CinConfigure.serviceName);
					sb.append(".ComputerName:");
					sb.append(CinConfigure.computerName);
					System.out.println("loadSecondaryConfig onResponseNotOK:" + trans.getRequest() + "\r\n" + response);
					CinAlarmNumberConfig.sendAlarmSms(sb.toString());

				}
				lock.notify();
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();

			StringBuilder sb = new StringBuilder("loadSecondaryConfig Exception.");
			sb.append("ServiceName:");
			sb.append(CinConfigure.serviceName);
			sb.append(".ComputerName:");
			sb.append(CinConfigure.computerName);
			sb.append("\r\n request:");
			sb.append(trans.getRequest());
			sb.append("\r\n response:");
			sb.append(trans.getResponse());
			System.out.println(sb.toString());

			CinAlarmNumberConfig.sendAlarmSms("loadSecondaryConfig Exception:" + "serviceName:" + CinConfigure.serviceName + ".ComputerName:" + CinConfigure.computerName);

			e.printStackTrace();
			synchronized (lock)
			{
				lock.notify();
			}
		}
	}

	@Override
	public void onRequestSentFailed(CinTransaction transaction)
	{
		CinConfigResult lock = (CinConfigResult) ((Object[]) transaction.getAttachment())[0];
		StringBuilder sb = new StringBuilder("loadSecondaryConfig onSendFailed.");
		synchronized (lock)
		{
			sb.append("ServiceName:");
			sb.append(CinConfigure.serviceName);
			sb.append(".ComputerName:");
			sb.append(CinConfigure.computerName);
			sb.append("\r\n Request:");
			sb.append(transaction.getRequest());

			lock.notify();
		}
		System.out.println(sb.toString());
		CinAlarmNumberConfig.sendAlarmSms("loadSecondaryConfig onSendFailed:" + "serviceName:" + CinConfigure.serviceName + ".ComputerName:" + CinConfigure.computerName);
	}

	@Override
	public void onRequestSentTimeout(CinTransaction transaction)
	{
		CinConfigResult lock = (CinConfigResult) ((Object[]) transaction.getAttachment())[0];

		StringBuilder sb = new StringBuilder("loadSecondaryConfig onTimeout.");
		synchronized (lock)
		{
			sb.append("ServiceName:");
			sb.append(CinConfigure.serviceName);
			sb.append(".ComputerName:");
			sb.append(CinConfigure.computerName);
			sb.append("\r\n Request:");
			sb.append(transaction.getRequest());
			lock.notify();
		}
		System.out.println(sb.toString());
		CinAlarmNumberConfig.sendAlarmSms("loadSecondaryConfig onTimeout:" + "serviceName:" + CinConfigure.serviceName + ".ComputerName:" + CinConfigure.computerName);
	}
}
