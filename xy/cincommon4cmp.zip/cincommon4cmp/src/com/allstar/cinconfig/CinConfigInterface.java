package com.allstar.cinconfig;

/**
 * Define each service and module level configuration of an abstract class
 * 
 * 
 */
public abstract class CinConfigInterface
{
	protected String _tableName = CinConfigure.serviceName;
	private boolean _isFirstLoad = true;

	/**
	 * Set the value of the primary configuration.<br>
	 * This method is after the service is initialized to CinCenter access
	 * configuration data after the callback is called</br>
	 * 
	 * @param config
	 */
	protected abstract void setValues(CinConfigEntity config);

	/**
	 * Update the level of configuration
	 */
	public void updateConfig()
	{
		CinConfigUpdateThread cinConfigUpdateThread = new CinConfigUpdateThread(this);
		cinConfigUpdateThread.start();

//		if (!(Thread.currentThread() instanceof CinMessageHandleWorker) && !(Thread.currentThread() instanceof CinSelector) && !(Thread.currentThread() instanceof SendThread))
//		{
			try
			{
				cinConfigUpdateThread.join();
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
//		}
	}

	/**
	 * Set up the module name, is to obtain the level of configuration
	 * identification
	 * 
	 * @param tableName
	 */
	public void setTableName(String tableName)
	{
		_tableName = tableName;
	}

	/**
	 * To determine whether access level configuration or reload level
	 * configuration for the first time
	 * 
	 * @return true: if the configuration is loaded for the first time</br>
	 *         false: when the configuration has been loaded before and is
	 *         reloaded now.
	 */
	public boolean isFirstLoad()
	{
		return _isFirstLoad;
	}

	/**
	 * Set is the first time for level 1 configuration
	 * 
	 * @param isFirstLoad
	 */
	public void setIsFirstLoad(boolean isFirstLoad)
	{
		_isFirstLoad = isFirstLoad;
	}

	/**
	 * Access level configuration
	 */
	public void loadConfig()
	{
		CinConfig.loadPrimaryConfig(_tableName, this);
	}
}
