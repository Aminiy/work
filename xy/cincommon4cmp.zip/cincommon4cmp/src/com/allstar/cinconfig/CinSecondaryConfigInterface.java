package com.allstar.cinconfig;

import java.util.List;

import com.allstar.cinstack.message.CinMessage;

/**
 * Define each service and secondary configuration module abstract classes
 * 
 * 
 */
public abstract class CinSecondaryConfigInterface
{
	protected String _tableName;
	private boolean _isFirstLoad = true;

	/**
	 * Set the value of the secondary configuration.<br>
	 * This method is after the service is initialized to CinCenter access configuration data after the callback is called</br>
	 * 
	 * @param configlist
	 */
	protected abstract void setValues(List<CinMessage> configlist);

	/**
	 * Update the secondary configuration
	 */
	public void updateConfig()
	{
		CinSecondaryConfigUpdateThread cinSecondaryConfigUpdateThread = new CinSecondaryConfigUpdateThread(this);
		cinSecondaryConfigUpdateThread.start();
//		if (!(Thread.currentThread() instanceof CinMessageHandleWorker) && !(Thread.currentThread() instanceof CinSelector) && !(Thread.currentThread() instanceof SendThread))
//		{
			try
			{
				cinSecondaryConfigUpdateThread.join();
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
//		}
//		else
//		{
//			System.out.println("Sencondary Config Thread Still Running");
//			System.out.println(Thread.currentThread().getClass().getCanonicalName());
//
//		}
	}

	/**
	 * Determine whether it is the first time for the secondary configuration or refresh the secondary configuration
	 * 
	 * @return
	 */
	public boolean isFirstLoad()
	{
		return _isFirstLoad;
	}

	/**
	 * Set is the first time to obtain the secondary configuration
	 * 
	 * @param isFirstLoad
	 */
	public void setIsFirstLoad(boolean isFirstLoad)
	{
		this._isFirstLoad = isFirstLoad;
	}

	/**
	 * To obtain the secondary configuration
	 */
	public void loadConfig()
	{
		CinConfig.loadSecondaryConfig(_tableName, this);
	}
}
