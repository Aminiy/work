package com.allstar.cinconfig.cinswf;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cinconfig.CinSecondaryConfigInterface;
import com.allstar.cinstack.message.CinMessage;

public class CinSensitiveWordFilter extends CinSecondaryConfigInterface
{
	private static ConcurrentHashMap<Byte, List<SensitiveWord>> _wordsfilter = new ConcurrentHashMap<Byte, List<SensitiveWord>>();
	private static CinSecondaryConfigInterface _instance;

	public CinSensitiveWordFilter()
	{
		_tableName = "cin_wordfilter";
	}

	/**
	 * initialize
	 * 
	 * @throws Exception
	 */
	public static void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new CinSensitiveWordFilter();
			_instance.updateConfig();
		}

	}

	public static SensitiveWord[] getFilter(byte type)
	{
		SensitiveWord[] sw = null;
		if (_wordsfilter.get(type) != null)
			sw = _wordsfilter.get(type).toArray(new SensitiveWord[_wordsfilter.get(type).size()]);
		return sw;
	}

	@Override
	protected void setValues(List<CinMessage> configlist)
	{
		try
		{
			_wordsfilter = new ConcurrentHashMap<Byte, List<SensitiveWord>>();
			for (byte t : SensitiveWordsFilterType.getTypeList())
			{
				_wordsfilter.put(t, new ArrayList<SensitiveWord>());
			}

			// filtertype,filtermode,word,relatedword,treatment
			for (int i = 0; i < configlist.size(); i++)
			{
				CinMessage m = configlist.get(i);

				byte mode = m.getHeader((byte) 2).getValue()[0];
				String word = m.containsHeader((byte) 3) ? m.getHeader((byte) 3).getString().toLowerCase() : "";
				String relateWords = m.containsHeader((byte) 4) ? m.getHeader((byte) 4).getString().toLowerCase() : "";
				int treatMent = m.getHeader((byte) 5).getValue()[0];

				SensitiveWord w = new SensitiveWord(i, word, mode, relateWords, treatMent);

				byte type = m.getHeader((byte) 1).getValue()[0];
				for (Byte b : _wordsfilter.keySet())
				{
					if ((type & b) == b)
					{
						_wordsfilter.get(b).add(w);
					}
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
