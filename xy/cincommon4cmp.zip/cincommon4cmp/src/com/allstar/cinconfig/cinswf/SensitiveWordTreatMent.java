package com.allstar.cinconfig.cinswf;

/**
 * When found after the treatment of sensitive words
 * 
 * 
 */
public class SensitiveWordTreatMent
{
	public static final int BLOCK_AND_KICKOFF = 10;// Stop and kick off the line?
	public static final int BLOCK_AND_REMIDER = 20; // Block and prompt
	public static final int BLOCK = 30; // prevent
	public static final int SUFFIX = 40;// Literal translation: plus suffix
	public static final int LOG_ONLY = 50;// Do not stop, only log

	public static String getName(int code)
	{
		switch (code)
		{
			case BLOCK_AND_KICKOFF:
				return "BLOCK_AND_KICKOFF";
			case BLOCK_AND_REMIDER:
				return "BLOCK_AND_REMIDER";
			case BLOCK:
				return "BLOCK";
			case SUFFIX:
				return "SUFFIX";
			case LOG_ONLY:
				return "LOG_ONLY";
			default:
				return "UNKOWN";
		}
	}
}
