package com.allstar.cinconfig.cinswf;

public class SensitiveWordsFilterMode
{
	public static final byte UNASSIGNED = 0X00;
	public static final byte EXACT = 0x01;
	public static final byte PHRASE = 0x02;
	public static final byte FILTERED = 0x04; // filter
	public static final byte COMPOSITE = 0x08;// Composite mode
	public static final byte LANGUAGE = 0x10;
	public static final byte RELATEDWORD = 0x40;

	public static byte valueOf(String str)
	{
		String s = str.toUpperCase();
		if (s.equals("EXACT"))
			return EXACT;
		else
			if (s.equals("PHRASE"))
				return PHRASE;
			else
				if (s.equals("FILTERED"))
					return FILTERED;
				else
					if (s.equals("COMPOSITE"))
						return COMPOSITE;
					else
						if (s.equals("LANGUAGE"))
							return LANGUAGE;
						else
							return UNASSIGNED;
	}

	public static String getName(byte code)
	{
		switch (code)
		{
			case UNASSIGNED:
				return "UNASSIGNED";
			case EXACT:
				return "EXACT";
			case PHRASE:
				return "PHRASE";
			case FILTERED:
				return "FILTERED";
			case COMPOSITE:
				return "COMPOSITE";
			case LANGUAGE:
				return "LANGUAGE";
			case RELATEDWORD:
				return "RELATEDWORD";
			default:
				return "UNKOWN";
		}
	}
}
