package com.allstar.cinconfig.cinswf;

public class SensitiveWord implements Cloneable
{
	private int _id;
	private String _word;
	private byte _mode;
	private String _relateWords;
	private int _treatMent;
	private byte _count;

	public SensitiveWord(int id, String word, byte mode, String relateWords, int treatMent)
	{
		_id = id;
		_word = word;
		_mode = mode;
		_relateWords = relateWords;
		_treatMent = treatMent;
	}

	public void setCount(byte count)
	{
		_count = count;
	}

	public int getId()
	{
		return _id;
	}

	public String getWord()
	{
		return _word;
	}

	public byte getMode()
	{
		return _mode;
	}

	public String getRelatedWords()
	{
		return _relateWords;
	}

	public int getTreatment()
	{
		return _treatMent;
	}

	public byte getCount()
	{
		return _count;
	}

	public boolean hasRelatedWord()
	{
		return _relateWords != null && !_relateWords.isEmpty();
	}

	@Override
	public SensitiveWord clone()
	{
		return cloneWithoutWord(_word);
	}

	public SensitiveWord cloneWithoutWord(char value)
	{
		return cloneWithoutWord(String.valueOf(value));
	}

	public SensitiveWord cloneWithoutWord(String word)
	{
		SensitiveWord n = new SensitiveWord(_id, word, _mode, _relateWords, _treatMent);
		n.setCount(_count);
		return n;
	}

	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("ID: ");
		sb.append(_id);
		sb.append(";Value: ");
		sb.append(_word);
		sb.append("; Mode: ");
		sb.append(SensitiveWordsFilterMode.getName(_mode));
		sb.append("; RelatedWord: ");
		sb.append(_relateWords);
		sb.append("; TreatMent: ");
		sb.append(SensitiveWordTreatMent.getName(_treatMent));
		sb.append("; Count: ");
		sb.append(_count);
		return sb.toString();
	}
}
