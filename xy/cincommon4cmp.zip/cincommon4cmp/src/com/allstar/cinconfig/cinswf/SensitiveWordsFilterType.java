package com.allstar.cinconfig.cinswf;

import java.util.ArrayList;
import java.util.List;

public class SensitiveWordsFilterType
{
	public static final byte UNASSIGNED = 0x00;
	public static final byte PERSONALINFO = 0x01;
	public static final byte GROUPINFO = 0x02;
	public static final byte INVITEMESSAGE = 0x04;
	public static final byte DIALOGMESSAGE = 0x08;
	public static final byte GROUPMESSAGE = 0x10;
	public static final byte SMS = 0x20;
	public static final byte IMPRESA = 0x40;

	private static List<Byte> _typelist;

	static
	{
		_typelist = new ArrayList<Byte>();
		_typelist.add(UNASSIGNED);
		_typelist.add(PERSONALINFO);
		_typelist.add(GROUPINFO);
		_typelist.add(INVITEMESSAGE);
		_typelist.add(DIALOGMESSAGE);
		_typelist.add(GROUPMESSAGE);
		_typelist.add(SMS);
		_typelist.add(IMPRESA);
	}

	public static List<Byte> getTypeList()
	{
		return _typelist;
	}

	// static final byte ALL = UNASSIGNED & PERSONALINFO & GROUPINFO &
	// INVITEMESSAGE & DIALOGMESSAGE & GROUPMESSAGE & SMS & IMPRESA;

	public static String getName(byte code)
	{
		switch (code)
		{
			case UNASSIGNED:
				return "UNASSIGNED";
			case PERSONALINFO:
				return "PERSONALINFO";
			case GROUPINFO:
				return "GROUPINFO";
			case INVITEMESSAGE:
				return "INVITEMESSAGE";
			case DIALOGMESSAGE:
				return "DIALOGMESSAGE";
			case GROUPMESSAGE:
				return "GROUPMESSAGE";
			case SMS:
				return "SMS";
			case IMPRESA:
				return "IMPRESA";
			default:
				return "UNKOWN";
		}
	}
}
