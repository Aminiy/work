package com.allstar.cinconfig.cinnav;

import java.util.Random;

import com.allstar.cinutil.CinTextUtil;

public class CinNav
{
	private static Random r = new Random();

	private long id;
	private String clienttype;
	private String clientversion;
	private String keyword;
	private String[] values;// CMP IP PORT

	public long getId()
	{
		return id;
	}

	public void setId(long id)
	{
		this.id = id;
	}

	public String getClienttype()
	{
		return clienttype;
	}

	public void setClienttype(String clienttype)
	{
		this.clienttype = clienttype;
	}

	public String getClientversion()
	{
		return clientversion;
	}

	public void setClientversion(String clientversion)
	{
		this.clientversion = clientversion;
	}

	public String getKeyword()
	{
		return keyword;
	}

	public void setKeyword(String keyword)
	{
		this.keyword = keyword;
	}

	public String getValue()
	{
		// Configure multiple CMP addresses, separated by ";" SetValue is the time to open up multiple addresses, and then getValue is a randomly selected
		// Extracting method Currently tentatively random If more than one equipment room is deployed or multi-access, modify the extraction rule needs to be adjusted according to the source IP
		int rand = r.nextInt(values.length);
		return values[rand];
	}

	public void setValue(String value)
	{
		this.values = value.split(CinTextUtil.SEMICOLON);
	}

}
