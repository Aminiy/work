package com.allstar.cinconfig.cinnav;

import java.util.HashMap;
import java.util.List;

import com.allstar.cinconfig.CinSecondaryConfigInterface;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cintracer.CinTracer;

public class CinClientUpdateConfig extends CinSecondaryConfigInterface
{
	private static CinTracer tracer = CinTracer.getInstance(CinClientUpdateConfig.class);
	private static CinSecondaryConfigInterface _instance;
	private static HashMap<String, CinClientUpdate> clientUpdateMap = new HashMap<String, CinClientUpdate>();
	private static HashMap<String, CinClientUpdate> newClientUpdateMap = new HashMap<String, CinClientUpdate>();

	private static byte id = 1;
	private static byte clienttype = 2;
	private static byte clientversion = 3;
	private static byte updatetype = 4;
	private static byte updateversion = 5;
	private static byte downloadurl = 6;
	private static byte detailpageurl = 7;
	private static byte packagesize = 8;
	private static byte releasetime = 9;

	public CinClientUpdateConfig()
	{
		_tableName = "cin_clientupdate";
	}

	public static void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new CinClientUpdateConfig();
			_instance.updateConfig();
		}
	}

	@Override
	protected void setValues(List<CinMessage> configlist)
	{
		clientUpdateMap.clear();
		tracer.info("Load NAV-clientupdate Data Start...");
		for (CinMessage m : configlist)
		{
			CinClientUpdate update = new CinClientUpdate();
			update.setId(m.getHeader(id).getInt64());
			update.setClienttype(m.getHeader(clienttype).getString());
			update.setClientversion(m.getHeader(clientversion).getString());
			update.setUpdatetype((int) m.getHeader(updatetype).getInt64());
			update.setUpdateversion(m.getHeader(updateversion).getString());
			update.setDownloadurl(m.getHeader(downloadurl).getString());
			update.setDetailpageurl(m.getHeader(detailpageurl).getString());
			update.setPackagesize(m.getHeader(packagesize).getInt64());
			update.setReleasetime(m.getHeader(releasetime).getString());

			clientUpdateMap.put(update.getClienttype() + update.getClientversion(), update);

			if (update.getUpdatetype() == 3)
				newClientUpdateMap.put(update.getClienttype(), update);

			tracer.info("[Nav]-->>ClientUpdate:id=" + update.getId() + ",clienttype=" + update.getClienttype() + ",clientversion=" + update.getClientversion() + ",updatetype=" + update.getUpdatetype() + ",updateversion=" + update.getUpdateversion() + ",downloadurl=" + update.getDownloadurl() + ",detailpageurl=" + update.getDetailpageurl() + ",packagesize=" + update.getPackagesize() + ",releasetime=" + update.getReleasetime());

		}
		tracer.info("Load NAV-clientupdate Data End..." + clientUpdateMap.size());
	}

	/**
	 * @param key
	 *            like type+version:ios1.0.0000
	 * @return
	 */
	public static CinClientUpdate getClientUpdate(String key)
	{
		return clientUpdateMap.get(key);
	}

	/**
	 * @param clientType
	 *            like ios
	 * @return
	 */
	public static CinClientUpdate getNewClient(String clientType)
	{
		return newClientUpdateMap.get(clientType);
	}
}
