package com.allstar.cinconfig.cinnav;

import java.util.List;

import com.allstar.cinconfig.CinSecondaryConfigInterface;
import com.allstar.cinstack.message.CinMessage;

public class CinRegionListConfig extends CinSecondaryConfigInterface
{
	private static CinSecondaryConfigInterface _instance;

	private static List<CinMessage> _regionlist;

	// Constructor
	public CinRegionListConfig()
	{
		_tableName = "cin_regionlist";
	}

	public static void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new CinRegionListConfig();
			_instance.updateConfig();
		}
	}

	@Override
	protected void setValues(List<CinMessage> configlist)
	{
		_regionlist = configlist;
	}

	public static List<CinMessage> getEnabledRegionList()
	{
		return _regionlist;
	}
}
