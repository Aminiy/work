package com.allstar.cinconfig.cinnav;

import java.util.HashMap;
import java.util.List;

import com.allstar.cinconfig.CinSecondaryConfigInterface;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cintracer.CinTracer;

public class CinNavConfig extends CinSecondaryConfigInterface
{
	private static CinSecondaryConfigInterface _instance;
	private static HashMap<String, CinNav> navMap = new HashMap<String, CinNav>();
	private static CinTracer tracer = CinTracer.getInstance(CinNavConfig.class);

	private static byte id = 1;
	private static byte clienttype = 2;
	private static byte clientversion = 3;
	private static byte keyword = 4;
	private static byte value = 5;

	// Constructor
	public CinNavConfig()
	{
		_tableName = "cin_nav";
	}

	public static void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new CinNavConfig();
			_instance.updateConfig();
		}
	}

	@Override
	protected void setValues(List<CinMessage> configlist)
	{
		navMap.clear();
		tracer.info("Load NAV-nav Data Start...");
		for (CinMessage m : configlist)
		{
			CinNav nav = new CinNav();
			nav.setId(m.getHeader(id).getInt64());
			nav.setClienttype(m.getHeader(clienttype).getString());
			nav.setClientversion(m.getHeader(clientversion).getString());
			nav.setKeyword(m.getHeader(keyword).getString());
			nav.setValue(m.getHeader(value).getString());
			navMap.put(nav.getClienttype() + nav.getClientversion(), nav);
		}
		tracer.info("Load NAV-nav Data End..." + navMap.size());
	}

	/**
	 * @param key
	 *            like type+version:ios1.0.0000
	 * @return
	 */
	public static CinNav getClientUpdate(String key)
	{
		return navMap.get(key);
	}
}
