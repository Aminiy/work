package com.allstar.cinconfig.cinnav;

public class CinClientUpdate
{
	private long id;
	private String clienttype;
	private String clientversion;
	private int updatetype;
	private String updateversion;
	private String downloadurl;
	private String detailpageurl;
	private long packagesize;
	private String releasetime;

	public long getId()
	{
		return id;
	}

	public void setId(long id)
	{
		this.id = id;
	}

	public String getClienttype()
	{
		return clienttype;
	}

	public void setClienttype(String clienttype)
	{
		this.clienttype = clienttype;
	}

	public String getClientversion()
	{
		return clientversion;
	}

	public void setClientversion(String clientversion)
	{
		this.clientversion = clientversion;
	}

	public int getUpdatetype()
	{
		return updatetype;
	}

	public void setUpdatetype(int updatetype)
	{
		this.updatetype = updatetype;
	}

	public String getUpdateversion()
	{
		return updateversion;
	}

	public void setUpdateversion(String updateversion)
	{
		this.updateversion = updateversion;
	}

	public String getDownloadurl()
	{
		return downloadurl;
	}

	public void setDownloadurl(String downloadurl)
	{
		this.downloadurl = downloadurl;
	}

	public String getDetailpageurl()
	{
		return detailpageurl;
	}

	public void setDetailpageurl(String detailpageurl)
	{
		this.detailpageurl = detailpageurl;
	}

	public long getPackagesize()
	{
		return packagesize;
	}

	public void setPackagesize(long packagesize)
	{
		this.packagesize = packagesize;
	}

	public String getReleasetime()
	{
		return releasetime;
	}

	public void setReleasetime(String releasetime)
	{
		this.releasetime = releasetime;
	}

}
