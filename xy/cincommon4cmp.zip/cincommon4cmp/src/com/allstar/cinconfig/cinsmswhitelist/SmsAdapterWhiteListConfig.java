package com.allstar.cinconfig.cinsmswhitelist;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.allstar.cinconfig.CinSecondaryConfigInterface;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cintracer.CinTracer;

public class SmsAdapterWhiteListConfig extends CinSecondaryConfigInterface
{
	private final static CinTracer LOGGER = CinTracer.getInstance(SmsAdapterWhiteListConfig.class);

	private static SmsAdapterWhiteListConfig _instance;

	private static Set<String> whiteListSet = new HashSet<String>();

	private SmsAdapterWhiteListConfig()
	{
		_tableName = "smsa_whitelist";
	}

	public static Set<String> getWhiteList()
	{
		return whiteListSet;
	}

	public static synchronized void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new SmsAdapterWhiteListConfig();
			_instance.updateConfig();
		}
	}

	@Override
	protected void setValues(List<CinMessage> configs)
	{
		LOGGER.info("-------Begin Load SmsAdapterWhiteListConfig-------");

		Set<String> tempWhiteListSet = new HashSet<String>();

		for (CinMessage config : configs)
		{
			tempWhiteListSet.add(config.getHeader((byte)2).getString());
		}

		whiteListSet = tempWhiteListSet;

		LOGGER.info(String.format("-------End Load SmsAdapterWhiteListConfig count=%s-------", whiteListSet.size()));
	}
}
