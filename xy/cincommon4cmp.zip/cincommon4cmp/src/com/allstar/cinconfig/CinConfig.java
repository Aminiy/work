package com.allstar.cinconfig;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cinconfig.cinalarmnumber.CinAlarmNumberConfig;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.handler.codec.CinEncoder;
import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionCreatedEvent;
import com.allstar.cintracer.CinTracer;
import com.allstar.event.CinConfigEvent;

/**
 * Base class for the service and the module configuration
 * 
 * 
 */
public class CinConfig
{
	private static CinTracer tracer  = CinTracer.getInstance(CinConfig.class);
	static ConcurrentHashMap<String, CinConfigInterface> _primaryConfigInterface = new ConcurrentHashMap<String, CinConfigInterface>();
	static ConcurrentHashMap<String, CinSecondaryConfigInterface> _secondaryconfiginterface = new ConcurrentHashMap<String, CinSecondaryConfigInterface>();
	static ConcurrentHashMap<String, CinThirdConfigInterface> _thirdconfiginterface = new ConcurrentHashMap<String, CinThirdConfigInterface>();
	
	private static boolean _isConfigInit = false;

	// Internal signaling constant
	static final byte ServiceNameHeader = 0x01;
	static final byte ComputerNameHeader = 0x02;
	static final byte ModuleNameHeader = 0x03;
	static final byte ConfigName = 0x01;

	/**
	 * According to the properties file initialization configuration
	 * 
	 * @param properties
	 * @throws Exception
	 */
	public static void Initialize(Properties properties) throws Exception
	{
		CinConfigure.initialize(properties);
		Initialize();
	}

	/**
	 * According to the configuration database initialization module or service
	 * 
	 * @throws Exception
	 */
	public static void Initialize() throws Exception
	{
		if (!_isConfigInit)
		{
			_isConfigInit = true;

			CinTransactionCreatedEvent monitorEvent = new MonitorTransactionCreated();

			CinTransactionCreatedEvent configEvent = new ConfigTransactionCreated();

			if (!CinConfigure.serviceName.equals(CinServiceName.ConfigCenter.name()))
			{
				CinStack.instance().registerCinTransactionCreatedEvent(CinRequestMethod.Config, configEvent);
				if (!CinConfigure.serviceName.equals(CinServiceName.CounterCenter.name()))
					CinStack.instance().registerCinTransactionCreatedEvent(CinRequestMethod.Monitoring, monitorEvent);
			}
		}
	}

	/**
	 * Access level configuration
	 * 
	 * @param moduleName
	 *            Module or service name
	 * @param config
	 */
	public static void loadPrimaryConfig(String moduleName, CinConfigInterface config)
	{
		CinConfigResult lock = new CinConfigResult();
		if (_isConfigInit)
		{
			_primaryConfigInterface.put(moduleName, config);
			CinRequest request = new CinRequest(CinRequestMethod.Config);
			request.addHeader(new CinHeader(CinHeaderType.From, CinConfigure.fromKey));
			request.addHeader(new CinHeader(CinHeaderType.To, UUID.randomUUID().getLeastSignificantBits()));
			request.addHeader(new CinHeader(CinHeaderType.CallId, 1L));
			request.addHeader(new CinHeader(CinHeaderType.Event, CinConfigEvent.LoadPrimaryConfig));
			CinMessage body = new CinMessage((byte) CinConfigEvent.LoadPrimaryConfig);
			body.addHeader(new CinHeader(CinConfig.ServiceNameHeader, CinConfigure.serviceName));
			body.addHeader(new CinHeader(CinConfig.ComputerNameHeader, CinConfigure.computerName));
			body.addHeader(new CinHeader(CinConfig.ModuleNameHeader, moduleName));
			request.addBody(new CinBody(CinEncoder.toBytes(body)));
			CinTransaction trans = CinStack.instance().createTransaction(new InetSocketAddress(CinConfigure.cinCenter.split(":")[0], Integer.parseInt(CinConfigure.cinCenter.split(":")[1])), request);
			trans.setAttachment(new Object[]{lock, moduleName, config});
			trans.Event = new LoadPrimaryConfigTransactionEvent();

			synchronized (lock)
			{
				trans.sendRequest();
				try
				{
					lock.wait();
				}
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
			}
			if (!lock.isTrue() && config.isFirstLoad())
			{
				StringBuilder sb = new StringBuilder("loadPrimaryConfig System.exit:");
				sb.append("ServiceName:");
				sb.append(CinConfigure.serviceName);
				sb.append(".ComputerName:");
				sb.append(CinConfigure.computerName);
				sb.append(".ModuleName:");
				sb.append(moduleName);
				System.out.println(sb.toString());
				CinAlarmNumberConfig.sendAlarmSms(sb.toString());
				System.exit(0);
			}
		}
	}

	/**
	 * To obtain the secondary configuration
	 * 
	 * @param tablename
	 *           Configure table name
	 * @param config
	 */
	public static void loadSecondaryConfig(String tablename, CinSecondaryConfigInterface config)
	{
		CinConfigResult lock = new CinConfigResult();
		List<CinMessage> msglist = new ArrayList<CinMessage>();
		if (_isConfigInit)
		{
			_secondaryconfiginterface.put(tablename, config);
			CinRequest request = new CinRequest(CinRequestMethod.Config);
			request.addHeader(new CinHeader(CinHeaderType.From, CinConfigure.fromKey));
			request.addHeader(new CinHeader(CinHeaderType.To, UUID.randomUUID().getLeastSignificantBits()));
			request.addHeader(new CinHeader(CinHeaderType.CallId, 1L));
			request.addHeader(new CinHeader(CinHeaderType.Event, CinConfigEvent.LoadSecondaryConfig));
			request.addHeader(new CinHeader(CinHeaderType.Name, tablename));
			CinTransaction trans = CinStack.instance().createTransaction(new InetSocketAddress(CinConfigure.cinCenter.split(":")[0], Integer.parseInt(CinConfigure.cinCenter.split(":")[1])), request);
			trans.setAttachment(new Object[]{lock, msglist, config});
			trans.Event = new LoadSecondaryConfigTransactionEvent();
			synchronized (lock)
			{
				try
				{
					trans.sendRequest();
					lock.wait();
				}
				catch (InterruptedException e)
				{
					e.printStackTrace();
				}
			}
			if (!lock.isTrue() && config.isFirstLoad())
			{
				StringBuilder sb = new StringBuilder("loadSecondaryConfig System.exit:");
				sb.append("ServiceName:");
				sb.append(CinConfigure.serviceName);
				sb.append(".ComputerName:");
				sb.append(CinConfigure.computerName);
				System.out.println(sb.toString());
				CinAlarmNumberConfig.sendAlarmSms(sb.toString());
				System.exit(0);
			}
		}
	}
	
	public static void loadThirdConfig(String tablename, CinThirdConfigInterface config)
	{
		CinConfigResult lock = new CinConfigResult();
		List<CinMessage> msglist = new ArrayList<CinMessage>();
		if (_isConfigInit)
		{
			_thirdconfiginterface.put(tablename, config);
			CinRequest request = new CinRequest(CinRequestMethod.Config);
			request.addHeader(new CinHeader(CinHeaderType.Event, CinConfigEvent.LoadThirdConfig));
			request.addHeader(new CinHeader(CinHeaderType.From, CinConfigure.fromKey));
			request.addHeader(new CinHeader(CinHeaderType.To, UUID.randomUUID().getLeastSignificantBits()));
			request.addHeader(new CinHeader(CinHeaderType.Name, tablename));
			request.addHeader(new CinHeader(CinHeaderType.CallId, 1L));
			CinTransaction trans = CinStack.instance().createTransaction(new InetSocketAddress(CinConfigure.cinCenter.split(":")[0], Integer.parseInt(CinConfigure.cinCenter.split(":")[1])), request);
			trans.setAttachment(new Object[]{lock, msglist, config});
			trans.Event = new LoadThirdConfigTransactionEvent();
			synchronized (lock)
			{
				try
				{
					trans.sendRequest();
					lock.wait();
				}
				catch (InterruptedException e)
				{
					tracer.error("-----Config--" + e.getMessage(), e);
					e.printStackTrace();
				}
			}
			if (!lock.isTrue() && config.isFirstLoad())
			{
				StringBuilder sb = new StringBuilder("---------->>loadThirdConfig System.exit:");
				sb.append("ServiceName:");
				sb.append(CinConfigure.serviceName);
				sb.append(".ComputerName:");
				sb.append(CinConfigure.computerName);
				sb.append("<<------------\r\n");
				System.out.println(sb.toString());
				CinAlarmNumberConfig.sendAlarmSms(sb.toString());
				System.exit(0);
			}
		}
	}
}
