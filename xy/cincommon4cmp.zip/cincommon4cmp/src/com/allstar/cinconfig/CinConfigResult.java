package com.allstar.cinconfig;

/**
 * Configuration updates multithreaded synchronization using objects in the process of the lock
 * 
 * 
 */
public class CinConfigResult
{
	private boolean ret = false;

	public boolean isTrue()
	{
		return ret;
	}

	public void setRet(boolean ret)
	{
		this.ret = ret;
	}

}
