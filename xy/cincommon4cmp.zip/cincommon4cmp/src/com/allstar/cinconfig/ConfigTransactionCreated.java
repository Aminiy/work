package com.allstar.cinconfig;

import com.allstar.cinstack.handler.codec.CinMessageReader;
import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionCreatedEvent;
import com.allstar.event.CinConfigEvent;

/**
 * CinCenter monitored access to configure the request event entity class
 * 
 * 
 */
public class ConfigTransactionCreated implements CinTransactionCreatedEvent
{

	@Override
	public void onCinTransactionCreated(CinTransaction trans)
	{
		CinRequest request = trans.getRequest();
		if (request.Event.getValue()[0] == CinConfigEvent.PrimaryConfigUpdated)
		{
			CinMessageReader reader = new CinMessageReader();
			for (CinBody body : request.getBodys())
			{
				CinMessage toBeUpdate = reader.load(body.getValue());
				if (toBeUpdate.getHeader(CinConfig.ModuleNameHeader) != null)
				{
					String moduleName = toBeUpdate.getHeader(CinConfig.ModuleNameHeader).getString();
					CinConfigInterface config = CinConfig._primaryConfigInterface.get(moduleName);
					if (config != null)
						try
						{
							CinConfigUpdateThread updateThread = new CinConfigUpdateThread(config);
							updateThread.start();
						}
						catch (Exception e)
						{
							e.printStackTrace();
						}
				}
			}
			trans.sendResponse(CinResponseCode.OK);
		}
		else
			if (request.Event.getValue()[0] == CinConfigEvent.SecondaryConfigUpdated)
			{
				CinMessageReader reader = new CinMessageReader();
				for (CinBody body : request.getBodys())
				{
					CinMessage toBeUpdate = reader.load(body.getValue());
					if (toBeUpdate.getHeader(CinConfig.ModuleNameHeader) != null)
					{
						String moduleName = toBeUpdate.getHeader(CinConfig.ModuleNameHeader).getString();
						CinSecondaryConfigInterface config = CinConfig._secondaryconfiginterface.get(moduleName);
						if (config != null)
							try
							{
								CinSecondaryConfigUpdateThread updateThread = new CinSecondaryConfigUpdateThread(config);
								updateThread.start();
							}
							catch (Exception e)
							{
								e.printStackTrace();
							}
					}
				}
				trans.sendResponse(CinResponseCode.OK);
			}
			else
				if (request.Event.getValue()[0] == CinConfigEvent.ThirdConfigUpdated)
				{
					CinMessageReader reader = new CinMessageReader();
					for (CinBody body : request.getBodys())
					{
						CinMessage toBeUpdate = reader.load(body.getValue());
						if (toBeUpdate.getHeader(CinConfig.ModuleNameHeader) != null)
						{
							String moduleName = toBeUpdate.getHeader(CinConfig.ModuleNameHeader).getString();
							CinThirdConfigInterface config = CinConfig._thirdconfiginterface.get(moduleName);
							if (config != null)
								try
								{
									CinThirdConfigUpdateThread updateThread = new CinThirdConfigUpdateThread(config);
									updateThread.start();
								}
								catch (Exception e)
								{
									e.printStackTrace();
								}
						}
					}
					trans.sendResponse(CinResponseCode.OK);
				}

				else
					trans.sendResponse(CinResponseCode.NotAvailable);
	}

}
