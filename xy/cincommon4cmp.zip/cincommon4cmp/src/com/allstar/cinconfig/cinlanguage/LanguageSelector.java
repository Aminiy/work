package com.allstar.cinconfig.cinlanguage;

import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinTextUtil;

/**
 * Please see LanguageTake instead of LanguageSelector
 * 
 * LanguageSelector select value length limit by 255 bytes but LanguageTake no limit.
 * 
 * 
 */
public class LanguageSelector
{
	private static CinTracer tracer = CinTracer.getInstance(LanguageSelector.class);
	private static ConcurrentHashMap<String, String[]> _textmap = new ConcurrentHashMap<String, String[]>();

	public static void initialize() throws Exception
	{
		CinLanguageConfig.initialize();
	}

	public static void put(String key, String[] values)
	{
		if (null != key)
		{
			_textmap.put(key.toLowerCase(), values);
		}
	}

	public static void clear()
	{
		_textmap.clear();
	}

	@Deprecated
	public static String selectValue(String key, byte language)
	{
		if (null != key && _textmap.containsKey(key.toLowerCase()))
		{
			return _textmap.get(key.toLowerCase())[language];
		}
		tracer.error("No Key found for Language Text " + key);
		return CinTextUtil.EmptyString;
	}

	@Deprecated
	public static String selectValue(String key, CinTransaction trans)
	{
		if (trans == null || trans.getRequest() == null || !trans.getRequest().containsHeader(CinHeaderType.Language))
			return selectValue(key);
		else
			return selectValue(key, trans.getRequest().getHeader(CinHeaderType.Language).getValue()[0]);
	}

	@Deprecated
	public static String selectValue(String key)
	{
		return selectValue(key, LanguageType.English);
	}
}
