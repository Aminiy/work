package com.allstar.cinconfig.cinlanguage;

import java.util.List;

import com.allstar.cinconfig.CinConfigure;
import com.allstar.cinconfig.CinSecondaryConfigInterface;
import com.allstar.cinstack.message.CinMessage;

/**
 * The secondary configuration - multi-language environment configuration
 * 
 * 
 */
public class CinLanguageConfig extends CinSecondaryConfigInterface
{

	public CinLanguageConfig()
	{
		_tableName = "cin_language";
	}

	@Override
	protected void setValues(List<CinMessage> configlist)
	{
		LanguageSelector.clear();
		for (CinMessage m : configlist)
		{
			String[] v = new String[m.getHeaders().size() - 2];
			for (int i = 2; i < m.getHeaders().size(); i++)
			{
				if (m.getHeader((byte) 2).getString().equals("*") || m.getHeader((byte) 2).getString().equals(CinConfigure.serviceName))
					v[i - 2] = m.getHeaders().get(i).getString();
			}
			LanguageSelector.put(m.getHeader((byte) 1).getString(), v);
		}
	}

	private static CinSecondaryConfigInterface _instance;

	/**
	 * initialize
	 * 
	 * @throws Exception
	 */
	public static void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new CinLanguageConfig();
			_instance.updateConfig();
		}
	}
}
