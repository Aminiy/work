package com.allstar.cinconfig.cinlanguage;

public class LanguageType
{
	@LanguageAnnotation(englishname = "en")
	public static final byte English = 0;

	@LanguageAnnotation(englishname = "chs")
	public static final byte SimplifiedChinese = 1;

	@LanguageAnnotation(englishname = "hi")
	public static final byte Hindi = 2;

	@LanguageAnnotation(englishname = "ms")
	public static final byte Marathi = 3;
	
	@LanguageAnnotation(englishname = "gujarati")
	public static final byte Gujarati = 4;
	
	@LanguageAnnotation(englishname = "bengali")
	public static final byte Bengali = 5;
	
	@LanguageAnnotation(englishname = "odia")
	public static final byte Odia = 6;// oriya
	
	@LanguageAnnotation(englishname = "punjabi")
	public static final byte Punjabi = 7;
	
	@LanguageAnnotation(englishname = "tamil")
	public static final byte Tamil = 8;
	
	@LanguageAnnotation(englishname = "telugu")
	public static final byte Telugu = 9;
	
	@LanguageAnnotation(englishname = "kannadas")
	public static final byte Kannadas = 10;
	
	@LanguageAnnotation(englishname = "malayalam")
	public static final byte Malayalam = 11;
	
}
