package com.allstar.cinconfig.cinlanguage;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinTextUtil;
import com.allstar.cinutil.CinUtil;

/**
 * new cin_language interface, third config.
 */
public class LanguageTake
{
	private static CinTracer tracer = CinTracer.getInstance(LanguageTake.class);
	private static ConcurrentHashMap<String, List<String>> _textmap = new ConcurrentHashMap<String, List<String>>();

	public static void initialize() throws Exception
	{
		LanguageTakeConfig.initialize();
	}

	public static void put(String key, List<String> values)
	{
		if (null != key)
		{
			_textmap.put(key.toLowerCase(), values);
		}
	}

	public static void clear()
	{
		_textmap.clear();
	}

	public static String selectValue(String key, byte language)
	{
		String ret = null;
		if (null != key && _textmap.containsKey(key.toLowerCase()))
		{
			try
			{
				ret = _textmap.get(key.toLowerCase()).get(language);
			}
			catch (Exception e)
			{
				tracer.error("Take Third Language exception key=" + key + ", lv=" + language, e);
			}

			if (CinUtil.isNullOrEmpty(ret))
				return _textmap.get(key.toLowerCase()).get(LanguageType.English);
			else
				return ret;
		}
		else
		{
			tracer.error("No Key found for Third Language Text key:" + key + ", lv=" + language);
			return CinTextUtil.EmptyString;
		}

	}

	public static String selectValue(String key, CinTransaction trans)
	{
		if (trans == null || trans.getRequest() == null || !trans.getRequest().containsHeader(CinHeaderType.Language))
			return selectValue(key);
		else
			return selectValue(key, trans.getRequest().getHeader(CinHeaderType.Language).getValue()[0]);
	}

	public static String selectValue(String key)
	{
		return selectValue(key, LanguageType.English);
	}
}
