package com.allstar.cinconfig.cinlanguage;

import java.util.ArrayList;
import java.util.List;

import com.allstar.cinconfig.CinConfigure;
import com.allstar.cinconfig.CinThirdConfigInterface;
import com.allstar.cinstack.handler.codec.CinMessageReader;
import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cintracer.CinTracer;

/**
 * new cin_language interface, third config.
 */
public class LanguageTakeConfig extends CinThirdConfigInterface
{
	private final static CinTracer LOGGER = CinTracer.getInstance(LanguageTakeConfig.class);

	private static CinThirdConfigInterface _instance;

	public LanguageTakeConfig()
	{
		_tableName = "cin_thirdlanguage";
	}

	@Override
	protected void setValues(List<CinMessage> configlist)
	{
		LanguageTake.clear();
		
		for (CinMessage row : configlist)
		{
			String key = "";
//			String[] v = new String[4];// String size should be >= language type count
			List<String> v = new ArrayList<>(16);
			String serviceName = "";
			
			for (CinBody colBody : row.getBodys())
			{
				CinMessage colunm = CinMessageReader.parse(colBody.getValue());
				
				if (colunm.getHeaders().size() > 0)
				{
					byte idx = colunm.getHeader((byte) 0x01).getValue()[0];

					// @see cin_thirdlanguage
					switch (idx)
					{
						case 0:
							key = colunm.getBody().getString();
							break;
						case 1:
							serviceName = colunm.getBody().getString();
							break;
						default:
							v.add(idx - 2, colunm.getBody().getString());// language value
							break;
					}
				}
			}

			if ("*".equals(serviceName) || CinConfigure.serviceName.equals(serviceName))
			{
				LanguageTake.put(key, v);
			}
			else
			{
				if (LOGGER.InfoTrace())
				{
					LOGGER.info(String.format("Shall not apply to the current service[%s-%s]", CinConfigure.serviceName, serviceName));
				}
			}
		}
	}

	/**
	 * initialize
	 * 
	 * @throws Exception
	 */
	public static void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new LanguageTakeConfig();
			_instance.updateConfig();
		}
	}

}
