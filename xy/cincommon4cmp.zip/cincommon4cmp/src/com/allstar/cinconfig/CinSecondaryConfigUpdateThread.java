package com.allstar.cinconfig;

/**
 * Update the secondary configuration thread
 * 
 * 
 */
public class CinSecondaryConfigUpdateThread extends Thread
{
	CinSecondaryConfigInterface _config;

	CinSecondaryConfigUpdateThread(CinSecondaryConfigInterface config)
	{
		_config = config;
	}

	@Override
	public void run()
	{
		_config.loadConfig();
	}
}
