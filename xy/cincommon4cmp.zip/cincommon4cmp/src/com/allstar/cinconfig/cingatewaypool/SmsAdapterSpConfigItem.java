package com.allstar.cinconfig.cingatewaypool;

public class SmsAdapterSpConfigItem
{
	private String prefix;

	private String spCode;

	private String protocol;	

	public String getPrefix()
	{
		return prefix;
	}

	public void setPrefix(String prefix)
	{
		this.prefix = prefix;
	}

	public String getSpCode()
	{
		return spCode;
	}

	public void setSpCode(String spCode)
	{
		this.spCode = spCode;
	}

	public String getProtocol()
	{
		return protocol;
	}

	public void setProtocol(String protocol)
	{
		this.protocol = protocol;
	}

	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("prefix=");
		sb.append(this.prefix);

		sb.append("	spName=");
		sb.append(this.spCode);

		sb.append("	protocol=");
		sb.append(this.protocol);;

		return sb.toString();
	}
}
