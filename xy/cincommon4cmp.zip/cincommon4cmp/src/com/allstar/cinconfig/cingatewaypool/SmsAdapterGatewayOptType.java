package com.allstar.cinconfig.cingatewaypool;

import java.util.HashMap;
import java.util.Map;

public enum SmsAdapterGatewayOptType
{
	TRANSMITTER("S"),

	RECEIVER("R"),

	TRANSCEIVER("*"),

	UNKNOWN("UNKNOWN");

	private String value;

	private final static Map<String, SmsAdapterGatewayOptType> MAP = new HashMap<String, SmsAdapterGatewayOptType>();

	private SmsAdapterGatewayOptType(String value)
	{
		this.value = value;
	}

	public String getValue()
	{
		return value;
	}

	public void setValue(String value)
	{
		this.value = value;
	}

	static
	{
		for (SmsAdapterGatewayOptType item : SmsAdapterGatewayOptType.values())
		{
			MAP.put(item.getValue(), item);
		}
	}

	public static SmsAdapterGatewayOptType getOptType(String value)
	{
		if (value == null || value.length() <= 0)
		{
			return SmsAdapterGatewayOptType.UNKNOWN;
		}

		if (MAP.containsKey(value.toUpperCase()))
		{
			return MAP.get(value.toUpperCase());
		}
		else
		{
			return SmsAdapterGatewayOptType.UNKNOWN;
		}
	}

	public static boolean validOptType(String value)
	{
		if (value == null || value.length() <= 0)
		{
			return false;
		}

		return MAP.containsKey(value.toUpperCase());
	}
}
