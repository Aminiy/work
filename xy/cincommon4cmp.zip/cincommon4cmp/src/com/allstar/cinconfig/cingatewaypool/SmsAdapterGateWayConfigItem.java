package com.allstar.cinconfig.cingatewaypool;

public class SmsAdapterGateWayConfigItem
{
	private String gatewayName;

	private String ip;

	private int port;

	private SmsAdapterGatewayOptType optType;

	private String systemId;

	private String systemPassword;

	private String spCode;

	private String gatewaytype;

	private String loadbalance;

	private String businesstype;

	private String shortcode;

	private String datacoding;

	private String nationalPrefix;

	private String internationalPrefix;

	public String getGatewayName()
	{
		return gatewayName;
	}

	public void setGatewayName(String gatewayName)
	{
		this.gatewayName = gatewayName;
	}

	public String getIp()
	{
		return ip;
	}

	public void setIp(String ip)
	{
		this.ip = ip;
	}

	public int getPort()
	{
		return port;
	}

	public void setPort(int port)
	{
		this.port = port;
	}

	public SmsAdapterGatewayOptType getOptType()
	{
		return optType;
	}

	public void setOptType(SmsAdapterGatewayOptType optType)
	{
		this.optType = optType;
	}

	public String getSystemId()
	{
		return systemId;
	}

	public void setSystemId(String systemId)
	{
		this.systemId = systemId;
	}

	public String getSystemPassword()
	{
		return systemPassword;
	}

	public void setSystemPassword(String systemPassword)
	{
		this.systemPassword = systemPassword;
	}

	public String getSpCode()
	{
		return spCode;
	}

	public void setSpCode(String spCode)
	{
		this.spCode = spCode;
	}

	public String getGatewaytype()
	{
		return gatewaytype;
	}

	public void setGatewaytype(String gatewaytype)
	{
		this.gatewaytype = gatewaytype;
	}

	public String getLoadBalance()
	{
		return loadbalance;
	}

	public void setLoadBalance(String loadbalance)
	{
		this.loadbalance = loadbalance;
	}

	public String getBusinessType()
	{
		return businesstype;
	}

	public void setBusinessType(String businesstype)
	{
		this.businesstype = businesstype;
	}

	public String getShortCode()
	{
		return shortcode;
	}

	public void setShortCode(String shortcode)
	{
		this.shortcode = shortcode;
	}

	public String getDataCoding()
	{
		return datacoding;
	}

	public void setDataCoding(String datacoding)
	{
		this.datacoding = datacoding;
	}
	
	public String getNationalPrefix()
	{
		return nationalPrefix;
	}
	

	public void setNationalPrefix(String nationalPrefix)
	{
		this.nationalPrefix = nationalPrefix;
	}
	

	public String getInternationalPrefix()
	{
		return internationalPrefix;
	}
	

	public void setInternationalPrefix(String internationalPrefix)
	{
		this.internationalPrefix = internationalPrefix;
	}
	

	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("gatewatName=");
		sb.append(this.gatewayName);

		sb.append("	ip=");
		sb.append(this.ip);

		sb.append("	port=");
		sb.append(this.port);

		sb.append("	opttype=");
		sb.append(this.optType);

		sb.append("	systemId=");
		sb.append(this.systemId);

		sb.append("	systemPassword=");
		sb.append(this.systemPassword);

		sb.append("	spCode=");
		sb.append(this.spCode);

		sb.append("	gatewaytype=");
		sb.append(this.gatewaytype);

		sb.append("	loadbalance=");
		sb.append(this.loadbalance);

		sb.append("	businesstype=");
		sb.append(this.businesstype);

		sb.append("	shortcode=");
		sb.append(this.shortcode);

		sb.append("	datacoding=");
		sb.append(this.datacoding);

		return sb.toString();
	}
}
