package com.allstar.cinconfig.cingatewaypool;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cinconfig.CinSecondaryConfigInterface;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cintracer.CinTracer;

public class SmsAdapterSpConfig extends CinSecondaryConfigInterface
{
	private final static CinTracer LOGGER = CinTracer.getInstance(SmsAdapterSpConfig.class);

	private final static byte PREFIX = 1;

	private final static byte SP_CODE = 2;

	private final static byte PROTOCOL = 3;

	private static SmsAdapterSpConfig _instance;
	
	private static Map<String, SmsAdapterSpConfigItem> sps = new ConcurrentHashMap<String, SmsAdapterSpConfigItem>();

	private SmsAdapterSpConfig()
	{
		_tableName = "smsa_spinfo";
	}

	public static Map<String, SmsAdapterSpConfigItem> getSps()
	{
		return sps;
	}

	public static synchronized void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new SmsAdapterSpConfig();
			_instance.updateConfig();
		}
	}

	@Override
	protected void setValues(List<CinMessage> configs)
	{
		Map<String, SmsAdapterSpConfigItem> items = new ConcurrentHashMap<String, SmsAdapterSpConfigItem>();
		
		for (CinMessage config : configs)
		{
			SmsAdapterSpConfigItem item = new SmsAdapterSpConfigItem();

			item.setPrefix(config.getHeader(PREFIX).getString());
			item.setSpCode(config.getHeader(SP_CODE).getString());
			item.setProtocol(config.getHeader(PROTOCOL).getString());

			items.put(item.getPrefix(),item);

			LOGGER.info(String.format("Load SmsAdapterSpConfig Item:%s", item));
		}

		sps = items;
	}
}
