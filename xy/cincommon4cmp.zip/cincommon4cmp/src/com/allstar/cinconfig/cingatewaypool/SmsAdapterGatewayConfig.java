package com.allstar.cinconfig.cingatewaypool;

import java.util.ArrayList;
import java.util.List;

import com.allstar.cinconfig.CinSecondaryConfigInterface;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cintracer.CinTracer;

/**
 * @see com.allstar.configcenter.entity.smsa_gatewayinfo
 * 
 */
public class SmsAdapterGatewayConfig extends CinSecondaryConfigInterface
{
	private final static CinTracer LOGGER = CinTracer.getInstance(SmsAdapterGatewayConfig.class);

	private final static byte GATEWAY_NAME = 1;

	private final static byte GATEWAY_IP = 2;

	private final static byte GATEWAY_PORT = 3;

	private final static byte GATEWAY_OPTTYPE = 4;

	private final static byte GATEWAY_SYSTEM_ID = 5;

	private final static byte GATEWAY_SYSTEM_PWD = 6;

	private final static byte GATEWAY_SP_CODE = 7;

	private final static byte GATEWAY_TYPE = 8;

	private final static byte GATEWAY_LOAD_BALANCE = 9;

	private final static byte GATEWAY_BUSINESS_TYPE = 10;

	private final static byte GATEWAY_SHORT_CODE = 11;

	private final static byte GATEWAY_DATA_CODING = 12;

	private static final byte GATEWAY_NATIONAL_PREFIX = 13;

	private static final byte GATEWAY_INTERNATIONAL_PREFIX = 14;

	private static SmsAdapterGatewayConfig _instance;

	private static List<SmsAdapterGateWayConfigItem> gateways = new ArrayList<SmsAdapterGateWayConfigItem>();

	private SmsAdapterGatewayConfig()
	{
		_tableName = "smsa_gatewayinfo";
	}

	public static List<SmsAdapterGateWayConfigItem> getGateways()
	{
		return gateways;
	}

	public static synchronized void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new SmsAdapterGatewayConfig();
			_instance.updateConfig();
		}
	}

	@Override
	protected void setValues(List<CinMessage> configs)
	{
		LOGGER.info("-------Begin Load SmsAdapterGatewayConfig-------");

		List<SmsAdapterGateWayConfigItem> items = new ArrayList<SmsAdapterGateWayConfigItem>();

		for (CinMessage config : configs)
		{
			SmsAdapterGateWayConfigItem item = new SmsAdapterGateWayConfigItem();

			item.setGatewayName(config.getHeader(GATEWAY_NAME).getString());
			item.setIp(config.getHeader(GATEWAY_IP).getString());
			item.setOptType(SmsAdapterGatewayOptType.getOptType(config.getHeader(GATEWAY_OPTTYPE).getString()));
			item.setPort(Integer.parseInt(config.getHeader(GATEWAY_PORT).getString()));
			item.setSpCode(config.getHeader(GATEWAY_SP_CODE).getString());
			item.setGatewaytype(config.getHeader(GATEWAY_TYPE).getString());
			item.setLoadBalance(config.getHeader(GATEWAY_LOAD_BALANCE).getString());
			item.setSystemId(config.getHeader(GATEWAY_SYSTEM_ID).getString());
			item.setSystemPassword(config.getHeader(GATEWAY_SYSTEM_PWD).getString());
			item.setBusinessType(config.getHeader(GATEWAY_BUSINESS_TYPE).getString());
			item.setShortCode(config.getHeader(GATEWAY_SHORT_CODE).getString());
			item.setDataCoding(config.getHeader(GATEWAY_DATA_CODING).getString());
			item.setNationalPrefix(config.getHeader(GATEWAY_NATIONAL_PREFIX).getString());
			item.setInternationalPrefix(config.getHeader(GATEWAY_INTERNATIONAL_PREFIX).getString());

			if (item.getOptType() == SmsAdapterGatewayOptType.UNKNOWN)
			{
				throw new IllegalArgumentException(String.format("OptType Error config=%s", item));
			}

			items.add(item);

			LOGGER.info(String.format("Load SmsAdapterGatewayConfig Item:%s", item));
		}

		gateways = items;

		LOGGER.info("-------End Load SmsAdapterGatewayConfig-------");
	}
}
