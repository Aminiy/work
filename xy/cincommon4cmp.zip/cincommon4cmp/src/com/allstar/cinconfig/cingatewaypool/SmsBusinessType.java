package com.allstar.cinconfig.cingatewaypool;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Number pool number Business type
 * 
 * 
 */
public enum SmsBusinessType implements Serializable
{
	/**
	 * Issued login verification code
	 */
	RegisterCode((byte) 1, "RegisterCode", false),

	/**
	 * Invite friends open
	 */
	InviteBuddy((byte) 2, "InviteBuddy", false),

	/**
	 * Send free sms
	 */
	FreeSmS((byte) 4, "FreeSmS", true),

	/**
	 * Monitor alarm message
	 */
	AlarmSms((byte) 5, "AlarmSms", false),

	/**
	 * Download sms
	 */
	DownLoad((byte) 6, "DownLoad", false),
	/**
	 * Does not support type
	 * */
	NotSupport((byte)7,"NotSupport",false),	
	/**
	 * A key activation
	 * */
	OneKeyRegisterUser((byte)8,"OneKeyRegisterUser",true),	
	/**
	 * Unknown type
	 */
	Unknown(Byte.MAX_VALUE, "Unknown", false);
	

	private byte value;

	private String name;

	/**
	 * Whether to reply
	 */
	private boolean canReply;

	private final static Map<Byte, SmsBusinessType> MAP = new HashMap<Byte, SmsBusinessType>();

	static
	{
		for (SmsBusinessType code : SmsBusinessType.values())
		{
			MAP.put(code.getValue(), code);
		}
	}

	private SmsBusinessType(byte value, String name, boolean supportReply)
	{
		this.value = value;
		this.name = name;
		this.canReply = supportReply;
	}

	public boolean getCanReply()
	{
		return canReply;
	}

	public byte getValue()
	{
		return value;
	}

	public String getName()
	{
		return name;
	}

	public static boolean IsValid(byte type)
	{
		return convertToSmsBusinessType(type) != SmsBusinessType.Unknown;
	}

	public static SmsBusinessType convertToSmsBusinessType(byte type)
	{
		if (MAP.containsKey(type))
		{
			return MAP.get(type);
		}
		else
		{
			return SmsBusinessType.Unknown;
		}
	}

	private static final long serialVersionUID = -1338435282924032336L;
}