package com.allstar.cinconfig.cinglobalconstant;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;

import com.allstar.cinconfig.CinSecondaryConfigInterface;
import com.allstar.cinstack.message.CinMessage;

/**
 * The secondary configuration
 * 
 * 
 */
public class CinGlobalConstantConfig extends CinSecondaryConfigInterface
{
	private static HashMap<String, Field> _fieldmap = new HashMap<String, Field>();

	private static final String PRODUCTNAME = "productname";
	private static final String LATESTDOWNLOADURL = "latestdownloadurl";

	// String type must be converted inside the get operation
	@ConstantAnnotation(fieldname = PRODUCTNAME)
	private static String _productName;

	@ConstantAnnotation(fieldname = LATESTDOWNLOADURL)
	private static String _latestDownloadUrl;

	private static CinSecondaryConfigInterface _instance;

	public static void initialize() throws Exception
	{
		for (Field f : CinGlobalConstantConfig.class.getDeclaredFields())
		{
			if (f.isAnnotationPresent(ConstantAnnotation.class))
			{
				_fieldmap.put(f.getAnnotation(ConstantAnnotation.class).fieldname(), f);
			}
		}

		if (_instance == null)
		{
			_instance = new CinGlobalConstantConfig();
			_instance.updateConfig();
		}
	}

	public CinGlobalConstantConfig()
	{
		_tableName = "cin_globalconstant";
	}

	@Override
	protected void setValues(List<CinMessage> configlist)
	{
		try
		{
			for (CinMessage m : configlist)
			{
				String key = m.getHeader((byte) 0x01).getString();
				if (_fieldmap.containsKey(key))
					_fieldmap.get(key).set(null, m.getHeader((byte) 0x02).getString());
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}

	public static String getProductName()
	{
		return _productName;
	}

	public static String getLatestDownloadUrl()
	{
		return _latestDownloadUrl;
	}
}
