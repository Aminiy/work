package com.allstar.cinconfig.cinvdc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import com.allstar.cinconfig.CinSecondaryConfigInterface;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cintracer.CinTracer;

public class CinVdcMappingConfig extends CinSecondaryConfigInterface
{
	private static CinTracer tracer = CinTracer.getInstance(CinVdcMappingConfig.class);

	private static CinSecondaryConfigInterface _instance;

	private static HashMap<String, ArrayList<String>> serversMappingMap = new HashMap<String, ArrayList<String>>();
	private static ArrayList<String> serverslist = new ArrayList<String>();
	private static String separator = "|";
	private static byte prefix = 1;
	private static byte servers = 2;

	public CinVdcMappingConfig()
	{
		_tableName = "cin_vdc_mapping";
	}

	public static void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new CinVdcMappingConfig();
			_instance.updateConfig();
		}
	}

	@Override
	protected void setValues(List<CinMessage> configlist)
	{
		tracer.info("Load cin_vdc_mapping Data Start");

		HashMap<String, ArrayList<String>> serversMappingTempMap = new HashMap<String, ArrayList<String>>();

		for (CinMessage m : configlist)
		{
			CinVdcMapping mapping = new CinVdcMapping();
			mapping.setPrefix(m.getHeader(prefix).getString());
			mapping.setServers(m.getHeader(servers).getString());

			ArrayList<String> values = new ArrayList<String>();
			
			for (String s : mapping.getServers().split(Pattern.quote(separator)))
			{
				if (!s.isEmpty())
				{
					if (!values.contains(s))
					{
						values.add(s);
					}
					if (!serverslist.contains(s))
					{
						serverslist.add(s);
					}
				}
			}

			serversMappingTempMap.put(mapping.getPrefix(), values);
		}

		serversMappingMap = serversMappingTempMap;

		tracer.info(String.format("Load cin_vdc_mapping Data End\r\nMap Size:%s\r\n%s", serversMappingMap.size(), serversMappingMap.toString()));
	}

	public static ArrayList<String> getServersMapping(String key)
	{
		return serversMappingMap.get(key);
	}
	
	public static ArrayList<String> getServersList()
	{
		return serverslist;
	}
}
