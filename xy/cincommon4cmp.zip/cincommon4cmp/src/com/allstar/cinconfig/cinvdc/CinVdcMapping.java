package com.allstar.cinconfig.cinvdc;

public class CinVdcMapping
{
	private String prefix;
	private String servers;	

	public String getPrefix()
	{
		return prefix;
	}

	public void setPrefix(String prefix)
	{
		this.prefix = prefix;
	}

	public String getServers()
	{
		return servers;
	}

	public void setServers(String servers)
	{
		this.servers = servers;
	}
}
