package com.allstar.cinconfig;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * Basic configuration entity class
 * 
 * 
 */
public class CinConfigure
{
	public static String serviceName = "ConfigCenter";
	public static String computerName = "CP01";
	public static String cinCenter = "127.0.0.1:30000";
	public static String fromKey = "ConfigCenterCP01";
	public static String traceUrl = "/data/logs/";

	public CinConfigure()
	{

	}

	public synchronized static void Initialize()
	{
		FileInputStream fis = null;
		try
		{
			fis = new FileInputStream("servicesetting.properties");
			Properties properties = new Properties();
			properties.load(fis);
			initialize(properties);
		}
		catch (FileNotFoundException e1)
		{
			e1.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if (fis != null)
					fis.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}

	/**
	 * Initialized by the properties files
	 * 
	 * @param properties
	 */
	public static void initialize(Properties properties)
	{
		serviceName = properties.getProperty("ServiceName");
		computerName = properties.getProperty("ComputerName");
		cinCenter = properties.getProperty("CinCenter");
		traceUrl = properties.getProperty("TraceUrl", "/data/logs/");
		fromKey = serviceName + computerName;
	}
}
