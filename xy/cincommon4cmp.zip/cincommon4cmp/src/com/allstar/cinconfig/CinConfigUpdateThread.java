package com.allstar.cinconfig;

/**
 * Update thread level configuration
 * 
 * 
 */
public class CinConfigUpdateThread extends Thread
{
	CinConfigInterface _config;

	CinConfigUpdateThread(CinConfigInterface config)
	{
		_config = config;
	}

	@Override
	public void run()
	{
		_config.loadConfig();
	}
}
