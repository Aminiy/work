package com.allstar.crypto;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class AES {
	private static Cipher cipher = null;

	public static String decrypt(byte[] data, byte[] randomkey) {
		try {
			if (null == cipher) {
				cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
			}
			SecretKey aesKey = new SecretKeySpec(randomkey, "AES");
			cipher.init(Cipher.DECRYPT_MODE, aesKey);
			byte[] decmsg = cipher.doFinal(data);
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < decmsg.length; i++) {
				sb.append((char) decmsg[i]);
			}
			String password = sb.toString();

			return password;
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return null;
	}
}