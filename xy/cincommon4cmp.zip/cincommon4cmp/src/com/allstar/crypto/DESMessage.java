package com.allstar.crypto;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

/**
 * Only used for Message DB encryption
 * 
 * 
 */
public class DESMessage extends DES
{

	public final static String _encryptKey = "B36D58478423404BB76FB1EADC122436";

	public static Cipher cipher = null;
	public static SecretKey securekey = null;

	/**
	 * Encrypt
	 * 
	 * @param datasource
	 *            byte[]
	 * @param password
	 *            String
	 * @return byte[]
	 */
	public static byte[] encrypt(byte[] datasource)
	{
		try
		{
			if (null == cipher || null == securekey)
			{
				DESKeySpec desKey = new DESKeySpec(_encryptKey.getBytes());
				SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
				securekey = keyFactory.generateSecret(desKey);
				cipher = Cipher.getInstance("DES");
			}
			SecureRandom random = new SecureRandom();
			cipher.init(Cipher.ENCRYPT_MODE, securekey, random);
			return cipher.doFinal(datasource);
		}
		catch (Throwable e)
		{
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * decrypt
	 * 
	 * @param src
	 *            byte[]
	 * @return byte[]
	 * @throws Exception
	 */
	public static byte[] decrypt(byte[] src) throws Exception
	{
		// The DES algorithm requires a trusted source of random numbers
		if (null == cipher || null == securekey)
		{
			DESKeySpec desKey = new DESKeySpec(_encryptKey.getBytes());
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
			securekey = keyFactory.generateSecret(desKey);
			cipher = Cipher.getInstance("DES");
		}
		SecureRandom random = new SecureRandom();
		cipher.init(Cipher.DECRYPT_MODE, securekey, random);
		return cipher.doFinal(src);
	}
}