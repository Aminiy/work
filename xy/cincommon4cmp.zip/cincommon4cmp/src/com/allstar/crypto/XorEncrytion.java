package com.allstar.crypto;

public class XorEncrytion
{
	/**
	 * Encryption method
	 * 
	 * @param body
	 *            Need to encrypt the message
	 * @param token
	 *            Encryption Token
	 * @param randomkey
	 *            Randomly generated Key
	 * @return Encrypted / decrypted bytes
	 */
	public static byte[] xorEncrytionMessage(byte[] cinbody, byte[] token, byte[] randomkey)
	{
		byte[] buffer = new byte[token.length + randomkey.length];
		System.arraycopy(token, 0, buffer, 0, token.length);
		System.arraycopy(randomkey, 0, buffer, token.length, randomkey.length);
		return xor(cinbody, buffer);
	}

	private static byte[] xor(byte[] buffer, byte[] randomkey)
	{
		byte[] result = new byte[buffer.length];
		for (int i = 0; i < buffer.length; i++)
		{
			byte b1 = randomkey[i % randomkey.length];
			result[i] = (byte) ((byte) buffer[i] ^ b1);
		}

		return result;
	}

	/**
	 * only for server side used, to encrypt the cinmessage to db table.
	 * 
	 * @param cinmesssage
	 * @param fromid
	 * @param toid
	 * @param messageid
	 * @return
	 */
	@Deprecated
	public static byte[] xorEncryptionMessage(byte[] cinmesssage, long fromid, long toid, String messageid)
	{
		StringBuilder sb = new StringBuilder();
		sb.append(fromid);
		sb.append(messageid);
		sb.append(toid);

		return xor(cinmesssage, MD5.encode(sb.toString()).getBytes());
	}
}
