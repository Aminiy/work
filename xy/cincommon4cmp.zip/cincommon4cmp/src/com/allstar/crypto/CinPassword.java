package com.allstar.crypto;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.UUID;

import com.allstar.cinutil.CinConvert;

public class CinPassword
{
	String _clientpwd, _serverpwd, _token;

	public CinPassword()
	{
		String randomstr = String.valueOf(Math.random());
		_clientpwd = MD5.encode(randomstr);
		_serverpwd = MD5.encode3(randomstr);
		_token = UUID.randomUUID().toString().replaceAll("-", "");
	}

	public byte[] getClientPassword()
	{
		return CinConvert.hexToBytes(_clientpwd);
	}

	public byte[] getServerPassword()
	{
		return CinConvert.hexToBytes(_serverpwd);
	}

	public byte[] getToken()
	{
		return CinConvert.hexToBytes(_token);
	}

	public static byte[] MD5Four(byte[] password)
	{
		try
		{
			byte[] md5 = MD5.digest(MD5.digest(MD5.digest(MD5.digest(password))));
			return md5;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	public static boolean CheckFourMD5(byte[] receive, byte[] cache)
	{
		try
		{
			byte[] compareString = MD5.digest(MD5.digest(receive));
			if (Arrays.equals(compareString, cache))
				return true;
			else
				return false;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	public static void main(String[] args) throws UnsupportedEncodingException
	{
		
		try
		{
			byte[] b = "abc123".getBytes();
			byte[] receive = MD5.digest(MD5.digest(b));
			String a = CinBase64.encode(receive);
			byte[] cache = CinPassword.MD5Four(b);
			
			System.out.println(CinPassword.CheckFourMD5(CinBase64.decode(a), cache));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}

}
