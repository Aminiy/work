/**
 * 
 */
package com.allstar.crypto;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;


public class ThreeDES
{
	private static final String Algorithm = "DESede";

	public static byte[] decode(byte[] crypted, byte[] publickey) throws Exception
	{
		SecretKey deskey = new SecretKeySpec(publickey, Algorithm);
		Cipher c1 = Cipher.getInstance(Algorithm);
		c1.init(Cipher.DECRYPT_MODE, deskey);
		return c1.doFinal(crypted);
	}

	public static byte[] encode(byte[] src, byte[] keybyte) throws Exception
	{
		SecretKey deskey = new SecretKeySpec(keybyte, Algorithm);
		Cipher c1 = Cipher.getInstance(Algorithm);
		c1.init(Cipher.ENCRYPT_MODE, deskey);
		return c1.doFinal(src);
	}
}
