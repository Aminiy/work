package com.allstar.crypto;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

public class DES
{
	/**
	 * encryption
	 * 
	 * @param datasource
	 *            byte[]
	 * @param password
	 *            String
	 * @return byte[]
	 */
	public static byte[] encrypt(byte[] datasource, String password)
	{
		try
		{
			SecureRandom random = new SecureRandom();
			DESKeySpec desKey = new DESKeySpec(password.getBytes());
			// Create a key factory, and then use it to convert DESKeySpec into
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
			SecretKey securekey = keyFactory.generateSecret(desKey);
			// The Cipher object actually does the encryption
			Cipher cipher = Cipher.getInstance("DES");
			// Initialize Cipher objects with keys
			cipher.init(Cipher.ENCRYPT_MODE, securekey, random);
			// Now, get the data and encrypt it
			// Enforcement of encryption operations
			return cipher.doFinal(datasource);
		}
		catch (Throwable e)
		{
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Decrypt
	 * 
	 * @param src
	 *            byte[]
	 * @param password
	 *            String
	 * @return byte[]
	 * @throws Exception
	 */
	public static byte[] decrypt(byte[] src, String password) throws Exception
	{
		// The DES algorithm requires a trusted source of random numbers
		SecureRandom random = new SecureRandom();
		// Create a DESKeySpec object
		DESKeySpec desKey = new DESKeySpec(password.getBytes());
		// Create a key factory
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
		// Convert DESKeySpec object to SecretKey object
		SecretKey securekey = keyFactory.generateSecret(desKey);
		// The Cipher object actually does the decryption
		Cipher cipher = Cipher.getInstance("DES");
		// Initialize Cipher objects with keys
		cipher.init(Cipher.DECRYPT_MODE, securekey, random);
		// Really start decryption operation
		return cipher.doFinal(src);
	}
}