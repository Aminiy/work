package com.allstar.crypto;

import java.nio.ByteBuffer;
import java.security.MessageDigest;

import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinConvert;

public class SHA1
{
	private static CinTracer tracer = CinTracer.getInstance(SHA1.class);

	public static String sha1(String domainname, String pwd)
	{
		String outStr = null;
		try
		{
			MessageDigest sha = MessageDigest.getInstance("SHA");
			;
			byte[] pwds = sha.digest((domainname + ":" + pwd).getBytes("UTF-8"));
			outStr = new String(pwds, "UTF-8");
		}
		catch (Exception e)
		{
			tracer.error("sha1 error " + pwd, e);
		}

		return outStr;
	}

	public static byte[] parseFetionPwd(Long userid, byte[] pwd) throws Exception
	{
		try
		{
			MessageDigest sha = MessageDigest.getInstance("SHA");

			byte[] uidbytes = CinConvert.intToByteArray((int) userid.longValue());
			ByteBuffer bf = ByteBuffer.allocate(uidbytes.length + pwd.length);
			bf.put(uidbytes);
			bf.put(pwd);
			byte[] pwds = sha.digest(bf.array());

			return MD5.digest(pwds);
		}
		catch (Exception e)
		{
			tracer.error("sha1 error " + pwd, e);
			return null;
		}
	}
}
