package com.allstar.cinsqc;

import java.util.Calendar;
import java.util.concurrent.ConcurrentHashMap;

public class CinSQCNatureCounter
{

	private ConcurrentHashMap<Long, CinSQCNatureObject> counters = new ConcurrentHashMap<Long, CinSQCNatureObject>(5000);

	private long _maxCount;
	private int _type;

	/**
	 * According to the natural day, month and year of quota control
	 * 
	 * @param type
	 *            Type (1 day, 2: month, 3: years]
	 * @param maxCount
	 *            The biggest quota
	 */
	public CinSQCNatureCounter(int type, int maxCount)
	{
		this._type = type;
		this._maxCount = maxCount;
	}

	public void set_maxCount(long _maxCount)
	{
		this._maxCount = _maxCount;
	}

	/**
	 * The quota to judge
	 * 
	 * @param userid
	 * @return TRUE:TRUE: did not exceed the quota restrictions, FALSE: has exceeded maximum quota
	 */
	public boolean checkCount(long userid)
	{

		int year = Calendar.getInstance().get(Calendar.YEAR);
		int month = Calendar.getInstance().get(Calendar.MONTH) + 1;
		int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);

		CinSQCNatureObject counter = counters.get(userid);

		if (null != counter)
		{
			boolean condition = false;
			if (_type == 1)
			{
				condition = year == counter.getYear() && month == counter.getMonth() && day == counter.getDay();
			}
			else
				if (_type == 2)
				{
					condition = year == counter.getYear() && month == counter.getMonth();
				}
				else
					if (_type == 3)
					{
						condition = year == counter.getYear();
					}

			if (condition)
			{
				long lastCount = counter.getCount();
				if (lastCount + 1 > _maxCount)
				{
					return false;
				}
				else
				{
					counter.setCount(lastCount + 1);
				}
			}
			else
			{
				counter.setYear(year);
				counter.setMonth(month);
				counter.setDay(day);

				counter.setCount(1);
			}
		}
		else
		{
			counters.put(userid, new CinSQCNatureObject(year, month, day, 1));
		}
		return true;
	}

	/**
	 * Query the remaining quota
	 * 
	 * @param userid
	 * @return Specify the user's quota remaining quantity
	 */
	public long queryLeftCount(long userid)
	{
		int year = Calendar.getInstance().get(Calendar.YEAR);
		int month = Calendar.getInstance().get(Calendar.MONTH) + 1;
		int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);

		CinSQCNatureObject counter = counters.get(userid);

		if (null != counter)
		{
			boolean condition = false;
			if (_type == 1)
			{
				condition = year == counter.getYear() && month == counter.getMonth() && day == counter.getDay();
			}
			else
				if (_type == 2)
				{
					condition = year == counter.getYear() && month == counter.getMonth();
				}
				else
					if (_type == 3)
					{
						condition = year == counter.getYear();
					}
			if (condition)
			{
				return _maxCount - counter.getCount();
			}
		}

		return _maxCount;
	}

	/**
	 * Counter plus one remaining quotas (minus one)
	 * 
	 * @param userid
	 */
	@SuppressWarnings("unused")
	private void decrementLeftQuota(long userid)
	{
		int year = Calendar.getInstance().get(Calendar.YEAR);
		int month = Calendar.getInstance().get(Calendar.MONTH) + 1;
		int day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);

		CinSQCNatureObject counter = counters.get(userid);
		if (null != counter)
		{
			boolean condition = false;
			if (_type == 1)
			{
				condition = year == counter.getYear() && month == counter.getMonth() && day == counter.getDay();
			}
			else
				if (_type == 2)
				{
					condition = year == counter.getYear() && month == counter.getMonth();
				}
				else
					if (_type == 3)
					{
						condition = year == counter.getYear();
					}
			if (condition)
			{
				long lastCount = counter.getCount();
				if (lastCount + 1 <= _maxCount)
				{
					counter.setCount(lastCount + 1);
				}
			}
			else
			{
				counter.setCount(1);
			}
		}
		else
		{
			counters.put(userid, new CinSQCNatureObject(year, month, day, 1));
		}
	}
}
