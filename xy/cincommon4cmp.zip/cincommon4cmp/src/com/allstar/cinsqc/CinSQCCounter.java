package com.allstar.cinsqc;

/**
 * Counter to control the frequency of Counter
 * 
 * 
 * @since 1.0
 */
public class CinSQCCounter
{

	/** Can use has been given */
	private boolean _isUsed = false;

	/** The time interval */
	private long _timelag = 10 * 60 * 1000;

	/**
	 * Within the specified time interval, allow the maximum number of sending a
	 * message
	 */
	private int _maxCount;

	/** An array of counters */
	private long[] _array;

	/** Used to record current head to tail in an array according to the pointer */
	private int _head = -1;
	private int _tail = -1;

	/**
	 * an approach to generate SQC Counter
	 * 
	 * @param timelag
	 *            Time interval, the unit milliseconds
	 * @param maxCount
	 *            Within the specified time interval, allow the maximum number
	 *            of sending a message
	 */
	public CinSQCCounter(long timelag, int maxCount)
	{
		this._timelag = timelag;
		this._maxCount = maxCount;
		this._array = new long[maxCount];
	}

	/**
	 * The increase in the number of messages sent, judge sends the message
	 * frequency
	 * 
	 * @return True There is no limit to the above frequency, False Beyond the
	 *         frequency limit
	 */
	public synchronized boolean increment()
	{
		long currentTime = System.currentTimeMillis();
		if (_head == _tail && _head == -1)
		{
			_head++;
			_tail++;
			_array[_head] = currentTime;
			return true;
		}

		int newTail = (_tail + 1) % _maxCount;

		// The array is full
		if (newTail == _head)
		{
			if (currentTime - _array[_head] <= _timelag)
			{
				return false;
			}
			else
			{
				_array[newTail] = currentTime;
				_head = (_head + 1) % _maxCount;
				_tail = newTail;
			}
		}
		else
		{
			_array[newTail] = currentTime;
			_tail = newTail;
		}

		return true;
	}

	/**
	 * When a user LogOff, and so on and so forth, the release of the Counter
	 */
	public void release()
	{
		for (int i = 0; i < _maxCount; i++)
		{
			_array[i] = 0;
		}
		_head = -1;
		_tail = -1;
		this.setUse(false);
	}

	boolean isUse()
	{
		return _isUsed;
	}

	public long UpdateDateTime()
	{
		if (_tail == -1)
			return 0;
		else
			return _array[_tail];
	}

	synchronized void setUse(boolean isUse)
	{
		this._isUsed = isUse;
	}

	/**
	 * Query the remaining quota
	 * 
	 * @return the remaining quota
	 */
	public int queryLeftQuota()
	{
		if (_head == _tail && _head == -1)
		{
			return _maxCount;
		}

		int sum = _maxCount;
		long cur = System.currentTimeMillis();
		if (_head <= _tail)
		{
			for (int i = _head; i <= _tail; i++)
			{
				if (cur - _array[i] <= _timelag)
				{
					sum--;
				}
			}
		}
		else
		{
			for (int i = _head; i < _maxCount; i++)
			{
				if (cur - _array[i] <= _timelag)
				{
					sum--;
				}
			}
			for (int i = 0; i <= _tail; i++)
			{
				if (cur - _array[i] <= _timelag)
				{
					sum--;
				}
			}
		}

		return sum;
	}

	/**
	 * To set the quota size, please carefully to invoke this method, commonly
	 * used in based on the quota set by the database configuration changes,
	 * need to call this method all allocated Counter
	 * 
	 * @param newCount
	 *            The new quota
	 * 
	 * @param newTimeLag
	 *            The new Time Lag
	 */
	public void resetCounter(int newCount, int newTimeLag)
	{
		long[] newArray = new long[newCount];
		if (newCount > _maxCount)
		{
			if (_head <= _tail)
			{
				System.arraycopy(_array, 0, newArray, 0, _maxCount);
				_array = newArray;
			}
			else
			{
				int index = 0;
				for (int i = _head; i < _maxCount; i++)
				{
					newArray[index++] = _array[i];
				}
				for (int i = 0; i <= _tail; i++)
				{
					newArray[index++] = _array[i];
				}
				_array = newArray;
				_head = 0;
				_tail = _maxCount - 1;
			}
		}
		else if (newCount < _maxCount)
		{
			if (_head <= _tail)
			{
				if (_tail - _head + 1 > newCount)
				{
					System.arraycopy(_array, _tail - newCount + 1, newArray, 0, newCount);
					_tail = newCount - 1;
				}
				else
				{
					System.arraycopy(_array, 0, newArray, 0, _tail - _head + 1);
				}
			}
			else
			{
				for (int i = _tail; i >= 0 && newCount > 0; i--)
				{
					newArray[--newCount] = _array[i];
				}
				for (int i = _maxCount - 1; i >= _head && newCount > 0; i--)
				{
					newArray[--newCount] = _array[i];
				}
				_head = 0;
				_tail = newArray.length - 1;
			}

			_array = newArray;
		}

		this._timelag = newTimeLag;
		this._maxCount = newCount;
	}
}