package com.allstar.cinsqc;

import java.util.ArrayList;
import java.util.List;

/**
 * Used for the control of frequency Counter Counter management class
 * 
 * 
 */
public class CinSQCCounterManager
{

	/** Counter list bool */
	private List<CinSQCCounter> counterList;

	/**
	 * The constructor
	 * 
	 * @param timelag
	 *            Time interval, the unit milliseconds
	 * @param maxCount
	 *            Within the specified time interval, allow the maximum number of sending a message
	 * @param counterNum
	 *            The number of initialize the Counter
	 * 
	 */
	public CinSQCCounterManager(long timelag, int maxCount, int counterNum)
	{
		this.counterList = new ArrayList<CinSQCCounter>(counterNum);

		for (int i = 0; i < counterNum; i++)
		{
			counterList.add(new CinSQCCounter(timelag, maxCount));
		}
	}

	/**
	 * From the list of the Counter to get a Counter is not used
	 * 
	 * @return CinSQCCounter
	 */
	public synchronized CinSQCCounter getCounter()
	{
		for (CinSQCCounter counter : this.counterList)
		{
			if (!counter.isUse())
			{
				counter.setUse(true);
				return counter;
			}
		}
		return null;
	}
}
