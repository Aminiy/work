package com.allstar.cinsqc;

public class CinSQCNatureObject
{
	private int year;
	private int month;
	private int day;
	private long count;

	public CinSQCNatureObject(int year, int month, int day, long count)
	{
		this.year = year;
		this.month = month;
		this.day = day;
		this.count = count;
	}

	public int getYear()
	{
		return year;
	}

	public void setYear(int year)
	{
		this.year = year;
	}

	public int getMonth()
	{
		return month;
	}

	public void setMonth(int month)
	{
		this.month = month;
	}

	public int getDay()
	{
		return day;
	}

	public void setDay(int day)
	{
		this.day = day;
	}

	public long getCount()
	{
		return count;
	}

	public void setCount(long count)
	{
		this.count = count;
	}

}
