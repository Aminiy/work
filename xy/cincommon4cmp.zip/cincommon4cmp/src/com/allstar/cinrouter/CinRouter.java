package com.allstar.cinrouter;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;

import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinutil.CinConvert;
import com.allstar.cinutil.CinPersonalId;
import com.allstar.cinutil.CinUtil;
import com.allstar.event.CinVideoEvent;

/**
 * Service routing module
 * 
 * 
 */
public class CinRouter
{
	public static boolean isInitialized = false;
	public static String RouterSeparator = ":";

	public CinRouter()
	{
	}

	/**
	 * Initialize
	 * 
	 * @throws Exception
	 */
	public static void Initialize() throws Exception
	{
		CinRouterConfig.initialize();
		isInitialized = true;
	}

	/**
	 * Adding routing information to parameters of the request, is advantageous
	 * for the protocol stack to create to the connection
	 * 
	 * @param request
	 * @param serviceName
	 */
	public static void setRoute(CinRequest request, CinServiceName serviceName)
	{
		request.addHeader(new CinHeader(CinHeaderType.Route, serviceName.getValue()));
	}

	private static String takeStringRoute(CinRequest request)
	{
		CinHeader route = request.getHeader(CinHeaderType.Route);
		String ipEndPoint = "";
		switch (CinServiceName.get(route.getString()))
		{
			case UserCacheCenter:
			{
				if (request.isMethod(CinRequestMethod.Take) || request.isMethod(CinRequestMethod.Ask))
				{
					CinHeader to = request.To;
					ipEndPoint = CinRouterConfig.getServiceUri(to.getInt64(), route.getString());
				}
				else
				{
					CinHeader from = request.From;
					ipEndPoint = CinRouterConfig.getServiceUri(from.getInt64(), route.getString());
				}
				break;
			}
			case ActivationProxy:
			case RobotSubCenter:
			case RobotDiscoveryPlatform:
			case ReportCenter:
			case EmoticonCenter:
			case PhoneBookCenter:
				// case CinSmsBaseCenter:
			case ContactCenter:
			case CinSyncCenter:
			case OfflineMessageCenter:
			case PortraitCenter:
			case MessageConvertCenter:
			case VerifycationCodeService:
			case MessagePushProxy:
			case SocialCenter:
			case CollectMessageCenter:
			case SipRouter:
			case OcsAdapter:
			case QuotaCenter:
			case PublicPlatform:
			case RCSAdapter:
			case JionetCenter:
			case RobotMessageCenter:
				CinHeader from = request.From;
				ipEndPoint = CinRouterConfig.getServiceUri(from.getInt64(), route.getString());
				break;
			case ConfigCenter:
				// case BasicDataCenter:
				ipEndPoint = CinRouterConfig.getServiceUri(0, route.getString());
				break;
			case VideoCenterSystem:
			    CinHeader eventvdcs = request.Event;
			    if(eventvdcs.getInt64() == CinVideoEvent.GetStunTurnServerInfo){
			      
			       CinHeader tovdcs = request.To;
			       ipEndPoint = CinRouterConfig.getServiceUri(tovdcs.getInt64(), route.getString());     
			    }else if(eventvdcs.getInt64() == CinVideoEvent.JoinRoom )
			    {
			    	CinHeader tovdcs = request.getHeader(CinHeaderType.Status);
				    ipEndPoint = CinRouterConfig.getServiceUri(tovdcs.getInt64(), route.getString());
			    }else if(eventvdcs.getInt64() == CinVideoEvent.QuitVideoRoom || eventvdcs.getInt64() == CinVideoEvent.DissolutionGroup )
			    {
			    	CinHeader tovdcs = request.getHeader(CinHeaderType.To);
				    ipEndPoint = CinRouterConfig.getServiceUri(tovdcs.getInt64(), route.getString());
				   
				}
			    else{
			       CinHeader fromvdcs = request.From;
			       ipEndPoint = CinRouterConfig.getServiceUri(fromvdcs.getInt64(), route.getString());     
			    }
			    break;
			case TraceCenter:
			case LogCenter:
			case AttendanceService:
			case RichMediaCenter:
				// case RcsFakeHSS:
			case UserIdCenter:
			case DatabaseAccessLayer:
			case EventFilterService:
			case PushNotificationProxy:
			case TrackingCenter:
			case JioMoneyProxy:
			case MessageReceiptService:
				ipEndPoint = CinRouterConfig.getServiceUri(route.getString());
				break;
			case VideoRoomSystem:
			case HdVideoCenter:
			case VideoCenter:
			{
				byte[] b = Arrays.copyOf(request.getHeader(CinHeaderType.Key).getValue(), 8);
				long id;
				// check router type
				if ((b[0] & 0x80) == 0x80)
					id = (long) (b[0] & 0x7F) - 1;
				else
					id = CinConvert.bytes2Long(b);
				ipEndPoint = CinRouterConfig.getServiceUri(id, route.getString());
				break;
			}
			case DataCenter:
				String key = request.getHeader(CinHeaderType.Key).getString();
				if(key.toLowerCase().startsWith("ceph-")){
					int index = key.indexOf("-", 5) + 1;
					String subKey = key.substring(index, index+8);
					long subId = CinConvert.bytes2Long(Arrays.copyOf(CinConvert.hexToBytes(subKey), 4));
					ipEndPoint = CinRouterConfig.getServiceUri(subId, route.getString());
				} else {
					String subKey = key.substring(0, 8);
					long subId = CinConvert.bytes2Long(Arrays.copyOf(CinConvert.hexToBytes(subKey), 4));
					ipEndPoint = CinRouterConfig.getServiceUri(subId, route.getString());
				}
				break;

			case MediaGatewaAdapter:
			{
				CinHeader to = request.To;
				long toid = Long.valueOf(to.getString().substring(4));
				ipEndPoint = CinRouterConfig.getServiceUri(toid, route.getString());
				break;
			}
			case GroupCenter:
			case SmsAdapter:
			case MessageCenter:
				// use From to route for the robot message.
				if (CinUtil.isRobotId(request.To.getInt64()))
				{
					ipEndPoint = CinRouterConfig.getServiceUri(request.From.getInt64(), route.getString());
					break;
				}
				// case APNSGateway:
				// case ThemeCenter:
			default:
				CinHeader to = request.To;
				ipEndPoint = CinRouterConfig.getServiceUri(to.getInt64(), route.getString());
				break;
		}
		route.setType(CinHeaderType.RecordRoute);
		return ipEndPoint;
	}

	/**
	 * Parameters in the request for routing information
	 * 
	 * @param request
	 * @return SocketAddress that the request should be sent
	 */
	public static InetSocketAddress takeRoute(CinRequest request)
	{
		CinHeader route = request.getHeader(CinHeaderType.Route);
		if (CinServiceName.get(route.getString()) == CinServiceName.MessageProxy)
		{
			CinHeader tpid = request.Tpid;
			route.setType(CinHeaderType.RecordRoute);
			return CinPersonalId.parse(tpid.getValue()).getAddress();
		}
		else
		{
			String[] ipEndPoint = takeStringRoute(request).split(RouterSeparator);
			return new InetSocketAddress(ipEndPoint[0], Integer.parseInt(ipEndPoint[1]));
		}
	}

	/**
	 * According to the parameters of the service name for address list
	 * 
	 * @param serviceName
	 * @return A list of Socket addresses that a service name refers to
	 */
	public static ArrayList<InetSocketAddress> takeServiceRoute(CinServiceName serviceName)
	{
		return CinRouterConfig.takeServiceRoute(serviceName);
	}

	/**
	 * According to the parameters of the service name string for address list
	 * 
	 * @param serviceName
	 * @return A list of Socket addresses that a service name accords to
	 */
	public static ArrayList<InetSocketAddress> takeServiceRoute(String serviceName)
	{
		return CinRouterConfig.takeServiceRoute(serviceName);
	}

	/**
	 * According to the parameters of the service name string to get the address
	 * 
	 * @param serviceName
	 * @return The first socket address in the list of Socket addresses that a
	 *         service name accords to
	 */
	public static InetSocketAddress takeRoute(CinServiceName serviceName)
	{
		try
		{
			return CinRouterConfig.takeServiceRoute(serviceName).get(0);
		}
		catch (Exception ex)
		{
			return null;
		}
	}

	public static InetSocketAddress getAddress(String serviceName, long routerId)
	{
		String[] ipEndPoint = CinRouterConfig.getServiceUri(routerId, serviceName).split(RouterSeparator);
		return new InetSocketAddress(ipEndPoint[0], Integer.parseInt(ipEndPoint[1]));
	}

	public static InetSocketAddress getAddress(String serviceName)
	{
		String[] ipEndPoint = CinRouterConfig.getServiceUri(serviceName).split(RouterSeparator);
		return new InetSocketAddress(ipEndPoint[0], Integer.parseInt(ipEndPoint[1]));
	}

}
