package com.allstar.cinrouter;

import java.util.HashMap;

/**
 * The service name enumeration
 *
 */
public enum CinServiceName {
	ConfigCenter("CNC"),
	MessageProxy("CMP"),
	MessageCenter("MSC"),
	SmsAdapter("SMSA"),
	UserCacheCenter("UCC"), 
	Nav("NAV"),
	GroupCenter("CGC"),
	TraceCenter("TRC"),
	LogCenter("LOG"),
	OfflineMessageCenter("OMC"),
	ActivationProxy("CAP"),
	RobotSubCenter("RSC"),
	RobotDiscoveryPlatform("RDP"),
	CinRobotCenter("ROBOT"),
	ReportCenter("REP"),
	CounterCenter("COUNTER"),
	EmoticonCenter("EMC"),
	UserIdCenter("UIDC"),
	QuotaCenter("QTC"),
	PhoneBookCenter("PBC"),
	DataCenter("DTC"),
	VideoRoomSystem("VRS"),
	HdVideoCenter("HDVDC"),
	VideoCenter("VDC"),
	VideoCenterSystem("VDCS"),
	ContactCenter("CONC"),
	PortraitCenter("POC"),
	CinSyncCenter("CSC"),
	MessagePushProxy("MPP"),
	VerifycationCodeService("VCS"),
	AppCenter("APC"),
	MessageConvertCenter("MCC"),
	SocialCenter("SOC"),
	AttendanceService("ATS"),
	CollectMessageCenter("CMC"),
	MediaGatewaAdapter("MGA"),
	SipRouter("SIPR"),
	PublicPlatform("PUBP"),
	OcsAdapter("OCSA"),
	PPMessageCenter("PPMSC"),
	MessageCenter4PublicPlatform("MSC4PP"),
	RCSAdapter("RCSA"),
	JionetCenter("JNC"),
	RobotMessageCenter("RBC"),
	OperationWebService("OWS"),
	MarketingWebService("MWS"),
	CustomerCareWebService("CCWS"),
	MPNSGateway("MPNS"),
	RichMediaCenter("RMC"),
	TrackingCenter("TRACK"),
	SmsToMsg("STM"),
	DatabaseAccessLayer("DAL"),
	EventFilterService("EFS"),
	RealTimeLocationSharing("RTLS"),
	GoogleCloudMessage("GCM"),
	PushNotificationProxy("PushProxy"),
	JioMoneyProxy("JioMoneyProxy"),
	MessageReceiptService("MRS"),
	Unknown("Unknow");

	private static HashMap<String, CinServiceName> _map;
	private String value;
	
	static {
		_map = new HashMap<String, CinServiceName>();
		for(CinServiceName requestMethod : CinServiceName.values())
			_map.put(requestMethod.getValue(), requestMethod);
	}
	
	public static CinServiceName get(String key) {
		CinServiceName method = _map.get(key);
		if(method == null)
			return Unknown;
		return method;
	}
	
	CinServiceName(String value)
	{
		this.value = value;
	}

	public String getValue() {
		return value;
	}
	
}
