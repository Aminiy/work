package com.allstar.cinrouter;

import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import com.allstar.cinconfig.CinConfigEntity;
import com.allstar.cinconfig.CinConfigInterface;

/**
 * Routing module configuration class
 * 
 * 
 */
public class CinRouterConfig extends CinConfigInterface
{

	private static String _domain;
	private static HashMap<String, HashMap<String, String>> _dicServices;
	private static CinConfigInterface _instance;
	private static Random _ra = new Random();

	CinRouterConfig()
	{
		_tableName = CinRouter.class.getSimpleName();
	}

	static void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new CinRouterConfig();
			_dicServices = new HashMap<String, HashMap<String, String>>();
			_instance.updateConfig();
		}
	}

	@Override
	protected synchronized void setValues(CinConfigEntity config)
	{
		_dicServices = new HashMap<String, HashMap<String, String>>();
		for (String key : config.getKeySet())
		{
			putService(key, config.get(key));
		}
	}

	private void putService(String serviceKey, String serviceIpEndPoint)
	{
		String[] serviceInfo;
		serviceInfo = serviceKey.split("\\.");
		if (_dicServices.get(serviceInfo[0]) == null)
		{
			_dicServices.put(serviceInfo[0], new HashMap<String, String>());
		}
		putServiceInfo(serviceInfo, serviceIpEndPoint);
	}

	private void putServiceInfo(String[] serviceInfo, String serviceIpEndPoint)
	{
		if (serviceInfo.length == 1)
		{
			_dicServices.get(serviceInfo[0]).put("1", serviceIpEndPoint);
		}
		else
		{
			_dicServices.get(serviceInfo[0]).put(serviceInfo[1], serviceIpEndPoint);
		}
	}

	static String domain()
	{
		return _domain;
	}

	static String getServiceUri(long toUid, String serviceName)
	{
		long serviceCount = _dicServices.get(serviceName).size();
		long targetServiceNum = Math.abs(toUid % serviceCount) + 1;
		return (String) _dicServices.get(serviceName).get(String.valueOf(targetServiceNum));
	}

	static String getServiceUri(String serviceName)
	{
		int serviceCount = _dicServices.get(serviceName).size();
		int targetServiceNum = Math.abs(_ra.nextInt() % serviceCount) + 1;
		return (String) _dicServices.get(serviceName).get(String.valueOf(targetServiceNum));
	}

	/**
	 * To obtain parameters specified in the number of services in the service
	 * name
	 * 
	 * @param serviceName
	 * @return Number of services with same service name
	 */
	public static int getServiceCount(String serviceName)
	{
		return _dicServices.get(serviceName).size();
	}

	/**
	 * To obtain parameters specified in the number of services in the service
	 * name
	 * 
	 * @param servicename
	 * @return Number of services with same service name
	 */
	public static int getServiceCount(CinServiceName servicename)
	{
		return getServiceCount(servicename.getValue());
	}

	static synchronized ArrayList<InetSocketAddress> takeServiceRoute(CinServiceName serviceName)
	{
		ArrayList<InetSocketAddress> ret = new ArrayList<InetSocketAddress>();
		for (String simpleServiceName : _dicServices.keySet())
		{
			if (CinServiceName.get(simpleServiceName) == serviceName)
			{
				for (String ipEndPoint : _dicServices.get(simpleServiceName).values())
				{
					ret.add(new InetSocketAddress(ipEndPoint.split(":")[0], Integer.parseInt(ipEndPoint.split(":")[1])));
				}
				break;
			}
		}
		return ret;
	}

	static synchronized ArrayList<InetSocketAddress> takeServiceRoute(String serviceName)
	{
		ArrayList<InetSocketAddress> ret = new ArrayList<InetSocketAddress>();
		for (String simpleServiceName : _dicServices.keySet())
		{
			if (CinServiceName.get(simpleServiceName).toString().equals(serviceName))
			{
				for (String ipEndPoint : _dicServices.get(simpleServiceName).values())
				{
					ret.add(new InetSocketAddress(ipEndPoint.split(":")[0], Integer.parseInt(ipEndPoint.split(":")[1])));
				}
				break;
			}
		}
		return ret;
	}

}
