package com.allstar.cincache;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cinconfig.CinConfigure;
import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinLinkedList;
import com.allstar.cinutil.CinLinkedNode;

public class CinCacheList4Long
{
	private final int Byte_Array_Size = 8;
	private final int File_Size;
	private RandomAccessFile raf;
	private FileChannel ioChannel;
	private MappedByteBuffer buf;
	private int minUnusedPos;
	private CinLinkedList<Integer> _queue;
	private ConcurrentHashMap<Long, Integer> _indexHash;

	public CinCacheList4Long(String filename, int valueCount) throws IOException
	{
		File_Size = valueCount * Byte_Array_Size;
		String dictionary = ("/data/caches/" + CinConfigure.serviceName + "/" + CinConfigure.computerName).toLowerCase();
		String fileName = (dictionary + "/" + filename + ".cache").toLowerCase();
		open(dictionary, fileName);
	}

	public CinCacheList4Long(String _dictionary, String filename, int valueCount) throws IOException
	{
		File_Size = valueCount * Byte_Array_Size;
		String fileName = (_dictionary + "/" + filename + ".cache").toLowerCase();
		open(_dictionary, fileName);
	}

	private void open(String dictionary, String fileName) throws IOException
	{
		File fl = new File(dictionary);
		if (!fl.exists())
		{
			fl.mkdirs();
		}
		raf = new RandomAccessFile(fileName, "rwd");
		ioChannel = raf.getChannel();
		buf = ioChannel.map(MapMode.READ_WRITE, 0, File_Size);
		_indexHash = new ConcurrentHashMap<Long, Integer>();
		loadEmptySpace();
	}

	private void loadEmptySpace() throws IOException
	{
		minUnusedPos = -1;
		_queue = new CinLinkedList<Integer>();
		int maxAbility = (int) Math.floor(File_Size / Byte_Array_Size);
		for (int i = maxAbility - 1; i >= 0; i--)
		{
			if (isEmpty(i))
			{
				if (minUnusedPos >= 0)
					_queue.put(i);
			}
			else
			{
				long l = get(i);
				if (l > 0L)
				{
					_indexHash.put(l, i);
				}
				else
				{
					_queue.put(i);
				}
				if (minUnusedPos < 0)
					minUnusedPos = i + 1;
			}
		}
		if (minUnusedPos < 0)
			minUnusedPos = 0;
		loadResult();
	}

	private void loadResult()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("LOAD_RESULT--userd space:");
		sb.append(_indexHash.size());
		sb.append("||empty queue length:");
		sb.append(_queue.length());
		sb.append("||min position unused:");
		sb.append(minUnusedPos);
		sb.append("||space remain:");
		sb.append((File_Size / Byte_Array_Size) - _indexHash.size());
		CinTracer.getInstance(getClass()).special(sb.toString());
	}

	public void close() throws IOException
	{
		raf.close();
		ioChannel.close();
		_indexHash.clear();
		buf.clear();
	}

	public Integer remove(long l) throws IOException
	{
		Integer index = _indexHash.get(l);
		if (index == null)
			return null;
		remove(index);
		return _indexHash.remove(l);
	}

	private void remove(int index) throws IOException
	{
		buf.putLong(index * Byte_Array_Size, 0);
		_queue.put(index);
	}

	public int add(long l) throws IOException
	{
		if (isExist(l))
			return -1;
		int pos = 0;
		CinLinkedNode<Integer> node = _queue.takeAwayFirst();
		if (node == null)
		{
			pos = minUnusedPos;
			if (pos * Byte_Array_Size + Byte_Array_Size > File_Size)
				throw new IOException("No space to write a byte!");
			minUnusedPos = minUnusedPos + 1;
		}
		else
		{
			pos = node.object().intValue();
		}
		buf.position(pos * Byte_Array_Size);
		buf.putLong(l);
		_indexHash.put(l, pos);
		return pos;
	}

	private synchronized long get(int index) throws IOException
	{
		buf.position(index * Byte_Array_Size);
		return buf.getLong();
	}

	private boolean isEmpty(int index)
	{
		int pos = index * Byte_Array_Size;
		if (pos >= File_Size)
			return true;
		return buf.getLong(pos) == 0L ? true : false;
	}

	public Long[] getValues()
	{
		return _indexHash.keySet().toArray(new Long[0]);
	}

	public boolean isExist(long l)
	{
		return _indexHash.containsKey(l);
	}
}
