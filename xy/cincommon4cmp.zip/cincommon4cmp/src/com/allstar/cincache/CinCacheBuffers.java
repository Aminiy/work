package com.allstar.cincache;

import java.io.IOException;
import com.allstar.cinstack.handler.codec.CinEncoder;
import com.allstar.cinstack.handler.codec.CinMessageReader;
import com.allstar.cinstack.message.CinMessage;

public class CinCacheBuffers
{
	private CinCacheBuffer[] bufArray;
	private int messageMaxSize = 0;

	public CinCacheBuffers(String dir, String fileName, int fileSize, int fileCount, int maxMsgSize) throws IOException
	{
		bufArray = new CinCacheBuffer[fileCount];
		messageMaxSize = maxMsgSize;
		int i = 0;
		while (i < fileCount)
		{
			String fname = dir + "/" + fileName + i + ".cache";
			bufArray[i] = new CinCacheBuffer(fname.toLowerCase(), fileSize);
			i++;
		}
	}

	public int size()
	{
		return bufArray.length;
	}

	public CinMessage get(int fileNumber, int position)
	{
		if (fileNumber >= this.size())
			return null;
		return CinMessageReader.parse(bufArray[fileNumber].get(position, messageMaxSize));
	}

	public CinMessage get(Long address)
	{
		if (address == null)
			return null;
		return CinMessageReader.parse(bufArray[CinCacheUtil.getFileNumber(address)].get(CinCacheUtil.getPosition(address), messageMaxSize));
	}

	public byte[] getBytes(Long address)
	{
		int pos = CinCacheUtil.getPosition(address);
		if (address == null || bufArray[CinCacheUtil.getFileNumber(address)].getByte(pos) == 0)
			return null;
		return bufArray[CinCacheUtil.getFileNumber(address)].get(pos, messageMaxSize);
	}

	public void put(Long address, CinMessage message)
	{
		if (message == null)
			return;
		put(address, CinEncoder.toBytes(message));
	}

	public void put(Long address, byte[] b)
	{
		if (b == null)
			return;
		bufArray[CinCacheUtil.getFileNumber(address)].put(b, CinCacheUtil.getPosition(address));
	}
}
