package com.allstar.cincache;

import java.net.InetSocketAddress;
import java.net.SocketAddress;

import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.handler.codec.CinEncoder;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cintracer.CinTracer;

public class CinCacheUtil
{
	public static final byte CACHE_METHOD = (byte) 1;
	public static final byte CACHE_TOOL_METHOD = (byte) 2;

	public class ServiceEvent
	{
		public static final byte Add = (byte) 1;
		public static final byte Update = (byte) 2;
		public static final byte Remove = (byte) 3;
		public static final byte Memory = (byte) 4;
		public static final byte BrotherServiceNotify = (byte) 5;
		public static final byte Sync = (byte) 6;
		public static final byte KickBrother = (byte) 7;
	}

	public class CacheToolEvent
	{
		public static final byte ToolAdd = (byte) 1;
		public static final byte ToolUpdate = (byte) 2;
		public static final byte ToolRemove = (byte) 3;
		public static final byte Get = (byte) 4;
		public static final byte GetKeys = (byte) 5;
		public static final byte Connect = (byte) 6;
		public static final byte SyncAll = (byte) 7;
		public static final byte HasBrother = (byte) 8;
	}

	public class ChangeType
	{
		public static final byte Add = (byte) 1;
		public static final byte Update = (byte) 2;
		public static final byte Remove = (byte) 3;
		public static final byte SyncOK = (byte) 4;
		public static final byte Memory = (byte) 5;
		public static final byte Response = (byte) 6;
		public static final byte Resp_Error = (byte) 10;
		public static final byte Resp_OK_ADD = (byte) 11;
		public static final byte Resp_OK_UPDATE = (byte) 12;
		public static final byte Resp_OK_REMOVE = (byte) 13;
		public static final byte Resp_OK_MEMORY = (byte) 14;
	}

	public static CinTransaction buildTrans(Long key, Long hashKey, byte eventType, CinMessage data, CinStack stack, SocketAddress socketAddress)
	{
		CinRequest req = new CinRequest(CACHE_METHOD);
		req.addHeader(new CinHeader(CinHeaderType.From, key));
		req.addHeader(new CinHeader(CinHeaderType.To, hashKey));
		req.addHeader(new CinHeader(CinHeaderType.Event, eventType));
		if (data != null)
			req.addBody(CinEncoder.toBytes(data));
		CinTransaction trans = stack.createTransaction((InetSocketAddress)socketAddress, req);
		return trans;
	}

	public static CinTransaction toolBuildTrans(Long key, byte eventType, CinMessage data, CinStack stack, SocketAddress socketAddress)
	{
		CinRequest req = new CinRequest(CACHE_METHOD);
		req.addHeader(new CinHeader(CinHeaderType.From, key));
		req.addHeader(new CinHeader(CinHeaderType.Event, eventType));
		if (data != null)
			req.addBody(CinEncoder.toBytes(data));
		CinTransaction trans = stack.createTransaction((InetSocketAddress)socketAddress, req);
		return trans;
	}

	public static int getModNum(Long l, int modNum)
	{
		return (int) (Math.abs(l) % 157) % modNum;
	}

	public static int getFileNumber(long address)
	{
		return (int) (address >> 32);
	}

	public static int getPosition(long address)
	{
		return (int) address;
	}

	public static long getAddress(Integer bufNumber, Integer position)
	{
		return ((long) bufNumber << 32) + position;
	}

	public static String bytesToHex(byte[] value)
	{
		StringBuffer sb = new StringBuffer();
		if (value.length > 0)
		{
			for (byte b : value)
			{
				sb.append(String.format("%02X", b));
			}
		}
		return sb.toString();
	}

	public static void kickBrotherService(CinStack stack, SocketAddress socketAddress)
	{
		CinRequest request = new CinRequest(CACHE_METHOD);
		request.addHeader(new CinHeader(CinHeaderType.Event, ServiceEvent.KickBrother));
		CinTransaction trans = stack.createTransaction((InetSocketAddress)socketAddress, request);
		trans.sendRequest();
	}

	public static void sendRouterBrotherDead()
	{
		CinTracer.getInstance(CinCacheUtil.class).special("sendRouterBrotherDead!!!!!");
	}

	public static void sendRouterAvaliable()
	{
		CinTracer.getInstance(CinCacheUtil.class).special("sendRouterAvaliable!!!!!");
	}
}
