package com.allstar.cincache;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel.MapMode;

public class CinCacheBuffer
{
	private MappedByteBuffer buf;
	private RandomAccessFile raf;
	public CinCacheBuffer(String fileName, int fileSize) throws IOException
	{
		raf = new RandomAccessFile(fileName, "rwd");
		buf = raf.getChannel().map(MapMode.READ_WRITE, 0, fileSize);
	}

	public synchronized void putLong(long l, int position)
	{
		buf.putLong(position, l);
	}
	public synchronized Long getLong(int position)
	{
		return buf.getLong(position);
	}

	public synchronized byte[] get(int positon,int length)
	{
		byte[] bytes = new byte[length];
		buf.position(positon);
		buf.get(bytes);
		return bytes;
	}
	public synchronized void putByte(byte b,int position)
	{
		buf.put(position, b);
	}
	public synchronized byte getByte(int position)
	{
		return buf.get(position);
	}

	public synchronized void put(byte[] message, int position)
	{
		buf.position(position);
		buf.put(message);
	}

	public synchronized void remove(int position)
	{
		buf.putLong(position, 0);
	}
	
	public synchronized void finalize()
	{
		try
		{
			raf.close();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
}
