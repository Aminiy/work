package com.allstar.cincache;

import java.io.IOException;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinLinkedList;
import com.allstar.cinutil.CinLinkedNode;

public class CinCacheIndex
{
	private final int KEY_SIZE = 8;
	private CinCacheBuffer buf;
	private ConcurrentHashMap<Long, Long> _hash;
	private CinLinkedList<Integer>[] _emptyPositionList;
	private int eachFileCount;
	private int maxMsgSize;
	private int fileCount;

	public CinCacheIndex(String dir, String fileName, int fileSize, int fileCount, int maxMsgSize) throws IOException
	{
		String indexFileName = dir + "/" + fileName + ".index";
		eachFileCount = fileSize / maxMsgSize;
		int indexFileSize = (KEY_SIZE * eachFileCount * fileCount);
		buf = new CinCacheBuffer(indexFileName.toLowerCase(), indexFileSize);
		this.maxMsgSize = maxMsgSize;
		this.fileCount = fileCount;
		initArray(indexFileSize);
	}

	@SuppressWarnings("unchecked")
	public void initArray(int indexFileSize)
	{
		_hash = new ConcurrentHashMap<Long, Long>();
		_emptyPositionList = new CinLinkedList[fileCount];
		int i = 0;
		while (i < fileCount)
		{
			_emptyPositionList[i] = new CinLinkedList<Integer>();
			i++;
		}
		loadIndex(indexFileSize);
	}

	private void loadIndex(int indexFileSize)
	{
		Long key;
		int position = 0;
		int fileCount = 0;
		int index = 0;
		while (position < indexFileSize)
		{
			key = buf.getLong(position);
			if (key == null || key == 0L)
				addEmptyPosition(fileCount, index * maxMsgSize);
			else
				putHash(key, CinCacheUtil.getAddress(fileCount, index * maxMsgSize));
			position += KEY_SIZE;
			index++;
			if (index == eachFileCount)
			{
				fileCount++;
				index = 0;
			}
		}
		openInfo();
	}

	private void openInfo()
	{
		int total = _hash.size();
		int totalEmpty = 0;
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < _emptyPositionList.length; i++)
		{
			totalEmpty += (_emptyPositionList[i].length());
		}
		sb.append("total:" + total + "\n");
		sb.append("empty:" + totalEmpty);
		CinTracer.getInstance(CinCacheIndex.class).special(sb.toString());
	}

	private int getIndexBufferPosition(Long address)
	{
		int indexPosition = (CinCacheUtil.getFileNumber(address) * eachFileCount) + (CinCacheUtil.getPosition(address) / maxMsgSize);
		return indexPosition * KEY_SIZE;
	}

	private void addEmptyPosition(int fileCount, int position)
	{
		_emptyPositionList[fileCount].put(position);
	}

	public void put(Long key, Long address)
	{
		_hash.put(key, address);
		buf.putLong(key, getIndexBufferPosition(address));
	}

	public void putHash(Long key, Long address)
	{
		_hash.put(key, address);
	}

	public Long getAddress(Long key)
	{
		if (key != null)
		{
			return _hash.get(key);
		}
		return null;
	}

	public Long getEmptyAddress(Long key)
	{
		if (key != null)
		{
			Integer fileNum = CinCacheUtil.getModNum(key, fileCount);
			CinLinkedNode<Integer> node = _emptyPositionList[fileNum].takeAwayFirst();
			if (node != null)
				return CinCacheUtil.getAddress(fileNum, node.object());
		}
		return null;
	}

	public Long getKey(Long address)
	{
		int position = (CinCacheUtil.getFileNumber(address) * eachFileCount + (CinCacheUtil.getPosition(address) / maxMsgSize)) * KEY_SIZE;
		return buf.getLong(position);
	}

	public Long remove(Long key)
	{
		Long address = getAddress(key);
		if (address == null)
			return address;
		buf.remove(getIndexBufferPosition(address));
		_hash.remove(key);
		_emptyPositionList[CinCacheUtil.getFileNumber(address)].put(CinCacheUtil.getPosition(address));
		return address;
	}

	public LinkedList<Long> getKeys()
	{
		return new LinkedList<Long>(_hash.keySet());
	}

	public boolean isExist(Long key)
	{
		return _hash.containsKey(key);
	}
}
