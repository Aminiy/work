package com.allstar.cincache;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinutil.CinLinkedList;
import com.allstar.cinutil.CinLinkedNode;

public class CinCacheLRU
{
	private CinLinkedList<CinMessage> _list;
	private ConcurrentHashMap<Long, CinLinkedNode<CinMessage>> _hash;
	private CinCacheBuffers buffers;
	private CinCacheIndex index;
	private int listMaxSize;

	public CinCacheLRU(int lruLength, CinCacheIndex index,CinCacheBuffers buffers) throws IOException
	{
		_list = new CinLinkedList<CinMessage>();
		_hash = new ConcurrentHashMap<Long, CinLinkedNode<CinMessage>>();
		this.buffers = buffers;
		this.index = index;
		listMaxSize = lruLength;
	}

	public CinMessage get(Long key)
	{
		if (key == null)
			return null;
		CinLinkedNode<CinMessage> node = _hash.get(key);
		CinMessage msg = null;
		if (node == null)
		{
			msg = getFromFile(key);
			if (msg != null)
				putList(key, msg);
		}
		else
		{
			msg = node.object();
			_list.kick(node);
		}
		return msg;
	}

	public void put(Long key)
	{
		CinMessage msg = getFromFile(key);
		if (msg != null)
		{
			CinLinkedNode<CinMessage> node = _hash.get(key);
			if (node == null)
			{
				_hash.put(key, _list.put(msg));
			}
			else
			{
				_list.remove(node);
				putList(key, msg);
			}
		}
		else
		{
			_list.remove(_hash.remove(key));
		}
	}

	private void putList(Long key, CinMessage msg)
	{
		if (_list.length() == listMaxSize)
			_hash.remove(_list.takeAwayFirst());
		_hash.put(key, _list.put(msg));
	}

	private CinMessage getFromFile(Long key)
	{
		CinMessage msg = null;
		Long address = index.getAddress(key);
		if (address != null)
		{
			msg = buffers.get(address);
		}
		return msg;
	}

	public void remove(Long key)
	{
		_list.remove(_hash.remove(key));
	}
}
