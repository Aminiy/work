package com.allstar.cincache;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;

import com.allstar.cinconfig.CinConfigure;
import com.allstar.cinstack.handler.codec.CinEncoder;
import com.allstar.cinstack.message.CinMessage;

/**
 * Based on Java NIO key - value data reading and writing modules
 * 
 * 
 */
public class CinCache
{
	private static final Integer DEFAULT_LRU_LENGTH = 50000;
	private static final String DEFAULT_DIR = "/data/caches/" + CinConfigure.serviceName + "/" + CinConfigure.computerName;
	private CinCacheIndex index;
	private CinCacheBuffers buffers;
	private byte keyHeaderType;
	private int maxMsgSize;

	/**
	 * The constructor
	 * 
	 * @param configure
	 * @throws IOException
	 */
	public CinCache(CinCacheConfigure configure) throws IOException
	{
		this(configure.dir, configure.fileName, configure.fileSize, configure.fileCount, configure.maxMsgSize, configure.keyHeader, configure.lruLength);
	}

	/**
	 * The constructor
	 * 
	 * @param propertiesName
	 * @throws IOException
	 */
	public CinCache(String propertiesName) throws IOException
	{
		this(new CinCacheConfigure(propertiesName));
	}

	/**
	 * The constructor
	 * 
	 * @param fileName
	 * @param fileSize
	 * @param fileCount
	 * @param maxMsgSize
	 * @param keyHeader
	 * @throws IOException
	 */
	public CinCache(String fileName, int fileSize, int fileCount, int maxMsgSize, byte keyHeader) throws IOException
	{
		this(DEFAULT_DIR, fileName, fileSize, fileCount, maxMsgSize, keyHeader, DEFAULT_LRU_LENGTH);
	}

	/**
	 * The constructor
	 * 
	 * @param dir
	 * @param fileName
	 * @param fileSize
	 * @param fileCount
	 * @param maxMsgSize
	 * @param keyHeader
	 * @param lruLength
	 * @throws IOException
	 */
	public CinCache(String dir, String fileName, int fileSize, int fileCount, int maxMsgSize, byte keyHeader, Integer lruLength) throws IOException
	{
		String dirPath = (dir + "/" + fileName).toLowerCase();
		File fl = new File(dirPath);
		if (!fl.exists())
			fl.mkdirs();
		fileSize = fileSize * CinCacheConfigure.Each_M_Size;
		this.buffers = new CinCacheBuffers(dirPath, fileName, fileSize, fileCount, maxMsgSize);
		this.index = new CinCacheIndex(dirPath, fileName, fileSize, fileCount, maxMsgSize);
		// this.lru = new CinCacheLRU(lruLength, index, buffers);
		this.keyHeaderType = keyHeader;
		this.maxMsgSize = maxMsgSize;
	}

	/**
	 * According to the key parameters to read data and return
	 * 
	 * @param key
	 * @return
	 */
	public CinMessage read(long key)
	{
		Long address = index.getAddress(key);
		if (address == null)
			return null;
		else
			return buffers.get(address);
	}

	/**
	 * According to the parameters of the key data is read and returns byte []
	 * 
	 * @param key
	 * @return
	 */
	public byte[] readBytes(long key)
	{
		Long address = index.getAddress(key);
		if (address == null)
			return null;
		else
			return buffers.getBytes(address);
	}

	private boolean checkMessage(CinMessage message)
	{
		return (message != null && message.containsHeader(keyHeaderType));
	}

	/**
	 * The parameter of CinMessage written to the Cache
	 * 
	 * @param message
	 * @return
	 */
	public boolean write(CinMessage message)
	{
		if (!checkMessage(message))
			return false;
		byte[] value = CinEncoder.toBytes(message);
		if (value.length > maxMsgSize)
			return false;
		long key = message.getHeader(keyHeaderType).getInt64();
		Long address = index.getEmptyAddress(key);
		if (address == null)
			return false;
		buffers.put(address, value);
		index.put(key, address);
		return true;
	}

	/**
	 * Update the data in the Cache
	 * 
	 * @param message
	 * @return
	 */
	public boolean update(CinMessage message)
	{
		if (!checkMessage(message))
			return false;
		byte[] value = CinEncoder.toBytes(message);
		if (value.length > maxMsgSize)
			return false;
		long key = message.getHeader(keyHeaderType).getInt64();
		Long address = index.getAddress(key);
		if (address == null)
			return false;
		buffers.put(address, value);
		return true;
	}

	/**
	 * Write Cache will byte []
	 * 
	 * @param key
	 * @param value
	 * @return
	 */
	public boolean write(long key, byte[] value)
	{
		Long address = index.getEmptyAddress(key);
		if (address == null)
			return false;
		buffers.put(address, value);
		index.put(key, address);
		return true;
	}

	/**
	 * According to the key value orientation to the data in the Cache and the byte [] write Cache, overwriting the original data
	 * 
	 * @param key
	 * @param value
	 * @return
	 */
	public boolean update(long key, byte[] value)
	{
		Long address = index.getAddress(key);
		if (address == null)
			return false;
		buffers.put(address, value);
		return true;
	}

	/**
	 * If the address to write data, if have the update data
	 * 
	 * @param message
	 * @return
	 */
	public boolean wirteOrUpdate(CinMessage message)
	{
		if (!checkMessage(message))
			return false;
		byte[] value = CinEncoder.toBytes(message);
		if (value.length > maxMsgSize)
			return false;
		long key = message.getHeader(keyHeaderType).getInt64();
		Long address = index.getAddress(key);
		if (address == null)
		{
			address = index.getEmptyAddress(key);
			index.put(key, address);
		}
		if (address == null)
			return false;
		buffers.put(address, value);
		return true;
	}

	/**
	 * Check the parameters of the key exists in the Cache
	 * 
	 * @param key
	 * @return
	 */
	public boolean isExist(long key)
	{
		return index.getAddress(key) != null;
	}

	/**
	 * Delete key corresponding to the data in the Cache
	 * 
	 * @param key
	 * @return
	 */
	public boolean remove(long key)
	{
		Long address = index.remove(key);
		if (address != null)
		{
			buffers.put(address, new byte[]{0});
			return true;
		}
		else
			return false;
	}

	/**
	 * To get the Key in the Cache list
	 * 
	 * @return
	 */
	public LinkedList<Long> getKeys()
	{
		return index.getKeys();
	}

}
