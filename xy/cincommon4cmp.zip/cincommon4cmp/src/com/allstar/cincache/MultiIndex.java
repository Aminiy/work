package com.allstar.cincache;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinMessage;

public class MultiIndex
{
	private ConcurrentHashMap<Long, Long>[] _hashArray;
	private ConcurrentHashMap<Byte, Integer> _headerHash;
	private CinCacheConfigure configure;

	@SuppressWarnings("unchecked")
	public MultiIndex(CinCacheConfigure cacheConfigure, CinCacheBuffers buffers) throws IOException
	{
		this.configure = cacheConfigure;
		String[] headers = configure.indexHeaders.trim().split(",");
		if (headers.length > 0)
		{
			_headerHash = new ConcurrentHashMap<Byte, Integer>();
			_hashArray = new ConcurrentHashMap[headers.length];
			int i = 0;
			while (i < _hashArray.length)
			{
				_headerHash.put(Byte.valueOf(headers[i]), i);
				_hashArray[i] = new ConcurrentHashMap<Long, Long>();
				i++;
			}
			loadFiles(buffers);
		}
		else
		{
			throw new IOException("no key");
		}
	}

	private void loadFiles(CinCacheBuffers buffers)
	{
		int i = 0;
		int position;
		while (i < buffers.size())
		{
			int j = 0;
			position = 0;
			while (j < configure.fileSize / configure.maxMsgSize)
			{
				CinMessage message = buffers.get(i, position);
				if (message != null)
				{
					for (Byte type : _headerHash.keySet())
					{
						if (message.containsHeader(type.byteValue()))
						{
							Long key = message.getHeader(type.byteValue()).getInt64();
							Long address = CinCacheUtil.getAddress(i, position);
							_hashArray[_headerHash.get(type.byteValue())].put(key, address);
						}
					}
				}
				position += configure.maxMsgSize;
				j++;
			}
			i++;
		}
	}

	public Long get(Long key, CinHeaderType type)
	{
		Long address = _hashArray[_headerHash.get(type)].get(key);
		if (address != null)
		{
			return address;
		}
		else
		{
			return null;
		}
	}

	public void put(CinMessage message, Long address)
	{
		for (Byte type : _headerHash.keySet())
		{
			if (message.containsHeader(type))
			{
				Long key = message.getHeader(type.byteValue()).getInt64();
				_hashArray[_headerHash.get(type.byteValue())].put(key, address);
			}
		}
	}

	public void remove(CinMessage message)
	{
		for (Byte type : _headerHash.keySet())
		{
			if (message.containsHeader(type))
			{
				Long key = message.getHeader(type.byteValue()).getInt64();
				_hashArray[_headerHash.get(type.byteValue())].remove(key);
			}
		}
	}
}
