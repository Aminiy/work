package com.allstar.cincache.scalablecache;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

import com.allstar.cincache.CinCacheBuffers;
import com.allstar.cincache.CinCacheConfigure;
import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cintracer.CinTracer;

public class ScalableCache
{
	private ScalableCacheIndex index;
	private CinCacheBuffers buffers;
	private ScalableCacheLRU lru;
	private byte keyHeaderType;
	private int maxHeaderCount;
	private int cleanRatio = 80;

	public static final byte MessageFull = (byte) 1;
	public static final byte MessageNotFull = (byte) 0;

	public ScalableCache(CinCacheConfigure configure) throws IOException
	{
		this(configure.dir, configure.fileName, configure.fileSize, configure.fileCount, configure.maxMsgSize, configure.keyHeader, configure.maxHeaderCount, configure.lruLength, configure.cleanRatio);
	}

	public ScalableCache(String dir, String fileName, int fileSize, int fileCount, int maxMsgSize, byte keyHeaderType, int maxHeaderCount, Integer lruLength) throws IOException
	{
		String dirPath = (dir + "/" + fileName).toLowerCase();
		File fl = new File(dirPath);
		if (!fl.exists())
			fl.mkdirs();
		this.index = new ScalableCacheIndex(dirPath, fileName, fileSize, fileCount, maxMsgSize);
		this.buffers = new CinCacheBuffers(dirPath, fileName, fileSize, fileCount, maxMsgSize);
		if (lruLength != null)
			this.lru = new ScalableCacheLRU(lruLength, index, buffers);
		this.maxHeaderCount = maxHeaderCount;
		this.keyHeaderType = keyHeaderType;
	}

	public ScalableCache(String dir, String fileName, int fileSize, int fileCount, int maxMsgSize, byte keyHeaderType, int maxHeaderCount, Integer lruLength, Integer cleanRatio) throws IOException
	{
		String dirPath = (dir + "/" + fileName).toLowerCase();
		File fl = new File(dirPath);
		if (!fl.exists())
			fl.mkdirs();
		this.index = new ScalableCacheIndex(dirPath, fileName, fileSize, fileCount, maxMsgSize);
		this.buffers = new CinCacheBuffers(dirPath, fileName, fileSize, fileCount, maxMsgSize);
		if (lruLength != null)
			this.lru = new ScalableCacheLRU(lruLength, index, buffers);
		this.maxHeaderCount = maxHeaderCount;
		this.keyHeaderType = keyHeaderType;
		if (cleanRatio != null)
			this.cleanRatio = cleanRatio;
	}

	public ScalableCache(String propertiesName) throws IOException
	{
		this(new CinCacheConfigure(propertiesName));
	}

	public ArrayList<CinMessage> get(Long key)
	{
		if (lru != null)
			return lru.get(key);
		return getFromFile(key);
	}

	public ArrayList<CinMessage> getFromFile(Long key)
	{
		ArrayList<CinMessage> messageList = new ArrayList<CinMessage>();
		ArrayList<Long> addList = index.getAddress(key);
		if (addList == null)
			return null;
		for (int i = 0, len = addList.size(); i < len; i++)
		{
			CinMessage message = buffers.get(addList.get(i));
			messageList.add(message);
		}
		if (messageList.size() == 0)
			return null;
		return messageList;
	}

	public CinMessage update(CinMessage message, int sequence)
	{
		long key = message.getHeader(keyHeaderType).getInt64();
		ArrayList<Long> addList = index.getAddress(key);
		Long address = addList.get(sequence);
		if (addList != null && sequence < addList.size())
		{
			int headerCount = msgHeaderCount(message);
			if (sequence < addList.size() - 1 && headerCount < (maxHeaderCount * cleanRatio / 100))
			{
				CinMessage newMsg = buildNewMessage(key);
				for (Long add : addList)
				{
					if (!add.equals(address))
					{
						CinMessage msg = buffers.get(add);
						if (msg != null)
						{
							for (CinHeader header : msg.getHeaders())
							{
								if (header.getType() != keyHeaderType)
									newMsg.addHeader(header);
							}
							for (CinBody body : msg.getBodys())
							{
								newMsg.addBody(body);
							}
						}
					}
				}
				for (CinHeader header : message.getHeaders())
				{
					if (header.getType() != keyHeaderType)
						newMsg.addHeader(header);
				}
				for (CinBody body : message.getBodys())
				{
					newMsg.addBody(body);
				}
				remove(key);
				appendMessage(newMsg);
				return newMsg;
			}
			else
				if (sequence == addList.size() - 1 && message.getHeaders().size() == 1)
				{
					index.removeTailAddress(key);
				}
				else
				{
					buffers.put(address, message);
				}
			return message;
		}
		return null;
	}

	public boolean appendHeader(Long key, CinHeader header)
	{
		ArrayList<CinHeader> headers = new ArrayList<CinHeader>();
		headers.add(header);
		return appendHeadersBodys(key, headers, null);
	}

	public boolean appendHeaders(Long key, ArrayList<CinHeader> headers)
	{
		return appendHeadersBodys(key, headers, null);
	}

	public boolean appendBody(Long key, CinBody body)
	{
		ArrayList<CinBody> bodys = new ArrayList<CinBody>();
		bodys.add(body);
		return appendHeadersBodys(key, null, bodys);
	}

	public boolean appendBodys(Long key, ArrayList<CinBody> bodys)
	{
		return appendHeadersBodys(key, null, bodys);
	}

	public boolean appendHeadersBodys(Long key, ArrayList<CinHeader> headers, ArrayList<CinBody> bodys)
	{
		boolean isWriteOK = false;
		ArrayList<Long> addressList = index.getAddress(key);
		if (addressList == null)
		{
			isWriteOK = putMessage(key, headers, bodys, null, null);
		}
		else
		{
			Long address = addressList.get(addressList.size() - 1);
			CinMessage tailMsg = buffers.get(address);
			isWriteOK = putMessage(key, headers, bodys, tailMsg, address);
		}
		if (lru != null)
			lru.remove(key);
		return isWriteOK;
	}

	@Deprecated
	public boolean writeOrUpdate(CinMessage message)
	{
		if (message == null)
			return false;
		CinMessage msg = new CinMessage((byte) 1);
		for (CinHeader header : message.getHeaders())
		{
			msg.addHeader(header);
		}
		for (CinBody body : message.getBodys())
		{
			msg.addBody(body);
		}
		long key = msg.getHeader(keyHeaderType).getInt64();
		remove(key);
		return appendMessage(msg);
	}

	@Deprecated
	public CinMessage getMessage(Long key)
	{
		ArrayList<CinMessage> messages = get(key);
		if (messages == null)
			return null;
		return combineMessage(messages);
	}

	public CinMessage combineMessage(ArrayList<CinMessage> messages)
	{
		CinMessage message = new CinMessage((byte) 1);
		for (CinMessage msg : messages)
		{
			for (CinHeader header : msg.getHeaders())
			{
				message.addHeader(header);
			}
			for (CinBody body : msg.getBodys())
			{
				message.addBody(body);
			}
		}
		return message;
	}

	public boolean appendMessage(CinMessage message)
	{
		boolean isWriteOk = false;
		CinHeader keyHeader = message.getHeader(keyHeaderType);
		Long key = keyHeader.getInt64();
		message.removeHeader(keyHeader);
		ArrayList<CinHeader> headers = message.getHeaders();
		ArrayList<CinBody> bodys = message.getBodys();
		if (index.isExist(key))
		{
			appendHeadersBodys(key, headers, bodys);
		}
		else
		{
			if (headers.size() + bodys.size() + 1 <= maxHeaderCount)
			{
				message.addHeader(keyHeader);
				isWriteOk = writeMessageToFile(message, key, null, MessageNotFull);
			}
			else
			{
				isWriteOk = putMessage(key, headers, bodys, null, null);
			}
		}
		return isWriteOk;
	}

	private boolean putMessage(Long key, ArrayList<CinHeader> headers, ArrayList<CinBody> bodys, CinMessage tailMsg, Long tailAddress)
	{
		int hasHeadersCount = 0;
		CinMessage msg = null;
		Long address = null;
		if (tailMsg != null)
		{
			hasHeadersCount = msgHeaderCount(tailMsg);
			if (hasHeadersCount >= maxHeaderCount)
			{
				msg = buildNewMessage(key);
				hasHeadersCount = 1;
			}
			else
			{
				msg = tailMsg;
				address = tailAddress;
			}
		}
		else
		{
			msg = buildNewMessage(key);
		}
		if (headers != null)
		{
			for (CinHeader header : headers)
			{
				if (hasHeadersCount >= maxHeaderCount)
				{
					if (writeMessageToFile(msg, key, address, MessageFull))
						address = null;
					else
						return false;
					msg = buildNewMessage(key);
					hasHeadersCount = 1;
				}
				msg.addHeader(header);
				hasHeadersCount++;
			}
		}
		if (bodys != null)
		{
			for (CinBody body : bodys)
			{
				if (hasHeadersCount >= maxHeaderCount)
				{
					if (writeMessageToFile(msg, key, address, MessageFull))
						address = null;
					else
						return false;
					msg = buildNewMessage(key);
					hasHeadersCount = 1;
				}
				msg.addHeader(body);
				hasHeadersCount++;
			}
		}
		Byte isFull;
		if (hasHeadersCount >= maxHeaderCount)
			isFull = MessageFull;
		else
			if (address == null)
				isFull = MessageNotFull;
			else
				isFull = null;
		if (!writeMessageToFile(msg, key, address, isFull))
			return false;
		return true;
	}

	private boolean writeMessageToFile(CinMessage message, Long key, Long address, Byte isFull)
	{
		if (address == null)
		{
			address = index.getEmptyAddress(key);
			if (address == null)
			{
				CinTracer.getInstance(getClass()).special("No Space to Write!!!!Key:" + key);
				return false;
			}
			index.putHash(key, address);
		}
		if (isFull != null)
			index.putIndexFile(key, address, isFull);
		buffers.put(address, message);
		return true;
	}

	private CinMessage buildNewMessage(Long key)
	{
		CinMessage msg = new CinMessage((byte) 1);
		msg.addHeader(new CinHeader(keyHeaderType, key));
		return msg;
	}

	public boolean remove(Long key)
	{
		if (lru != null)
			lru.remove(key);
		return index.remove(key);
	}

	public void removeHeader(Long key, byte headerType)
	{
		ArrayList<CinMessage> msgList = get(key);
		CinMessage newMsg = new CinMessage(msgList.get(0).getMethodValue());
		for (CinMessage message : msgList)
		{
			for (CinHeader header : message.getHeaders())
			{
				if (header.getType() != headerType)
					newMsg.addHeader(header);
			}
		}
		writeOrUpdate(newMsg);
	}

	public LinkedList<Long> getKeys()
	{
		return index.getKeys();
	}

	public void removeLRU(Long key)
	{
		if (lru != null)
			lru.remove(key);
	}

	public void putLRU(Long key)
	{
		if (lru != null)
			lru.putList(key);
	}

	public int msgHeaderCount(CinMessage msg)
	{
		return msg.getHeaders().size() + msg.getBodys().size();
	}
}
