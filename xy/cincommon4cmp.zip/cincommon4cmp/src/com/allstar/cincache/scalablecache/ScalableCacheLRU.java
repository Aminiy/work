package com.allstar.cincache.scalablecache;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cincache.CinCacheBuffers;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinutil.CinLinkedList;
import com.allstar.cinutil.CinLinkedNode;

public class ScalableCacheLRU
{
	private CinLinkedList<ArrayList<CinMessage>> _list;
	private ConcurrentHashMap<Long, CinLinkedNode<ArrayList<CinMessage>>> _hash;
	private CinCacheBuffers buffers;
	private ScalableCacheIndex index;
	private int listMaxSize;

	public ScalableCacheLRU(int lruLength, ScalableCacheIndex index,CinCacheBuffers buffers) throws IOException
	{
		_list = new CinLinkedList<ArrayList<CinMessage>>();
		_hash = new ConcurrentHashMap<Long, CinLinkedNode<ArrayList<CinMessage>>>();
		this.buffers = buffers;
		this.index = index;
		listMaxSize = lruLength;
	}

	public ArrayList<CinMessage> get(Long key)
	{
		if (key == null)
			return null;
		CinLinkedNode<ArrayList<CinMessage>> node = _hash.get(key);
		ArrayList<CinMessage> msgList = null;
		if (node == null)
		{
			msgList = getFromFile(key);
			if (msgList != null)
				putList(key, msgList);
		}
		else
		{
			msgList = node.object();
			_list.kick(node);
		}
		return msgList;
	}

	public void putList(Long key)
	{
		ArrayList<CinMessage> msgList = getFromFile(key);
		if (msgList != null)
			putList(key, msgList);
	}

	private void putList(Long key, ArrayList<CinMessage> msgList)
	{
		if (_list.length() == listMaxSize)
			_hash.remove(_list.takeAwayFirst());
		_hash.put(key, _list.put(msgList));
	}

	private ArrayList<CinMessage> getFromFile(Long key)
	{
		ArrayList<CinMessage> messageList = new ArrayList<CinMessage>();
		ArrayList<Long> addList = index.getAddress(key);
		if (addList == null)
			return null;
		for (int i = 0, len = addList.size(); i < len; i++)
		{
			CinMessage message = buffers.get(addList.get(i));
			messageList.add(message);
		}
		if (messageList.size() == 0)
			return null;
		return messageList;
	}

	public void remove(Long key)
	{
		_list.remove(_hash.remove(key));
	}
}
