package com.allstar.cincache.scalablecache;

public interface ScalableCacheObject
{
	public abstract int getValueLength();
	public abstract byte[] toBytes();
}
