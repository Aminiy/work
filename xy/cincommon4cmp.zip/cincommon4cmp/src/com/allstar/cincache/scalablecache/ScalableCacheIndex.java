package com.allstar.cincache.scalablecache;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cincache.CinCacheBuffer;
import com.allstar.cincache.CinCacheIndex;
import com.allstar.cincache.CinCacheUtil;
import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinLinkedList;
import com.allstar.cinutil.CinLinkedNode;

public class ScalableCacheIndex
{
	private CinCacheBuffer buf;
	private ConcurrentHashMap<Long, ArrayList<Long>> _hash;
	private CinLinkedList<Integer>[] _emptyPositionList;
	private int eachFileCount;
	private int keySize = 9;
	private int fileCount;
	private int maxMsgSize;

	public ScalableCacheIndex(String dir, String fileName, int fileSize, int fileCount, int maxMsgSize) throws IOException
	{
		String indexFileName = dir + "/" + fileName + ".index";
		this.eachFileCount = fileSize / maxMsgSize;
		this.fileCount = fileCount;
		this.maxMsgSize = maxMsgSize;
		int indexFileSize = (keySize * eachFileCount * fileCount);
		buf = new CinCacheBuffer(indexFileName.toLowerCase(), indexFileSize);

		initArray(indexFileSize);
	}

	@SuppressWarnings("unchecked")
	public void initArray(int indexFileSize)
	{
		_hash = new ConcurrentHashMap<Long, ArrayList<Long>>();
		_emptyPositionList = new CinLinkedList[fileCount];
		int i = 0;
		while (i < fileCount)
		{
			_emptyPositionList[i] = new CinLinkedList<Integer>();
			i++;
		}
		loadIndex(indexFileSize);
	}

	private void addEmptyPosition(int fileCount, int position)
	{
		_emptyPositionList[fileCount].put(position);
	}

	public ArrayList<Long> putHash(Long key, Long address)
	{
		ArrayList<Long> list = _hash.get(key);
		if (list == null)
		{
			list = new ArrayList<Long>();
		}
		list.add(address);
		_hash.put(key, list);
		return list;
	}

	private void loadIndex(int indexFileSize)
	{
		int userdPos = 0;
		HashMap<Long, Long> tailHash = new HashMap<Long, Long>();
		Long key;
		int position = 0;
		int fileCount = 0;
		int index = 0;
		while (position < indexFileSize)
		{
			key = buf.getLong(position);
			if (key == null || key == 0L)
				addEmptyPosition(fileCount, index * maxMsgSize);
			else
			{
				userdPos++;
				Long address = CinCacheUtil.getAddress(fileCount, index * maxMsgSize);
				if (buf.getByte(position + 8) == (byte) 1)
				{
					putHash(key, address);
				}
				else
				{
					if (tailHash.containsKey(key))
					{
						Long elderAddress = tailHash.remove(key);
						if (elderAddress != null)
							putHash(key, elderAddress);
					}
					tailHash.put(key, address);
				}
			}
			position += keySize;
			index++;
			if (index == eachFileCount)
			{
				fileCount++;
				index = 0;
			}
		}
		for (java.util.Map.Entry<Long, Long> entry : tailHash.entrySet())
		{
			putHash(entry.getKey(), entry.getValue());
		}
		openInfo(userdPos);
	}

	private void openInfo(int userdPos)
	{
		int total = _hash.size();
		int totalEmpty = 0;
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < _emptyPositionList.length; i++)
		{
			totalEmpty += (_emptyPositionList[i].length());
		}
		sb.append("total:" + total + "||");
		sb.append("empty:" + totalEmpty + "||");
		sb.append("used" + userdPos);
		CinTracer.getInstance(CinCacheIndex.class).special(sb.toString());
	}

	public void putIndexFile(Long key, Long address, Byte isFull)
	{
		int position = getIndexBufferPosition(address);
		ByteBuffer buffer = ByteBuffer.allocate(keySize);
		buffer.putLong(key);
		if (isFull != null)
			buffer.put(isFull);
		buf.put(buffer.array(), position);
	}

	private int getIndexBufferPosition(Long address)
	{
		int indexPosition = (CinCacheUtil.getFileNumber(address) * eachFileCount) + (CinCacheUtil.getPosition(address) / maxMsgSize);
		return indexPosition * keySize;
	}

	public ArrayList<Long> getAddress(Long key)
	{
		if (key != null)
		{
			return _hash.get(key);
		}
		return null;
	}

	public Long getEmptyAddress(Long key)
	{
		if (key != null)
		{
			Integer fileNum = CinCacheUtil.getModNum(key, fileCount);
			CinLinkedNode<Integer> node = _emptyPositionList[fileNum].takeAwayFirst();
			if (node != null)
				return CinCacheUtil.getAddress(fileNum, node.object());
		}
		return null;
	}

	public boolean isExist(Long key)
	{
		if (key != null)
		{
			return _hash.containsKey(key);
		}
		return false;
	}

	public boolean remove(Long key)
	{
		ArrayList<Long> addressList = getAddress(key);
		if (addressList == null)
			return false;
		for (Long address : addressList)
		{
			buf.remove(getIndexBufferPosition(address));
			addEmptyPosition(CinCacheUtil.getFileNumber(address), CinCacheUtil.getPosition(address));
		}
		_hash.remove(key);
		return true;
	}

	public boolean removeTailAddress(Long key)
	{
		ArrayList<Long> addressList = getAddress(key);
		if (addressList == null)
			return false;
		Long address = addressList.remove(addressList.size() - 1);
		buf.remove(getIndexBufferPosition(address));
		addEmptyPosition(CinCacheUtil.getFileNumber(address), CinCacheUtil.getPosition(address));
		_hash.put(key, addressList);
		return true;
	}

	public LinkedList<Long> getKeys()
	{
		return new LinkedList<Long>(_hash.keySet());
	}
}
