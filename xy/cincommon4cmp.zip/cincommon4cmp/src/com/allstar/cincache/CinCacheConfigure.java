package com.allstar.cincache;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicBoolean;

import com.allstar.cinconfig.CinConfigure;

public class CinCacheConfigure
{
	private final String defaultDir = "/data/caches/" + CinConfigure.serviceName + "/" + CinConfigure.computerName;
	public static final int Each_M_Size = 1024 * 1024;
	public String dir = defaultDir;
	public String fileName = "CacheFile";
	public int fileSize = 512 * Each_M_Size;
	public int fileCount = 8;
	public int keySize = 8;
	public int maxMsgSize = 1024;
	public byte keyHeader = (byte) 1;
	public String indexHeaders = null;
	public AtomicBoolean isBrotherAlive = new AtomicBoolean(false);
	public String ipEndPoint = null;
	public Integer port = null;
	public Integer lruLength = null;
	public int socketNum = 1;
	public int maxHeaderCount;
	public int cleanRatio = 80;

	public CinCacheConfigure(String propertyFileName)
	{
		FileInputStream fis = null;
		try
		{
			fis = new FileInputStream(propertyFileName);
			Properties properties = new Properties();
			properties.load(fis);
			init(properties);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if (fis != null)
					fis.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}

	private void init(Properties properties)
	{
		fileName = properties.getProperty("FileName", "CacheFile");
		dir = properties.getProperty("Dir", defaultDir);
		fileSize = Integer.valueOf(properties.getProperty("FileSize", "512")) * Each_M_Size;
		fileCount = Integer.valueOf(properties.getProperty("FileCount", "8"));
		keySize = Integer.valueOf(properties.getProperty("KeySize", "8"));
		maxMsgSize = Integer.valueOf(properties.getProperty("MessageMaxSize", "1024"));
		keyHeader = Integer.valueOf(properties.getProperty("KeyHeader", "1")).byteValue();
		indexHeaders = properties.getProperty("IndexHeaders");
		ipEndPoint = properties.getProperty("IpEndPoint");
		String portString = properties.getProperty("Port");
		if (portString != null)
			port = Integer.valueOf(portString);
		lruLength = properties.getProperty("LRULength") == null ? null : Integer.valueOf(properties.getProperty("LRULength", "10000"));
		socketNum = Integer.valueOf(properties.getProperty("SocketNum", "1"));
		maxHeaderCount = Integer.valueOf(properties.getProperty("MaxHeaderCount", "400"));
		cleanRatio = Integer.valueOf(properties.getProperty("CleanRatio", "80"));
	}

	public CinCacheConfigure(String dir, String fileName, int fileSize, int fileCount, int maxMsgSize, byte keyHeader, Integer lruLength)
	{
		this.fileName = fileName;
		if (dir != null)
			this.dir = dir;
		else
			this.dir = defaultDir;
		File fl = new File(this.dir.toLowerCase());
		if (!fl.exists())
			fl.mkdirs();
		this.fileSize = fileSize;
		this.fileCount = fileCount;
		this.maxMsgSize = maxMsgSize;
		this.keyHeader = keyHeader;
		if (lruLength != null)
			this.lruLength = lruLength;
	}

	// fileSize's Unit:MB
	public CinCacheConfigure(String fileName, int fileSize, int fileCount, int maxMsgSize, byte keyHeader)
	{
		this(null, fileName, fileSize, fileCount, maxMsgSize, keyHeader, null);
	}

}
