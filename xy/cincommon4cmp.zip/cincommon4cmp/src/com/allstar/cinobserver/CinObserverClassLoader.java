package com.allstar.cinobserver;

import java.net.URL;
import java.net.URLClassLoader;
import java.util.Hashtable;

import com.allstar.cintracer.CinTracer;

/**
 * The Observer load function class
 * 
 * 
 */
public class CinObserverClassLoader extends URLClassLoader
{
	private static CinTracer tracer = CinTracer.getInstance(CinObserverClassLoader.class);

	private Hashtable<String, byte[]> streammap = null;

	public CinObserverClassLoader(URL[] urls)
	{
		super(urls, null);
		streammap = new Hashtable<String, byte[]>();
	}

	@Override
	public void addURL(URL url)
	{
		super.addURL(url);
	}

	public void addStream(String name, byte[] stream)
	{
		streammap.put(name, stream);
	}

	/**
	 * Through the parameter name lookup in the the designated Observer
	 */
	@Override
	public Class<?> findClass(String name) throws ClassNotFoundException
	{
		tracer.info("Find class name " + name);
		try
		{
			if (!streammap.containsKey(name))
			{
				tracer.info("System Class found " + name);
				return getSystemClassLoader().loadClass(name);
			}
			byte[] ret = streammap.get(name);
			Class<?> cls = defineClass(name, ret, 0, ret.length);
			streammap.remove(name);
			return cls;
		}
		catch (Exception e)
		{
			tracer.error("Exception By reading class from jar ", e);
			throw new ClassNotFoundException(name, e);
		}
	}
}
