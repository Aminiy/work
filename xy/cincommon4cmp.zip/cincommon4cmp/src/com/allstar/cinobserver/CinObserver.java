package com.allstar.cinobserver;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cintracer.CinTracer;

/**
 * Observer function class.<br>
 * Used for dynamic loading in the service runtime logic, to look at the data in memory or to an interim fix exception logic
 * 
 * 
 */
public class CinObserver
{
	private static CinTracer tracer = CinTracer.getInstance(CinObserver.class);
	private static String _filename;
	private static String _defaultjarfilename = "./observer.jar";
	private static CinObserverClassLoader classloader = null;

	static CinObserverClassLoader getClassLoader()
	{
		return classloader;
	}

	/**
	 * initialize
	 * 
	 * @throws Exception
	 */
	public static void initialize() throws Exception
	{
		initialize(_defaultjarfilename);
	}

	/**
	 * Initialize the specified jar package
	 * 
	 * @param filename
	 * @throws Exception
	 */
	@SuppressWarnings("deprecation")
	public static void initialize(String filename) throws Exception
	{
		_filename = filename;
		classloader = new CinObserverClassLoader(new URL[]{});
		CinStack.instance().registerCinTransactionCreatedEvent(CinRequestMethod.Observation, new CinObserverTransactionCreated());
		System.gc();
		CinObserverHandlerPool.initialize(getObserverHandlers());
		tracer.info("Initialize Observer Handler OK");
	}

	/**
	 * To obtain a list of the Observer processing logic class
	 * 
	 * @return
	 * @throws FileNotFoundException
	 */
	@SuppressWarnings("unchecked")
	private static List<Class<? extends CinObserverHandler>> getObserverHandlers() throws FileNotFoundException
	{
		ArrayList<Class<? extends CinObserverHandler>> classlist = new ArrayList<Class<? extends CinObserverHandler>>();
		JarFile jar = null;
		InputStream in = null;

		try
		{
			jar = new JarFile(_filename);
			Enumeration<?> e = jar.entries();
			while (e.hasMoreElements())
			{
				try
				{
					JarEntry entry = (JarEntry) e.nextElement();
					if (entry.getName().endsWith(".class"))
					{
						in = jar.getInputStream(entry);
						byte[] stream = new byte[in.available()];
						in.read(stream);
						classloader.addURL(new File(entry.getName()).toURI().toURL());
						String className = entry.getName().replace("/", ".");
						className = className.substring(0, className.length() - 6);
						classloader.addStream(className, stream);

						Class<?> mainClass = classloader.loadClass(className);
						if (CinObserverHandler.class.isAssignableFrom(mainClass))
							classlist.add((Class<? extends CinObserverHandler>) mainClass);
					}
				}
				catch (Exception streamex)
				{
					tracer.error("Read Jar entry Failed", streamex);
				}
				finally
				{
					if (in != null)
						in.close();
				}
			}
		}
		catch (FileNotFoundException fnfe)
		{
			tracer.warn("Jar File Not Found, Maybe you don't need Observer but you initiailize it in the main entry, try to remove the Initialize method or upload your observer.jar", fnfe);
			// throw fnfe;
		}
		catch (IOException e)
		{
			tracer.error("Read Jar File Failed", e);
		}
		catch (Exception finayex)
		{
			tracer.error("get Observer Handler Failed", finayex);
		}
		finally
		{
			if (jar != null)
				try
				{
					jar.close();
				}
				catch (IOException e)
				{
					tracer.error("Close jar failed", e);
				}
		}
		return classlist;
	}
}
