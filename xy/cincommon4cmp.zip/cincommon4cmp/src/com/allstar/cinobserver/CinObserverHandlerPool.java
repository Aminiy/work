package com.allstar.cinobserver;

import java.util.HashMap;
import java.util.List;

import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cintracer.CinTracer;

/**
 * Processing logic of management, the factory pattern
 * 
 * 
 */
public class CinObserverHandlerPool
{
	private static HashMap<Integer, String> handlerpool = new HashMap<Integer, String>();
	private static CinTracer tracer = CinTracer.getInstance(CinObserverHandlerPool.class);

	/**
	 * initialize
	 * 
	 * @param handlers
	 */
	public static void initialize(List<Class<? extends CinObserverHandler>> handlers)
	{
		handlerpool.clear();
		try
		{
			for (Class<? extends CinObserverHandler> h : handlers)
				put(h.newInstance().getHandlerEvent(), h.getName());
		}
		catch (Exception e)
		{
			tracer.error("initialize Handlerpool Exception", e);
		}

	}

	private static void put(int key, String value)
	{
		if (handlerpool.containsKey(key))
		{
			tracer.error("Duplicated Key for Event " + key);
		}
		else
			handlerpool.put(key, value);
	}

	public static CinObserverHandler getHandler(CinTransaction transaction) throws Exception
	{
		String name = handlerpool.get((int) transaction.getRequest().getHeader(CinHeaderType.Event).getInt64());
		if (name == null)
			return null;
		return (CinObserverHandler) CinObserver.getClassLoader().loadClass(name).newInstance();
	}
}
