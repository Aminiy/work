package com.allstar.cinobserver;

import java.io.FileNotFoundException;

import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionCreatedEvent;
import com.allstar.cintracer.CinTracer;
import com.allstar.event.CinObservationEvent;

/**
 * The Observer signaling transaction to create event classes after the call
 * 
 * 
 */
public class CinObserverTransactionCreated implements CinTransactionCreatedEvent
{
	private static CinTracer tracer = CinTracer.getInstance(CinObserverTransactionCreated.class);

	@Override
	public void onCinTransactionCreated(CinTransaction trans)
	{
		try
		{
			if (trans.getRequest().Event.getInt64() == CinObservationEvent.ReinitializeObserver)
			{
				CinObserver.initialize();
				trans.sendResponse(CinResponseCode.OK);
				return;
			}
			else
				if (trans.getRequest().Event.getInt64() == CinObservationEvent.GetConfigVersionForEachModule)
				{
					return;
				}
			CinObserverHandler handler = CinObserverHandlerPool.getHandler(trans);
			if (handler == null)
				trans.sendResponse(CinResponseCode.NotSupport);
			else
				handler.handle(trans);
		}
		catch (FileNotFoundException fe)
		{
			trans.sendResponse(CinResponseCode.NotExist);
			tracer.error("observer.jar not found", trans.getRequest(), fe);
		}
		catch (Exception e)
		{
			trans.sendResponse(CinResponseCode.Error);
			tracer.error("Handle Observation Exception", trans.getRequest(), e);
		}
	}
}
