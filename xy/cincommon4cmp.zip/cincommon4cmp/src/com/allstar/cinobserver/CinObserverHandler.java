package com.allstar.cinobserver;

import com.allstar.cinstack.transaction.CinTransaction;

/**
 * The Observer processing logic abstract class, defines the unified method
 * 
 * 
 */
public abstract class CinObserverHandler
{
	protected int _observationevent;

	protected CinObserverHandler()
	{
		setHandlerEvent();
	}

	protected abstract void handle(CinTransaction trans);

	protected abstract void setHandlerEvent();

	public int getHandlerEvent()
	{
		return _observationevent;
	}
}
