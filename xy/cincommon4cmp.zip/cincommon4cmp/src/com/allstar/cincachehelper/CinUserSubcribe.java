package com.allstar.cincachehelper;

public class CinUserSubcribe
{
	public static final byte UserId = (byte) 0x01;

	public static final byte Msc = (byte) 0x02;
}
