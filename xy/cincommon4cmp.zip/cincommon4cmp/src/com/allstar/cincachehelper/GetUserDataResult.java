package com.allstar.cincachehelper;

import com.allstar.cinstack.handler.codec.CinMessageReader;
import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionEvent;

public abstract class GetUserDataResult implements CinTransactionEvent
{
	public abstract void getResult(CinUserInfo profile, CinUserProfile userInfo, CinTransaction stateTrans, Object stateObj);

	public void onResponseReceived(CinTransaction trans)
	{
		CinResponse response = trans.getResponse();
		if (response.isResponseCode(CinResponseCode.OK))
		{
			CinUserProfile userInfo = null;
			CinUserInfo profile = null;
			for (CinBody body : response.getBodys())
			{
				CinMessage msg = CinMessageReader.parse(body.getValue());
				if (msg != null)
				{
					if (msg.getMethodValue() == (byte) 1)
					{
						profile = new CinUserInfo(msg);
					}
					else
						if (msg.getMethodValue() == (byte) 2)
						{
							userInfo = new CinUserProfile(msg);
						}
				}
			}
			getResult(profile, userInfo, trans.getStateTransaction(), trans.getAttachment());
		}
		else
		{
			getResult(null, null, trans.getStateTransaction(), trans.getAttachment());
		}
	}

	@Override
	public void onRequestSentFailed(CinTransaction trans)
	{
		// TODO Auto-generated method stub
		getResult(null, null, trans.getStateTransaction(), trans.getAttachment());
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans)
	{
		// TODO Auto-generated method stub
		getResult(null, null, trans.getStateTransaction(), trans.getAttachment());
	}
}
