package com.allstar.cincachehelper;

import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinMessage;

public class CinUserProfile
{
	public static final byte UserId = (byte) 0x40;
	public static final byte MobileNum = (byte) 0x41;

	public static final byte Name = (byte) 0x42;
	public static final byte Mood = (byte) 0x43;
	public static final byte Expression = (byte) 0x44;
	public static final byte Gender = (byte) 0x45;
	public static final byte PortraitId = (byte) 0x46;
	
	/**
	 * Language is the equipment level, why in the user level, this design is a problem
	 */
	public static final byte Language = (byte) 0x47;
	public static final byte VisitingCard_Version = (byte) 0x52;
	public static final byte Customer_Field = (byte) 0x53;

	private long userid;
	private Long mobileNum;
	private String name;
	private String mood;
	private Byte gender;
	private Byte language;
	private Long portraitVersion;
	private String customerField;

	public CinMessage toMessage()
	{
		CinMessage message = new CinMessage((byte) 1);
		message.addHeader(new CinHeader(UserId, userid));
		if (mobileNum != null)
		{
			message.addHeader(new CinHeader(MobileNum, mobileNum));
		}
		if (name != null)
		{
			message.addHeader(new CinHeader(Name, name));
		}
		if (mood != null)
		{
			message.addHeader(new CinHeader(Mood, mood));
		}
		if (gender != null)
		{
			message.addHeader(new CinHeader(Gender, gender));
		}
		if (language != null)
		{
			message.addHeader(new CinHeader(Language, language));
		}
		if (portraitVersion != null)
		{
			message.addHeader(new CinHeader(PortraitId, PortraitId));
		}
		if (customerField != null)
		{
			message.addHeader(new CinHeader(Customer_Field, customerField));
		}
		return message;
	}

	public CinUserProfile(CinMessage message)
	{
		for (CinHeader header : message.getHeaders())
		{
			switch (header.getType())
			{
				case UserId:
					userid = header.getInt64();
				break;
				case MobileNum:
					mobileNum = header.getInt64();
				break;
				case Name:
					name = header.getString();
				break;
				case Mood:
					mood = header.getString();
				break;
				case Gender:
					gender = header.getValue()[0];
				break;
				case Language:
					language = header.getValue()[0];
				break;
				case PortraitId:
					portraitVersion = header.getInt64();
				case Customer_Field:
					customerField = header.getString();
				break;
			}
		}
	}

	public CinUserProfile()
	{
	}
}
