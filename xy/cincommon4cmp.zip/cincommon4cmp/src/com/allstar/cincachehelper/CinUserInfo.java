package com.allstar.cincachehelper;

import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinutil.CinConvert;

/**
 * Size (19 * 2) + 23 + (8 * 12) + 4 = 161 + 255 = 416 + 1 = 417
 * 417 - 255 - 48 = 114
 * 417 + (756 * 2)  
 * (ios or android) + PC = 417 + (756 * 2)  - 255 (no push token) = 1674
 * WP + PC = 417 + (756 * 2) - (255 * 2) + 1024 = 2443
 * 
 * 
 * 
 *
 */
public class CinUserInfo
{
	/**
	 * Size 8 bytes
	 */
	public static final byte UserId = (byte) 0x01;

	/**
	 * normal max 15 bytes
	 */
	public static final byte MobileNum = (byte) 0x02;

	/**
	 * now,not used
	 */
	public static final byte Email = (byte) 0x03;

	/**
	 * now,not used
	 */
	public static final byte Password = (byte) 0x04;

	/**
	 * Size 8 bytes
	 */
	public static final byte PhonebookVersion = (byte) 0x05;

	/**
	 * Size 8 bytes
	 */
	public static final byte CollectContact_Version = (byte) 0x06;

	/**
	 * Size 8 bytes
	 */
	public static final byte Reverse_Version = (byte) 0x07;

	/**
	 * Size 8 bytes
	 */
	public static final byte User_Switch = (byte) 0x08;

	/**
	 * Size 4 bytes
	 */
	public static final byte Max_Group_Count = (byte) 0x09;

	/**
	 * Size 8 bytes
	 */
	public static final byte Dnd_Start = (byte) 0x0A;

	/**
	 * Size 8 bytes
	 */
	public static final byte Dnd_Interval = (byte) 0x0B;

	/**
	 * Size 8 bytes
	 */
	public static final byte System_Blocked = (byte) 0x0C;

	/**
	 * Size 8 bytes
	 */
	public static final byte Block_List_Version = (byte) 0x0D;

	/**
	 * Size 8 bytes
	 */
	public static final byte OnlineStatusSettingDate = (byte) 0x0E;

	/**
	 * Size 8 bytes
	 */
	public static final byte Favorite_Msg_Version = (byte) 0x0F;

	// Hidden message related settings

	/**
	 * Size 8 bytes
	 */
	public static final byte Hidden_List_Version = (byte) 0X10;

	/**
	 * Size 8 bytes real use 1 byte
	 */
	public static final byte Hidden_Password_Type = (byte) 0X11;

	/**
	 * Max Size 255 bytes
	 */
	public static final byte Hidden_Password = (byte) 0X12;

	/**
	 * Whether to push the read message to the sender of the message
	 */
	public static final byte MessageReadReplyType = 0x21;

	private long userId;
	private Long mobileNum;
	private Integer clientAbility;
	private String clientType;
	private String clientVersion;
	private Long oem;
	private Long groupMaxCount;
	private boolean firstRegister;
	private byte[] password;
	private byte[] token;
	private Long userSwitch;
	private Long switchVersion;
	private Long dndStart;
	private Long dndInterval;
	private byte[] pid;
	private byte[] subPid;
	private byte[] credential;
	private byte[] ip;
	private byte[] deviceToken;
	private String loginName;
	private String email;
	private Long systemBlocked;

	public Long getSystemBlocked()
	{
		return systemBlocked;
	}

	public void setSystemBlocked(Long systemBlocked)
	{
		this.systemBlocked = systemBlocked;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public long getUserId()
	{
		return userId;
	}

	public void setUserId(long userId)
	{
		this.userId = userId;
	}

	public Long getMobileNum()
	{
		return mobileNum;
	}

	public void setMobileNum(Long mobileNum)
	{
		this.mobileNum = mobileNum;
	}

	public Integer getClientAbility()
	{
		return clientAbility;
	}

	public void setClientAbility(Integer clientAbility)
	{
		this.clientAbility = clientAbility;
	}

	public String getClientType()
	{
		return clientType;
	}

	public void setClientType(String clientType)
	{
		this.clientType = clientType;
	}

	public String getClientVersion()
	{
		return clientVersion;
	}

	public void setClientVersion(String clientVersion)
	{
		this.clientVersion = clientVersion;
	}

	public Long getOem()
	{
		return oem;
	}

	public void setOem(Long oem)
	{
		this.oem = oem;
	}

	public Long getGroupMaxCount()
	{
		return groupMaxCount;
	}

	public void setGroupMaxCount(Long groupMaxCount)
	{
		this.groupMaxCount = groupMaxCount;
	}

	public boolean isFirstRegister()
	{
		return firstRegister;
	}

	public void setFirstRegister(boolean firstRegister)
	{
		this.firstRegister = firstRegister;
	}

	public byte[] getPassword()
	{
		return password;
	}

	public void setPassword(byte[] password)
	{
		this.password = password;
	}

	public byte[] getToken()
	{
		return token;
	}

	public void setToken(byte[] token)
	{
		this.token = token;
	}

	public Long getUserSwitch()
	{
		return userSwitch;
	}

	public void setUserSwitch(Long userSwitch)
	{
		this.userSwitch = userSwitch;
	}

	public Long getSwitchVersion()
	{
		return switchVersion;
	}

	public void setSwitchVersion(Long switchVersion)
	{
		this.switchVersion = switchVersion;
	}

	public Long getDndStart()
	{
		return dndStart;
	}

	public void setDndStart(Long dndStart)
	{
		this.dndStart = dndStart;
	}

	public Long getDndInterval()
	{
		return dndInterval;
	}

	public void setDndInterval(Long dndInterval)
	{
		this.dndInterval = dndInterval;
	}

	public byte[] getPid()
	{
		return pid;
	}

	public void setPid(byte[] pid)
	{
		this.pid = pid;
	}

	public byte[] getCredential()
	{
		return credential;
	}

	public void setCredential(byte[] credential)
	{
		this.credential = credential;
	}

	public byte[] getIp()
	{
		return ip;
	}

	public void setIp(byte[] ip)
	{
		this.ip = ip;
	}

	public byte[] getAppDeviceToken()
	{
		return deviceToken;
	}

	public void setAppDeviceToken(byte[] appDeviceToken)
	{
		this.deviceToken = appDeviceToken;
	}

	public String getLoginName()
	{
		return loginName;
	}

	public void setLoginName(String loginName)
	{
		this.loginName = loginName;
	}

	public CinUserInfo()
	{

	}

	public CinUserInfo(CinMessage message)
	{
		this.firstRegister = false;
		for (CinHeader header : message.getHeaders())
		{
			switch (header.getType())
			{
				case UserId:
					this.userId = header.getInt64();
					break;
				case MobileNum:
					this.mobileNum = header.getInt64();
					break;
				case Password:
					this.password = header.getValue();
					break;
				case User_Switch:
					this.userSwitch = header.getInt64();
					break;
				case Dnd_Start:
					this.dndStart = header.getInt64();
					break;
				case Dnd_Interval:
					this.dndInterval = header.getInt64();
					break;
				case Email:
					this.email = header.getString();
					break;
				case System_Blocked:
					this.systemBlocked = header.getInt64();
					break;
			}
		}
	}

	@Override
	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		sb.append("UserProfile:-----");
		sb.append("\nUserId:").append(userId);
		sb.append("\nMobileNum:").append(mobileNum);
		sb.append("\nClientAbility:").append(clientAbility);
		sb.append("\nClientType:").append(clientType);
		sb.append("\nClientVersion:").append(clientVersion);
		sb.append("\nOem:").append(oem);
		sb.append("\nGroupMaxCount:").append(groupMaxCount);
		sb.append("\nFirstRegister:").append(firstRegister);
		sb.append("\nPassword:").append(password == null ? null : CinConvert.bytes2String(password));
		sb.append("\nToken:").append(token == null ? null : CinConvert.bytes2String(token));
		sb.append("\nUserSwitch:").append(userSwitch);
		sb.append("\nSwitchVersion:").append(switchVersion);
		sb.append("\nDndStart:").append(dndStart);
		sb.append("\nDndInterval:").append(dndInterval);
		sb.append("\nPid:").append(pid == null ? null : CinConvert.bytes2String(pid));
		sb.append("\nCredential:").append(credential == null ? null : CinConvert.bytes2String(credential));
		sb.append("\nIp:").append(ip == null ? null : CinConvert.bytes2String(ip));
		sb.append("\nAppDeviceToken:").append(deviceToken == null ? null : CinConvert.bytes2String(deviceToken));
		sb.append("\nEmail:").append(email);
		sb.append("\nSystemBlocked:").append(systemBlocked);
		sb.append("\n-----");
		return sb.toString();
	}

	public static String getString(CinMessage userProfile)
	{
		CinUserInfo profile = new CinUserInfo(userProfile);
		return profile.toString();
	}

	public CinMessage toMessage()
	{
		CinMessage message = new CinMessage((byte) 1);
		message.addHeader(new CinHeader(UserId, userId));
		if (mobileNum != null)
		{
			message.addHeader(new CinHeader(MobileNum, mobileNum));
		}
		if (password != null)
		{
			message.addHeader(new CinHeader(Password, password));
		}
		if (userSwitch != null)
		{
			message.addHeader(new CinHeader(User_Switch, userSwitch));
		}
		if (dndStart != null)
		{
			message.addHeader(new CinHeader(Dnd_Start, dndStart));
		}
		if (dndInterval != null)
		{
			message.addHeader(new CinHeader(Dnd_Interval, dndInterval));
		}
		if (email != null)
		{
			message.addHeader(new CinHeader(Email, email));
		}
		if (systemBlocked != null)
		{
			message.addHeader(new CinHeader(System_Blocked, systemBlocked));
		}
		return message;
	}

	public byte[] getSubPid()
	{
		return subPid;
	}

	public void setSubPid(byte[] subPid)
	{
		this.subPid = subPid;
	}
}
