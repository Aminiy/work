package com.allstar.cincachehelper;

public class CinUserExtensionHeader
{
	public static final byte USERID = 0x40;
	public static final byte MOBLIENO = 0x41;
	public static final byte NAME = 0x42;
	public static final byte MOOD = 0x43;
	public static final byte GENDER = (byte) 0x44;
	public static final byte PORTRAITVERSION = 0x47;
	public static final byte AGE = (byte) 0x4A;
	public static final byte PORTRAIT_SEQUENCE = 0x4C;
	public static final byte HASVOICEMOOD = 0x4E;
	public static final byte VISITINGCARDVERSION = 0x52;
	public static final byte CARRIER_TYPE = (byte) 0x80;
	public static final byte LOCAL_NAME = (byte) 0x81;
	public static final byte HIGHTLIGHT = (byte) 0x82;
	public static final byte ISBLACKLISTUSER = (byte) 0x83;
	public static final byte CONTACT_INLIST_VERSION = (byte) 0x84;
	public static final byte LBS_DISTANCE = (byte) 0x85;
	public static final byte REGIONID = (byte) 0x86;
	public static final byte REGIONNAME = (byte) 0x87;
	public static final byte HASMOREREGION = (byte) 0x88;
	public static final byte DialogHighLight = (byte) 0x89;
	public static final byte ISURAPPORTUSER = (byte) 0xFE;

}
