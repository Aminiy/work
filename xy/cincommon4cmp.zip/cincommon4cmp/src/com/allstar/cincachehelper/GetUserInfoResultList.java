package com.allstar.cincachehelper;

import java.util.LinkedList;

import com.allstar.cinstack.handler.codec.CinMessageReader;
import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionEvent;

public abstract class GetUserInfoResultList implements CinTransactionEvent
{
	public abstract void getResult(LinkedList<CinUserProfile> userInfo, CinTransaction stateTrans, Object stateObj);

	public void onResponseReceived(CinTransaction trans)
	{
		CinResponse response = trans.getResponse();
		if (response.isResponseCode(CinResponseCode.OK))
		{
			LinkedList<CinUserProfile> list = new LinkedList<CinUserProfile>();
			for (CinBody body : response.getBodys())
			{
				CinMessage msg = CinMessageReader.parse(body.getValue());
				if (msg != null)
				{
					list.add(new CinUserProfile(msg));
				}
			}
			getResult(list, trans.getStateTransaction(), trans.getAttachment());
		}
		else
		{
			getResult(null, trans.getStateTransaction(), trans.getAttachment());
		}
	}

	@Override
	public void onRequestSentFailed(CinTransaction trans)
	{
		// TODO Auto-generated method stub
		getResult(null, trans.getStateTransaction(), trans.getAttachment());
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans)
	{
		// TODO Auto-generated method stub
		getResult(null, trans.getStateTransaction(), trans.getAttachment());
	}
}
