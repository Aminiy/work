package com.allstar.cincachehelper;

import com.allstar.cinstack.handler.codec.CinMessageReader;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionEvent;

public abstract class GetUserInfoResult implements CinTransactionEvent {
	public abstract void getResult(CinUserProfile userInfo, CinTransaction stateTrans, Object stateObj);

	@Override
	public void onResponseReceived(CinTransaction trans) {
		CinResponse response = trans.getResponse();
		if (response.isResponseCode(CinResponseCode.OK)) {
			if (response.getBody() != null) {
				CinMessage msg = CinMessageReader.parse(response.getBody().getValue());
				if (msg != null) {
					getResult(new CinUserProfile(msg), trans.getStateTransaction(), trans.getAttachment());
					return;
				}
			}
		}
		getResult(null, trans.getStateTransaction(), trans.getAttachment());
	}

	@Override
	public void onRequestSentFailed(CinTransaction trans) {
		getResult(null, trans.getStateTransaction(), trans.getAttachment());
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans) {
		getResult(null, trans.getStateTransaction(), trans.getAttachment());
	}
}
