package com.allstar.cincachehelper;

public class UserProfileHeaderType
{
	public static final byte Password = (byte)0xE4;
	public static final byte Token = (byte)0xE5;
	public static final byte Contact_Version = (byte)0xE6;
}
