/**
 * 
 */
package com.allstar.cincachehelper;

import java.util.ArrayList;
import java.util.List;

import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinRouterConfig;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionEvent;
import com.allstar.event.CinInnerServiceEvent;

public class CinUserInfoUtil
{
	public static void queryUserData(long userid, boolean needUserInfo, GetUserDataResult event, CinTransaction stateTrans, Object stateObject)
	{
		CinRequest request = new CinRequest(CinRequestMethod.InnerService);
		request.addHeader(new CinHeader(CinHeaderType.From, userid));
		request.addHeader(new CinHeader(CinHeaderType.Event, CinInnerServiceEvent.GetUserWholeData));
		if (needUserInfo)
			request.addHeader(new CinHeader(CinHeaderType.Index));
		CinRouter.setRoute(request, CinServiceName.UserCacheCenter);
		CinTransaction trans = CinStack.instance().createTransaction(request);
		trans.setStateTransaction(stateTrans);
		trans.setAttachment(stateObject);
		trans.Event = event;
		trans.sendRequest();
	}
	public static int queryUserData(List<Long> userids, CinTransactionEvent event, CinTransaction stateTrans, Object stateObject)
	{
		int sendCount = 0;
		int serviceCount = CinRouterConfig.getServiceCount(CinServiceName.UserCacheCenter);
		CinRequest[] requestArray = new CinRequest[serviceCount];
		for (Long userid : userids)
		{
			int idx = (int) (userid % serviceCount);
			if (requestArray[idx] == null)
			{
				requestArray[idx] = new CinRequest(CinRequestMethod.InnerService);
				requestArray[idx].addHeader(new CinHeader(CinHeaderType.From, userid));
				requestArray[idx].addHeader(new CinHeader(CinHeaderType.Event, CinInnerServiceEvent.GetUserWholeData));
				CinRouter.setRoute(requestArray[idx], CinServiceName.UserCacheCenter);
			}
			requestArray[idx].addHeader(new CinHeader(CinHeaderType.Key, userid));
		}
		for (CinRequest request : requestArray)
		{
			if (request != null)
			{
				CinTransaction trans = CinStack.instance().createTransaction(request);
				if (event != null)
				{
					trans.Event = event;
					if (stateTrans != null)
						trans.setStateTransaction(stateTrans);
					if (stateObject != null)
						trans.setAttachment(stateObject);
				}
				trans.sendRequest();
				sendCount++;
			}
		}
		return sendCount;
	}
	
	public static int getUserProfile(List<Long> userids, CinTransactionEvent event, CinTransaction stateTrans, Object stateObject)
	{
		int sendCount = 0;
		int serviceCount = CinRouterConfig.getServiceCount(CinServiceName.UserCacheCenter);
		CinRequest[] requestArray = new CinRequest[serviceCount];
		for (Long userid : userids)
		{
			int idx = (int) (userid % serviceCount);
			if (requestArray[idx] == null)
			{
				requestArray[idx] = new CinRequest(CinRequestMethod.InnerService);
				requestArray[idx].addHeader(new CinHeader(CinHeaderType.From, userid));
				requestArray[idx].addHeader(new CinHeader(CinHeaderType.Event, CinInnerServiceEvent.GetUserProfile));
				CinRouter.setRoute(requestArray[idx], CinServiceName.UserCacheCenter);
			}
			requestArray[idx].addHeader(new CinHeader(CinHeaderType.Key, userid));
		}
		for (CinRequest request : requestArray)
		{
			if (request != null)
			{
				CinTransaction trans = CinStack.instance().createTransaction(request);
				if (event != null)
				{
					trans.Event = event;
					if (stateTrans != null)
						trans.setStateTransaction(stateTrans);
					if (stateObject != null)
						trans.setAttachment(stateObject);
				}
				trans.sendRequest();
				sendCount++;
			}
		}
		return sendCount;
	}

	public static int getUserProfile(List<Long> userids, CinTransactionEvent event)
	{
		return getUserProfile(userids, event, null, null);
	}

	public static int getUserProfile(Long userid, CinTransactionEvent event, CinTransaction stateTrans, Object stateObject)
	{
		List<Long> l = new ArrayList<Long>();
		l.add(userid);
		return getUserProfile(l, event, stateTrans, stateObject);
	}

	public static int getUserProfile(Long userid, CinTransactionEvent event)
	{
		return getUserProfile(userid, event, null, null);
	}
}
