package com.allstar.cincachehelper;


/**
 * 2 + (17 * 2) + 729 = 756
 *
 */
public class CinUserInfoBody
{
	
	
	/**
	 * Size 2 btes
	 */
	public static final byte Client_Type = (byte) 0x01;

	/**
	 * Size 10 bytes
	 */
	public static final byte Client_Version = (byte) 0x02;

	/**
	 * Size 8 bytes
	 */
	public static final byte OEM = (byte) 0x03;

	/**
	 * Size 52 bytes
	 */
	public static final byte Pid = (byte) 0x04;

	/**
	 * Size 16 bytes
	 */
	public static final byte Credential = (byte) 0x05;

	/**
	 * Size 8 bytes
	 */
	public static final byte Ability = (byte) 0x06;

	/**
	 * Size 2 bytes
	 */
	public static final byte Language = (byte) 0x07;

	/**
	 * Size Max 255 bytes
	 */
	public static final byte DeviceDesc = (byte) 0x08;

	/**
	 * Size 47 bytes
	 */
	public static final byte DeviceID = (byte) 0x0A;

	/**
	 * Size 16 bytes
	 */
	public static final byte DToken = (byte) 0x0B;

	/**
	 * Size 16 bytes
	 */
	public static final byte DPassword = (byte) 0x0C;

	/**
	 * Size 8 bytes
	 */
	public static final byte LastActiveDate = (byte) 0x0D;

	/**
	 * Size 255 bytes
	 */
	public static final byte Push_Token = (byte) 0x0E;

	/**
	 * Size 2 bytes
	 */
	public static final byte Push_Language = (byte) 0x0F;

	/**
	 * Size 16 bytes
	 */
	public static final byte Encryte_Key = (byte) 0x10;

	/**
	 * credential generated time, 8 byte
	 */
	public static final byte CredentialDateTime = (byte) 0x11;

	/**
	 * 8 byte
	 */
	public static final byte LastKeepaliveDate = (byte) 0x12;
	
	/**
	 * Size 16 bytes
	 */
	public static final byte SharingMessageCredential = (byte) 0x13;
	
	/**
	 * Size 16 bytes
	 */
	public static final byte SharingDataCredential = (byte) 0x14;

}
