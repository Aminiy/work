package com.allstar.cintracer;

import com.allstar.cinconfig.CinConfigure;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinutil.CinTextUtil;
import com.allstar.cinutil.CinUtil;

/**
 * Field mapping for object in which tracer data is stored.
 * 
 * 
 */
public class CinTraceObject
{
	private CinTraceLevel TraceLevel;
	private String Message;
	private CinMessage CinMessage;
	private Throwable StackTrace;
	private Long currentDateTime;
	private String ThreadName;
	private String ClassName;

	public CinTraceObject(CinTraceLevel level, String message, CinMessage cinMessage, Throwable t, Long dateTime, String threadName, String className)
	{
		TraceLevel = level;
		Message = message;
		CinMessage = cinMessage;
		StackTrace = t;
		currentDateTime = dateTime;
		ThreadName = threadName;
		ClassName = className;
	}

	public CinMessage getInnerMessage()
	{
		return CinMessage;
	}

	public StringBuffer toString(boolean printStringValue)
	{
		StringBuffer sb = new StringBuffer();
		try
		{
			sb.append(CinTextUtil.getDateTimeString(currentDateTime));
			sb.append(CinTextUtil.SPACE);
			switch (TraceLevel)
			{
				case Info:
					sb.append(" [INFO]-[");
				break;
				case Warn:
					sb.append(" [WARN]-[");
				break;
				case Error:
					sb.append(" [ERRO]-[");
				break;
				case Special:
					sb.append(" [SPEC]-[");
				break;
			}
			sb.append(ClassName);
			sb.append("]-[");
			sb.append(ThreadName);
			sb.append("]");

			sb.append(CinTextUtil.RETURN);
			if (Message != null && !Message.isEmpty())
			{
				sb.append(Message);
				sb.append(CinTextUtil.RETURN);
				sb.append(CinTextUtil.RETURN);
			}
			if (CinMessage != null)
			{
				sb.append(CinMessage.toString(printStringValue));
				sb.append(CinTextUtil.RETURN);
				sb.append(CinTextUtil.RETURN);
			}

			Throwable tempT = StackTrace;
			while (tempT != null)
			{
				if (StackTrace != null)
				{
					sb.append(tempT.toString());
					sb.append(CinTextUtil.RETURN);
					for (StackTraceElement e : tempT.getStackTrace())
					{
						sb.append(e.toString());
						sb.append(CinTextUtil.RETURN);
					}
					sb.append(CinTextUtil.RETURN);
				}
				tempT = tempT.getCause();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return sb;
	}

	/**
	 * Converting system log entity class CinMessage to send TraceCenter, by
	 * TraceCenter put in storage
	 * 
	 * @return A CinMessage representation of this tracer object.
	 */
	public CinMessage toMessage()
	{
		CinMessage msg = new CinMessage(TraceLevel.getValue());
		if (Message != null)
		{
			msg.addHeader(new CinHeader(CinTraceHeaderId.Message.getValue(), CinUtil.getBytes(Message.getBytes(), 255)));
		}
		if (CinMessage != null)
		{
			if (CinMessage.From != null)
			{
				msg.addHeader(CinMessage.From);
			}
			if (CinMessage.To != null)
			{
				msg.addHeader(CinMessage.To);
			}
			msg.addHeader(new CinHeader(CinTraceHeaderId.CinMessage.getValue(), CinUtil.getBytes(CinMessage.toString(false).getBytes(), 255)));
		}
		if (StackTrace != null)
		{
			StringBuffer sb = new StringBuffer();
			sb.append(StackTrace.toString());
			sb.append(CinTextUtil.RETURN);
			for (StackTraceElement e : StackTrace.getStackTrace())
			{
				sb.append(e.toString());
				sb.append(CinTextUtil.RETURN);
			}
			sb.append(CinTextUtil.RETURN);

			msg.addHeader(new CinHeader(CinTraceHeaderId.StackTrace.getValue(), CinUtil.getBytes(sb.toString().getBytes(), 255)));
		}
		msg.addHeader(new CinHeader(CinTraceHeaderId.TraceDate.getValue(), currentDateTime));
		msg.addHeader(new CinHeader(CinTraceHeaderId.ThreadName.getValue(), ThreadName));
		msg.addHeader(new CinHeader(CinTraceHeaderId.ClassName.getValue(), ClassName));
		msg.addHeader(new CinHeader(CinTraceHeaderId.ServiceName.getValue(), CinConfigure.serviceName));
		msg.addHeader(new CinHeader(CinTraceHeaderId.ComputerName.getValue(), CinConfigure.computerName));

		return msg;
	}
}
