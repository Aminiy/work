package com.allstar.cintracer;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.allstar.cinconfig.CinConfigure;
import com.allstar.cinutil.CinLinkedList;
import com.allstar.cinutil.CinLinkedNode;

/**
 * Class for writing system trace.
 * 
 * 
 */
class CinTraceWriter extends Thread
{
	private final int sleepTime = 500;
	private final int maxQueueSize = 65536;

	private static long TraceCount = 0l;
	private static long OutPutCount = 0l;

	private static CinLinkedList<CinTraceObject> _list;

	CinTraceWriter()
	{
		_list = new CinLinkedList<CinTraceObject>();
	}

	public void save(CinTraceObject obj)
	{
		if (obj == null)
			return;
		if (_list.length() < maxQueueSize)
		{
			_list.put(obj);
			TraceCount++;
		}
		else
		{
			OutPutCount++;
			if (OutPutCount % sleepTime == 1)
			{
				System.out.println("Out Of MaxQueueSize: " + maxQueueSize + ", and the TraceCount is :" + TraceCount + ", and OutOfQueueSize Count:" + OutPutCount);
			}
		}
	}

	@Override
	public void run()
	{

		while (true)
		{
			try
			{
				if (_list == null)
					break;
				if (_list.length() == 0)
					Thread.sleep(sleepTime);
				else
				{
					_list.moveToHead();

					StringBuffer buffer = new StringBuffer();
					for (int i = 0; i < _list.length(); i++)
					{
						CinLinkedNode<CinTraceObject> node = _list.takeAwayFirst();
						if (node == null)
							break;
						buffer.append(node.object().toString(true));
					}
					write(buffer);
				}

			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}

	}

	private synchronized void write(StringBuffer buffer)
	{
		String posix = new SimpleDateFormat("yyyy-MM-dd-HH").format(new Date());
		String posdir = new SimpleDateFormat("yyyy/MM/dd/").format(new Date());
		File f = new File(CinTracerConfig.TraceURL() + posdir + CinConfigure.serviceName + "." + posix + ".log");
		File d = new File(CinTracerConfig.TraceURL() + posdir);

		if (!d.exists() && !d.isDirectory())
		{
			try
			{
				d.mkdirs();
			}
			catch (Exception e)
			{
				if (d != null)
					System.out.println(d.toString());
				e.printStackTrace();
				return;
			}
		}
		if (!f.exists())
		{// Create time-sharing files
			try
			{
				f.createNewFile();
			}
			catch (IOException e)
			{
				if (f != null)
					System.out.println(f.toString());
				e.printStackTrace();
				return;
			}
		}

		FileWriter fw = null;
		try
		{
			fw = new FileWriter(f, true);
			fw.append(buffer);
		}
		catch (IOException e)
		{
			e.printStackTrace();
			return;
		}
		finally
		{
			if (fw != null)
			{
				try
				{
					fw.close();
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
			}
		}
	}
}
