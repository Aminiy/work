package com.allstar.cintracer.spy;

import java.util.concurrent.ConcurrentLinkedQueue;

import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.common.CinStackConfiguration;
import com.allstar.cinstack.common.CinStackMode;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionCreatedEvent;
import com.allstar.cintracer.CinTraceLevel;
import com.allstar.cintracer.spy.common.CinTracerSpyConfig;
import com.allstar.cintracer.spy.common.CinTracerSpyEvent;
import com.allstar.cintracer.spy.entity.CinTraceSpyObject;
import com.allstar.cinutil.CinHashMap;

public class CinTracerSpyManager extends Thread implements CinTransactionCreatedEvent
{
	// private static CinTracer _tracer =
	// CinTracer.getInstance(CinTracerSpyManager.class);
	private static CinTracerSpyManager _instance;

	private boolean _isRunning;
	private CinStack _stack;
	private CinHashMap<Long, CinTracerSpy> _spys;
	private ConcurrentLinkedQueue<CinTraceSpyObject> _queue;
	private Object _syncRoot;
	private long _checkTime;

	public static CinTracerSpyManager getInstance()
	{
		if (_instance == null)
			_instance = new CinTracerSpyManager();
		return _instance;
	}

	@SuppressWarnings("deprecation")
	public CinTracerSpyManager()
	{
		super("CinTracerSpyManager-Thread");
		_isRunning = false;
		CinStackConfiguration config = new CinStackConfiguration();
		config.setStackMode(CinStackMode.Mutiplex);
		_stack = new CinStack(config);
		_spys = new CinHashMap<Long, CinTracerSpy>();
		_queue = new ConcurrentLinkedQueue<CinTraceSpyObject>();
		_syncRoot = new Object();
		updateCheckTime();
	}

	public void listen()
	{
		try
		{
			// if (CinTracerSpyConfig.getInstance().getListenPort() == -1)
			// {
			// System.out.println("CinTracer can't get the listen port. ");
			// return;
			// }

			_stack.listen(CinTracerSpyConfig.getInstance().getListenIP(), CinTracerSpyConfig.getInstance().getListenPort(), this);
			_isRunning = true;
			start();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public void dispose()
	{
		try
		{
			_isRunning = false;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public void sendTrace(CinTraceSpyObject obj)
	{
		// _tracer.info("Receive CinTracerObject: " + obj.toString());
		_queue.add(obj);
		synchronized (_syncRoot)
		{
			_syncRoot.notify();
		}
	}

	@Override
	public void run()
	{
		while (_isRunning)
			try
			{
				synchronized (_syncRoot)
				{
					_syncRoot.wait(CinTracerSpyConfig.getInstance().getWaitTime());
				}
				flushQueue();
				cleanExpiredSpy();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}
	}

	private void cleanExpiredSpy()
	{
		if (System.currentTimeMillis() < _checkTime)
			return;

		_spys.linkedListMoveToHead();
		CinTracerSpy spy = _spys.linkedListGet();
		while (spy != null)
		{
			if (spy.isExpired())
			{
				spy.sendTrace(new CinTraceSpyObject(CinTraceLevel.Special, "The spy has expired!!!", null, null, System.currentTimeMillis(), Thread.currentThread().getName(), CinTracerSpyManager.class.getName()));
				flushQueue();
				_spys.remove(spy.getKey());
				System.out.println("Remove Spy. " + spy.toString());
			}
			spy = _spys.linkedListGet();
		}
		updateCheckTime();
	}

	private void flushQueue()
	{
		// _tracer.info("Start to flush queue.");
		CinTraceSpyObject obj = _queue.poll();
		while (obj != null)
		{
			_spys.linkedListMoveToHead();
			CinTracerSpy spy = _spys.linkedListGet();
			while (spy != null)
			{
				System.out.println("start to send trace to spy.\r\n" + spy.toString() + "\r\n" + obj.toString());
				spy.sendTrace(obj);
				spy = _spys.linkedListGet();
			}
			obj = _queue.poll();
		}
	}

	private void updateCheckTime()
	{
		_checkTime = System.currentTimeMillis() + CinTracerSpyConfig.getInstance().getCheckIntervalTime();
	}

	@Override
	public void onCinTransactionCreated(CinTransaction trans)
	{
		try
		{
			CinRequest req = trans.getRequest();
			if (!req.isMethod(CinRequestMethod.Config) || !req.containsHeader(CinHeaderType.Event) || !req.containsHeader(CinHeaderType.Key))
			{
				trans.sendResponse(CinResponseCode.NotSupport);
				return;
			}

			long event = req.getHeader(CinHeaderType.Event).getInt64();
			long key = req.getHeader(CinHeaderType.Key).getInt64();
			CinTracerSpy spy = getSpy(key);
			if (req.containsHeader(CinHeaderType.Fpid))
				spy.updatePid(req.getHeader(CinHeaderType.Fpid).getValue());

			if (event == CinTracerSpyEvent.ADD_MONITORED_PERSON)
			{
				for (CinHeader header : req.getHeaders())
					if (header.getType() == CinHeaderType.Index)
						spy.addMonitoredUser(header.getInt64());
				trans.sendResponse(CinResponseCode.OK);
				return;
			}

			if (event == CinTracerSpyEvent.REMOVE_MONITORED_PERSON)
			{
				for (CinHeader header : req.getHeaders())
					if (header.getType() == CinHeaderType.Index)
						spy.removeMonitoredPersons(header.getInt64());
				trans.sendResponse(CinResponseCode.OK);
				return;
			}

			if (event == CinTracerSpyEvent.SET_NO_REQUEST)
			{
				spy.setNoRequest(req.getHeader(CinHeaderType.Index).getInt64() == 0x01);
				trans.sendResponse(CinResponseCode.OK);
				return;
			}

			if (event == CinTracerSpyEvent.SET_NO_USERID_REQUEST)
			{
				spy.setNoUserIdRequest(req.getHeader(CinHeaderType.Index).getInt64() == 0x01);
				trans.sendResponse(CinResponseCode.OK);
				return;
			}

			trans.sendResponse(CinResponseCode.NotSupport);
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
			trans.sendResponse(CinResponseCode.Error);
		}
	}

	private synchronized CinTracerSpy getSpy(long key)
	{
		CinTracerSpy spy = _spys.get(key);
		if (spy == null)
			_spys.add(key, spy = new CinTracerSpy(key, _stack));
		return spy;
	}
}
