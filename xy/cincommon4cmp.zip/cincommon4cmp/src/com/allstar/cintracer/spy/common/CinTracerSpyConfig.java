package com.allstar.cintracer.spy.common;

import com.allstar.cinconfig.CinConfigEntity;
import com.allstar.cinconfig.CinConfigInterface;

public class CinTracerSpyConfig extends CinConfigInterface
{
	private static CinTracerSpyConfig _instance;

	private long _expiredTime;
	private String _listenIP;
	private int _listenPort;
	private long _checkIntervalTime;
	private long _waitTime;

	public static CinTracerSpyConfig getInstance()
	{
		if (_instance == null)
		{
			_instance = new CinTracerSpyConfig();
			try
			{
				_instance.updateConfig();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}
		}
		return _instance;
	}

	private CinTracerSpyConfig()
	{
		_tableName = "CinTracer";
		_expiredTime = 60 * 1000 * 10;
		_listenIP = "0.0.0.0";
		_listenPort = 19999;
		_checkIntervalTime = 60 * 1000;
		_waitTime = 3 * 1000;
	}

	public long getExpiredTime()
	{
		return _expiredTime;
	}

	public String getListenIP()
	{
		return _listenIP;
	}

	public int getListenPort()
	{
		return _listenPort;
	}

	public long getCheckIntervalTime()
	{
		return _checkIntervalTime;
	}

	public long getWaitTime()
	{
		return _waitTime;
	}

	@Override
	protected void setValues(CinConfigEntity config)
	{
		try
		{
			String[] address = config.get("SpyIpEndPoint", "0.0.0.0:19999").split(":");
			_listenIP = address[0];
			_listenPort = Integer.valueOf(address[1]);

			_expiredTime = Long.valueOf(config.get("SpyExpiredTime", "10")) * 60 * 1000;
			_checkIntervalTime = Long.valueOf(config.get("CheckExpiredInterval", "1")) * 60 * 1000;
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
