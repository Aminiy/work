package com.allstar.cintracer.spy.common;

public class CinTracerSpyEvent
{
	public static final long ADD_MONITORED_PERSON = 0x01;
	public static final long REMOVE_MONITORED_PERSON = 0x02;
	public static final long SET_NO_REQUEST = 0x03;
	public static final long SET_NO_USERID_REQUEST = 0x04;
}
