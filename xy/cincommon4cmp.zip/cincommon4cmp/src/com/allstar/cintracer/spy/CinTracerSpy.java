package com.allstar.cintracer.spy;

import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cintracer.spy.common.CinTracerSpyConfig;
import com.allstar.cintracer.spy.entity.CinTraceSpyObject;
import com.allstar.cinutil.CinConvert;

class CinTracerSpy
{
	// private static CinTracer _tracer =
	// CinTracer.getInstance(CinTracerSpy.class);

	private Long _key;
	private CinStack _stack;
	private long _expiredTime;
	private ConcurrentHashMap<Long, Long> _monitoredUsers;
	private boolean _noRequest;
	private boolean _noUserIdRequest;
	private byte[] _pid;
	private Random _ra;

	public CinTracerSpy(Long key, CinStack stack)
	{
		_key = key;
		_stack = stack;
		updateExpiredTime();
		_monitoredUsers = new ConcurrentHashMap<Long, Long>();
		_ra = new Random();
	}

	public Long getKey()
	{
		return _key;
	}

	public void updatePid(byte[] pid)
	{
		_pid = pid;
	}

	public void addMonitoredUser(long userId)
	{
		_monitoredUsers.put(userId, 0L);
		updateExpiredTime();
	}

	public void removeMonitoredPersons(long userId)
	{
		_monitoredUsers.remove(userId);
		updateExpiredTime();
	}

	public void setNoRequest(boolean value)
	{
		_noRequest = value;
		updateExpiredTime();
	}

	public void setNoUserIdRequest(boolean value)
	{
		_noUserIdRequest = value;
		updateExpiredTime();
	}

	private void updateExpiredTime()
	{
		_expiredTime = System.currentTimeMillis() + CinTracerSpyConfig.getInstance().getExpiredTime();
	}

	private boolean canSend(CinMessage message)
	{
		if (message == null)
			return _noRequest;
		if (message.From == null && message.To == null)
			return _noUserIdRequest;
		if (message.From != null && _monitoredUsers.containsKey(message.From.getInt64()))
			return true;
		if (message.To != null && _monitoredUsers.containsKey(message.To.getInt64()))
			return true;
		return false;
	}

	public boolean isExpired()
	{
		return _expiredTime < System.currentTimeMillis();
	}

	public void sendTrace(CinTraceSpyObject obj)
	{
		if (!canSend(obj.getInnerMessage()))
			return;
		// _tracer.info("Ready to send trace. " + obj.toString());
		CinRequest request = new CinRequest(CinRequestMethod.Trace);
		request.addHeader(new CinHeader(CinHeaderType.From, _ra.nextLong()));
		request.addHeader(new CinHeader(CinHeaderType.To, _ra.nextLong()));
		request.addHeader(new CinHeader(CinHeaderType.Key, getKey()));
		request.addHeader(new CinHeader(CinHeaderType.Tpid, _pid));
		CinRouter.setRoute(request, CinServiceName.MessageProxy);
		request.addBody(obj.toBytes());

		CinTransaction trans = _stack.createTransaction(request);
		trans.sendRequest();
	}

	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Key: ");
		sb.append(_key);
		sb.append("; ExpiredTime: ");
		sb.append(_expiredTime);
		sb.append("; NoRequest: ");
		sb.append(_noRequest);
		sb.append("; NoUserIdRequest: ");
		sb.append(_noUserIdRequest);
		if (_pid != null)
		{
			sb.append("; Pid: ");
			sb.append(CinConvert.bytes2String(_pid));
		}
		return sb.toString();
	}
}
