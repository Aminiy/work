package com.allstar.cintracer.spy.entity;

import com.allstar.cinconfig.CinConfigure;
import com.allstar.cinstack.handler.codec.CinEncoder;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cintracer.CinTraceHeaderId;
import com.allstar.cintracer.CinTraceLevel;
import com.allstar.cinutil.CinTextUtil;
import com.allstar.cinutil.CinUtil;

public class CinTraceSpyObject
{
	private CinTraceLevel _level;
	private String _message;
	private CinMessage _cinMessage;
	private Throwable _stackTrace;
	private Long _currentDateTime;
	private String _threadName;
	private String _className;

	public CinTraceSpyObject(CinTraceLevel level, String message, CinMessage cinMessage, Throwable t, Long dateTime, String threadName, String className)
	{
		_level = level;
		_message = message;
		_cinMessage = cinMessage;
		_stackTrace = t;
		_currentDateTime = dateTime;
		_threadName = threadName;
		_className = className;
	}

	public CinMessage getInnerMessage()
	{
		return _cinMessage;
	}

	public byte[] toBytes()
	{
		CinMessage msg = new CinMessage(_level.getValue());
		if (_message != null)
		{
			msg.addHeader(new CinHeader(CinTraceHeaderId.Message.getValue(), CinUtil.getBytes(_message.getBytes(), 255)));
		}
		if (_cinMessage != null)
		{
			if (_cinMessage.From != null)
			{
				msg.addHeader(_cinMessage.From);
			}
			if (_cinMessage.To != null)
			{
				msg.addHeader(_cinMessage.To);
			}
			// msg.addHeader(new
			// CinHeader(CinTraceHeaderId.CinMessage.getValue(),
			// CinUtil.getBytes(_cinMessage.toString(false).getBytes(), 255)));
			msg.addBody(CinEncoder.toBytes(_cinMessage));
		}
		if (_stackTrace != null)
		{
			StringBuffer sb = new StringBuffer();
			sb.append(_stackTrace.toString());
			sb.append(CinTextUtil.RETURN);
			for (StackTraceElement e : _stackTrace.getStackTrace())
			{
				sb.append(e.toString());
				sb.append(CinTextUtil.RETURN);
			}
			sb.append(CinTextUtil.RETURN);

			msg.addHeader(new CinHeader(CinTraceHeaderId.StackTrace.getValue(), CinUtil.getBytes(sb.toString().getBytes(), 255)));
		}
		msg.addHeader(new CinHeader(CinTraceHeaderId.TraceDate.getValue(), _currentDateTime));
		msg.addHeader(new CinHeader(CinTraceHeaderId.ThreadName.getValue(), _threadName));
		msg.addHeader(new CinHeader(CinTraceHeaderId.ClassName.getValue(), _className));
		msg.addHeader(new CinHeader(CinTraceHeaderId.ServiceName.getValue(), CinConfigure.serviceName));
		msg.addHeader(new CinHeader(CinTraceHeaderId.ComputerName.getValue(), CinConfigure.computerName));

		return CinEncoder.toBytes(msg);
	}

	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("\r\nLevel: ");
		sb.append(_level);
		sb.append("\r\nMessage: ");
		sb.append(_message);
		sb.append("\r\nCinMessage: ");
		sb.append(_cinMessage == null ? "NULL" : _cinMessage.toString());
		sb.append("\r\nStackTrace: ");
		sb.append(_stackTrace);
		sb.append("\r\nTime: ");
		sb.append(_currentDateTime);
		sb.append("\r\nThreadName: ");
		sb.append(_threadName);
		sb.append("\r\nClassName: ");
		sb.append(_className);
		return sb.toString();
	}
}
