/**
 * 
 */
package com.allstar.cintracer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.PropertyConfigurator;

import com.allstar.cinconfig.CinConfigEntity;
import com.allstar.cinconfig.CinConfigInterface;
import com.allstar.cinconfig.CinConfigure;
import com.allstar.cintracer.spy.CinTracerSpyManager;
import com.allstar.cintracer.spy.common.CinTracerSpyConfig;
import com.allstar.cinutil.CinTextUtil;

/**
 * Configuration for CinTracer module.
 * 
 * 
 */
public class CinTracerConfig extends CinConfigInterface
{
	/*
	 * WriteToFileLevel SendToDBLevel WriteToConsoleLevel TraceLevel: 10, 20,
	 * 30; [info, warn, error]; WhiteList: "15801509000, 699999999"; "none"; "";
	 */
	private final static String writeToFileConfigString = "WriteToFileLevel";
	private final static String sendToDBConfigString = "SendToDBLevel";
	private final static String writeToConsoleConfigString = "WriteToConsoleLevel";
	private final static String whiteListConfigString = "TraceWhiteList";
	private static Byte _writeToFileLevel = 10;
	private static Byte _sendToDBLevel = 40;
	private static Byte _writeToConsoleLevel = 40;
	private static String _whiteList = CinTextUtil.EmptyString;

	private static boolean closeDBTrace = false;
	private static String rootLogger = "info,stdout,file";

	private static CinConfigInterface _instance;
	private static ArrayList<Long> _whiteListArray;
	private static boolean _enableSpy = false;
	private static List<String> _useridList;

	CinTracerConfig()
	{
		_tableName = "CinTracer";
	}

	public static void initialize()
	{
		if (_instance == null)
		{
			_instance = new CinTracerConfig();

			try
			{
				_instance.updateConfig();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}

	@Override
	protected void setValues(CinConfigEntity config)
	{
		rootLogger = config.get("RootLogger");

		_writeToFileLevel = Byte.valueOf(config.get(writeToFileConfigString));
		if (closeDBTrace)
			_sendToDBLevel = 50;
		else
			_sendToDBLevel = Byte.valueOf(config.get(sendToDBConfigString));
		_writeToConsoleLevel = Byte.valueOf(config.get(writeToConsoleConfigString));
		_whiteList = config.get(whiteListConfigString);
		if (_whiteList != null && !_whiteList.isEmpty() && _whiteList != "none")
		{
			setWhiteList(_whiteList);
		}

		Properties properties = new Properties();
		properties.setProperty("log4j.rootLogger", rootLogger);

		if (rootLogger.indexOf("stdout") != -1)
		{
			properties.setProperty("log4j.appender.stdout", "org.apache.log4j.ConsoleAppender");
			properties.setProperty("log4j.appender.stdout.Target", "System.out");
			properties.setProperty("log4j.appender.stdout.layout", "org.apache.log4j.PatternLayout");
			properties.setProperty("log4j.appender.stdout.layout.ConversionPattern", "%d [%t] %-5p %c %x - %m%n");

		}

		if (rootLogger.indexOf("debug") != -1)
		{
			properties.setProperty("log4j.logger.java.sql.Connection", "debug");
			properties.setProperty("log4j.logger.java.sql.Statement", "debug");
			properties.setProperty("log4j.logger.java.sql.PreparedStatement", "debug");

		}

		properties.setProperty("log4j.appender.file", "org.apache.log4j.DailyRollingFileAppender");

		properties.setProperty("log4j.appender.file.DatePattern", "'.'yyyy-MM-dd-HH");
		properties.setProperty("log4j.appender.file.File", CinConfigure.traceUrl + "/" + CinConfigure.serviceName + "/" + CinConfigure.computerName + "/" + CinConfigure.serviceName + ".log");
		properties.setProperty("log4j.appender.file.layout", "org.apache.log4j.PatternLayout");
		properties.setProperty("log4j.appender.file.layout.ConversionPattern", "%d [%t] %-5p %c %x - %m%n");
		properties.setProperty("log4j.appender.file.encoding", "UTF-8");
		PropertyConfigurator.configure(properties);

		boolean enableSpy = Boolean.valueOf(config.get("EnableSpy", "false"));
		if (enableSpy != _enableSpy)
		{
			CinTracerSpyConfig.getInstance();
			updateSpyStatus(enableSpy);
			_enableSpy = enableSpy;
		}
		_useridList = Arrays.asList(config.get("userid", "0").trim().split(" , "));
	}

	private static void setWhiteList(String whiteList)
	{
		try
		{
			String[] list = whiteList.split(",");

			if (list.length > 0)
			{
				_whiteListArray = new ArrayList<Long>();
				for (int i = 0; i < list.length; i++)
				{
					_whiteListArray.add(Long.valueOf(list[i]));
				}
			}
		}
		catch (Exception ex)
		{
			_whiteListArray = null;
		}
	}

	public static Byte WriteToFileLevel()
	{
		return _writeToFileLevel;
	}

	public static Byte SendToDBLevel()
	{
		return _sendToDBLevel;
	}

	public static Byte WriteToConsoleLevel()
	{
		return _writeToConsoleLevel;
	}

	public static String TraceURL()
	{
		return CinConfigure.traceUrl + "/" + CinConfigure.serviceName + "/" + CinConfigure.computerName + "/";
	}

	public static ArrayList<Long> WhiteListArray()
	{
		return _whiteListArray;
	}

	public static boolean enableSpy()
	{
		return _enableSpy;
	}

	public static void closeDBTrace()
	{
		closeDBTrace = true;
		_sendToDBLevel = 50;
	}

	public static void closeTrace()
	{
		closeDBTrace = true;
		_sendToDBLevel = 50;
		_writeToFileLevel = 50;
		_writeToConsoleLevel = 40;
	}

	public static void openTrace()
	{
		_writeToFileLevel = 10;
	}

	private void updateSpyStatus(boolean enable)
	{
		if (enable)
		{
			System.out.println("Ready to start CinTrace Spy....");
			CinTracerSpyManager.getInstance().listen();
		}
		else
		{
			System.out.println("Ready to stop CinTrace Spy....");
			CinTracerSpyManager.getInstance().dispose();
		}
	}
	
	public static List<String> get_useridList() {
		return _useridList;
	}
}
