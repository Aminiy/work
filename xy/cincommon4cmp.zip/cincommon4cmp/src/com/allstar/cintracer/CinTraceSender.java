package com.allstar.cintracer;

import java.net.InetSocketAddress;

import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.handler.codec.CinEncoder;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.transaction.CinTransaction;

/**
 * Class for sending trace data to database
 * 
 * 
 */
class CinTraceSender
{
	/**
	 * Send log
	 * 
	 * @param obj
	 */
	public void send(CinTraceObject obj)
	{
		if (CinStack.instance() != null)
		{
			CinRequest request = new CinRequest(CinRequestMethod.Trace);
			request.addBody(CinEncoder.toBytes(obj.toMessage()));

			InetSocketAddress add = CinRouter.takeRoute(CinServiceName.TraceCenter);
			if (add != null)
			{
				CinTransaction trans = CinStack.instance().createTransaction(add, request);
				trans.sendRequest();
			}
		}
	}
}
