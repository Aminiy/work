package com.allstar.cintracer;

import java.util.HashMap;

/**
 * Enumeration of tracer level
 * 
 * 
 */
public enum CinTraceLevel
{
	Info((byte) 10), Warn((byte) 20), Error((byte) 30), Special((byte) 40);

	private byte value;
	private static HashMap<Byte, CinTraceLevel> _map;
	static
	{
		_map = new HashMap<Byte, CinTraceLevel>();
		for (CinTraceLevel level : CinTraceLevel.values())
			_map.put(level.getValue(), level);
	}

	CinTraceLevel(byte value)
	{
		this.setValue(value);
	}

	public void setValue(byte value)
	{
		this.value = value;
	}

	public byte getValue()
	{
		return value;
	}

	public static CinTraceLevel get(byte type)
	{
		CinTraceLevel level = _map.get(type);
		if (level == null)
			return Info;
		else
			return level;
	}
}
