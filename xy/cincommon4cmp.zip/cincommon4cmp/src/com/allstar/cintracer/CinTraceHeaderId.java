package com.allstar.cintracer;

import java.util.HashMap;

/**
 * Tracer format definition in database

 * 
 */
public enum CinTraceHeaderId
{
	From((byte) 1),

	To((byte) 2),

	CinMessage((byte) 3),

	Message((byte) 4),

	StackTrace((byte) 5),

	TraceDate((byte) 6),

	ThreadName((byte) 7),

	ClassName((byte) 8),

	ServiceName((byte) 9),

	ComputerName((byte) 10),

	Unknown((byte) 0);

	private byte value;
	private static HashMap<Byte, CinTraceHeaderId> _map;
	static
	{
		_map = new HashMap<Byte, CinTraceHeaderId>();
		for (CinTraceHeaderId id : CinTraceHeaderId.values())
			_map.put(id.getValue(), id);
	}

	CinTraceHeaderId(byte value)
	{
		this.setValue(value);
	}

	public void setValue(byte value)
	{
		this.value = value;
	}

	public byte getValue()
	{
		return value;
	}

	public static CinTraceHeaderId get(byte type)
	{
		CinTraceHeaderId id = _map.get(type);
		if (id == null)
			return Unknown;
		else
			return id;
	}
}
