package com.allstar.cintracer;

import java.util.ArrayList;

import com.allstar.cinstack.message.CinMessage;
import com.allstar.cintracer.spy.CinTracerSpyManager;
import com.allstar.cintracer.spy.entity.CinTraceSpyObject;
import com.allstar.cinutil.CinTextUtil;

/**
 * Class for CinTracer module
 * 
 * 
 */
public class CinTracer
{
	private String className = "";

	private boolean _IsStackTrace = true;

	private static CinTraceWriter writer = new CinTraceWriter();
	private static CinTraceSender sender = new CinTraceSender();

	/**
	 * Initialize
	 * 
	 * @throws Exception
	 */
	public static void Initialize() throws Exception
	{
		CinTracerConfig.initialize();
		if (!writer.isAlive())
		{
			writer.setDaemon(true);
			writer.setName("CinTracerThread");
			writer.start();
		}
	}

	public static void closeDBTrace()
	{
		CinTracerConfig.closeDBTrace();
	}

	private CinTracer(Class<?> clazz, boolean isStackTrace)
	{
		className = clazz.getSimpleName();
		_IsStackTrace = isStackTrace;
	}

	public static CinTracer getInstance(Class<?> clazz)
	{
		return new CinTracer(clazz, false);
	}

	/**
	 * Access to the singleton
	 * 
	 * @param clazz
	 * @param isStackTrace
	 * @return Singleton instance of CinTracer
	 * @deprecated
	 */
	public static CinTracer getInstance(Class<?> clazz, boolean isStackTrace)
	{
		return new CinTracer(clazz, isStackTrace);
	}

	/**
	 * Will get info to the Trace log write library
	 * 
	 * @return true: If the info level is ON </br> false: If the info level is
	 *         OFF
	 */
	public boolean InfoTrace()
	{
		return checkTraceLevel(CinTraceLevel.Info);
	}

	/**
	 * Will get warning level log write to Trace
	 * 
	 * @return true: If the warn level is ON </br> false: If the warn level is
	 *         OFF
	 */
	public boolean WarnTrace()
	{
		return checkTraceLevel(CinTraceLevel.Warn);
	}

	/**
	 * Will get the error log write to Trace level library
	 * 
	 * @return true: If the error level is ON </br> false: If the error level is
	 *         OFF
	 */
	public boolean ErrorTrace()
	{
		return checkTraceLevel(CinTraceLevel.Error);
	}

	private boolean checkTraceLevel(CinTraceLevel level)
	{
		return CinTracerConfig.WriteToConsoleLevel() <= level.getValue() || CinTracerConfig.WriteToFileLevel() <= level.getValue() || CinTracerConfig.SendToDBLevel() <= level.getValue();
	}

	/**
	 * Writing system log
	 * 
	 * @param level
	 * @param message
	 * @param cinMessage
	 * @param t
	 */
	private void write(CinTraceLevel level, String message, CinMessage cinMessage, Throwable t)
	{
		try
		{
			CinTraceObject obj = null;
			if (cinMessage != null && inWhitList(cinMessage))
			{// When TraceLevel <= Error, write
				// Trace.
				if (CinTracerConfig.WriteToFileLevel() <= CinTraceLevel.Error.getValue())
				{
					if (obj == null)
						obj = new CinTraceObject(level, message, cinMessage, t, System.currentTimeMillis(), CinTextUtil.getThreadName(Thread.currentThread()), className);
					writer.save(obj);
				}

				if (CinTracerConfig.WriteToConsoleLevel() <= CinTraceLevel.Error.getValue())
				{
					if (obj == null)
						obj = new CinTraceObject(level, message, cinMessage, t, System.currentTimeMillis(), CinTextUtil.getThreadName(Thread.currentThread()), className);
					System.out.println(obj.toString(true));
				}

				if (CinTracerConfig.SendToDBLevel() <= CinTraceLevel.Error.getValue() && !_IsStackTrace)
				{
					if (obj == null)
						obj = new CinTraceObject(level, message, cinMessage, t, System.currentTimeMillis(), CinTextUtil.getThreadName(Thread.currentThread()), className);
					sender.send(obj);
				}
			}
			else
			{
				if (level.getValue() >= CinTracerConfig.WriteToFileLevel())
				{
					if (obj == null)
						obj = new CinTraceObject(level, message, cinMessage, t, System.currentTimeMillis(), CinTextUtil.getThreadName(Thread.currentThread()), className);
					writer.save(obj);
				}

				if (level.getValue() >= CinTracerConfig.WriteToConsoleLevel())
				{
					if (obj == null)
						obj = new CinTraceObject(level, message, cinMessage, t, System.currentTimeMillis(), CinTextUtil.getThreadName(Thread.currentThread()), className);
					System.out.println(obj.toString(true));
				}

				if (level.getValue() >= CinTracerConfig.SendToDBLevel() && !_IsStackTrace)
				{
					if (obj == null)
						obj = new CinTraceObject(level, message, cinMessage, t, System.currentTimeMillis(), CinTextUtil.getThreadName(Thread.currentThread()), className);
					sender.send(obj);
				}
			}

			writeToSpy(level, message, cinMessage, t);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public void writeToSpy(CinTraceLevel level, String message, CinMessage cinMessage, Throwable t)
	{
		if (CinTracerConfig.enableSpy())
		{
			CinTraceSpyObject o = new CinTraceSpyObject(level, message, cinMessage, t, System.currentTimeMillis(), CinTextUtil.getThreadName(Thread.currentThread()), className);
			CinTracerSpyManager.getInstance().sendTrace(o);
		}
	}

	private boolean inWhitList(CinMessage cinMessage)
	{
		ArrayList<Long> list = CinTracerConfig.WhiteListArray();
		if (list != null && list.size() > 0)
		{
			Long from = 0L;
			Long to = 0L;
			if (cinMessage.From != null)
			{
				from = cinMessage.From.getInt64();
			}
			if (cinMessage.To != null)
			{
				to = cinMessage.To.getInt64();
			}

			return list.contains(from) || list.contains(to);
		}
		return false;
	}

	/**
	 * Record the info logs
	 * 
	 * @param message
	 */
	public void info(String message)
	{
		this.info(message, null, null);
	}

	/**
	 * Record the info logs
	 * 
	 * @param message
	 * @param cinMessage
	 */
	public void info(String message, CinMessage cinMessage)
	{
		this.info(message, cinMessage, null);
	}

	/**
	 * Record the info logs
	 * 
	 * @param message
	 * @param t
	 */
	public void info(String message, Throwable t)
	{
		this.info(message, null, t);
	}

	/**
	 * Record the info logs
	 * 
	 * @param message
	 * @param cinMessage
	 * @param t
	 */
	public void info(String message, CinMessage cinMessage, Throwable t)
	{
		write(CinTraceLevel.Info, message, cinMessage, t);
	}

	/**
	 * Record the warning logs
	 * 
	 * @param message
	 */
	public void warn(String message)
	{
		this.warn(message, null, null);
	}

	/**
	 * Record the warning logs
	 * 
	 * @param message
	 * @param cinMessage
	 */
	public void warn(String message, CinMessage cinMessage)
	{
		this.warn(message, cinMessage, null);
	}

	/**
	 * Record the warning logs
	 * 
	 * @param message
	 * @param t
	 */
	public void warn(String message, Throwable t)
	{
		this.warn(message, null, t);
	}

	/**
	 * Record the warning logs
	 * 
	 * @param message
	 * @param cinMessage
	 * @param t
	 */
	public void warn(String message, CinMessage cinMessage, Throwable t)
	{
		write(CinTraceLevel.Warn, message, cinMessage, t);
	}

	/**
	 * Record the warning logs
	 * 
	 * @param message
	 */
	public void error(String message)
	{
		this.error(message, null, null);
	}

	/**
	 * Record the error logs
	 * 
	 * @param message
	 * @param cinMessage
	 */
	public void error(String message, CinMessage cinMessage)
	{
		this.error(message, cinMessage, null);
	}

	/**
	 * Record the error logs
	 * 
	 * @param message
	 * @param t
	 */
	public void error(String message, Throwable t)
	{
		this.error(message, null, t);
	}

	/**
	 * Record the error logs
	 * 
	 * @param message
	 * @param cinMessage
	 * @param t
	 */
	public void error(String message, CinMessage cinMessage, Throwable t)
	{
		write(CinTraceLevel.Error, message, cinMessage, t);
	}

	/**
	 * Record the error logs
	 * 
	 * @param message
	 */
	public void special(String message)
	{
		this.special(message, null, null);
	}

	/**
	 * Record the error logs
	 * 
	 * @param message
	 * @param cinMessage
	 */
	public void special(String message, CinMessage cinMessage)
	{
		this.special(message, cinMessage, null);
	}

	/**
	 * Record the special logs
	 * 
	 * @param message
	 * @param t
	 */
	public void special(String message, Throwable t)
	{
		this.special(message, null, t);
	}

	/**
	 * Record the special logs
	 * 
	 * @param message
	 * @param cinMessage
	 * @param t
	 */
	public void special(String message, CinMessage cinMessage, Throwable t)
	{
		write(CinTraceLevel.Special, message, cinMessage, t);
	}
	
	/*
	 * Record the error log for some special condition for debugging
	 */
	/**
	 * Record the error logs with special condition
	 * 
	 * @param message
	 */
	public void info(String message, long userid) {
		if (CinTracerConfig.get_useridList().contains(String.valueOf(userid))) {
			this.error(message, null, null);
		}
	}

	/**
	 * Record the error logs with special condition
	 * 
	 * @param message
	 * @param cinMessage
	 */
	public void info(String message, CinMessage cinMessage, long userid) {
		if (CinTracerConfig.get_useridList().contains(String.valueOf(userid))) {
			this.error(message, cinMessage, null);
		}
	}

	/**
	 * Record the error logs with special condition
	 * 
	 * @param message
	 * @param t
	 */
	public void info(String message, Throwable t, long userid) {
		if (CinTracerConfig.get_useridList().contains(String.valueOf(userid))) {
			this.error(message, null, t);
		}
	}

	/**
	 * Record the error logs with special condition
	 * 
	 * @param message
	 * @param cinMessage
	 * @param t
	 */
	public void info(String message, CinMessage cinMessage, Throwable t, long userid) {
		if (CinTracerConfig.get_useridList().contains(String.valueOf(userid))) {
			write(CinTraceLevel.Error, message, cinMessage, t);
		}
	}
	/* Special condition for debugging Ends */
}