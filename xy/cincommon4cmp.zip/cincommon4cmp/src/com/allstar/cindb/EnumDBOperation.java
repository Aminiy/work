package com.allstar.cindb;

/**
 * Database operation type enumeration 1:select;2:update
 * 
 * 
 */
public class EnumDBOperation
{
	public static final byte Select = 1;
	public static final byte Update = 2;
}
