package com.allstar.cindb.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.allstar.cindb.dbaccess.DbName;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface TableAttribute
{
	public String dbname() default DbName.FETIONCHAT;

	public String tablename();
};