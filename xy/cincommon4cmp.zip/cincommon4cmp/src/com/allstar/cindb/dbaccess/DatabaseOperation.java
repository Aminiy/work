package com.allstar.cindb.dbaccess;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.allstar.cindb.CinDbEntity;
import com.allstar.cindb.EnumDBOperation;
import com.allstar.cindb.annotation.FieldAttribute;
import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinTextUtil;
import com.allstar.cinutil.CinUtil;
import com.mysql.jdbc.Statement;

/**
 * Database operations class
 * 
 * 
 */
public class DatabaseOperation
{
	private static CinTracer tracer = CinTracer.getInstance(DatabaseOperation.class);
	private String _sql;
	HashMap<Byte, Byte> idMap = new HashMap<Byte, Byte>();
	private CinDbEntity _entity;
	private Database _db;

	/**
	 * The constructor
	 * 
	 * @param entity
	 * @param db
	 */
	public DatabaseOperation(CinDbEntity entity, Database db)
	{
		_db = db;
		_sql = entity.getSqlName();
		_entity = entity;

		if (_sql == null || !_sql.contains(CinTextUtil.SHARP))
			return;
		String[] params = _sql.trim().split(CinTextUtil.SHARP)[1].split(CinTextUtil.Comma);
		for (int i = 0; i < params.length; i++)
		{
			byte id = _entity.getIdField(params[i].trim());
			idMap.put((byte) (i + 1), id);
		}
	}

	/**
	 * Perform a Select operation and returns a result set
	 * 
	 * @return
	 */
	public <T extends CinDbEntity> T select() throws Exception
	{
		try
		{
			List<T> list = selectList();
			if (!CinUtil.isNullOrEmpty(list))
				return list.get(0);
			else
				return null;
		}
		catch (Exception e)
		{
			tracer.error("select from db failed " + _sql, e);
			throw e;
		}
	}

	/**
	 * Perform a Select operation list and returns the result set
	 * 
	 * @return List of CinDbEntities that converted from query result
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public <T extends CinDbEntity> List<T> selectList() throws Exception
	{
		ResultSet rs = null;
		PreparedStatement stmt = null;
		Connection conn = null;
		List<T> entityList = new ArrayList<T>();
		try
		{
			conn = _db.getConnection();
			stmt = prepareConnStmt(EnumDBOperation.Select, conn, false);
			rs = stmt.executeQuery();
			while (rs.next())
			{
				T ent = (T) _entity.getClass().newInstance();

				HashMap<Byte, Field> fields = new HashMap<Byte, Field>();
				for (Field f : ent.getClass().getFields())
				{
					FieldAttribute fa = f.getAnnotation(FieldAttribute.class);
					if (fa != null)
						fields.put(fa.idx(), f);
				}

				for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++)
				{
					Byte t = _entity.getIdField(rs.getMetaData().getColumnLabel(i));

					switch (_entity.getTypeField(t))
					{
						case BIGINT:
							fields.get(t).setLong(ent, rs.getLong(i));
						break;
						case DATETIME:
							fields.get(t).setLong(ent, rs.getTimestamp(i).getTime());
						break;
						case HEXSTRING:
							fields.get(t).set(ent, rs.getString(i).getBytes());
						break;
						case INTEGER:
							fields.get(t).setInt(ent, rs.getInt(i));
						break;
						case IPADDRESS:
							fields.get(t).set(ent, InetAddress.getByName(rs.getString(i)).getAddress());
						break;
						case TINYINT:
							fields.get(t).setByte(ent, rs.getByte(i));
						break;
						case VARCHAR:
							fields.get(t).set(ent, rs.getString(i));
						break;
						case DECIMAL:
							fields.get(t).set(ent, rs.getBigDecimal(i));
						break;
						case BIN:
							fields.get(t).set(ent, rs.getBytes(i));
						break;
						default:
							fields.get(t).set(ent, rs.getBytes(i));
						break;
					}
				}
				entityList.add(ent);
			}
			return entityList;
		}
		catch (Exception e)
		{
			tracer.error("select list from db failed " + _sql, e);
			throw e;
		}
		finally
		{
			closeResultSet(rs);
			closeStmt(stmt);
			closeConn(conn);
		}
	}

	/**
	 * To perform the update or Insert operations, and returns the affected rows
	 * 
	 * @return Number of rows affected by this execution
	 * @throws Exception
	 */
	public int update() throws Exception
	{
		Connection conn = null;
		PreparedStatement stmt = null;
		try
		{
			conn = _db.getConnection();
			conn.setAutoCommit(false);
			stmt = prepareConnStmt(EnumDBOperation.Update, conn, false);
			int ret = stmt.executeBatch()[0];
			conn.commit();
			return ret;
			// return 1;
		}
		catch (Exception e)
		{
			tracer.error("insert/update/delete from db failed " + _sql, e);
			try
			{
				conn.rollback();
			}
			catch (SQLException e1)
			{
				tracer.error("rollback failed", e);
			}
			throw e;
		}
		finally
		{
			closeStmt(stmt);
			closeConn(conn);
		}
	}

	private static String getCallSql(String spName, int paramsCount)
	{
		StringBuilder sb = new StringBuilder();

		sb.append("{call ").append(spName).append("(");

		for (int i = 0; i < paramsCount; i++)
		{
			sb.append("?");
			if (i < paramsCount - 1)
			{
				sb.append(",");
			}
		}

		sb.append(")}");
		return sb.toString();
	}

	private static void fillStatement(CallableStatement statement, String[] params, Object[] values) throws SQLException
	{
		if (values != null)
		{
			for (int i = 0; i < values.length; i++)
			{
				if (params == null)
				{
					statement.setObject(i + 1, values[i]);
				}
				else
				{
					statement.setObject(params[i], values[i]);
				}
			}
		}
	}

	/**
	 * match contact only for UIDC
	 * 
	 * @param spName
	 * @param params
	 * @param values
	 * @return return userId if success
	 * @throws Exception
	 */
	@Deprecated
	public long spMatchContact(String[] params, Object... values) throws Exception
	{
		final String spName = "sp_matchcontact";

		params = params == null ? new String[]{} : params;
		values = values == null ? new String[]{} : values;

		ResultSet rs = null;
		Connection conn = null;
		CallableStatement statement = null;
		try
		{
			if (params.length != values.length)
			{
				throw new IllegalArgumentException("params.length != values.length");
			}

			conn = _db.getConnection();

			String sql = getCallSql(spName, values == null ? 0 : values.length);
			statement = conn.prepareCall(sql);

			fillStatement(statement, params, values);

			rs = statement.executeQuery();

			if (rs != null && rs.getMetaData().getColumnCount() == 1)
			{
				rs.next();
				return rs.getLong(1);
			}
			else
			{
				return 0;
			}
		}
		catch (Exception e)
		{
			tracer.error(String.format("spExecute:{%s} error", spName), e);
			throw e;
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
				}
			}
			catch (Exception e2)
			{
				tracer.error("close Database ResultSet failed", e2);
			}

			closeStmt(statement);
			closeConn(conn);
		}
	}

	/**
	 * An Insert operation, and returns on the ID
	 * 
	 * @return The auto-increment key
	 * @throws Exception
	 */
	public long updateReturnKeys() throws Exception
	{
		Connection conn = null;
		PreparedStatement stmt = null;
		long ret = 0;
		try
		{
			conn = _db.getConnection();
			conn.setAutoCommit(false);
			stmt = prepareConnStmt(EnumDBOperation.Update, conn, true);
			stmt.executeBatch();
			ResultSet rs = stmt.getGeneratedKeys();
			rs.next();
			if (rs.getRow() > 0)
			{
				ret = rs.getLong(1);
			}

			conn.commit();
			return ret;
		}
		catch (Exception e)
		{
			tracer.error("insert/update/delete from db failed Return Keys " + _sql, e);
			try
			{
				conn.rollback();
			}
			catch (SQLException e1)
			{
				tracer.error("rollback return Keys failed", e);
			}
			throw e;
		}
		finally
		{
			closeStmt(stmt);
			closeConn(conn);
		}
	}

	/**
	 * Returns the last Insert on multi-stage operation, the operation on the ID
	 * must will need to return the ID of the SQL statement in the last one.
	 * 
	 * @return the results in the SQL order array </br> = 0: perform successful
	 *         article number represents influence the number; </br>-2: perform
	 *         successful article affect the number of unknown; </br>-3 failure;
	 * @throws Exception
	 */
	@SuppressWarnings("resource")
	public long updateBatchReturnKeys(String... sqls) throws Exception
	{
		Connection conn = null;
		java.sql.Statement st = null;
		long ret = 0;
		try
		{
			conn = _db.getConnection();
			conn.setAutoCommit(false);
			st = conn.createStatement();
			for (String sql : sqls)
				st.addBatch(sql);

			int[] result = st.executeBatch();

			for (int t : result)
			{
				if (t == -3)
				{
					conn.rollback();
					return 0;
				}
			}

			ResultSet rs = st.getGeneratedKeys();
			rs.next();
			ret = rs.getLong(1);

			conn.commit();
			return ret;
		}
		catch (Exception e)
		{
			tracer.error("insert/update/delete from db failed " + _sql, e);
			try
			{
				conn.rollback();
			}
			catch (SQLException e1)
			{
				tracer.error("rollback failed", e1);
			}
			throw e;
		}
		finally
		{
			closeSt(st);
			closeConn(conn);
		}
	}

	/**
	 * @param list
	 *            all params of the _sql.
	 * @return
	 * 
	 *         0:Error; 1:OK.
	 */
	@SuppressWarnings("resource")
	public int executeBatch(List<CinDbEntity> list)
	{
		Connection conn = null;
		PreparedStatement stmt = null;

		// Here need to modify possible SQL does not require splicing parameters
		if (list == null || list.size() == 0)
			return 1;

		try
		{
			conn = _db.getConnection();
			conn.setAutoCommit(false);
			stmt = conn.prepareStatement(_sql.split(CinTextUtil.SHARP)[0]);

			// sql number
			for (int j = 0; j < list.size(); j++)
			{
				// The parameters in each SQL
				if (!idMap.isEmpty())
				{
					CinDbEntity entity = list.get(j);

					for (byte i : idMap.keySet())
					{
						Field header = entity.getClass().getField(_entity.getFieldName(idMap.get(i).byteValue()));
						if (header != null)
						{
							switch (_entity.getTypeField(idMap.get(i).byteValue()))
							{
								case VARCHAR:
									stmt.setString(i, (String) header.get(entity));
								break;
								case BIGINT:
									stmt.setLong(i, header.getLong(entity));
								break;
								case DATETIME:
									stmt.setTimestamp(i, new java.sql.Timestamp((Long) header.get(entity)));
								break;
								case INTEGER:
									stmt.setInt(i, header.getInt(entity));
								break;
								case TINYINT:
									stmt.setByte(i, header.getByte(entity));
								break;
								case DECIMAL:
									stmt.setBigDecimal(i, (BigDecimal) header.get(entity));
								break;
								case HEXSTRING:
									stmt.setString(i, bytesToHex((byte[]) header.get(entity)));
								break;
								case IPADDRESS:
									InetAddress addr = InetAddress.getByAddress((byte[]) header.get(entity));
									stmt.setString(i, addr.getHostAddress());
								break;
								case BIN:
									stmt.setBytes(i, (byte[]) header.get(entity));
								break;
								default:
									stmt.setNull(i, Types.NULL);
								break;
							}
						}
						else
							stmt.setNull(i, Types.NULL);
					}
					stmt.addBatch();
				}
			}

			int[] result = stmt.executeBatch();
			conn.commit();
			for (int t : result)
			{
				if (t == -3)
				{
					tracer.info("Deal Batch Insert/Update Error-->Roback!");
					conn.rollback();
					return 0;
				}
			}
			return 1;
		}
		catch (Exception e)
		{
			tracer.info("--Exception:", e);
			e.printStackTrace();
		}
		finally
		{
			closeSt(stmt);
			closeConn(conn);
		}
		return 0;
	}

	private PreparedStatement prepareConnStmt(byte opr, Connection conn, boolean returnGeneratedKey) throws Exception
	{
		HashMap<Byte, Field> fields = new HashMap<Byte, Field>();
		for (Field f : _entity.getClass().getFields())
		{
			FieldAttribute fa = f.getAnnotation(FieldAttribute.class);
			if (fa != null)
				fields.put(fa.idx(), f);
		}

		PreparedStatement stmt;
		if (returnGeneratedKey)
			stmt = conn.prepareStatement(_sql.split(CinTextUtil.SHARP)[0], Statement.RETURN_GENERATED_KEYS);
		else
			stmt = conn.prepareStatement(_sql.split(CinTextUtil.SHARP)[0], ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
		if (stmt.getParameterMetaData().getParameterCount() > 0)
		{
			if (!idMap.isEmpty())
			{
				if (CinUtil.isNullOrEmpty(_entity.getList()))
					_entity.addList(_entity);
				while (!_entity.getList().isEmpty())
				{
					CinDbEntity entity = _entity.getList().remove(0);

					for (byte i : idMap.keySet())
					{
						Field header = entity.getClass().getField(_entity.getFieldName(idMap.get(i).byteValue()));
						if (header != null)
						{
							switch (_entity.getTypeField(idMap.get(i).byteValue()))
							{
								case VARCHAR:
									stmt.setString(i, (String) header.get(entity));
								break;
								case BIGINT:
									stmt.setLong(i, header.getLong(entity));
								break;
								case DATETIME:
									stmt.setTimestamp(i, new java.sql.Timestamp((Long) header.get(entity)));
								break;
								case INTEGER:
									stmt.setInt(i, header.getInt(entity));
								break;
								case TINYINT:
									stmt.setByte(i, header.getByte(entity));
								break;
								case DECIMAL:
									stmt.setBigDecimal(i, (BigDecimal) header.get(entity));
								break;
								case HEXSTRING:
									stmt.setString(i, bytesToHex((byte[]) header.get(entity)));
								break;
								case IPADDRESS:
									InetAddress addr = InetAddress.getByAddress((byte[]) header.get(entity));
									stmt.setString(i, addr.getHostAddress());
								break;
								case BIN:
									stmt.setBytes(i, (byte[]) header.get(entity));
								break;
								default:
									stmt.setNull(i, Types.NULL);
								break;
							}
						}
						else
							stmt.setNull(i, Types.NULL);
					}
					if (opr == EnumDBOperation.Update)
						stmt.addBatch();
				}
			}
		}
		else
		{
			if (opr == EnumDBOperation.Update)
				stmt.addBatch();
		}
		return stmt;

	}

	private void closeConn(Connection conn)
	{
		try
		{
			if (conn != null)
				conn.close();
		}
		catch (Exception e)
		{
			tracer.error("close Database connection failed", e);
		}
	}

	private void closeStmt(PreparedStatement stmt)
	{
		try
		{
			if (stmt != null)
				stmt.close();
		}
		catch (Exception e)
		{
			tracer.error("close Database Statement failed", e);
		}
	}

	private void closeSt(java.sql.Statement st)
	{
		try
		{
			if (st != null)
				st.close();
		}
		catch (Exception e)
		{
			tracer.error("close Database Statement failed", e);
		}
	}

	private void closeResultSet(ResultSet rs)
	{
		try
		{
			if (rs != null)
				rs.close();
		}
		catch (Exception e)
		{
			tracer.error("close Resultset failed", e);
		}
	}

	private String bytesToHex(byte[] data)
	{
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < data.length; i++)
		{
			int num = Integer.valueOf(byteToBits(data[i]), 2);
			if (num < 16)
			{
				sb.append("0" + Integer.toHexString(num));
			}
			else
			{
				sb.append(Integer.toHexString(num));
			}
		}

		return sb.toString();
	}

	private String byteToBits(byte b)
	{
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < 8; i++)
			buf.append((int) (b >> (8 - (i + 1)) & 0x0001));
		return buf.toString();
	}
}
