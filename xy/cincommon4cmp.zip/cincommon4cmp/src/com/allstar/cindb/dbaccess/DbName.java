package com.allstar.cindb.dbaccess;

import java.lang.reflect.Field;
import java.util.HashMap;

/**
 * The name of the database
 * 
 * 
 */
public class DbName
{
	public static final String FETIONCHAT = "urapport";
	public static final String CONFIG = "urapport_config";

	private static HashMap<String, Byte> _map;
	static
	{
		try
		{
			Class<?> headertype = Class.forName(DbName.class.getCanonicalName());
			Field[] fields = headertype.getFields();
			_map = new HashMap<String, Byte>();

			for (byte b = 0; b < fields.length; b++)
				_map.put(fields[b].getName(), b);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public static byte get(String type)
	{
		return _map.get(type);
	}
}
