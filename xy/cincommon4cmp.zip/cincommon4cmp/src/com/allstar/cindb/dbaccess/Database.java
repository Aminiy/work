package com.allstar.cindb.dbaccess;

import java.sql.Connection;
import java.util.List;

import com.allstar.cindb.CinDbEntity;
import com.allstar.cindb.config.ConfigDbConfig;
import com.allstar.cindb.config.DbConfig;
import com.mchange.v2.c3p0.ComboPooledDataSource;

/**
 * Class for DataBase
 * 
 * 
 */
public class Database
{
	private ComboPooledDataSource dataSource;

	public Database(String dbName) throws Exception
	{
		dataSource = new ComboPooledDataSource();
		setDefaultDbSetting();
		if (dbName.equals(DbName.CONFIG))
			setConfigDbSetting();
		else
			setDbConfig();
	}

	/**
	 * Access to the database operation object
	 * 
	 * @param cinDbEntity
	 * @return Instance of DatabaseOperation for database operation
	 * @throws Exception
	 */
	public DatabaseOperation getDbAccess(CinDbEntity cinDbEntity) throws Exception
	{
		return new DatabaseOperation(cinDbEntity, this);
	}

	public DatabaseOperationMulti getDbAccessMulti(List<CinDbEntity> _entities)
	{
		return new DatabaseOperationMulti(_entities, this);
	}

	/**
	 * Access to the database connection object, including the database
	 * connection string, username, password, and other parameters
	 * 
	 * @return A database connection maintained by c3p0
	 * @throws Exception
	 */
	public Connection getConnection() throws Exception
	{
		return dataSource.getConnection();
	}

	private void setDefaultDbSetting() throws Exception
	{
		dataSource.setDriverClass(DbConfig.driverClass);
		dataSource.setAcquireIncrement(DbConfig.acquireIncrement);
		dataSource.setIdleConnectionTestPeriod(DbConfig.idleConnectionTestPeriod);
		dataSource.setMaxIdleTime(DbConfig.maxIdleTime);
		dataSource.setMaxConnectionAge(DbConfig.maxConnectionAge);

		dataSource.setMaxStatements(DbConfig.maxStatements);
		dataSource.setMaxStatementsPerConnection(DbConfig.maxStatementsPerConnection);
		dataSource.setNumHelperThreads(DbConfig.numHelperThreads);
		dataSource.setMaxAdministrativeTaskTime(DbConfig.maxAdministrativeTaskTime);
		dataSource.setAcquireRetryAttempts(DbConfig.acquireRetryAttempts);

		dataSource.setAcquireRetryDelay(DbConfig.acquireRetryDelay);
		dataSource.setAutoCommitOnClose(DbConfig.autoCommitOnClose);
		dataSource.setPreferredTestQuery(DbConfig.preferredTestQuery);
		dataSource.setBreakAfterAcquireFailure(DbConfig.breakAfterAcquireFailure);
		dataSource.setCheckoutTimeout(DbConfig.checkoutTimeout);

		dataSource.setForceIgnoreUnresolvedTransactions(DbConfig.forceIgnoreUnresolvedTransactions);
		dataSource.setPropertyCycle(DbConfig.propertyCycle);
		dataSource.setTestConnectionOnCheckout(DbConfig.testConnectionOnCheckout);
		dataSource.setTestConnectionOnCheckin(DbConfig.testConnectionOnCheckin);
		dataSource.setUsesTraditionalReflectiveProxies(DbConfig.usesTraditionalReflectiveProxies);
	}

	private void setDbConfig() throws Exception
	{
		DbConfig.initialize();

		dataSource.setJdbcUrl(DbConfig.jdbcUrl);
		dataSource.setUser(DbConfig.user);
		dataSource.setPassword(DbConfig.password);
		dataSource.setMaxPoolSize(DbConfig.maxPoolSize);
		dataSource.setMinPoolSize(DbConfig.minPoolSize);
	}

	private void setConfigDbSetting() throws Exception
	{
		ConfigDbConfig.initialize();

		dataSource.setJdbcUrl(ConfigDbConfig.jdbcUrl);
		dataSource.setUser(ConfigDbConfig.user);
		dataSource.setPassword(ConfigDbConfig.password);
		dataSource.setMaxPoolSize(ConfigDbConfig.maxPoolSize);
		dataSource.setMinPoolSize(ConfigDbConfig.minPoolSize);
	}
}
