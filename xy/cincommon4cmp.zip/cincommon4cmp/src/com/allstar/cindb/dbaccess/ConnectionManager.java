/**
 * 
 */
package com.allstar.cindb.dbaccess;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.SQLException;

import com.allstar.cindb.config.DbConfig;
import com.allstar.cintracer.CinTracer;
import com.mchange.v2.c3p0.ComboPooledDataSource;

/**
 * The connection to the database maintenance class
 * 
 * 
 */
public class ConnectionManager
{

	private static ConnectionManager instance;

	private static ComboPooledDataSource dataSource;

	private static CinTracer tracer = CinTracer.getInstance(ConnectionManager.class);

	/**
	 * 
	 * @throws Exception
	 */
	private ConnectionManager() throws Exception
	{

	}

	public static synchronized ConnectionManager getInstance()
	{
		if (instance == null)
		{
			try
			{
				instance = new ConnectionManager();
			}
			catch (Exception e)
			{
				tracer.error("ConnectionManager getInstance()", e);
			}
		}
		return instance;
	}

	public ComboPooledDataSource initialize() throws Exception
	{
		try
		{
			if (dataSource == null)
			{
				DbConfig.initialize();

				dataSource = new ComboPooledDataSource();

				this.setDefaultDbSetting(dataSource);

				dataSource.setJdbcUrl(DbConfig.jdbcUrl);
				dataSource.setUser(DbConfig.user);
				dataSource.setPassword(DbConfig.password);
				dataSource.setMaxPoolSize(DbConfig.maxPoolSize);
				dataSource.setMinPoolSize(DbConfig.minPoolSize);
			}
		}
		catch (Exception e)
		{
			tracer.error("ConnectionManager initialize()", e);
			throw e;
		}
		return dataSource;
	}

	/**
	 * Give datasouce set configuration (default configuration)
	 * 
	 * @param dataSource
	 * @throws PropertyVetoException
	 */
	private void setDefaultDbSetting(ComboPooledDataSource dataSource) throws PropertyVetoException
	{
		dataSource.setDriverClass(DbConfig.driverClass);
		dataSource.setAcquireIncrement(DbConfig.acquireIncrement);
		dataSource.setIdleConnectionTestPeriod(DbConfig.idleConnectionTestPeriod);
		dataSource.setMaxIdleTime(DbConfig.maxIdleTime);
		dataSource.setMaxConnectionAge(DbConfig.maxConnectionAge);

		dataSource.setMaxStatements(DbConfig.maxStatements);
		dataSource.setMaxStatementsPerConnection(DbConfig.maxStatementsPerConnection);
		dataSource.setNumHelperThreads(DbConfig.numHelperThreads);
		dataSource.setMaxAdministrativeTaskTime(DbConfig.maxAdministrativeTaskTime);
		dataSource.setAcquireRetryAttempts(DbConfig.acquireRetryAttempts);

		dataSource.setAcquireRetryDelay(DbConfig.acquireRetryDelay);
		dataSource.setAutoCommitOnClose(DbConfig.autoCommitOnClose);
		dataSource.setPreferredTestQuery(DbConfig.preferredTestQuery);
		dataSource.setBreakAfterAcquireFailure(DbConfig.breakAfterAcquireFailure);
		dataSource.setCheckoutTimeout(DbConfig.checkoutTimeout);

		dataSource.setForceIgnoreUnresolvedTransactions(DbConfig.forceIgnoreUnresolvedTransactions);
		dataSource.setPropertyCycle(DbConfig.propertyCycle);
		dataSource.setTestConnectionOnCheckout(DbConfig.testConnectionOnCheckout);
		dataSource.setTestConnectionOnCheckin(DbConfig.testConnectionOnCheckin);
		dataSource.setUsesTraditionalReflectiveProxies(DbConfig.usesTraditionalReflectiveProxies);

	}

	public static Connection getConnection()
	{

		Connection conn = null;
		if (dataSource != null)
		{
			try
			{
				conn = dataSource.getConnection();
			}
			catch (SQLException e)
			{
				tracer.error("ConnectionManager getConnection()", e);
			}
		}
		return conn;
	}
}
