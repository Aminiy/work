package com.allstar.cindb.dbaccess;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.allstar.cindb.CinDbEntity;
import com.allstar.cindb.annotation.FieldAttribute;
import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinTextUtil;
import com.mysql.jdbc.Statement;

/**
 * Database operations class
 * 
 * 
 */
public class DatabaseOperationMulti {
	private static CinTracer tracer = CinTracer
			.getInstance(DatabaseOperationMulti.class);
	private List<String> _sql;
	HashMap<String, HashMap<Byte, Byte>> idMap = new HashMap<String, HashMap<Byte, Byte>>();
	private List<CinDbEntity> _entities;
	private Database _db;

	/**
	 * The constructor
	 * 
	 * @param entities
	 * @param db
	 */
	public DatabaseOperationMulti(List<CinDbEntity> entities, Database db) {
		_db = db;
		_entities = entities;
		_sql = new ArrayList<String>();
		for (CinDbEntity e : entities) {
			_sql.add(e.getSqlName());

			if (!e.getSqlName().contains(CinTextUtil.SHARP))
				continue;
			if (idMap.containsKey(e.getSqlName()))
				continue;
			String[] params = e.getSqlName().trim().split(CinTextUtil.SHARP)[1]
					.split(CinTextUtil.Comma);
			idMap.put(e.getSqlName(), new HashMap<Byte, Byte>());
			for (int i = 0; i < params.length; i++) {
				byte id = e.getIdField(params[i].trim());
				idMap.get(e.getSqlName()).put((byte) (i + 1), id);
			}
		}
	}

	/**
	 * To perform the update or Insert operations, and returns the affected rows
	 * 
	 * @return
	 * @throws Exception
	 */
	public int update() throws Exception {
		return 1;
		// TODO Use to add at present can't see the application scenario
		// Connection conn = null;
		// PreparedStatement stmt = null;
		// try
		// {
		// conn = _db.getConnection();
		// conn.setAutoCommit(false);
		// stmt = prepareConnStmt(conn, false);
		// int ret = stmt.executeBatch()[0];
		// conn.commit();
		// return ret;
		// }
		// catch (Exception e)
		// {
		// tracer.error("insert/update/delete from db failed " + _sql, e);
		// try
		// {
		// conn.rollback();
		// }
		// catch (SQLException e1)
		// {
		// tracer.error("rollback failed", e);
		// }
		// throw e;
		// }
		// finally
		// {
		// closeConn(conn);
		// closeStmt(stmt);
		// }
	}

	/**
	 * An Insert operation, and returns on the ID
	 * 
	 * @return
	 * @throws Exception
	 */
	public long[] updateReturnKeys() throws Exception {
		Connection conn = null;
		long ret = -1;
		List<PreparedStatement> stmtlist = new ArrayList<PreparedStatement>();
		long[] arrayLong = new long[_entities.size()];
		try {
			PreparedStatement stmt = null;
			conn = _db.getConnection();
			conn.setAutoCommit(false);
			for (int i = 0; i < _entities.size(); i++) {
				CinDbEntity e = _entities.get(i);
				stmt = prepareConnStmt(conn, e, true);
				stmtlist.add(stmt);
				stmt.executeBatch();
				ResultSet rs = stmt.getGeneratedKeys();
				rs.next();
				if (rs.getRow() > 0)
				{
					ret = rs.getLong(1);
					arrayLong[i] = ret;
				}
				else
				{
					arrayLong[i] = 0;
				}
			}
			conn.commit();
			return arrayLong;
		} catch (Exception e) {
			tracer.error("insert/update/delete from db failed Return Keys "
					+ _sql, e);
			try {
				conn.rollback();
			} catch (SQLException e1) {
				tracer.error("rollback return Keys failed", e);
			}
			throw e;
		} finally {
			closeConn(conn);
			for (PreparedStatement p : stmtlist)
				closeStmt(p);
		}
	}

	private PreparedStatement prepareConnStmt(Connection conn, CinDbEntity ent,
			boolean returnGeneratedKey) throws Exception {
		HashMap<Byte, Field> fields = new HashMap<Byte, Field>();
		for (Field f : ent.getClass().getFields()) {
			FieldAttribute fa = f.getAnnotation(FieldAttribute.class);
			if (fa != null)
				fields.put(fa.idx(), f);
		}
		PreparedStatement stmt;
		if (returnGeneratedKey)
			stmt = conn.prepareStatement(
					ent.getSqlName().split(CinTextUtil.SHARP)[0],
					Statement.RETURN_GENERATED_KEYS);
		else
			stmt = conn.prepareStatement(
					ent.getSqlName().split(CinTextUtil.SHARP)[0],
					ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
		if (stmt.getParameterMetaData().getParameterCount() > 0) {
			if (idMap.containsKey(ent.getSqlName())) {

				for (byte i : idMap.get(ent.getSqlName()).keySet()) {
					Field header = ent.getClass().getField(
							ent.getFieldName(idMap.get(ent.getSqlName()).get(i)
									.byteValue()));
					if (header != null) {
						switch (ent.getTypeField(idMap.get(ent.getSqlName())
								.get(i).byteValue())) {
						case VARCHAR:
							stmt.setString(i, (String) header.get(ent));
							break;
						case BIGINT:
							stmt.setLong(i, header.getLong(ent));
							break;
						case DATETIME:
							stmt.setTimestamp(i, new java.sql.Timestamp(
									(Long) header.get(ent)));
							break;
						case INTEGER:
							stmt.setInt(i, header.getInt(ent));
							break;
						case TINYINT:
							stmt.setByte(i, header.getByte(ent));
							break;
						case DECIMAL:
							stmt.setBigDecimal(i, (BigDecimal) header.get(ent));
							break;
						case HEXSTRING:
							stmt.setString(i,
									bytesToHex((byte[]) header.get(ent)));
							break;
						case IPADDRESS:
							InetAddress addr = InetAddress
									.getByAddress((byte[]) header.get(ent));
							stmt.setString(i, addr.getHostAddress());
							break;
						case BIN:
							stmt.setBytes(i, (byte[]) header.get(ent));
							break;
						default:
							stmt.setNull(i, Types.NULL);
							break;
						}
					} else
						stmt.setNull(i, Types.NULL);
				}
				stmt.addBatch();

			}
		} else {
			stmt.addBatch();
		}
		return stmt;
	}

	private void closeConn(Connection conn) {
		try {
			if (conn != null)
				conn.close();
		} catch (Exception e) {
			tracer.error("close Database connection failed", e);
		}
	}

	private void closeStmt(PreparedStatement stmt) {
		try {
			if (stmt != null)
				stmt.close();
		} catch (Exception e) {
			tracer.error("close Database Statement failed", e);
		}
	}

	private String bytesToHex(byte[] data) {
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < data.length; i++) {
			int num = Integer.valueOf(byteToBits(data[i]), 2);
			if (num < 16) {
				sb.append("0" + Integer.toHexString(num));
			} else {
				sb.append(Integer.toHexString(num));
			}
		}

		return sb.toString();
	}

	private String byteToBits(byte b) {
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < 8; i++)
			buf.append((int) (b >> (8 - (i + 1)) & 0x0001));
		return buf.toString();
	}
}
