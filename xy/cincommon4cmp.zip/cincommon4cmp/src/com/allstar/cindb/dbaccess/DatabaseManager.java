package com.allstar.cindb.dbaccess;

import java.util.Hashtable;

import com.allstar.cintracer.CinTracer;

/**
 * Database management class
 * 
 * 
 */
public class DatabaseManager
{
	/**
	 * The singleton
	 */
	private static CinTracer tracer = CinTracer.getInstance(Database.class);

	private static Hashtable<String, Database> databases = new Hashtable<String, Database>();

	/**
	 * Access to database objects
	 * 
	 * @param dbName
	 * @return Instance of a database
	 * @see com.allstar.cindb.dbaccess.Database
	 */
	public static Database getDatabase(String dbName)
	{
		Database db = databases.get(dbName);
		if (db == null)
		{
			synchronized (DatabaseManager.class)
			{
				db = databases.get(dbName);
				if (db == null)
				{
					try
					{
						db = new Database(dbName);
					}
					catch (Exception e)
					{
						tracer.error("Database can't been initialized with dbname : " + dbName);
						throw new IllegalArgumentException("Datbase initialize failed", e);
					}
					databases.put(dbName, db);
				}
			}
		}
		return db;
	}
}
