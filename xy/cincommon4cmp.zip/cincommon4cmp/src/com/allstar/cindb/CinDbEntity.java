package com.allstar.cindb;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.allstar.cindb.annotation.FieldAttribute;
import com.allstar.cindb.annotation.TableAttribute;
import com.allstar.cindb.config.TableFieldType;
import com.allstar.cindb.dbaccess.DatabaseManager;
import com.allstar.cindb.dbaccess.DatabaseOperation;
import com.allstar.cindb.dbaccess.DatabaseOperationMulti;

/**
 * A database object abstract classes
 * 
 * 
 */
public abstract class CinDbEntity
{
	boolean _replacetablename;
	String _tablenameReplacement;
	String _sql;
	String _tablename = getClass().getAnnotation(TableAttribute.class).tablename();
	String _dbname = getClass().getAnnotation(TableAttribute.class).dbname();

	List<CinDbEntity> _list = new ArrayList<CinDbEntity>();

	private static HashMap<String, HashMap<Byte, TableFieldType>> _typemap = new HashMap<String, HashMap<Byte, TableFieldType>>();
	private static HashMap<String, HashMap<String, Byte>> _namemap = new HashMap<String, HashMap<String, Byte>>();
	private static HashMap<String, HashMap<Byte, String>> _idmap = new HashMap<String, HashMap<Byte, String>>();
	private static HashMap<String, Class<? extends CinDbEntity>> _entitylist = new HashMap<String, Class<? extends CinDbEntity>>();

	/**
	 * For the mapping relationship between entity class
	 * 
	 * @return Relation between table name and class
	 */
	public static HashMap<String, Class<? extends CinDbEntity>> getEntities()
	{
		return _entitylist;
	}

	/**
	 * To initialize the database entity class
	 * 
	 * @param entites
	 */
	@SuppressWarnings("unchecked")
	public static void initialize(Class<? extends CinDbEntity>... entites)
	{
		for (Class<? extends CinDbEntity> e : entites)
		{
			_entitylist.put(e.getSimpleName(), e);
			String tablename = e.getAnnotation(TableAttribute.class).tablename();
			_typemap.put(tablename, new HashMap<Byte, TableFieldType>());
			_namemap.put(tablename, new HashMap<String, Byte>());
			_idmap.put(tablename, new HashMap<Byte, String>());
			for (Field f : e.getFields())
			{
				FieldAttribute fa = f.getAnnotation(FieldAttribute.class);
				if (fa != null)
				{
					_typemap.get(tablename).put(fa.idx(), fa.type());
					_namemap.get(tablename).put(f.getName(), fa.idx());
					_idmap.get(tablename).put(fa.idx(), f.getName());
				}
			}
		}
	}

	/**
	 * Obtain corresponding database table name entity class
	 * 
	 * @return
	 */
	public String getTableName()
	{
		return _tablename;
	}

	/**
	 * Get the number of fields in entity class
	 * 
	 * @return
	 */
	public int getFieldCount()
	{
		return _typemap.get(_tablename).size();
	}

	/**
	 * Through parameter acquisition to the field string describing the field
	 * corresponds to the serial number
	 * 
	 * @param field
	 * @return
	 */
	public byte getIdField(String field)
	{
		return _namemap.get(_tablename).get(field);
	}

	/**
	 * Through parameter fields in the serial number for a string description of
	 * the to field
	 * 
	 * @param id
	 * @return
	 */
	public String getFieldName(byte id)
	{
		return _idmap.get(_tablename).get(id);
	}

	/**
	 * Through the parameters of the serial number to obtain to the field of
	 * data types
	 * 
	 * @see com.allstar.cindb.config.TableFieldType
	 * @param type
	 * @return
	 */
	public TableFieldType getTypeField(byte type)
	{
		return _typemap.get(_tablename).get(type);
	}

	/**
	 * Access to the database operation object
	 * 
	 * @return
	 * @throws Exception
	 */
	protected DatabaseOperation getDbOperation() throws Exception
	{
		return DatabaseManager.getDatabase(_dbname).getDbAccess(this);
	}

	protected DatabaseOperationMulti getDbOperationMulti()
	{
		return DatabaseManager.getDatabase(_dbname).getDbAccessMulti(_list);
	}

	/**
	 * Access to the entity class object in the SQL database operation
	 * 
	 * @return
	 */
	public String getSqlName()
	{
		return _sql;
	}

	/**
	 * Set the entity class object is the SQL database operation
	 * 
	 */
	public void setSqlName(String sql)
	{
		_sql = sql;
	}

	/**
	 * The SQL execution parameters, we get the returned data set and wrap into
	 * entity class object list
	 * 
	 * @param sql
	 * @return
	 * @throws Exception
	 */
	protected <T extends CinDbEntity> List<T> queryList(String sql) throws Exception
	{
		_sql = sql;
		List<T> list = getDbOperation().selectList();
		return list;
	}

	/**
	 * The SQL execution parameters, get back to a single data set
	 * 
	 * @param sql
	 * @return instance of class which extends CinDbEntity
	 * @throws Exception
	 */
	protected <T extends CinDbEntity> T queryObject(String sql) throws Exception
	{
		_sql = sql;
		return getDbOperation().select();
	}

	/**
	 * The SQL execution parameters and returns the number of rows. Can be used
	 * for internal service use only
	 * 
	 * @param sql
	 * @return
	 * @throws Exception
	 */
	protected int excute(String sql) throws Exception
	{
		_sql = sql;
		return getDbOperation().update();
	}

	/**
	 * match contact only for UIDC
	 * @param spName
	 * @param params
	 * @param values
	 * @return return userId if success
	 * @throws Exception
	 */
	@Deprecated
	protected long spMatchContact(String[] params, Object... values) throws Exception
	{
		return getDbOperation().spMatchContact(params, values);
	}
	
	/**
	 * Failure returns 1 if the tasks, if successfully returns returns the
	 * database to the last a new insert data generated on the ID
	 * 
	 * @return
	 * @throws Exception
	 */
	protected long[] excuteBatchAndReturnKeys() throws Exception
	{
		return getDbOperationMulti().updateReturnKeys();
		// return getDbOperation().updateBatchReturnKeys(sqls);
	}

	/**
	 * one SQL execute many times.
	 * 
	 * @param sql
	 *            like insert into tablename(a,b,c)values(?,?,?)#a,b,c
	 * @param list
	 *            sql's params
	 * @return
	 * @throws Exception
	 */
	protected int executeBatch(String sql, List<CinDbEntity> list) throws Exception
	{
		_sql = sql;
		return getDbOperation().executeBatch(list);
	}

	/**
	 * Perform the insert operation parameters, and returns the database for the
	 * newly inserted data generated from the ID
	 * 
	 * @param sql
	 * @return
	 * @throws Exception
	 */
	protected long insertAndReturnKeys(String sql) throws Exception
	{
		_sql = sql;
		return getDbOperation().updateReturnKeys();
	}

	/**
	 * To obtain a list entity class object
	 */
	@SuppressWarnings("unchecked")
	public <T extends CinDbEntity> List<T> getList()
	{
		return (List<T>) _list;
	}

	/**
	 * An entity class object added to the list, it is mainly used for batch
	 * insert opration
	 * 
	 * @param entity
	 */
	public <T extends CinDbEntity> void addList(T entity)
	{
		_list.add(entity);
	}
}
