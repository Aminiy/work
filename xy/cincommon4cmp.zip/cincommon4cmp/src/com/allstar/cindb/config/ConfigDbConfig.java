package com.allstar.cindb.config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.allstar.cintracer.CinTracer;
import com.allstar.crypto.CinBase64;

public class ConfigDbConfig extends DbConfig
{
	private static CinTracer tracer = CinTracer.getInstance(ConfigDbConfig.class);

	public static String user;
	public static String password;
	public static String jdbcUrl;
	public static int maxPoolSize;
	public static int minPoolSize;

	/**
	 * Special database configuration, cincenter use.Can only read the initial
	 * configuration from the configuration file
	 */
	ConfigDbConfig()
	{
	}

	public static void initialize() throws Exception
	{
		tracer.special("ConfigDbConfig setValues start!");

		FileInputStream fis = null;
		try
		{
			fis = new FileInputStream("dbconfig.properties");
			Properties properties = new Properties();
			properties.load(fis);
			user = properties.getProperty("username");
			password = properties.getProperty("password");

			user = new String(CinBase64.decode(user.substring(1)));
			password = new String(CinBase64.decode(password.substring(1)));

			jdbcUrl = properties.getProperty("url");
			maxPoolSize = Integer.valueOf(properties.getProperty("maxpoolsize"));
			minPoolSize = Integer.valueOf(properties.getProperty("minpoolsize"));

			tracer.special("ConfigDbConfig setValues end!");
		}
		catch (FileNotFoundException e1)
		{
			tracer.error("NO such file ", e1);
		}
		catch (IOException e)
		{
			tracer.error("IO Exception ", e);
		}
		finally
		{
			try
			{
				fis.close();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
