package com.allstar.cindb.config;

import java.util.HashMap;

public enum TableFieldType
{
	BIGINT((String) "BIGINT"), INTEGER((String) "INTEGER"), TINYINT((String) "TINYINT"), VARCHAR((String) "VARCHAR"), DATETIME((String) "DATETIME"), HEXSTRING((String) "HEXSTRING"), IPADDRESS((String) "IPADDRESS"), BIN((String) "BIN"), DECIMAL((String) "DECIMAL");

	private String value;
	private static HashMap<String, TableFieldType> _map;
	static
	{
		_map = new HashMap<String, TableFieldType>();
		for (TableFieldType t : TableFieldType.values())
			_map.put(t.getValue(), t);
	}

	TableFieldType(String value)
	{
		this.setValue(value);
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(String value)
	{
		this.value = value;
	}

	/**
	 * @return the value
	 */
	public String getValue()
	{
		return value;
	}

	public static TableFieldType get(String type)
	{
		TableFieldType t = _map.get(type);
		if (t == null)
			return VARCHAR;
		else
			return t;
	}
}
