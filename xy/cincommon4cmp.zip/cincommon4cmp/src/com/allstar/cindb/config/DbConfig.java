package com.allstar.cindb.config;

import com.allstar.cinconfig.CinConfigEntity;
import com.allstar.cinconfig.CinConfigInterface;
import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinConvert;
import com.allstar.crypto.AES;
import com.allstar.crypto.CinBase64;

public class DbConfig extends CinConfigInterface
{
	private static final CinTracer LOGGER = CinTracer.getInstance(DbConfig.class);
	
	private static CinConfigInterface _instance;

	public static String driverClass = "com.mysql.jdbc.Driver";
	public static int acquireIncrement = 5;
	public static int idleConnectionTestPeriod = 60;
	public static int maxIdleTime = 600;
	public static int maxConnectionAge = 0;

	public static int maxStatements = 2000;
	public static int maxStatementsPerConnection = 300;
	public static int numHelperThreads = 20;
	public static int maxAdministrativeTaskTime = 30;
	public static int acquireRetryAttempts = 30;

	public static int acquireRetryDelay = 1000;
	public static boolean autoCommitOnClose = false;
	public static String preferredTestQuery = "select 1";
	public static boolean breakAfterAcquireFailure = false;
	public static int checkoutTimeout = 30000;

	public static boolean forceIgnoreUnresolvedTransactions = false;
	public static int propertyCycle = 300;
	public static boolean testConnectionOnCheckout = false;
	public static boolean testConnectionOnCheckin = false;
	public static boolean usesTraditionalReflectiveProxies = false;

	public static String user;
	public static String password;
	public static String jdbcUrl;
	public static int maxPoolSize;
	public static int minPoolSize;

	DbConfig()
	{
		_tableName = "DbSetting";
	}

	public static void initialize() throws Exception
	{
		if (_instance == null)
		{
			_instance = new DbConfig();
			_instance.updateConfig();
		}
	}

	@Override
	protected void setValues(CinConfigEntity config)
	{
		user = config.get("user");
		/* Decryption of DB password */
		byte[] passwordInBytes = CinBase64.decode(config.get("password"));
		byte[] key = CinConvert.hexToBytes(config.get("AESKey"));
		password = AES.decrypt(passwordInBytes, key);
		LOGGER.info("Password:" + password);
		jdbcUrl = config.get("jdbcUrl");
		maxPoolSize = Integer.parseInt(config.get("maxPoolSize"));
		minPoolSize = Integer.parseInt(config.get("minPoolSize"));
	}
}
