package com.allstar.cinlogger;

import com.allstar.cinstack.message.CinMessage;

/**
 * Business log interface </br> 
 * Business log data in the service side and encapsulate CinMessage and specify the TableName,Send to LogCenter,</br>
 * LogCenter according to the configuration of the TableName and LogCenter SqlTable CinMessage parsing and map into a field in a database table
 * ,Then insert operation
 * 
 * 
 */
public interface CinLoggerIObject
{
	public CinMessage toMessage();

	public String TableName();
}
