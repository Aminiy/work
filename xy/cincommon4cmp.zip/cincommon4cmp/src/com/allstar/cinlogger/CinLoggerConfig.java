package com.allstar.cinlogger;

import com.allstar.cinconfig.CinConfigEntity;
import com.allstar.cinconfig.CinConfigInterface;

/**
 * Business log configuration class
 * 
 * 
 */
public class CinLoggerConfig extends CinConfigInterface
{

	private static Integer IdleTime = 4000;
	private static Integer MaxQueueSize = 1024;

	private static CinConfigInterface _instance;

	CinLoggerConfig()
	{
		_tableName = "CinLogger";
	}

	/**
	 * initialize
	 */
	public static void initialize()
	{
		if (_instance == null)
		{
			_instance = new CinLoggerConfig();
			_instance.updateConfig();
		}
	}

	@Override
	protected void setValues(CinConfigEntity config)
	{
		try
		{
			IdleTime = Integer.valueOf(config.get("IdleTime", "4000"));
			MaxQueueSize = Integer.valueOf(config.get("MaxQueueSize", "1024"));
		}
		catch (Exception e)
		{
			IdleTime = 4000;
			MaxQueueSize = 1024;
		}
	}

	/**
	 * The thread of dormancy interval
	 * 
	 * @return
	 */
	public static Integer IdleTime()
	{
		return IdleTime;
	}

	/**
	 * To get business log queue maximum length
	 * 
	 * @return
	 */
	public static Integer MaxQueueSize()
	{
		return MaxQueueSize;
	}
}
