package com.allstar.cinlogger;

import com.allstar.cinconfig.CinConfigure;
import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.handler.codec.CinEncoder;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionEvent;
import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinLinkedList;
import com.allstar.cinutil.CinLinkedNode;

/**
 * Business log class
 * 
 * 
 */
public class CinLogger extends Thread
{
	private static CinLogger _logger = null;
	private static CinTracer tracer = CinTracer.getInstance(CinLogger.class);

	private static CinLinkedList<CinLoggerIObject> _list = null;

	/**
	 * Access to the singleton
	 * 
	 * @return Singleton instance of CinLogger
	 */
	public synchronized static CinLogger getInstance()
	{
		if (_logger == null)
			_logger = new CinLogger();
		return _logger;
	}

	private CinLogger()
	{
		CinLoggerConfig.initialize();
		_list = new CinLinkedList<CinLoggerIObject>();
		if (!this.isAlive())
		{
			this.setDaemon(true);
			this.setName("Business logger thread");
			this.start();
		}
	}

	/**
	 * Send Logger Object to LogCenter
	 * 
	 * @param obj
	 */
	public void send(CinLoggerIObject obj)
	{
		try
		{
			if (CinStack.instance() == null)
			{
				addList(obj);
				return;
			}
			CinRequest req = new CinRequest(CinRequestMethod.Log);
			req.addHeader(new CinHeader(CinHeaderType.Name, obj.TableName()));
			req.addHeader(new CinHeader(CinHeaderType.Key, CinConfigure.serviceName + CinConfigure.computerName));
			req.addBody(CinEncoder.toBytes(obj.toMessage()));
			CinRouter.setRoute(req, CinServiceName.LogCenter);
			CinTransaction trans = CinStack.instance().createTransaction(req);
			trans.setAttachment(obj);
			trans.Event = new CinTransactionEvent() {

				@Override
				public void onRequestSentTimeout(CinTransaction trans)
				{
					addList((CinLoggerIObject) trans.getAttachment());
					tracer.warn("CinLogger.getInstance().send(OBJ).onTimeout()", trans.getRequest());
				}

				@Override
				public void onRequestSentFailed(CinTransaction trans)
				{
					addList((CinLoggerIObject) trans.getAttachment());
					tracer.warn("CinLogger.getInstance().send(OBJ).onSendFailed()", trans.getRequest());
				}

				@Override
				public void onResponseReceived(CinTransaction trans)
				{
					CinResponse response = trans.getResponse();
					if (!response.isResponseCode(CinResponseCode.OK))
					{
						addList((CinLoggerIObject) trans.getAttachment());
						tracer.warn("CinLogger.getInstance().send(OBJ).onResponseReceived(Is Not OK)", trans.getRequest());
					}
				}
			};
			trans.sendRequest();
		}
		catch (Exception e)
		{
			tracer.error("CinLogger send error", e);
		}
	}

	private synchronized void addList(CinLoggerIObject obj)
	{
		if (_list.length() < CinLoggerConfig.MaxQueueSize())
		{
			_list.put(obj);
			if (tracer.WarnTrace())
				tracer.warn("CinLogger.addList(), list Length: " + _list.length(), obj.toMessage());
		}
		else
		{
			if (tracer.WarnTrace())
				tracer.warn("CinLogger.addList() Out of MaxQueueSize, list Length: " + _list.length(), obj.toMessage());
		}
	}

	@Override
	public void run()
	{
		while (true)
		{
			try
			{
				if (_list.length() == 0)
				{
					Thread.sleep(CinLoggerConfig.IdleTime());
				}
				else
				{
					_list.moveToHead();

					for (int i = 0; i < _list.length(); i++)
					{
						CinLinkedNode<CinLoggerIObject> node = _list.takeAwayFirst();
						if (node == null)
							break;
						send(node.object());
					}
				}
			}
			catch (Exception ex)
			{
				tracer.warn("CinLogger.run()", ex);
			}
		}
	}
}
