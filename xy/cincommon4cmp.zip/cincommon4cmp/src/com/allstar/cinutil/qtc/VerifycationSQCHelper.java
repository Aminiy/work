package com.allstar.cinutil.qtc;

import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionEvent;
import com.allstar.cintracer.CinTracer;
import com.allstar.event.CinInnerServiceEvent;

public class VerifycationSQCHelper implements CinTransactionEvent {
	private static VerifycationSQCHelper _instance;

	private VerifycationSQCHelper() {
	}

	public static VerifycationSQCHelper getInstance() {
		if (_instance == null)
			return new VerifycationSQCHelper();
		return _instance;
	}

	/**
	 * SMS quota check
	 * 
	 * @param userId
	 * @param event
	 */
	public void checkSMSSQCCounter(long userId, VerifycationSQCResult event) {
		CinRequest request = new CinRequest(CinRequestMethod.InnerService);
		request.addHeader(new CinHeader(CinHeaderType.From, userId));
		request.addHeader(new CinHeader(CinHeaderType.Event, CinInnerServiceEvent.SMSSQCCheck));
		request.addHeader(new CinHeader(CinHeaderType.Type, VerifycationSQCType.SQC_INCREMENT));
		// CinRouter.setRoute(request, CinServiceName.QuotaCenter);
		CinTransaction tran = CinStack.instance().createTransaction(request);
		tran.setAttachment(event);
		tran.Event = this;
		tran.sendRequest();
	}

	/**
	 * Removal of SMS quota data
	 * 
	 * @param userId
	 * @param event
	 */
	public void clearSMSSQCCounter(long userId, VerifycationSQCResult event) {
		CinRequest request = new CinRequest(CinRequestMethod.InnerService);
		request.addHeader(new CinHeader(CinHeaderType.From, userId));
		request.addHeader(new CinHeader(CinHeaderType.Event, CinInnerServiceEvent.SMSSQCCheck));
		request.addHeader(new CinHeader(CinHeaderType.Type, VerifycationSQCType.SQC_CLEAR));
		// CinRouter.setRoute(request, CinServiceName.QuotaCenter);
		CinTransaction tran = CinStack.instance().createTransaction(request);
		tran.setAttachment(event);
		tran.Event = this;
		tran.sendRequest();
	}

	/**
	 * Monthly quota remaining query messages
	 * 
	 * @param userId
	 * @param event
	 */
	public void querySMSLeftQuota(long userId, VerifycationSQCResult event) {
		CinRequest request = new CinRequest(CinRequestMethod.InnerService);
		request.addHeader(new CinHeader(CinHeaderType.From, userId));
		request.addHeader(new CinHeader(CinHeaderType.Event, CinInnerServiceEvent.SMSSQCCheck));
		request.addHeader(new CinHeader(CinHeaderType.Type, VerifycationSQCType.SQC_QUERY));
		// CinRouter.setRoute(request, CinServiceName.QuotaCenter);
		CinTransaction tran = CinStack.instance().createTransaction(request);
		tran.setAttachment(event);
		tran.Event = this;
		tran.sendRequest();
	}

	@Override
	public void onResponseReceived(CinTransaction trans) {
		CinResponse response = trans.getResponse();
		VerifycationSQCResult event = (VerifycationSQCResult) trans.getAttachment();
		Long type = response.getHeader(CinHeaderType.Version) == null ? null : response.getHeader(CinHeaderType.Version).getInt64();
		Long leftQuota = response.getHeader(CinHeaderType.Status) == null ? null : response.getHeader(CinHeaderType.Status).getInt64();
		if (response.isResponseCode(CinResponseCode.OK)) {
			event.getResult(true, type, leftQuota, event.getObject());
		} else {
			CinTracer.getInstance(VerifycationSQCHelper.class).warn("QTC ERROR", trans.getRequest());
			event.getResult(false, type, leftQuota, event.getObject());
		}
	}

	@Override
	public void onRequestSentFailed(CinTransaction trans) {
		CinTracer.getInstance(VerifycationSQCHelper.class).warn("QTC SendFailed", trans.getRequest());
		VerifycationSQCResult event = (VerifycationSQCResult) trans.getAttachment();
		event.getResult(false, null, null, event.getObject());
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans) {
		CinTracer.getInstance(VerifycationSQCHelper.class).warn("QTC Timeout", trans.getRequest());
		VerifycationSQCResult event = (VerifycationSQCResult) trans.getAttachment();
		event.getResult(false, null, null, event.getObject());
	}
}
