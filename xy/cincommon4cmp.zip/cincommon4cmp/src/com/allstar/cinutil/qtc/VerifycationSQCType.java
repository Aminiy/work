package com.allstar.cinutil.qtc;

public class VerifycationSQCType {

	public static final long SQC_INCREMENT = 0x01;
	public static final long SQC_CLEAR = 0x02;
	public static final long SQC_QUERY = 0x03;

}
