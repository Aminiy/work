package com.allstar.cinutil.qtc;

public abstract class VerifycationSQCResult {
	private Object _obj;

	public VerifycationSQCResult() {
	}

	public void setObject(Object obj) {
		_obj = obj;
	}

	public Object getObject() {
		return _obj;
	}

	/**
	 * SMS quota calibration results
	 * 
	 * @param result
	 *            TRUE: does not exceed limit, FALSE: exceed the configured limit
	 * @param type
	 *            Exceed the configured limit type: 1, more than 1 minute quotas, 2, more than a month
	 * @param leftQuota
	 *            Monthly quota remaining text messages
	 * @param obj
	 */
	public abstract void getResult(boolean result, Long type, Long leftQuota, Object obj);
}
