package com.allstar.cinutil;

import java.util.Calendar;

public class CinBirthday
{
	public int _year;
	public int _month;
	public int _day;
	
	public CinBirthday(int value)
	{
		if (value > 10000000)
		{
			this._year = value / 10000;
			this._month = (value % 10000) / 100;
			this._day = value - _year * 10000 - _month * 100;
		}
	}

	public int getAge()
	{
		int age = -1;
		if (_year > 0)
		{
			age = Calendar.getInstance().get(Calendar.YEAR) - this._year;
			Calendar c = Calendar.getInstance();
			c.set(_year, _month - 1, _day);
			int monthNow = Calendar.getInstance().get(Calendar.MONTH) + 1;
			if (_month > monthNow)
				age--;
			else
				if (_month == monthNow)
				{
					if (_day > Calendar.getInstance().get(Calendar.DATE))
					{
						age--;
					}
				}
			if (age < 0)
				age = -1;
		}
		return age;
	}
}
