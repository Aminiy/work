package com.allstar.cinutil;

public class CinAbility
{
	public static final int RoamingContact = 1 << 3;
	public static final int DiscoveryPlatform = 1 << 4;
	public static final int Emoticon = 1 << 5;

	/**
	 * @deprecated - Can Only be Used for parsing Ability of Userinfo from UCC
	 */
	@Deprecated
	public static boolean hasAbility(int value, int ability)
	{
		return (value & ability) == ability;
	}

}
