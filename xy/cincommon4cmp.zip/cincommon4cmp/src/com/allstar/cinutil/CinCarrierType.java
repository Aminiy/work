package com.allstar.cinutil;

import java.util.EnumSet;
import java.util.HashMap;

public enum CinCarrierType
{
	CMUser((byte) 1), NotCMUser((byte) 0);

	private static final HashMap<Byte, CinCarrierType> dic = new HashMap<Byte, CinCarrierType>();
	static
	{
		for (CinCarrierType s : EnumSet.allOf(CinCarrierType.class))
		{
			dic.put(s.getValue(), s);
		}
	}

	public static CinCarrierType get(String code)
	{
		return (CinCarrierType) dic.get(code);
	}

	private Byte _value;

	private CinCarrierType(Byte value)
	{
		this._value = value;
	}

	public Byte getValue()
	{
		return _value;
	}

	public static CinCarrierType getType(Byte value)
	{
		return dic.get(value);
	}
}
