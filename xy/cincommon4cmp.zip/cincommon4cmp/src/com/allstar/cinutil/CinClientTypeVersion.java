package com.allstar.cinutil;

/**
 * Integration of ClientType & ClientVersion
 * 
 *
 */
public class CinClientTypeVersion
{
	private CinClientVersion clientVersion;

	private CinClientType clientType;

	/**
	 * 
	 * @param clientTypeVersion
	 *            E.g android_1.0.1
	 */
	public CinClientTypeVersion(String clientTypeVersion)
	{
		try
		{
			String[] typever = clientTypeVersion.split(CinTextUtil.UnderScore);
			this.clientType = CinClientType.valueOf(typever[0]);
			this.clientVersion = CinClientVersion.valueFrom(typever[1]);
		}
		catch (Exception e)
		{
			throw new IllegalArgumentException(String.format("clientTypeVersion is illegal [%s]", clientTypeVersion), e);
		}
	}

	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		if (this.clientType != null)
		{
			sb.append("clientType=");
			sb.append(this.clientType.name());
		}
		else
		{
			sb.append("clientType=NULL");
		}

		sb.append(" ");

		if (this.clientVersion != null)
		{
			sb.append("clientVersion=");
			sb.append(this.clientVersion.toString());
		}
		else
		{
			sb.append("clientVersion=NULL");
		}

		return sb.toString();
	}

	public static void main(String[] args)
	{
		CinClientTypeVersion c = new CinClientTypeVersion("android_1.2.3");
		c = new CinClientTypeVersion("PC_1.2.3");
		System.out.println(c);
	}
}
