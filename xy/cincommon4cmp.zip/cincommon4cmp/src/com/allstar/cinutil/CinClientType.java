package com.allstar.cinutil;

import java.util.EnumSet;
import java.util.HashMap;

public enum CinClientType
{
	ios("ios", (byte) 0x01), 
	android("android", (byte) 0x02), 
	Tizen("tizen", (byte) 0x05), 
	UWP("uwp", (byte) 0x06), 
	Java("java", (byte) 0x07), 
	PC("pc", (byte) 0x08), 
	WP("wp", (byte) 0x09), 
	WEB("WEB", (byte) 0x0A),
	FEATUREPHONE("featurephone", (byte) 0x0B), 	
	unknown("unknown", (byte) 0xFF);
	
	private static final HashMap<String, CinClientType> dic = new HashMap<String, CinClientType>();
	private static final HashMap<String, Byte> id = new HashMap<String, Byte>();

	static
	{
		for (CinClientType s : EnumSet.allOf(CinClientType.class))
		{
			dic.put(s.getCode(), s);
			id.put(s.getCode(), s.getId());
		}
	}

	public static CinClientType get(String code)
	{
		return (CinClientType) dic.get(code);
	}

	private String _code;
	private byte _ord;

	private CinClientType(String code, byte ord)
	{
		this._code = code;
		_ord = ord;
	}

	public String getCode()
	{
		return _code;
	}

	public byte getId()
	{
		return _ord;
	}

	public static CinClientType getType(byte i)
	{
		for (String type : id.keySet())
		{
			if (id.get(type) == i)
				return dic.get(type);
		}
		return null;
	}

	public static boolean isMainClient(byte type)
	{
		return type == CinClientType.PC.getId();
	}
}
