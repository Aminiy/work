package com.allstar.cinutil;

public class ClientCapacityUtil
{

	public static enum ClientCapactity
	{
		RobotCapacity(0x01),

		DecryptionCapacity(0x02),

		MessageReadReplyStatusCapacity(0x04),

		PublicPlatformCapacity(0x08),
		
		TagUsersGroupChat(0x16),
		
		JioMoney(0x200);

		private long value;

		private ClientCapactity(long value)
		{
			this.value = value;
		}

		public long getValue()
		{
			return value;
		}
	}

	public static boolean isHaveRobotCapacity(byte[] pid)
	{
		CinPersonalId o = CinPersonalId.parse(pid);
		if (null != o)
		{
			return o.hasAbility((int) ClientCapactity.RobotCapacity.getValue());
		}
		else
		{
			return false;
		}
	}

	public static boolean isHaveDecryptionCapacity(byte[] pid)
	{
		CinPersonalId o = CinPersonalId.parse(pid);
		if (null != o)
		{
			return o.hasAbility((int) ClientCapactity.DecryptionCapacity.getValue());
		}
		else
		{
			return false;
		}
	}

	public static boolean isHaveMessageRRCapacity(byte[] pid)
	{
		CinPersonalId o = CinPersonalId.parse(pid);
		if (null != o)
		{
			return o.hasAbility((int) ClientCapactity.MessageReadReplyStatusCapacity.getValue());
		}
		else
		{
			return false;
		}
	}

	public static boolean isHavePublicPlatformCapacity(byte[] pid)
	{
		CinPersonalId o = CinPersonalId.parse(pid);
		if (null != o)
		{
			return o.hasAbility((int) ClientCapactity.PublicPlatformCapacity.getValue());
		}
		else
		{
			return false;
		}
	}
	
	public static boolean isHaveTagUsersGroupChatCapacity(byte[] pid)
	{
		CinPersonalId o = CinPersonalId.parse(pid);
		if (null != o)
		{
			return o.hasAbility((int) ClientCapactity.TagUsersGroupChat.getValue());
		}
		else
		{
			return false;
		}
	}
	
	public static boolean isHaveJioMoneyCapacity(byte[] pid)
	{
		CinPersonalId o = CinPersonalId.parse(pid);
		if (null != o)
		{
			return o.hasAbility((int) ClientCapactity.JioMoney.getValue());
		}
		else
		{
			return false;
		}
	}	
}
