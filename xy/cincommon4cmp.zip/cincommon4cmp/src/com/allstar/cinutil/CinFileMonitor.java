package com.allstar.cinutil;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

public class CinFileMonitor extends Thread
{
	private static CinFileMonitor _instance;

	private HashMap<File, Long> _files;
	private HashMap<File, ArrayList<CinFileChangedEvent>> _events;
	private Object _syncRoot;
	private long _interval;

	private CinFileMonitor()
	{
		this.setName("CinFileMonitor");
		this.setDaemon(true);

		_files = new HashMap<File, Long>();
		_events = new HashMap<File, ArrayList<CinFileChangedEvent>>();
		_syncRoot = new Object();
		_interval = 3000L;

		start();
	}

	public void addFile(File file, CinFileChangedEvent event)
	{
		synchronized (_syncRoot)
		{
			if (!_files.containsKey(file))
				_files.put(file, file.lastModified());

			if (!_events.containsKey(file))
				_events.put(file, new ArrayList<CinFileChangedEvent>());

			ArrayList<CinFileChangedEvent> list = _events.get(file);
			if (!list.contains(event))
				list.add(event);
		}
	}

	public void removeFile(File file, CinFileChangedEvent event)
	{
		synchronized (_syncRoot)
		{
			if (_events.containsKey(file))
				_events.get(file).remove(event);
		}
	}

	@Override
	public void run()
	{
		while (true)
		{
			try
			{
				Thread.sleep(_interval);
				HashMap<CinFileChangedEvent, File> map = new HashMap<CinFileChangedEvent, File>();
				synchronized (_syncRoot)
				{
					for (Entry<File, Long> entry : _files.entrySet())
					{
						long last = entry.getKey().lastModified();
						if (last > entry.getValue())
						{
							entry.setValue(last);
							if (_events.containsKey(entry.getKey()))
							{
								ArrayList<CinFileChangedEvent> events = _events.get(entry.getKey());
								for (CinFileChangedEvent event : events)
									map.put(event, entry.getKey());
							}
						}
					}
				}

				for (Entry<CinFileChangedEvent, File> entry : map.entrySet())
				{
					entry.getKey().onFileChanged(entry.getValue());
				}
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}
		}
	}

	public static void initialize()
	{
		if (_instance == null)
			_instance = new CinFileMonitor();
	}

	public static CinFileMonitor getInstance()
	{
		return _instance;
	}
}
