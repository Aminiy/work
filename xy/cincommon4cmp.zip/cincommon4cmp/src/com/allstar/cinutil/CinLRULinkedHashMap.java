/**
 * 
 */
package com.allstar.cinutil;

import java.util.LinkedHashMap;
import java.util.Map.Entry;


public abstract class CinLRULinkedHashMap<K, V> extends LinkedHashMap<K, V>
{

	/** serialVersionUID */
	private static final long serialVersionUID = -5933045562735378538L;

	/** Data storage capacity */
	protected int capacity = 1024;

	/**
	 * Constructor with parameters
	 * 
	 * @param initialCapacity
	 *            Capacity
	 * @param loadFactor
	 *            Load factor
	 * @param isLRU
	 *            Whether to use lru algorithm, and true: use (according to
	 *            access order);False: do not use (by store order)
	 * @param lruCapacity
	 *            Lru data storage capacity
	 */
	public CinLRULinkedHashMap(int initialCapacity, float loadFactor, boolean isLRU, int lruCapacity)
	{
		super(initialCapacity, loadFactor, isLRU);
		this.capacity = lruCapacity;
	}

	/**
	 * Delete the old data, this method need not take the initiative to call
	 * 
	 * @param eldest
	 * @return True to delete old data, false don't delete
	 */

	protected boolean removeEldestEntry(Entry<K, V> eldest)
	{
		if (size() > capacity)
		{
			this.removeEldestEntryDoSome(eldest);
			return true;

		}
		this.unRemoveEldestEntryDoSome(eldest);
		return false;
	}

	/**
	 * Before calling delete old data needs to be done when the processing
	 * method
	 * 
	 * @param eldest
	 *            The old data
	 */
	public abstract void removeEldestEntryDoSome(Entry<K, V> eldest);

	/**
	 * Don't need to delete old data call needs to be done when the processing method
	 * 
	 * @param eldest
	 */
	public abstract void unRemoveEldestEntryDoSome(Entry<K, V> eldest);
}