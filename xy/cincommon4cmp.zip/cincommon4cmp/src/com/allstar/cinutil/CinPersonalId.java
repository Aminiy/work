package com.allstar.cinutil;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Arrays;

/**
 * Encapsulation PID generation and read PID structure: Server Listened
 * IpEndPoint 6byte PersonalId Created DateTime 8byte CinConnection Id on Server
 * 4byte Client Type 4byte Client Ability 4byte
 */
public class CinPersonalId
{

	/** Initialize the each service startup, represent different services */
	private ByteBuffer value;
	private final static short valueLength = 26;

	private static final int POS_SERVER_IPENDPOINT = 0;
	private static final int POS_PERSONALID_CREATEDDATETIME = 6;
	private static final int POS_CONNECTIONID = 14;
	private static final int POS_CLIENT_TYPE = 18;
	private static final int POS_CLIENT_ABILITY = 22;

	private CinPersonalId()
	{

	}

	public CinPersonalId(String host, int port, int connectid, byte clientType, int clientAbility)
	{
		this(host, (char) port, connectid, clientType, clientAbility);
	}

	private CinPersonalId(String host, char port, int connectid, byte clientType, int clientAbility)
	{
		this(host, port, connectid);
		this.setClientType(clientType);
		this.setClientAbility(clientAbility);
	}

	public CinPersonalId(String host, int port, int connectid)
	{
		this(host, (char) port, connectid);
	}

	private CinPersonalId(String host, char port, int connectid)
	{
		ByteBuffer serviceaddress = ByteBuffer.allocate(POS_PERSONALID_CREATEDDATETIME - POS_SERVER_IPENDPOINT);
		try
		{
			serviceaddress.put(InetAddress.getByName(host).getAddress());
		}
		catch (UnknownHostException e)
		{
			e.printStackTrace();
		}
		serviceaddress.putChar(port);
		byte[] address = serviceaddress.array();
		value = ByteBuffer.allocate(valueLength);
		value.put(address);
		value.putLong(System.currentTimeMillis());
		value.putInt(connectid);
		value.putInt((short) 0);
		value.putInt((short) 0);
		value.flip();
	}

	public static CinPersonalId parse(byte[] data)
	{
		if (data.length <= valueLength)
		{
			byte[] pid = new byte[valueLength];
			System.arraycopy(data, 0, pid, 0, data.length);
			data = pid;
		}
		else
		{
			return null;
		}

		CinPersonalId temp = new CinPersonalId();
		temp.value = ByteBuffer.wrap(data);
		return temp;
	}

	public int getConnectionId()
	{
		return value.getInt(POS_CONNECTIONID);
	}

	public byte getClientTypeId()
	{
		return value.get(POS_CLIENT_TYPE);
	}

	public byte getClientLanguage()
	{
		return value.get(POS_CLIENT_TYPE + 2);
	}

	public CinClientType getClientType()
	{
		return CinClientType.getType(getClientTypeId());
	}

	public int getClientAblity()
	{
		//who ? why ?
		return value.getInt(POS_CLIENT_ABILITY) & 7;
	}

	public boolean hasAbility(int ability)
	{
		return ((value.getInt(POS_CLIENT_ABILITY) & ability) == ability);
	}

	public long getTimeStamp()
	{
		return value.getLong(POS_PERSONALID_CREATEDDATETIME);
	}

	public void setClientType(byte type)
	{
		value.put(POS_CLIENT_TYPE, type);
	}

	public void setClientLanguage(byte type)
	{
		value.put(POS_CLIENT_TYPE + 2, type);
	}

	public void setClientAbility(int ability)
	{
		value.putInt(POS_CLIENT_ABILITY, ability);
	}

	public byte[] getBytes()
	{
		return value.array();
	}

	public byte[] getByte(int index)
	{
		byte[] temp = new byte[index];
		value.get(temp);
		value.rewind();
		return temp;
	}

	public InetSocketAddress getAddress()
	{
		byte[] ipaddr = new byte[4];
		value.get(ipaddr);
		try
		{
			return new InetSocketAddress(InetAddress.getByAddress(ipaddr), value.getChar(4));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}

	public String getHexString()
	{
		return CinConvert.bytes2String(value.array());
	}

	@Override
	public String toString()
	{
		return getHexString();
	}

	@Override
	public boolean equals(Object obj)
	{
		return (obj != null) && (Arrays.equals(this.getBytes(), ((CinPersonalId) obj).getBytes()));
	}

	@Override
	public int hashCode()
	{
		int hash = 0;
		for (int i = 0; i < (value.limit() / 2); i++)
		{
			hash = 37 * hash + value.getShort(i * 2);
		}
		return hash;
	}

	public static void main(String[] args)
	{
		byte[] bytes = CinConvert.toByteArray("0A0AD124177000000142E9E522D0000006F10100000000000000");
		CinPersonalId pid = CinPersonalId.parse(bytes);
		pid.setClientType((byte) 2);
		pid.setClientLanguage((byte) 3);
		pid.setClientAbility(0xfffffff);
		System.out.println(CinConvert.bytes2String(pid.getBytes()));
		System.out.println(pid.getClientType());
		System.out.println(pid.getConnectionId());
		System.out.println(pid.getClientLanguage());
		System.out.println(pid.getClientAblity());
	}

}
