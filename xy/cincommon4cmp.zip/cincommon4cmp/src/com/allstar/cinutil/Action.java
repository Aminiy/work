package com.allstar.cinutil;

public interface Action<T>
{
	void run(T a);
}