package com.allstar.cinutil.vcs;

public abstract class CheckPicResultEvent {
	private Object _obj;

	public CheckPicResultEvent() {
	}

	public void setObject(Object obj) {
		_obj = obj;
	}

	public Object getObject() {
		return _obj;
	}

	public abstract void getResult(boolean result, Object obj);
}
