package com.allstar.cinutil.vcs;

import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionEvent;

class CheckPicUACHandler implements CinTransactionEvent
{
	// private static CinTracer _tracer =
	// CinTracer.getInstance(CheckPicUACHandler.class);

	private String _id;
	private long _userId;
	private byte _reqEvent;
	private String _code;
	private CheckPicResultEvent _event;

	public CheckPicUACHandler(String id, long userId, byte reqEvent, String code, CheckPicResultEvent event)
	{
		_id = id;
		_userId = userId;
		_reqEvent = reqEvent;
		_code = code;
		_event = event;
	}

	public void handle()
	{
		CinRequest request = new CinRequest(CinRequestMethod.Verify);
		request.addHeader(new CinHeader(CinHeaderType.From, _userId));
		request.addHeader(new CinHeader(CinHeaderType.Event, _reqEvent));
		request.addHeader(new CinHeader(CinHeaderType.MessageID, _id));
		request.addHeader(new CinHeader(CinHeaderType.Key, _code));
		CinRouter.setRoute(request, CinServiceName.VerifycationCodeService);
		CinTransaction tran = CinStack.instance().createTransaction(request);
		tran.Event = this;
		tran.sendRequest();
	}

	@Override
	public void onResponseReceived(CinTransaction trans)
	{
		CinResponse response = trans.getResponse();
		CheckPicResultEvent event = _event;
		if (event != null)
			event.getResult(response.isResponseCode(CinResponseCode.OK), response.getStatusCode());
	}

	@Override
	public void onRequestSentFailed(CinTransaction trans)
	{
		CheckPicResultEvent event = _event;
		if (event != null)
			event.getResult(false, event.getObject());
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans)
	{
		CheckPicResultEvent event = _event;
		if (event != null)
			event.getResult(false, event.getObject());
	}
}
