package com.allstar.cinutil.vcs;

import com.allstar.event.CinVerifyEvent;

public class VerifycationCodeHelper {
	// private static CinTracer _tracer = CinTracer.getInstance(VerifycationCodeHelper.class);
	private static VerifycationCodeHelper _instance;

	private VerifycationCodeHelper() {
	}

	public static VerifycationCodeHelper getInstance() {
		if (_instance == null)
			return new VerifycationCodeHelper();
		return _instance;
	}

	public void getPicVerificationCode(GetPicResultEvent event) {
		getPicVerificationCode(0, event);
	}

	public void getPicVerificationCode(long userId, GetPicResultEvent event) {
		GetPicUACHandler handler = new GetPicUACHandler(userId, event);
		handler.handle();
	}

	public void checkPicVerificationCode(String id, String code, CheckPicResultEvent event) {
		checkPicVerificationCode(id, 0, code, event);
	}

	public void checkPicVerificationCode(String id, long userId, String code, CheckPicResultEvent event) {
		checkPicVerificationCode(id, userId, CinVerifyEvent.VERIFY_PIC_CODE, code, event);
	}

	public void checkPicVerificationCode(String id, long userId, byte reqEvent, String code, CheckPicResultEvent event) {
		CheckPicUACHandler handler = new CheckPicUACHandler(id, userId, reqEvent, code, event);
		handler.handle();
	}
}
