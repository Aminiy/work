package com.allstar.cinutil.vcs;

import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionEvent;
import com.allstar.cintracer.CinTracer;
import com.allstar.event.CinVerifyEvent;

class GetPicUACHandler implements CinTransactionEvent
{
	private static CinTracer _tracer = CinTracer.getInstance(GetPicUACHandler.class);

	private long _userId;
	private GetPicResultEvent _event;

	public GetPicUACHandler(long userId, GetPicResultEvent event)
	{
		_userId = userId;
		_event = event;
	}

	public void handle()
	{
		CinRequest request = new CinRequest(CinRequestMethod.Verify);
		request.addHeader(new CinHeader(CinHeaderType.From, _userId));
		request.addHeader(new CinHeader(CinHeaderType.Event, CinVerifyEvent.GET_PIC_CODE));
		CinRouter.setRoute(request, CinServiceName.VerifycationCodeService);
		CinTransaction tran = CinStack.instance().createTransaction(request);
		tran.Event = this;
		tran.sendRequest();
	}

	@Override
	public void onResponseReceived(CinTransaction trans)
	{
		CinResponse response = trans.getResponse();
		if (!response.isResponseCode(CinResponseCode.OK))
		{
			_tracer.error("GetPic is not ok.\r\n" + response.toString(), trans.getRequest());
			return;
		}

		GetPicResultEvent event = _event;
		if (event != null)
		{
			String picId = response.getHeader(CinHeaderType.MessageID).getString();
			byte[] image = response.getBody().getValue();
			event.getPicResult(picId, image);
		}
	}

	@Override
	public void onRequestSentFailed(CinTransaction trans)
	{
		_tracer.error("GetPicUACHandler.onSendFailed error.", trans.getRequest());
		GetPicResultEvent event = _event;
		if (event != null)
		{
			event.getError("send request failed.");
		}
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans)
	{
		_tracer.error("GetPicUACHandler.onTimeout error", trans.getRequest());
		GetPicResultEvent event = _event;
		if (event != null)
		{
			event.getError("send request time out.");
		}
	}
}
