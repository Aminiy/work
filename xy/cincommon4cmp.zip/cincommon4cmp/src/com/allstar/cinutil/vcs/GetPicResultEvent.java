package com.allstar.cinutil.vcs;

public abstract class GetPicResultEvent {
	public abstract void getPicResult(String picId, byte[] image);

	public void getError(String error) {
	}
}
