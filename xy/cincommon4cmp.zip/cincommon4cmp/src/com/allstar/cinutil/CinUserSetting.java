package com.allstar.cinutil;

public class CinUserSetting
{
	public static final long PushOpen = 0x0004;
	public static final long PushType = 0x0008;
	public static final long MessageRead = 0x0010;
	public static final long CircleOfFriends = 0x0020;
	public static final long ReceiveBuddyJoin = 0x0040;
	public static final long OnlineStatus = 0x0080;
	public static final long PushPreview = 0x0100;

	private long setting;

	public CinUserSetting(Long setting)
	{
		this.setting = setting;
	}

	public boolean isPushOpen()
	{
		return getStatus(PushOpen);
	}

	public boolean isPushPreview()
	{
		return getStatus(PushType);
	}
	public boolean isMessageRead()
	{
		return getStatus(MessageRead);
	}

	public boolean getStatus(long settingType)
	{
		return (setting & settingType) == settingType;
	}

	public void switchChange(long switchType, boolean b)
	{
		if (b)
			setting = setting | switchType;
		else
			setting = setting & ~switchType;
	}

	public long getValue()
	{
		return this.setting;
	}

	public void setValue(long setting)
	{
		this.setting = setting;
	}

	public static long getDefaultSwtich()
	{
		CinUserSetting us = new CinUserSetting(0L);
		us.switchChange(PushType, true);
		us.switchChange(CircleOfFriends, true);
		us.switchChange(ReceiveBuddyJoin, true);
		us.switchChange(OnlineStatus, true);
		us.switchChange(PushPreview, true);
		us.switchChange(MessageRead, true);
		return us.getValue();
	}

	public static boolean isOpen(long value, long type)
	{
		return (value & type) == type;
	}

}
