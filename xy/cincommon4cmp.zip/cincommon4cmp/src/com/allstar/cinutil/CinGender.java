package com.allstar.cinutil;

public class CinGender
{
	public static final byte FEMALE = 0;
	public static final byte MALE = 1;
	public static final byte UNKNOWN = 2;
}
