package com.allstar.cinutil;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.allstar.cinconfig.CinConfigure;
import com.allstar.cinstack.handler.codec.CinEncoder;
import com.allstar.cinstack.handler.codec.CinMessageReader;
import com.allstar.cinstack.message.CinMessage;

public class CinScalableMappedData
{
	private int Cell_Size = 0;
	private int File_Size = 0;
	private String dictionary;
	private String fileName;
	private String indexFileName;
	private int indexByteArraySize;
	private int indexFileSize;
	private RandomAccessFile indexRaf;
	private FileChannel indexIOChannel;
	private MappedByteBuffer indexMappedBuf;
	private RandomAccessFile raf;
	private FileChannel ioChannel;
	private MappedByteBuffer mappedBuf;
	public int MaxAbility;
	public int keySize;
	public ConcurrentLinkedQueue<Integer> _queue;
	private byte _headerTypeValue;
	public ConcurrentHashMap<CinObject, ArrayList<Integer>> _pointerHash;

	public CinScalableMappedData(int cellsize, int filesize, String filedictionary, String filename, byte headertype, int keysize) throws IOException
	{
		if (filename.equals(CinTextUtil.EmptyString))
			throw new IOException("File Name shouldn't be EMPTY");
		dictionary = filedictionary;
		fileName = dictionary + "/" + filename.toLowerCase() + ".cache";
		indexFileName = dictionary + "/" + filename.toLowerCase() + ".index";
		_headerTypeValue = headertype;
		Cell_Size = cellsize;
		File_Size = filesize;
		MaxAbility = (int) Math.floor(File_Size / Cell_Size);
		keySize = keysize;
		indexByteArraySize = keySize + 4;
		indexFileSize = MaxAbility * indexByteArraySize;
		open();
	}

	public CinScalableMappedData(int cellsize, int filesize, String filename, byte headertype, int keysize) throws IOException
	{
		if (filename.equals(CinTextUtil.EmptyString))
			throw new IOException("File Name shouldn't be EMPTY");
		dictionary = ("/data/caches/" + CinConfigure.serviceName + "/" + CinConfigure.computerName).toLowerCase();
		fileName = dictionary + "/" + filename.toLowerCase() + ".cache";
		indexFileName = dictionary + "/" + filename.toLowerCase() + ".index";
		_headerTypeValue = headertype;
		Cell_Size = cellsize;
		File_Size = filesize;
		keySize = keysize;
		indexByteArraySize = keySize + 4;
		MaxAbility = (int) Math.floor(File_Size / Cell_Size);
		indexFileSize = MaxAbility * indexByteArraySize;
		open();
	}

	private void open() throws IOException
	{
		// open file
		File fl = new File(dictionary);
		if (!fl.exists())
		{
			fl.mkdirs();
		}
		raf = new RandomAccessFile(fileName, "rwd");
		ioChannel = raf.getChannel();
		mappedBuf = ioChannel.map(MapMode.READ_WRITE, 0, File_Size);
		indexRaf = new RandomAccessFile(indexFileName, "rwd");
		indexIOChannel = indexRaf.getChannel();
		indexMappedBuf = indexIOChannel.map(MapMode.READ_WRITE, 0, indexFileSize);
		_pointerHash = new ConcurrentHashMap<CinObject, ArrayList<Integer>>();
		_queue = new ConcurrentLinkedQueue<Integer>();
		loadFile();
	}

	private void loadFile()
	{
		int i = 0;
		HashMap<Integer, Integer> _pointerNumHash = new HashMap<Integer, Integer>();
		while (i < MaxAbility)
		{
			indexMappedBuf.position(i * indexByteArraySize);
			byte[] b = new byte[keySize];
			indexMappedBuf.get(b);
			CinObject key = new CinObject(b);
			Integer num = indexMappedBuf.getInt();
			if (key.isNull())
			{
				_queue.add(i);
			}
			else
			{
				if (_pointerHash.containsKey(key))
				{
					_pointerHash.get(key).add(i);
				}
				else
				{
					_pointerHash.put(key, new ArrayList<Integer>());
					_pointerHash.get(key).add(i);
				}
				_pointerNumHash.put(i, num);
			}
			i++;
		}
		for (CinObject key : _pointerHash.keySet())
		{
			ArrayList<Integer> list = _pointerHash.get(key);
			int[] intArray = new int[list.size()];
			for (Integer index : list)
			{
				int asd = _pointerNumHash.get(index);
				intArray[asd] = index;
			}
			list.clear();
			for (i = 0; i < intArray.length; i++)
			{
				list.add(intArray[i]);
			}
			_pointerHash.replace(key, list);
		}
	}

	/**
	 * write method
	 * 
	 * @param message
	 *            the message you want to write into the file
	 * @return if write successfully,return true,otherwise return false
	 * @throws IOException
	 */
	public boolean write(CinMessage message) throws IOException
	{
		if (message.getHeader(_headerTypeValue) == null)
			return false;
		CinObject key = new CinObject(message.getHeader(_headerTypeValue).getValue());
		key.changeLimit(keySize);
		if (_pointerHash.containsKey(key))
			return false;
		ArrayList<Integer> list = writePointers(ByteBuffer.wrap(CinEncoder.toBytes(message)));
		if (list == null)
			return false;
		writeIndex(key, list);
		return true;
	}

	/**
	 * remove method
	 * 
	 * @param key
	 *            delete the message which has the key
	 */
	public void remove(CinObject key)
	{
		key.changeLimit(keySize);
		ArrayList<Integer> list = _pointerHash.get(key);
		if (list == null || list.size() == 0)
			return;
		removeIndex(key, list);
	}

	/**
	 * update method
	 * 
	 * @param message
	 *            new message,the message will remove the old message which has
	 *            the same key,then write the new message
	 * @return if succeed return true,else return false
	 * @throws IOException
	 */
	public boolean update(CinMessage message) throws IOException
	{
		if (message.getHeader(_headerTypeValue) == null)
			return false;
		CinObject key = new CinObject(message.getHeader(_headerTypeValue).getValue());
		key.changeLimit(keySize);
		if (!_pointerHash.containsKey(key))
			return false;
		remove(key);
		return write(message);
	}

	/**
	 * read method
	 * 
	 * @param key
	 *            the key of message
	 * @return CinMessage
	 */
	public CinMessage read(CinObject key)
	{
		key.changeLimit(keySize);
		ArrayList<Integer> list = _pointerHash.get(key);
		if (list == null || list.size() == 0)
			return null;
		ByteBuffer buff = ByteBuffer.allocate(list.size() * Cell_Size);
		for (Integer index : list)
		{
			byte[] byff = readCeil(index);
			buff.put(byff);
		}
		return CinMessageReader.parse(buff.array());
	}

	/**
	 * getKeySet
	 * 
	 * @return key array(long[])
	 */
	public CinObject[] getKeys()
	{
		return _pointerHash.keySet().toArray(new CinObject[0]);
	}

	private byte[] readCeil(Integer index)
	{
		byte[] b = new byte[Cell_Size];
		mappedBuf.position(index * Cell_Size);
		mappedBuf.get(b);
		return b;
	}

	private void removeIndex(CinObject key, ArrayList<Integer> list)
	{
		_pointerHash.remove(key);
		for (int i = 0; i < list.size(); i++)
		{
			indexMappedBuf.position(list.get(i) * indexByteArraySize);
			byte[] b = new byte[keySize];
			indexMappedBuf.put(b);
			indexMappedBuf.putInt(0);
			_queue.add(list.get(i));
		}
	}

	private int writeCeil(byte[] b) throws IOException
	{
		Integer index = _queue.poll();
		if (index == null)
			throw new IOException("The file has no empty space!");
		mappedBuf.position(index * Cell_Size);
		mappedBuf.put(b);
		return index;
	}

	private void writeIndex(CinObject key, ArrayList<Integer> list)
	{
		_pointerHash.put(key, list);
		for (int i = 0; i < list.size(); i++)
		{
			indexMappedBuf.position(list.get(i) * indexByteArraySize);
			indexMappedBuf.put(key.getBytes());
			indexMappedBuf.putInt(i);
		}
	}

	private ArrayList<Integer> writePointers(ByteBuffer byteBuffer) throws IOException
	{
		int needCount = (int) Math.ceil((double) byteBuffer.capacity() / Cell_Size);
		ByteBuffer longBuf = ByteBuffer.allocate(needCount * Cell_Size);
		longBuf.put(byteBuffer);
		longBuf.position(0);
		ArrayList<Integer> list = new ArrayList<Integer>();
		byte[] b = new byte[Cell_Size];
		for (int i = 0; i < needCount; i++)
		{
			longBuf.get(b);
			list.add(writeCeil(b));
		}
		return list.size() == 0 ? null : list;
	}
}
