package com.allstar.cinutil;

import com.allstar.cinconfig.CinConfig;
import com.allstar.cinconfig.CinConfigure;
import com.allstar.cinconfig.cinalarmnumber.CinAlarmNumberConfig;
import com.allstar.cinrouter.CinRouter;
import com.allstar.cintracer.CinTracer;

public class CinCommonHelper
{
	public static void Initialize() throws Exception
	{
		Initialize(true);
	}

	public static void Initialize(boolean readProperties) throws Exception
	{
		if (readProperties)
			CinConfigure.Initialize();
		CinConfig.Initialize();
		CinAlarmNumberConfig.initialize();
		CinTracer.Initialize();
		CinRouter.Initialize();
	}
}
