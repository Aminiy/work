package com.allstar.cinutil;

import java.io.File;

public interface CinFileChangedEvent
{
	public void onFileChanged(File file);
}
