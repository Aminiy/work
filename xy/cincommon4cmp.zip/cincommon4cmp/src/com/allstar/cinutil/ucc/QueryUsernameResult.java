package com.allstar.cinutil.ucc;

import java.util.HashMap;

public abstract class QueryUsernameResult
{
	private Object _obj;

	public QueryUsernameResult()
	{
	}

	public void setObject(Object obj)
	{
		_obj = obj;
	}

	public Object getObject()
	{
		return _obj;
	}

	/**
	 * USERNAME according to USERID
	 * 
	 * @param result
	 *            TRUE: Success, FALSE: failed
	 * 
	 * @param values
	 *            Query the relationship between <USERID, USERNAME>
	 * @param obj
	 */
	public abstract void queryUsernameResult(HashMap<Long, String> values, Object obj);
}
