package com.allstar.cinutil.ucc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinRouterConfig;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.handler.codec.CinMessageReader;
import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionEvent;
import com.allstar.cintracer.CinTracer;
import com.allstar.event.CinInnerServiceEvent;

public class QueryUsernameHelper implements CinTransactionEvent
{
	private static CinTracer tracer = CinTracer.getInstance(QueryUsernameHelper.class);

	/** Record the number of card requests sent to the UCC, which should be less than or equal to the number of UCC services */
	private int _count = 0;

	/** Correspondence between USERID and USERNAME */
	private HashMap<Long, String> usernames = new HashMap<Long, String>();

	private QueryUsernameResult _result;

	public void getUsernameByUserid(List<Long> userids, QueryUsernameResult result)
	{
		if (userids == null || userids.isEmpty())
		{
			result.queryUsernameResult(null, result.getObject());
			return;
		}

		_result = result;

		// UCC service quantity(Number of services)
		int uccCount = CinRouterConfig.getServiceCount(CinServiceName.UserCacheCenter.getValue());

		// Group USERIDs based on the number of UCC services
		Map<Integer, List<Long>> useridMap = new HashMap<Integer, List<Long>>(uccCount);
		for (long userid : userids)
		{
			int uccNum = (int) (userid % uccCount);
			if (!useridMap.containsKey(uccNum))
			{
				useridMap.put(uccNum, new ArrayList<Long>());
			}
			useridMap.get(uccNum).add(userid);
		}

		this._count = useridMap.size();

		// For each group of USRID UCC request user name card
		Iterator<Entry<Integer, List<Long>>> it = useridMap.entrySet().iterator();
		while (it.hasNext())
		{

			CinRequest req = new CinRequest(CinRequestMethod.InnerService);
			req.addHeader(new CinHeader(CinHeaderType.Event, CinInnerServiceEvent.GetUserProfile));
			Entry<Integer, List<Long>> entry = it.next();
			req.addHeader(new CinHeader(CinHeaderType.From, entry.getValue().get(0)));

			for (long userid : entry.getValue())
			{
				req.addHeader(new CinHeader(CinHeaderType.Key, userid));
			}

			CinRouter.setRoute(req, CinServiceName.UserCacheCenter);
			CinTransaction trans = CinStack.instance().createTransaction(req);
			trans.Event = this;
			trans.sendRequest();
		}
	}

	@Override
	public void onResponseReceived(CinTransaction trans)
	{
		CinResponse response = trans.getResponse();
		if (response.isResponseCode(CinResponseCode.OK))
		{
			for (CinBody m : response.getBodys())
			{
				CinMessage message = CinMessageReader.parse(m.getValue());
				long userid = message.getHeader((byte) 0x40).getInt64();
				String name = message.getHeader((byte) 0x42).getString();

				usernames.put(userid, name);
			}
		}

		if (--_count <= 0)
		{
			_result.queryUsernameResult(usernames, _result.getObject());
		}

	}

	@Override
	public void onRequestSentFailed(CinTransaction trans)
	{
		if (--_count <= 0)
		{
			_result.queryUsernameResult(usernames, _result.getObject());
		}
		tracer.error("Get UserInfo From UCC Failed...", trans.getRequest());
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans)
	{
		if (--_count <= 0)
		{
			_result.queryUsernameResult(usernames, _result.getObject());
		}
		tracer.error("Get UserInfo From UCC Failed...", trans.getRequest());
	}
}
