package com.allstar.cinutil;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cinconfig.CinConfigure;
import com.allstar.cinstack.handler.codec.CinEncoder;
import com.allstar.cinstack.handler.codec.CinMessageReader;
import com.allstar.cinstack.message.CinMessage;

public class CinMappedData
{
	private int Byte_Array_Size;
	private int File_Size;
	private String dictionary;
	private String fileName;
	private RandomAccessFile raf;
	private FileChannel ioChannel;
	private MappedByteBuffer buf;
	public int MaxAbility;
	public CinLinkedList<Integer> _queue;
	public ConcurrentHashMap<Long, Integer> _indexHash;
	private byte _headerTypeValue;

	public CinMappedData(int cellSize, int fileSize, String filename, byte type) throws IOException
	{
		this(cellSize, fileSize, ("/data/caches/" + CinConfigure.serviceName + "/" + CinConfigure.computerName).toLowerCase(), filename, type);
	}

	public CinMappedData(int cellSize, int fileSize, String _dictionary, String filename, byte type) throws IOException
	{
		Byte_Array_Size = cellSize;
		File_Size = fileSize;
		dictionary = _dictionary;
		fileName = (dictionary + "/" + filename + ".cache").toLowerCase();
		_headerTypeValue = type;
		open();
	}

	public void open() throws IOException
	{
		File fl = new File(dictionary);
		if (!fl.exists())
		{
			fl.mkdirs();
		}
		raf = new RandomAccessFile(fileName, "rwd");
		ioChannel = raf.getChannel();
		buf = ioChannel.map(MapMode.READ_WRITE, 0, File_Size);
		_indexHash = new ConcurrentHashMap<Long, Integer>();
		// load Empty space
		_queue = new CinLinkedList<Integer>();
		MaxAbility = (int) Math.floor(File_Size / Byte_Array_Size);
		for (int i = 0; i < MaxAbility; i++)
		{
			if (isNull(i))
			{
				_queue.put(i);
			}
			else
			{
				CinMessage message = CinMessageReader.parse(read(i));
				if (message != null && message.getHeader(_headerTypeValue) != null)
				{
					_indexHash.put(CinMessageReader.parse(read(i)).getHeader(_headerTypeValue).getInt64(), i);
				}
				else
				{
					_queue.put(i);
				}
			}
		}
	}

	public void close() throws IOException
	{
		raf.close();
		ioChannel.close();
		_indexHash.clear();
		buf.clear();
	}

	public void remove(Long key) throws IOException
	{
		Integer index = _indexHash.get(key);
		if (index == null)
			return;
		remove(index);
		_indexHash.remove(key);
	}

	public int write(CinMessage message) throws IOException
	{
		long key = message.getHeader(_headerTypeValue).getInt64();
		byte[] msgBytes = CinEncoder.toBytes(message);
		if (msgBytes.length > Byte_Array_Size)
			throw new IOException("The Message you want to write is too large");
		if (_indexHash.containsKey(key))
			return -1;
		int i = write(msgBytes);
		_indexHash.put(key, i);
		return i;
	}

	public boolean update(CinMessage message) throws IOException
	{
		long key = message.getHeader(_headerTypeValue).getInt64();
		byte[] msgBytes = CinEncoder.toBytes(message);
		if (msgBytes.length > Byte_Array_Size)
			throw new IOException("The Message you want to write is too large");
		Integer index = _indexHash.get(key);
		if (index == null)
			return false;
		update(index, CinEncoder.toBytes(message));
		return true;
	}

	public CinMessage read(Long key) throws IOException
	{
		Integer index = _indexHash.get(key);
		if (index == null)
			return null;
		byte[] b = read(index);
		if (b != null)
			return CinMessageReader.parse(b);
		else
			return null;
	}

	public void remove(int index) throws IOException
	{
		buf.put(index * Byte_Array_Size, (byte) 0);
		_queue.put(new Integer(index));
	}

	public int write(byte[] b) throws IOException
	{
		CinLinkedNode<Integer> node = _queue.takeAwayFirst();
		if (node == null)
			throw new IOException("No space to write a byte!");
		update(node.object(), b);
		return node.object();
	}

	public synchronized void update(int index, byte[] b)
	{
		buf.position(index * Byte_Array_Size);
		buf.put(b);
	}

	public synchronized byte[] read(int index) throws IOException
	{
		if (buf.get(index * Byte_Array_Size) == (byte) 0)
			return null;
		byte[] b = new byte[Byte_Array_Size];
		buf.position(index * Byte_Array_Size);
		buf.get(b);
		return b;
	}

	public boolean isNull(int index)
	{
		if (index >= MaxAbility)
			return true;
		return buf.get(index * Byte_Array_Size) == (byte) 0 ? true : false;
	}

	public Long[] getKeys()
	{
		return _indexHash.keySet().toArray(new Long[0]);
	}

	public boolean isExist(Long key)
	{
		return _indexHash.containsKey(key);
	}
}
