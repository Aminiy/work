package com.allstar.cinutil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import com.allstar.cinconfig.CinConfigure;

public class CinCounter {
	private static List<CinCounter> mgr = Collections.synchronizedList(new LinkedList<CinCounter>());
	private final Date time;
	private final String name;
	public AtomicLong Counter;
	public static List<String> _loggerModelList = new ArrayList<String>();
	public static final String LoggerSeparator = "##";

	static {
		_loggerModelList.add("countertype");
		_loggerModelList.add("counter");
		_loggerModelList.add("computername");
		_loggerModelList.add("servertime");
	}

	public CinCounter(String countername) {
		Counter = new AtomicLong();
		time = new Date();
		this.name = countername;
		mgr.add(this);
	}

	public String toString() {
		StringBuilder sb = new StringBuilder(64);
		sb.append(name).append(LoggerSeparator).append(Counter).append(LoggerSeparator).append(CinConfigure.computerName).append(LoggerSeparator).append(time.getTime());
		return sb.toString();
	}

	public void increment() {
		Counter.incrementAndGet();
	}

	public void decrement() {
		Counter.decrementAndGet();
	}

	public static String getAllCounterInfo() {
		synchronized (mgr) {
			Iterator<CinCounter> i = mgr.iterator();
			StringBuilder sb = new StringBuilder(2048);
			while (i.hasNext()) {
				sb.append(i.next().toString()).append(CinTextUtil.RETURN);
			}
			return sb.toString();
		}
	}
}
