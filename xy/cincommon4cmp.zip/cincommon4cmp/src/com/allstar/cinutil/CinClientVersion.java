package com.allstar.cinutil;

import java.nio.ByteBuffer;
import java.util.Comparator;

/**
 * Encapsulation the client version<br>
 * 1.Override equals() & hashCode() & toString() methods<br>
 * 2.Implement interface Comparable & Comparator
 * 
 *
 */
public class CinClientVersion implements Comparable<CinClientVersion>, Comparator<CinClientVersion>
{
	public final static int SIZE = 12;

	private int majorVersion = 0;

	private int minorVersion = 0;

	private int internalVersion = 0;

	// private String buildDate = null;

	private CinClientVersion()
	{

	}

	@Override
	public int hashCode()
	{
		// return majorVersion * 100000 + minorVersion * 10000 + internalVersion
		// + this.buildDate != null ? this.buildDate.hashCode() : 0;
		return majorVersion * 100000 + minorVersion * 10000 + internalVersion;
	}

	@Override
	public boolean equals(Object obj)
	{

		if (this == obj)
		{
			return true;
		}

		if (obj == null)
		{
			return false;
		}

		if (getClass() != obj.getClass())
		{
			return false;
		}

		CinClientVersion rval = (CinClientVersion) obj;
		if (this.majorVersion != rval.majorVersion)
		{
			return false;
		}

		if (this.minorVersion != rval.minorVersion)
		{
			return false;
		}

		if (this.internalVersion != rval.internalVersion)
		{
			return false;
		}

		// String lbuild = "".equals(this.buildDate) ? null : this.buildDate;
		// String rbuild = "".equals(rval.buildDate) ? null : rval.buildDate;
		//
		// if (lbuild == null)
		// {
		// if (rbuild != null)
		// {
		// return false;
		// }
		// }
		// else if (!lbuild.equals(rbuild))
		// {
		// return false;
		// }

		return true;
	}

	public boolean IsGreaterThan(CinClientVersion rval)
	{
		return this.compareTo(rval) > 0;
	}

	@Override
	public String toString()
	{
		// if (CinUtil.isNullOrEmpty(this.buildDate))
		// {
		// return String.format("%s.%s.%s", this.majorVersion,
		// this.minorVersion, this.internalVersion);
		// }
		// else
		// {
		// return String.format("%s.%s.%s.%s", this.majorVersion,
		// this.minorVersion, this.internalVersion, this.buildDate);
		// }
		return String.format("%s.%s.%s", this.majorVersion, this.minorVersion, this.internalVersion);
	}

	@Override
	public int compareTo(CinClientVersion rval)
	{
		if (rval == null)
		{
			return 1;
		}

		int lt = this.majorVersion * 100000 + this.minorVersion * 10000 + this.internalVersion;
		int rt = rval.majorVersion * 100000 + rval.minorVersion * 10000 + rval.internalVersion;

		if (lt > rt)
		{
			return 1;
		}
		else if (lt < rt)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}

	@Override
	public int compare(CinClientVersion lval, CinClientVersion rval)
	{
		if (lval == null)
		{
			if (rval != null)
			{
				return -1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return lval.compareTo(rval);
		}
	}

	public byte[] toBytes()
	{
		ByteBuffer buffer = ByteBuffer.allocate(SIZE);
		buffer.putInt(this.majorVersion);
		buffer.putInt(this.minorVersion);
		buffer.putInt(this.internalVersion);
		return buffer.array();
	}

	public int getMajorVersion()
	{
		return majorVersion;
	}

	public int getMinorVersion()
	{
		return minorVersion;
	}

	public int getInternalVersion()
	{
		return internalVersion;
	}

	/**
	 * 
	 * @param version
	 *            E.g 1.0.16
	 * @return
	 */
	public static CinClientVersion valueFrom(String version)
	{
		try
		{
			String[] ss = version.split("\\.");
			if (ss.length != 3)
			{
				throw new IllegalArgumentException(version);
			}

			CinClientVersion ret = new CinClientVersion();
			ret.majorVersion = Integer.parseInt(ss[0]);
			ret.minorVersion = Integer.parseInt(ss[1]);
			ret.internalVersion = Integer.parseInt(ss[2]);
			return ret;
		}
		catch (Throwable e)
		{
			throw new IllegalArgumentException(String.format("Version is illegal [%s]", version), e);
		}
	}

	public static CinClientVersion valueFrom(byte[] data)
	{
		try
		{
			ByteBuffer buffer = ByteBuffer.allocate(SIZE);
			buffer.put(data);
			buffer.flip();
			CinClientVersion version = new CinClientVersion();
			version.majorVersion = buffer.getInt();
			version.minorVersion = buffer.getInt();
			version.internalVersion = buffer.getInt();
			return version;
		}
		catch (Exception e)
		{
			throw new IllegalArgumentException(String.format("data is illegal [%s]", data != null ? CinConvert.bytes2String(data) : ""), e);
		}

	}

	public static CinClientVersion valueFrom(int majorVersion, int minorVersion, int internalVersion)
	{
		CinClientVersion version = new CinClientVersion();
		version.majorVersion = majorVersion;
		version.minorVersion = minorVersion;
		version.internalVersion = internalVersion;
		return version;
	}

	public static void main(String[] args)
	{
		try
		{
			// System.out.println(CinClientVersion.valueFrom("1.0.1"));
			// System.out.println(CinClientVersion.valueFrom("1.3.1"));
			// System.out.println(CinClientVersion.valueFrom("34234.00004.6545"));
			// // System.out.println(CinClientVersion.valueFrom("1.01"));
			// System.out.println(CinClientVersion.valueFrom(""));

			CinClientVersion version = CinClientVersion.valueFrom("1.2.3");
			byte[] buffer = version.toBytes();
			version = CinClientVersion.valueFrom(buffer);
			System.out.println(String.format("buffer.length=%s version=%s", buffer != null ? buffer.length : 0, version));
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
