package com.allstar.cinutil;

import java.util.regex.Pattern;

public class CinEmailUtil
{
	private final static String EmailRegExString = "^([a-z0-9A-Z]+[-|//.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?//.)+[a-zA-Z]{2,}$";
	private static Pattern emailregex = Pattern.compile(EmailRegExString);

	public static boolean isValidEmail(String email)
	{
		return emailregex.matcher(email).matches();
	}
}
