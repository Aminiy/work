package com.allstar.cinutil;

import java.nio.ByteBuffer;
import java.util.Arrays;

public class CinObject
{
	ByteBuffer value;

	public CinObject(byte[] b)
	{
		this.setValue(b);
	}

	public CinObject(Long l)
	{
		if (l != 0)
		{
			int zeros = Long.numberOfLeadingZeros(l);
			int length = 8 - zeros / 8;
			byte[] rawValue = new byte[length];
			for (int i = 0; i < length; i++)
			{
				rawValue[i] = (byte) (l >>> ((i) * 8));
			}
			this.setValue(rawValue);
		}
		else
		{
			this.setValue(new byte[]{(byte) 0});
		}
	}

	public void changeLimit(int i)
	{
		if (value.limit() == i)
			return;
		ByteBuffer bf = ByteBuffer.allocate(i);
		bf.put(getBytes());
		value = bf;
	}

	public CinObject(String str)
	{
		this.setValue(str.getBytes());
	}

	public void setValue(byte[] value)
	{
		if (value != null && value.length > 255)
		{
			this.value = null;
		}
		else
		{
			this.value = ByteBuffer.wrap(value);
		}
	}

	public boolean isNull()
	{
		for (byte b : value.array())
		{
			if (b != (byte) 0)
				return false;
		}
		return true;
	}

	public byte[] getBytes()
	{
		return value.array();
	}

	@Override
	public boolean equals(Object obj)
	{
		return (obj != null) && (Arrays.equals(this.getBytes(), ((CinObject) obj).getBytes()));
	}

	public long getInt64()
	{
		if (getBytes().length > 8)
			return -1;
		byte[] buff = new byte[8];
		int i = 7;
		for (byte b : getBytes())
		{
			buff[i--] = b;
		}
		return ByteBuffer.wrap(buff).getLong();
	}

	@Override
	public int hashCode()
	{
		int hash = 0;
		for (int i = 0; i < (value.limit() / 2); i++)
		{
			hash = 37 * hash + value.getShort(i * 2);
		}
		return hash;
	}
}
