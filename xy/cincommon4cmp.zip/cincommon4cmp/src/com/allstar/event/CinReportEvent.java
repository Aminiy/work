package com.allstar.event;

public class CinReportEvent
{
	public static final int UserFeedBack = 0x01;
	public static final int IllegalReport = 0x02;
	public static final int StatisticPoints = 0x03;
}
