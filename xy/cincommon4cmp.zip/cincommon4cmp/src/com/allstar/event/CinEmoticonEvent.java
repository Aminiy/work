package com.allstar.event;

public class CinEmoticonEvent
{
	public static final int GetEmoticonList = 0x01;

	public static final int GetEmoticonInfo = 0x02;

	public static final int OrderEmoticon = 0x03;

	public static final int GetOrderEmoticonList = 0x04;

	public static final int CheckOrderEmoticon = 0x05;

	public static final int GetRecommendEmoticonList = 0x06;

	public static final int GetEmoticonKeyWord = 0x07;
}
