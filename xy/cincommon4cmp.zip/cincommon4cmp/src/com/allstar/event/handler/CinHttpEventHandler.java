package com.allstar.event.handler;

import com.allstar.cinstack.message.CinMessage;
import com.allstar.cintracer.CinTracer;
import com.allstar.http.connection.HttpServerConnection;
import com.allstar.http.message.HttpRequest;

public abstract class CinHttpEventHandler
{
	protected static CinTracer _tracer;
	protected HttpServerConnection _connection;
	protected HttpRequest _request;
	protected CinHttpRequestQueryBuilder _builder;
	protected CinMessage _resp;

	public void setConnection(HttpServerConnection connection)
	{
		_connection = connection;
	}

	public void setRequest(HttpRequest request)
	{
		_request = request;
	}

	public void setTracer()
	{
		_tracer = CinTracer.getInstance(getClass());
	}

	public abstract void handle() throws Exception;
}
