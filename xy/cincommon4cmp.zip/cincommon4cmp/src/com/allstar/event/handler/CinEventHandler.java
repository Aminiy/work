package com.allstar.event.handler;

import com.allstar.cinstack.transaction.CinTransaction;

public abstract class CinEventHandler
{
	protected CinTransaction _transaction;

	public abstract void handle() throws Exception;

	void setTransaction(CinTransaction transaction)
	{
		this._transaction = transaction;
	}
}
