package com.allstar.event.handler;

import com.allstar.http.connection.HttpConnection;
import com.allstar.http.message.HttpRequest;

public interface CinHttpRequestQueryBuilder
{
	void buildRequestQuery(HttpConnection connection, HttpRequest request);
}
