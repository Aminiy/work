package com.allstar.event.handler;

import java.net.URL;
import java.util.HashMap;

import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinTextUtil;
import com.allstar.exception.CinDuplicatedKeyException;
import com.allstar.http.connection.HttpServerConnection;
import com.allstar.http.message.HttpRequest;
import com.allstar.http.message.HttpResponse;
import com.allstar.http.message.HttpResponseCode;

public class CinHttpEventHandlerManager
{
	private static CinTracer _tracer = CinTracer.getInstance(CinHttpEventHandlerManager.class);
	private static HashMap<String, Class<? extends CinHttpEventHandler>> _handlers;

	public static void initialize(String method, Class<? extends CinHttpEventHandler> handler) throws CinDuplicatedKeyException
	{
		if (_handlers == null)
			_handlers = new HashMap<String, Class<? extends CinHttpEventHandler>>();

		put(method, handler);
	}

	public static CinHttpEventHandler getHandler(HttpServerConnection connection, HttpRequest request)
	{
		try
		{
			URL url = request.getURL();
			String methodname = url.getPath().substring(url.getPath().lastIndexOf(CinTextUtil.SLASH) + 1);

			if (_handlers.containsKey(methodname.toLowerCase()))
			{
				CinHttpEventHandler handler = _handlers.get(methodname.toLowerCase()).newInstance();
				handler.setTracer();
				handler.setConnection(connection);
				handler.setRequest(request);
				return handler;
			}
			else
			{
				HttpResponse resp = new HttpResponse(HttpResponseCode.NOTFOUND, request);
				connection.sendResponse(resp);
			}
		}
		catch (Exception e)
		{
			_tracer.error("Handle Http request error," + request.toString(), e);
		}
		return null;
	}

	private static void put(String method, Class<? extends CinHttpEventHandler> value) throws CinDuplicatedKeyException
	{
		if (!_handlers.containsKey(method.toLowerCase()))
			_handlers.put(method.toLowerCase(), value);
		else
			throw new CinDuplicatedKeyException();
	}
}
