package com.allstar.event.handler;

import java.util.HashMap;

import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cintracer.CinTracer;
import com.allstar.exception.CinDuplicatedKeyException;

public class CinEventHandlerManager
{
	public static final int DefaultEventValue = 0;
	private static CinTracer _tracer = CinTracer.getInstance(CinEventHandlerManager.class);
	private static HashMap<Byte, HashMap<Integer, Class<? extends CinEventHandler>>> _handlers;

	public static void initialize(byte method, Integer event, Class<? extends CinEventHandler> handler) throws CinDuplicatedKeyException
	{
		if (_handlers == null)
			_handlers = new HashMap<Byte, HashMap<Integer, Class<? extends CinEventHandler>>>();

		put(method, event, handler);
	}

	public static CinEventHandler getHandler(CinTransaction transaction)
	{
		try
		{
			byte method = transaction.getRequest().getMethod();
			if (_handlers.containsKey(Byte.valueOf(method)))
			{
				Integer event = transaction.getRequest().containsHeader(CinHeaderType.Event) && transaction.getRequest().Event.isNotNullValue() ? (int) transaction.getRequest().Event.getInt64() : DefaultEventValue;

				if (_handlers.get(method).containsKey(event))
				{
					CinEventHandler handler = _handlers.get(method).get(event).newInstance();
					handler.setTransaction(transaction);
					return handler;
				}
				else
					return null;
			}
			else
				return null;
		}
		catch (Exception e)
		{
			_tracer.error("Get Handler Exception ", transaction.getRequest(), e);
			return null;
		}
	}

	private static void put(byte method, Integer event, Class<? extends CinEventHandler> value) throws CinDuplicatedKeyException
	{
		if (!_handlers.containsKey(Byte.valueOf(method)))
			_handlers.put(Byte.valueOf(method), new HashMap<Integer, Class<? extends CinEventHandler>>());
		if (_handlers.get(Byte.valueOf(method)).containsKey(event))
			throw new CinDuplicatedKeyException();
		_handlers.get(Byte.valueOf(method)).put(event, value);
	}
}
