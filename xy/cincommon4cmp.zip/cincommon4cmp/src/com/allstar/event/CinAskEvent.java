package com.allstar.event;

public class CinAskEvent
{
	/** Get the client's most recent active time */
	public static final int GetLastAliveTime = 0x02;

}
