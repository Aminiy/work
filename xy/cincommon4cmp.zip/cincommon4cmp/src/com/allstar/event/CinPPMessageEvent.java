package com.allstar.event;

public class CinPPMessageEvent
{
	public static final int SendPPMessage = 0x01;
	public static final int GetOfflinePPMessage = 0x02;
}
