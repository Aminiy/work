package com.allstar.event;

public class CinSipEvent
{
	public static final int Logon = 0x01;

	public static final int Logoff = 0x02;

	public static final int Keepalive = 0x03;

	public static final int Option = 0x04;

	public static final int Info = 0x05;

	public static final int AuthToken = 0x06;

	public static final int Message = 0x07;
	
	/**
	 * Message receipt
	 */
	public static final int Imdn = 0x08;
	
	public static final int VoWifi = 0x08;
}
