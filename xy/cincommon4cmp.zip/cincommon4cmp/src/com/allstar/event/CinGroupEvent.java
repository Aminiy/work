/**
 * 
 */
package com.allstar.event;


public class CinGroupEvent
{

	/**
	 * Change the group of information
	 */
	public static final int GroupInfoUpdate = 1;

	/**
	 * Invited into the group members
	 */
	public static final int GroupInviteBuddy = 2;

	/**
	 * Exit the group
	 */
	public static final int GroupQuit = 3;

	/**
	 * Group offlinemessage initialization/access group
	 */
	public static final int GroupInitialize = 4;

	/**
	 * Get group List
	 */
	public static final int GroupGetGroupList = 5;

	/**
	 * Change group set
	 */
	public static final int GroupSetUpdate = 6;
	
	/**
	 * Scan the qr code to get group of basic information
	 */
	public static final int GetGroupBasicInfo = 7;
	
	/**
	 * Scan the qr code to get group of basic information
	 */
	public static final int JoinGroup = 8;
	
	public static final int UpdateMessageType = 9;

	/**
	 * Group members invited
	 */
	public static final int GroupNewJoinedNotify = 0x10;

	/**
	 * Group updated notice
	 */
	public static final int GroupInfoUpdateNotify = 0x11;

	/**
	 * Members change notification
	 */
	public static final int GroupBuddyUpdateNotify = 0x12;

	/**
	 * Exit the group members
	 */
	public static final int GroupQuitNotify = 0x13;

	/** Group of profile modification notification (0x14) */
	public static final int GroupSetNotify = 0x14;
	
	/** Join the group of notice(0X15) */
	public static final int JoinGroupNotify = 0x15;
	
	public final static int UpdateGroupPortrait = 0x16;
	
	public final static int GetGroupPortrait = 0x17;
	
	public final static int GroupPortraitChangedNotify = 0x18;
	
	public final static int GetGroupListForNewClient = 0x20;
	public final static int GetUserGroupProfile = 0x21;
	public final static int TransferGroupAdmin = 0x22;
	
	public final static int DissolutionGroup = 0x23;
	
	public final static int TransferGroupAdminNotifyForMembers = 0x30;	
	public final static int TransferGroupAdminNotifyForNewAdmin = 0x31;
	
	


	public static final int ACK = ((byte) 0X80);

}
