package com.allstar.event;

public class CinObservationEvent
{

	public static final int ReinitializeObserver = 0x00;
	public static final int GetConfigVersionForEachModule = 0xFF;

	/** Query the user registration information (phone number, UserID, status, update time, registration time) */
	public static final int UserRegistInfoObserver = 0x01;

	/** The query cache user activation code */
	public static final int UserCheckCodebserver = 0x02;

	/** Monthly quota remaining query messages*/
	public static final int QuerySMSQuotaObserver = 0x03;

	/** Clear message quota */
	public static final int ClearSMSQuotaObserver = 0x04;

	public static final int UserContactInfoObserver = 0x05;

	public static final int UserSubscriptionInfo = 0x06;

	/** To UCC query the UserInfo */
	public static final int QueryUserInfo = 0x07;

	/** To UCC query the UserProfile */
	public static final int QueryUserProfile = 0x08;

	/** Query opened subscribers */
	public static final int QueryRegistUserCount = 0x09;

	/** To track the status of users online */
	public static final int QueryUserPresense = 0x0A;

	/** Modify the user information */
	public static final int UpdateUserData = 0x0B;

	/** smsr Add a blacklist */
	public static final int SMSrAddMobile = 0x0C;

	/** smsr delete a blacklist */
	public static final int SMSrRemoveMobile = 0x0D;

	/** smsr query a blacklist */
	public static final int SMSrCheckMobile = 0x0E;

	/** smsr Get full amount blacklists */
	public static final int SMSrGetAllMobile = 0x0F;

	/** Remove the user's registration information, from the Cache of RGC delete user registration information */
	public static final int ClearUserRegistCache = 0x10;

	/** Remove the user's frequency limited information in the registration process */
	public static final int ClearUserRegistSQC = 0x11;

	public static final int ReinitBetaTestUser = 0x12;

	public static final int RegBySMSAdapter = 0x13;

	public static final int KeepAliveBySMSAdapter = 0x14;

	public static final int QuitBySMSAdapter = 0x15;
	
	/** Refresh the apc data **/
	public static final int UpdateAPPCache = 0x21;
}
