package com.allstar.event;

public class CinServiceEvent
{
	public static final int InviteContactViaEmail = 0x03;

	public static final int InviteContactViaMobile = 0x04;

	public static final int AddOrRemoveBlackContact = 0x05;

	public static final int GetBlackContact = 0x06;

	public static final int CheckMobiles = 0x07;

	public static final int UpdateUserInfo = 0x08;

	public static final int UploadPortraitThumb = 0x09;

	public static final int UpdateMobile = 0x10;

	public static final int DownloadThumbPackage = 0x0A;

	public static final int DeleteThumbPackage = 0x11;
	// bdc
	public static final int GetRegionInfo = 0x0B;
	
	public static final int DeleteReverseContact = 0x12;
	
	public static final int AddOrRemoveHideContact = 0x13;
	
	public static final int GetHideListContact = 0x14;
	
	public static final int DeleteRecommendContact = 0x15;
	
	public static final int GetBasePermissionList = 0x16;

	// ACP Qr code to log in
	public static final int CheckCredentialForQRCode = 0x0C;
	public static final int AllowLogon = 0x0D;

	// CONC Collect the contact
	public static final int CollectContact = 0x0E;

	public static final int FindReverseContact = 0x17;
	
	public static final int Client2ServerContactChanged = 0x18;

	// 0x2? signaling, unified as client switch related signaling, please do not
	// occupy

	public static final byte SetHiddenPassword = 0x20;
	
	public static final byte SetDNDInterval = 0x21;// Don't disturb the switch

	public static final byte SetPushOpen = 0x22;// Push switch

	public static final byte SetPushType = 0x23;// PushType switch

	public static final byte RoamClientSetting = 0x25;// Roaming the client
														// switches
	public static final byte OnlineStatusSetting = 0x26;
	public static final byte PushPreview = 0x27; // Push Message is Preview switch
	
	public static final byte SetMessageReadReplyType = 0x28;

	public static final byte GetSwitch = 0x2F;// Get all the switch state

	// service poc is used 0x30-3f
	public static final int PortraitGetActiveCount = 0x30;
	public static final int PortraitDelete = 0x34;
	public static final int PortraitDeleteRemark = 0x35;
	public static final int PortraitGetRemark = 0x36;

	// Queries remaining free SMS quotas
	public static final int QueryLeftSmsQuota = 0x40;
	public static final int ChangedLanguage = 0x41;
	
	/**
	 * Set push token for client
	 */
	public static final byte SetPushToken = 0x42;
	
	public static final byte GetSharingCredential4Client = 0x43;
	
	// To report 0x4C-0x4F
	public static final int Complaint = 0x4C;
	public static final int SearchWithMobileNo = 0x5D;

	/**
	 * Collect messages
	 */
	public static final int GetCollectMessageList = 0x61;

	public static final int AddCollectMessage = 0x62;

	public static final int DeleteCollectMessage = 0x63;

	public static final int GetCollectMessageInfo = 0x64;

	public static final int GetUserCollectSpaceInfo = 0x65;

	/**
	 * Audio and video related
	 */
	public static final int RtmInvite = 0x90;
	public static final int RtmInviteSession = 0x91;
	public static final int RtmAck = 0x92;
	public static final int RtmBye = 0x93;
	
	/**
	 * Jio Money Proxy
	 */
	public static final byte GetChecksumSeed = 0x50;
	public static final byte CheckUserAccount = 0x51;
	public static final byte GetUserAccount = 0x52;
	public static final byte GetAccountBanance = 0x53;
	public static final byte GetTransaction = 0x54;
	public static final byte SendOTP = 0x55;
	public static final byte UnLink = 0x56;
	public static final byte UpdateTransaction = 0x57;
	public static final byte VerifyOTP = 0x58;
	public static final byte fetchTransaction = 0x59;
	public static final byte PPSendMessage = 0x5A;
	public static final byte SignUpChecksum = 0x5B;
	public static final byte LoadMoneyChecksum = 0x5C;
	public static final byte LimitBreachChecksum = 0x5E;
}
