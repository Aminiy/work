package com.allstar.event;

public class CinDPServiceEvent
{
	public static final long INITIALIZE_VERSION = 0x01;
	public static final long INITIALIZE = 0x02;
	public static final long CHECK_SUBSCRIBED_FROM_PARTNER = 0x10;
	public static final long GET_SUBSCRIBED_ROBOT_LIST = 0xA1;
	public static final long SET_SUBSCRIBED_STAMP = 0xA2;
	public static final long CLIENT_UPGRADE = 0xA3;
	public static final long GET_SUBSCRIBED_ROBOT_USER_LIST = 0xA4;
}