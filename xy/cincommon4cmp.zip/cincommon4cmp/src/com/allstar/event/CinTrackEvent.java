package com.allstar.event;
public class CinTrackEvent
{
	public static final int GetReferralCode = 0x01;
	
	public static final int GetReferralDetail = 0x02;
	
	public static final int SaveReferralDetail = 0x03;
	
	public static final int GetReferralCount = 0x04;

}
