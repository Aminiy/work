package com.allstar.event;

public class CinVerifyEvent
{
	public static final byte GET_PIC_CODE = 0x01;
	public static final byte VERIFY_PIC_CODE = 0x02;
	public static final byte CHECK_COUNTER = 0x03;
}
