package com.allstar.event;

public class CinConfigEvent
{
	public static final int LoadPrimaryConfig = 0x01;
	public static final int PrimaryConfigUpdated = 0x02;
	public static final int LoadSecondaryConfig = 0x03;
	public static final int SecondaryConfigUpdated = 0x04;
	public static final int LoadThirdConfig = 0x05;
	public static final int ThirdConfigUpdated = 0x06;
}
