package com.allstar.event.filter;

import java.util.HashMap;

import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionCreatedEvent;

public class EventFilterTransactionCreated implements CinTransactionCreatedEvent
{
	EventFilterHandler[] _handlers;

	private HashMap<Byte, EventFilterHandler> handlerpool;

	public EventFilterTransactionCreated(EventFilterHandler... handlers)
	{
		_handlers = handlers;
		handlerpool = new HashMap<Byte, EventFilterHandler>();
		for (EventFilterHandler h : handlers)
		{
			handlerpool.put(h.getEvent(), h);
		}
	}

	@Override
	public void onCinTransactionCreated(CinTransaction trans)
	{
		byte event = (byte) trans.getRequest().Event.getInt64();
		if (handlerpool.containsKey(event))
			handlerpool.get(event).handle();
		else
			trans.sendResponse(CinResponseCode.NotSupport);
	}
}
