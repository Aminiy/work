package com.allstar.event.filter;

public abstract class EventFilterHandler
{
	private byte _event;

	public EventFilterHandler(byte event)
	{
		_event = event;
	}

	public Byte getEvent()
	{
		return _event;
	}

	abstract void handle();
}
