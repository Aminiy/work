package com.allstar.event.filter;

import com.allstar.cinstack.message.CinMessage;

public class EventProducer
{
	public static void send(CinMessage msg)
	{
		//CinRequest req = new CinRequest(CinRequestMethod.EventFilter);
		//req.addBody(msg.toBytes());
		//CinRouter.setRoute(req, CinServiceName.EventFilterCenter);

		//CinStack.instance().createTransaction(req).SendRequest();
	}
}
