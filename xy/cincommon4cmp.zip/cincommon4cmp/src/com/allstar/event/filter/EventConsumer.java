package com.allstar.event.filter;


public class EventConsumer
{
	public static void initialize(EventFilterHandler handler)
	{
		//CinStack.instance().registerTransactionCreated(CinRequestMethod.EventFilter, new EventFilterTransactionCreated(handler));
	}
}
