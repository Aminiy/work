package com.allstar.event.filter;

import com.allstar.cinconfig.CinConfigEntity;
import com.allstar.cinconfig.CinConfigInterface;

public class EventFilterConfig extends CinConfigInterface
{

	@Override
	protected void setValues(CinConfigEntity config)
	{
	}
}
