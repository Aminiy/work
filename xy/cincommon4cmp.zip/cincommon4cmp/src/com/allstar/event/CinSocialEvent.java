package com.allstar.event;
public class CinSocialEvent
{
	public static final int PublishTopic = 0x01; // publish new topic 
	public static final int PublishComment = 0x02; // add comment
	public static final int PublishPraise = 0x03; // praise topic

	public static final int DeleteTopic = 0x04; // delete topic
	public static final int DeleteComment = 0x05; // delete comment
	public static final int DeletePraise = 0x06; // cancel prise

	public static final int GetTopicList = 0x07; // get list of  TopicId and topicversion
	public static final int GetSocialInfo = 0x08; // get a detail info of a Topic 

	public static final int SetCover = 0x09; // set cover image
	public static final int GetCover = 0x0A; // get cover image

	public static final int GetSocialContactList = 0x21; // get contact list
	public static final int AddFriendApplication = 0x22; // add friend
	public static final int ApproveAddFriendApplication = 0x24;
	public static final int DeleteFriend = 0x26;
	
	public static final int updateUserAccountType = 0x10; //update account
	
	public final static int SetReceiveHighPermission = 0x27; // Hide user’posts
	public final static int SetSendHighPermission = 0x29; // Do Not Share My Post
	public final static int GetHighPermission = 0x2B; // Get List(Hide user’posts + Do Not Share My Post)
}