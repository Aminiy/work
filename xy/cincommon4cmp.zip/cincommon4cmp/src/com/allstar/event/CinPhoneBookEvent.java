package com.allstar.event;

public class CinPhoneBookEvent
{
	public static final int UploadPhonebookData = 0x01;

	public static final int DownloadPhonebookData = 0x02;
	
	public static final int CollectMobileno = 0x03;
	
	public static final int DownloadCollectMobileno = 0x04;
	
	public static final int PhoneBookBackUp = 0x05;
	
	public static final int GetPhoneBookBackUpList = 0x06;
	
	public static final int RestorePhoneBook = 0x07;
	
	public static final int PCPhoneBookBackUp = 0x08;
	
	public static final int ApprovalOrDenial = 0x09;
	
	public static final int PhoneUploadPhonebook = 0x0A;
	
	public static final int PCDownloadPhonebook = 0x0B;
	
	public static final int PCCancelSyncPhonebook = 0x0C;
}
