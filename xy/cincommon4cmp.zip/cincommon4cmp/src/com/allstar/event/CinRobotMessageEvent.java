package com.allstar.event;

public class CinRobotMessageEvent
{
	public static final int UserReplyRMCMessage = 0x01;
	public static final int GetOfflineRMCMessage = 0x02;
}
