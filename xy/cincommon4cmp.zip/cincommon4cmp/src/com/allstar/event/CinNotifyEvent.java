package com.allstar.event;

/**
 * When the Notify request with the Event value in [0X01,0X2F] is sent to the client through the MSC, the MSC transparently transmits the request to the currently online client of the To header.
 * 
 * If you need to filter out the current client, the PID of the current client into the requested FPID header
 * 
 * When the Notify request of other Event values ​​needs to be sent through the MSC, the MSC processes the information again according to the logic.
 * 
 * 
 */
public class CinNotifyEvent
{
	public static final int SyncClientDevice = 0x01;
	public static final int ContactsChanged = 0x02;
	public static final int BlackListChanged = 0x03;

	/**
	 * Collect notification message change other client
	 */
	public static final int CollectMesVersionChanged = 0x04;

	public static final int ReverseVersionChanged = 0x05;

	public static final int PortraitIdChanged = 0x06;

	public static final int SetDndTime = 0x07;

	public static final int UserSettingChange = 0x08;

	public static final int OnlineStatusSettingChange = 0x09;

	public static final int UserLogoff = 0x0A;

	public static final int BuddyRecommandation = 0x0B;

	public static final int OnlineStatusChanged = 0x0C;

	// Remaining free SMS quota notification
	public static final int SmsLeftQuotaNotify = 0x0D;

	public static final int PushPreviewStatusChanged = 0x0E;

	/** User activated login notification */
	public static final int UserRegistNotify = 0x0F;

	/** Notify the PC client when the phone client goes online */
	public static final int NotifyPCClientOnlineOffline = 0x10;
	/**
	 * The contact
	 */
	public static final int ReverseContactOfflineNotify = 0x11;
	/** After the user's contact is changed, notify the PC client */
	public static final int NotifyPCContactChanged = 0x12;
	public static final int CollectMobilenoVersionChanged = 0x14;
	public static final int PhoneBookVersionChanged = 0x15;
	public static final int ContactsVersionUpdated = 0x16;
	public static final int BlocklistVersionUpdated = 0x17;
	public static final int AddedAsBuddy = 0x18;
	public static final int NotifyPhoneManualSyncPhonebook = 0x19;
	public static final int NotifyPCApprovalOrDenial = 0x1A;
	public static final int NotifyPCDownloadPhonebook = 0x1B;
	public static final int NotifyPCPhoneNotOnline = 0x1C;
	public static final int NotifyPhoneCancelOperate = 0x1D;
	public static final int NotifyPCCancelOperate = 0x1E;
	public static final int RecommendContactNotity = 0x1F;

	/** Public platform users subscribe to unsubscribe notification public platform users subscribe to unsubscribe notice */
	public static final int PPSubNotify = 0x20;

	/** Hide password or notification after list changes */
	public static final int HiddenPwdChangedNotify = 0x21;
	public static final int HiddenListChangedNotify = 0x22;

	/** When the number of unread messages changes, notify the other clients of the current number of unread messages on each session */
	public static final int UnReadMessageNumNotify = 0X23;
	public static final int BasePermissionChangedNotification = 0x24;
	public static final int MessageReadSwtichChanged = 0x25;

	/** System alerts */
	public static final int SystemNotify = 0x3F;

	/** Set message Read message is sent to the message sender */
	public static final int MsgReadReplyTypeNotify = 0x31;

	/**
	 * Audio and video related
	 */
	public static final int RtmInvite = 0x50;
	public static final int RtmInviteSession = 0x51;
	public static final int RtmAck = 0x52;
	public static final int RtmBye = 0x53;
	public static final int RtmUdpBindFailed = 0x54;
	public static final int RtmNotify = 0x54;
}
