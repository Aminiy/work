package com.allstar.event;

public class CinVideoEvent
{

	// Up====================================================
	public static final int CreateSession = 0x01;

	public static final int AddMembers = 0x02;

	public static final int removeMembers = 0x03;

	public static final int GetSessionInfo = 0x04;

	public static final int SessionVoiceToVideoApply = 0x05;

	public static final int SessionVoiceToVideoReply = 0x06;

	public static final int UserEnterSession = 0x07;

	public static final int UserApplyForUpDownPlatform = 0x08;

	public static final int UserRetainOrReturnSession = 0x09;

	public static final int UserApplyForOrActoringToTransferDevice = 0x0A;

	public static final int UserSetChattersImageQuality = 0x0B;

	public static final int InformPackagesCount = 0x0C;

	public static final int UACInviteeSendNotityToInviter = 0x0D;

	// Down====================================================
	public static final int NotifyToAddedMember = 0x21;

	public static final int NotifyForAddingMembers = 0x22;

	public static final int NotifyForRemovingMembers = 0x23;

	public static final int NotifyForVoiceToVideoApplication = 0x24;

	public static final int NotifyForVoiceToVideoReplication = 0x25;

	public static final int NotifyForEnteringSession = 0x26;

	public static final int NotifyForUserUpDownPlatform = 0x27;

	public static final int NotifyForRetainingOrReturningSession = 0x28;

	public static final int NotifyForApplicationForOrActoringToTransferDevice = 0x29;

	public static final int NotifyForDestorySession = 0x2A;

	public static final int NotifyForPackagesCount = 0x2B;

	public static final int UASInviteeSendNotityToInviter = 0x2C;

	/**
	 * Ring notification
	 */
	public static final int NotityForRing = 0x2D;

	public static final int GetCallingSession = 0x31;

	public static final int StartRate = 0x41;

	public static final int UpdateRate = 0x42;

	public static final int StopRate = 0x43;

	public static final int DeviceLogOff = 0x44;

	public static final int DeviceReLogOn = 0x45;
	
    public static final int GetStunTurnServerInfo = 0x13;
	
	public static final int CheckP2PCallEligibility =  0x12;
	
	public static final int CreatRoom = 0x15;
	 
	public static final int CheckKurentoEligibility = 0x16;
	
	public static final int JoinRoom = 0x17;
	
	public static final int LeaveRoom = 0x18;
	
	public static final int KurnetoActiveParticipant = 0x20;
	
	public static final int QuitVideoRoom = 0x35;
	
	public static final int DissolutionGroup = 0x36;
}
