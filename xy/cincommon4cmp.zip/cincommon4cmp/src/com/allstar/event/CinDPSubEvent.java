package com.allstar.event;

public class CinDPSubEvent {
	public static final long SUB_FROM_CLIENT = 0x01;
	public static final long SUB_FROM_PARTNER = 0x02;
	public static final long SUB_TO_PARTNER = 0x03;
	public static final long START_SUB_FROM_PARTNER = 0x10;
	public static final long SUB_TO_RSC = 0xA1;
}