package com.allstar.event;

public class CinInnerServiceEvent
{
	/** UIDC */
	public static final int UIDVERIFICATION = 0x01;
	public static final int CHECK_MOBILENOS = 0x02;

	/** UCC */
	public static final int CHECK_INNERCREDENTIAL = 0x03;;
	public static final int SET_RANDOMCODE = 0x04;
	public static final int SET_PASSWORD = 0x05;
	public static final int SET_TOKEN = 0x06;

	/** SMS frequency validation */
	public static final int SMSSQCCheck = 0x07;// QTC

	public static final int UpdateUserInfoForGroup = 0x08;// CGC

	public static final int ReverseContact = 0x09;

	public static final int CheckReverseContact = 0x0A;

	public static final int GetMobileNoByUserid = 0x0B; // UIDC
	public static final int SET_TOKEN_PC = 0x0C;// For PC Encryption

	/** UCC get the user name card */
	public static final int GetUserProfile = 0x0D;// UCC

	/** UCC users were complaints, banned logging */
	public static final int BlockUser = 0x0E;// UCC

	public static final int OneKeyRegisterUser = 0x11;// ACP
	/**
	 * Activationcenter a key activation SMS gateway sent request
	 */
	public static final int OnekeyActivationEvent = 0x14;// ActivationProxy

	public static final int GetOfflineCSCNotify = 0x16; // CEC

	public static final int RegisterUsingEmail = 0x19; // CEC

	public static final int UpdateUserVersion = 0x1A;// UCC

	// /** New: by fetion password login, registration, fly to cha */
	// public static final int RegistByFetionPwd = 0x1F; // RGC

	// /** Notify the robot subscription platform, user activated or
	// cancellation status changes */
	// public static final int UserRegistryStatusChanged = 0x23;// RSC

	/** Get the user of the UserInfo & UserProfile */
	public static final int GetPidBatch = 0x20; // UCC

	/** Get the user of the UserInfo & UserProfile */
	public static final int GetUserWholeData = 0x24; // UCC

	/** GetPid into internal signaling */
	public static final int SetHiddenVersion = 0x25;// UCC

	/** GetPid into internal signaling */
	public static final int GetPid = 0x26;// UCC

	/** GetHashedCredential into internal signaling */
	public static final int GetHashedCredential = 0x27;// UCC

	/** The old activation interface */
	public static final int OldUserRegister = 0x28;// UCC

	/**
	 * Before forthcoming OMC hair after user registration will not read offline messages set to temporarily offline
	 */
	public static final int SetOfflineMessageToTmpState = 0x29;
	public static final int GetPushPreviewSwitch = 0x2A;

	public static final int AddUserRelation = 0x2B;

	public static final int AddReverseUserRelation = 0x2C;

	public static final int RemoveUserRelation = 0x2D;

	public static final int RemoveMultipleAttachment = 0x2E;
	public static final int GetMeessageReadReplySwitch = 0x2F;

	public static final int CreateRobotInfo = 0x31;// UCC
	public static final int UpdatePortrait = 0x32;// UCC

	public static final int GetDefaultPortrait = 0x34;// UCC

	public static final int GetClientSetting = 0x35;// UCC

	public static final int GetPidByDeviceID = 0x38;// UCC

	public static final int KickOffToken = 0x39;// UCC

	public static final int GetDNDTime = 0x40;// UCC

	/** Send a message */
	public static final int DownloadMultimediaIndex = 0x41;// MCC

	public static final int DownloadMultimediaPackage = 0x42;// MCC

	public static final int SendSMSMessage = 0x43;// MCC

	// DTC
	/** Get all the file information **/
	public static final int GetAllFileDataIndex = 0x45;
	/** Delete a file**/
	public static final int DeleteFileDataByKey = 0x46;

	public static final int UpdatePortraitVersion = 0x47;

	// Circle of friends Push
	public static final int APNSCircleFriendsPush = 0x49;

	public static final int SyncConcToSocialCenter = 0x4A;

	// Push to MPP service cache and check Pushtoken
	public static final int CachePushToken2MPP = 0x4B;
	public static final int ClearPushToken4MPP = 0x4C;
//	public static final int CachePushToken2RBC = 0x4D;

	// robot push
	public static final int APNSRobotMessagePush = 0x4E;

	// Ordinary Push
	public static final int APNSPushMessage = 0x50;

	/** VDC between VDCS and transmitting messages */
	public static final int CreateSession = 0x51;

	public static final int RemoveSession = 0x52;

	public static final int AddMembers = 0x53;

	public static final int RemoveMembers = 0x54;

	// Push service synchronization blacklist
	public static final int SYNC_BlackList = 0x55;

	/** Inform MSC delete roaming record */
	public static final int DEL_Message = 0x56;

	// Push service to clear the number of blocked messages
	public static final int ClearGroupPushCount = 0x57;

	// Attendance
	public static final int ATSUploadAttendanceRecord = 0x58;
	public static final int ATSGetLastAttendanceRecord = 0x59;

	public static final int RCSinnerLogon = 0x5A;

	/** Blacklist judgment */
	public static final int CheckBlackListUser = 0x60;

	/** Uplink free message to message */
	public static final int UploadSms2Message = 0x61;

	/** Free SMS quota check*/
	public static final int CheckSmsQuota = 0x62;

	/** Send audio and video PUSH through MSC, and record offline notification */
	public static final int SendVDCPushByMSC = 0x63;

	// Audio and video Push
	public static final int APNSVoiceVideoPush = 0x64;

	/** Clear the specified user's SMS quota */
	public static final int ClearSmsQuota = 0x65;

	/**
	 * VDCS video and audio equipment received off-line notification
	 */
	public static final int VideoDeviceLogOff = 0x66;

	public static final int FpidStateChanged = 0x67;

	/**
	 * Get the calling state of the session
	 */
	public static final int GetCallingSession = 0x68;

	/**
	 * Check if there is a calling session
	 */
	public static final int CheckCallingSessionExist = 0x69;

	/**
	 * Check if the calling user is blacklisted
	 */
	public static final int CheckBlackListUserForVideo = 0x6A;

	/**
	 * VDCS video and audio equipment received reconnection notification
	 */
	public static final int VideoDeviceReLogOn = 0x6B;

	/**
	 * The user checks the contact's hidden status
	 */
	public static final int CheckHideContact = 0x6C;
	public static final int InsertRobotidtoUIDC = 0x6D;

	public static final int SmsDeliveryStatus = 0x6E;

	/** SocialCenter */
	public final static int AddBasicPermission = 0x6F;
	public final static int DeleteBasicPermission = 0x70;

	/**
	 * Notify CSC to reset contact information
	 */
	public final static int ResetContact = 0x71;

	/** ask the url that jion jionet */
	public final static int AskJionetUrl = 0x72;

	public final static int DeleteRecommendContact = 0x73;

	public final static int SendRobotMessage = 0x74;

	public final static int UserRegistNotify = 0x75;

	public final static int UserSendRMCMessage = 0x76;

	public static final int MPNSPushMessage = 0x80;

	public static final int MPNSVoiceVideoPush = 0x81;

	public static final int MPNSCircleFriendsPush = 0x82;

	public static final int MPNSTileClean = 0x83;
	
	public static final int MPNSCachePushToken = 0x89;
	
	public static final int MPNSClearGroupPushCount = 0x90;
	
	public static final int CheckUserIsGroupMember = 0x91;

	/**
	 * PortraitCenter 
	 */
	public final static int UpdateGroupPortrait = 0x84;

	public final static int GetGroupPortrait = 0x85;
	
	public final static int GetSharingCredential = 0x86;
	
	/**
	 * RMC
	 */
	public final static int SendInvalidNotify = 0x88;

	/**
	 * Public Platform Temporarily obtain the user's public platform side receive message switch settings
	 */

	public final static int PPAutoFollow = 0x97;

	public final static int GetUserPPMessageSettings = 0x98;

	public final static int SendRequestToAllOnlineUser = 0x99;
	
	//Jio Money
	public static final int SendMoney = 0xA1;
	public static final int PublicSetFocus = 0xA3;
	public static final int GetReceiverMobileNumber = 0xA2;
}
