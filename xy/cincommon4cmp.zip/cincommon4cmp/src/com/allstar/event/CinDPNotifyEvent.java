package com.allstar.event;

public class CinDPNotifyEvent
{
	public static final long ROBOT_INFO_TO_CLIENT = 0x01;
	public static final long ROBOT_LIST_VERSION_TO_CLIENT = 0x02;
	public static final long ROBOT_ID_REMOVE_TO_CLIENT = 0x03;
	public static final long ROBOT_INFO_TO_CLIENT_FOR_SUB = 0x04;
	// public static final long ROBOT_ID_REMOVE_TO_CLIENT_FOR_SUB = 0x05;
	public static final long ROBOT_INFO_TO_CLIENT_FOR_UNSUB = 0x06;
	public static final long ROBOT_ID_REMOVE_TO_CLIENT_FOR_UNSUB = 0x07;
	public static final long ROBOT_ID_TO_RDP_ADD = 0xA1;
	public static final long ROBOT_ID_TO_RDP_REMOVE = 0xA2;
	public static final long SUB_ROBOT = 0xA3;
	public static final long UNSUB_ROBOT = 0xA4;
	public static final long ROBOT_USER_LOGON_NOTIRY = 0xA5;
}