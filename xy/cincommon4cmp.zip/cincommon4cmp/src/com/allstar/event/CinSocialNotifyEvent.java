package com.allstar.event;

public class CinSocialNotifyEvent
{
	// By @ notice (subject, comment, like)
	public static final int AttentiveNotification = 0x1;
	
	// Friends release theme notice
	public static final int NewTopicNotification = 0x2;
	
	// Add friend application notice
	public static final int AddFriendNotification = 0x3;
	
	// The other party agrees to add a friend notification
	public static final int ApproveFriendNotification = 0x4;
	
	// Deleted friend notification
	public static final int DeleteFriendNotify = 0x5;
	
	// Agreed to add each other as a friend notification
	public static final int SyncAddFriendNotification = 0x6;
	
	public final static int BasePermissionChangedNotification = 0x07;
	
	public final static int HighPermissionChangedNotification = 0x08;
}
