package com.allstar.event;

public class CinTakeEvent
{
	/**
	 * Get the user information
	 */
	public static final int TakeVisitingCard = 0x01;

	/**
	 * Get all the client information online
	 */
	public static final int TakeClientInfo = 0x02;
}
