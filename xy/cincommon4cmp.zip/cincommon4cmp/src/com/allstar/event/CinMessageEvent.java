package com.allstar.event;

public class CinMessageEvent
{
	public static final int Message = 0x01; // Ordinary message
	public static final int ExchangeMessage = 0x02; // PC and mobile devices
													// each other
	public static final int GetOfflineMessage = 0x03;// Get offline messages
	public static final int GetFormalOffLineMessage = 0x04;// To obtain a formal
															// offline messages

	/** Delete all chat with someone from the server */
	public static final int DeleteAllMessage = 0x05;// To obtain a formal
													// offline messages

	/**
	 * Get news state (the current is to obtain the session state issued the
	 * message)
	 */
	public static final int GetMessageStatus = 0x06;

	/** Get offline notifications about friends circles */
	public static final int GetOfflineSocialNotify = 0X07;

	public static final int DeleteSingleMessage = 0X08;

	/** Get audio and video offline notification */
	public static final int GetOfflineVDCNotify = 0X09;

	/** The status of the update audio / video offline notification is Acquired */
	public static final int UpdateOfflineVDCNotifyStatus = 0X0A;

	/** Clients delete all chat history */
	public static final int DeleteAllSesssionMessage = 0X0B;
	
	/** Message withdrawn */
	public static final int MessageRecall = 0X0C;
	
	public static final int UpdateJMTransaction = 0X0E;
}
