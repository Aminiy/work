package com.allstar.event;

public class CinDPUnSubEvent {
	public static final long UNSUB_FROM_CLIENT = 0x01;
	public static final long UNSUB_FROM_PARTNER = 0x02;
	public static final long UNSUB_TO_PARTNER = 0x03;
	public static final long UNSUB_TO_RSC = 0xA1;
}