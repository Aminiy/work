package com.allstar.event;

public class CinDataEvent
{
	public static final int GetInfo = 0x01;

	public static final int Authen = 0x02;
	
	public static final int KeepAlive = 0x03;
	
	public static final int UploadBegin = 0x11;
	
	public static final int Uploading = 0x12;
	
	public static final int UploadConfirm = 0x13;
	
	public static final int UploadEnd = 0x14;
	
	public static final int UploadCancel = 0x15;
	
	public static final int DownloadBegin = 0x21;
	
	public static final int Downloading = 0x22;
	
	public static final int DownloadConfirm = 0x23;
	
	public static final int DownloadEnd = 0x24;
	
	public static final int DownloadCancel = 0x25;
}
