package com.allstar.event;

public class CinLogonEvent
{
	public static final int CHALLENGE = 0x01;
	public static final int LOGON = 0x02;
	public static final int CHECKCREDENTIAL = 0x03;
	public static final int KEEP_ALIVE = 0x04;
	public static final int LOGOFF = 0x05;
	public static final int DELETE_ACCOUNT = 0x06;
	public static final int KICK_OTHER_CLIENT = 0x08;
}
