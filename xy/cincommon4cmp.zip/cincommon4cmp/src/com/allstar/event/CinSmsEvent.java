package com.allstar.event;

public class CinSmsEvent
{
	/**
	 * Send Register Code SMS
	 */
	//public static final int Send_NO_MT_SMS = 0x01;

	/**
	 * simulator
	 */
	public static final int MT = 0x02;

	/** The establishment of the SMS simulator user connection request */
	public static final int SMSA_BUILDCONNECTION = 0x03;

	/** SMS simulator text messages, reply messages between users */
	public static final int SMSA_SENDMESSAGE = 0x04;

	//public static final int MO = 0x05;

	public static final int MTWITHChildNR = 0x06;

	/** SMSA to distribute short messages to the operator */
	public static final int SMSA_DISPATCHERMESSAGE = 0x07;

	/** Free Message **/
	//public static final int SMSA_FREEMESSAGE = 0x08;

	//public static final int SMSA_BUSINESSMESSAGE = 0x09;

	public static final int SMSBASE_GETGROUP = 0x10;

	public static final int SMSBASE_GETCONTENT = 0x11;

	/**
	 * Standard SMS delivery port support the business scope, please see SMSA SmsType
	 */
	public static final int STANDARD_SEND_SMS = 0x20;
	
	
	

	// -------------Number pool related------------------
	public static final int MNP_AddServiceNo = 0x50;
	public static final int MNP_DeleteServiceNo = 0x51;
	public static final int MNP_GetServiceNo = 0x52;
	public static final int MNP_GetServiceNoStatus = 0x53;
	public static final int MNP_RecycleServiceNo = 0x54;
	public static final int MNP_GetServiceNoRelation = 0x55;
	

}
