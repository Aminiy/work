package com.allstar.event;

public class CinRMCEvent
{
	public static final int GetChannelList = 0x01;
	
	public static final int GetChannelInfo = 0x02;
	
	public static final int Like = 0x03;
	
	public static final int NotificationChannleUpdate = 0x21;
}
