package com.allstar.cinswf;

import java.util.ArrayList;
import java.util.HashMap;

import com.allstar.cinconfig.cinswf.CinSensitiveWordFilter;
import com.allstar.cinconfig.cinswf.SensitiveWord;
import com.allstar.cinconfig.cinswf.SensitiveWordTreatMent;
import com.allstar.cinconfig.cinswf.SensitiveWordsFilterMode;
import com.allstar.cinconfig.cinswf.SensitiveWordsFilterType;
import com.allstar.cinlogger.CinLogger;
import com.allstar.cintracer.CinTracer;

public class SensitiveWordsFilter
{
	private static CinLogger _logger = CinLogger.getInstance();
	private static CinTracer _tracer = CinTracer.getInstance(SensitiveWordsFilter.class);

	private SensitiveWordNode _senstiveWordsTree;
	private byte _type;

	SensitiveWordsFilter(byte type) throws Exception
	{
		long b = System.currentTimeMillis();
		SensitiveWord[] senstiveWords = CinSensitiveWordFilter.getFilter(type);
		SensitiveWord[] preparedWrods = preparedSenstiveWords(senstiveWords);

		_senstiveWordsTree = buildSenstiveTree(preparedWrods);
		long a = System.currentTimeMillis();
		_type = type;
		_tracer.info("New SenstiveWordsTree(Type: " + SensitiveWordsFilterType.getName(_type) + ") has been initialized. Time Costs: " + (a - b) + "ms");
	}

	/**
	 * @param from
	 * @param to
	 * @param str
	 * @param digest
	 *            true count summary false does not calculate the summary of the current two-person conversation and group conversation news is the need to calculate the summary
	 * @return
	 */
	public boolean digestAndSenstiveWords(long from, long to, String str)
	{
		if (null != str)
		{
			try
			{
				return this.containSenstiveWord(from, to, str.toLowerCase());
			}
			catch (Exception e)
			{
				_tracer.error(e.getMessage(), e);
			}
		}
		return false;
	}

	public boolean containSenstiveWord(long from, long to, String str)
	{
		SensitiveWord word = containSenstiveWord(str, _senstiveWordsTree);
		if (word == null)
			return false;

		String tmpword = word.getWord();
		// 1000, The length of this field in the database
		if (str.length() > 1000)
		{
			str = str.substring(0, 1000);
		}

		// 100, The length of this field in the database
		if (tmpword.length() > 100)
		{
			tmpword = tmpword.substring(0, 100);
		}
		SensitiveWordLoggerObject obj = new SensitiveWordLoggerObject(from, to, str, tmpword, _type, word.getMode(), word.getTreatment());
		_logger.send(obj);

		// If you set the sensitive word processing is blocked or more rigorous test
		if (word.getTreatment() <= SensitiveWordTreatMent.BLOCK)
			return true;

		// Other ways: do not stop, only log, or suffix (plus suffix)
		else
			return false;
	}

	private SensitiveWord containSenstiveWord(String str, SensitiveWordNode tree)
	{
		HashMap<Integer, ArrayList<Character>> compositeMap = new HashMap<Integer, ArrayList<Character>>();
		HashMap<Integer, Integer> filteredMap = new HashMap<Integer, Integer>();
		for (int i = 0; i < str.length(); i++)
		{
			ArrayList<SensitiveWordNode> nodes = tree.containSenstiveWord(str.substring(i));
			for (SensitiveWordNode node : nodes)
			{
				for (SensitiveWord word : node.getWords().values())
				{
					switch (word.getMode())
					{
						case SensitiveWordsFilterMode.PHRASE:
							int specialCount = 0;
							int nomalCount = 0;
							int j = 0;
							for (j = i; j < str.length(); j++)
							{
								if (nomalCount >= node.getLevel())
									break;

								if (SpecialCharaterContainer.getInstance().containSpecailCharater(str.charAt(j)))
									specialCount++;
								else
									nomalCount++;
							}

							if (i >= 1 && SensitiveWordsFilterUtils.beginWithEnglishLetter(str.substring(i - 1)))
								return null;
							if (i + node.getLevel() + specialCount >= str.length())
								return word;
							if (SensitiveWordsFilterUtils.isEnglishLetter(str.charAt(i + node.getLevel() + specialCount)))
								return null;
							return word;
						case SensitiveWordsFilterMode.COMPOSITE:

							if (!compositeMap.containsKey(word.getId()))
								compositeMap.put(word.getId(), new ArrayList<Character>());

							ArrayList<Character> tempList = compositeMap.get(word.getId());
							if (!tempList.contains(node.getValue()))
								tempList.add(node.getValue());
							if (tempList.size() >= word.getCount())
								return word;

						break;
						case SensitiveWordsFilterMode.RELATEDWORD:
							if (filteredMap.containsKey(word.getId()))
							{
								if (filteredMap.get(word.getId()) == 1)
									return word;
							}
							else
							{
								filteredMap.put(word.getId(), 2);
							}
						break;
						case SensitiveWordsFilterMode.FILTERED:
							if (!word.hasRelatedWord())
								return word;
							if (filteredMap.containsKey(word.getId()))
								return word;
							filteredMap.put(word.getId(), 1);
						break;
						default:
							return word;
					}
				}
			}
		}
		return null;
	}

	private SensitiveWord[] preparedSenstiveWords(SensitiveWord[] words)
	{
		CollectWordsHandler handler1 = new CollectWordsHandler();
		EnhanceFilteredScopeHandler handler3 = new EnhanceFilteredScopeHandler();
		handler1.setSuccessor(handler3);
		return handler1.handle(words);
	}

	private SensitiveWordNode buildSenstiveTree(SensitiveWord[] words)
	{
		SensitiveWordNode sentiveWordsTree = new SensitiveWordNode((char) Character.NON_SPACING_MARK, null);
		for (int i = 0; i < words.length; i++)
		{
			SensitiveWordNode parentNode = sentiveWordsTree;
			for (int j = 0; j < words[i].getWord().length(); j++)
			{
				Character c = words[i].getWord().charAt(j);
				parentNode = parentNode.addChildNode(c);
			}
			parentNode.setLevel((byte) words[i].getWord().length());
			parentNode.addWord(words[i]);
		}

		return sentiveWordsTree;
	}
}
