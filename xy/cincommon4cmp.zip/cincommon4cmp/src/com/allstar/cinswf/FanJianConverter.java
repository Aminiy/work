package com.allstar.cinswf;

class FanJianConverter
{
	private static String _simpleSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static String _tranditionSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

	static char traditionalized(char c)
	{
		int index = _simpleSet.indexOf(c);
		if (index != -1)
			return _tranditionSet.charAt(index);
		else
			return Character.UNASSIGNED;
	}

	static String traditionalized(String st)
	{
		String stReturn = "";
		for (int i = 0; i < st.length(); i++)
		{
			char temp = st.charAt(i);
			int index = _simpleSet.indexOf(temp);
			if (index != -1)
				stReturn += _tranditionSet.charAt(index);
			else
				stReturn += temp;
		}
		return stReturn;
	}

	static char simplized(char c)
	{
		int index = _tranditionSet.indexOf(c);
		if (index != -1)
			return _simpleSet.charAt(index);
		else
			return Character.UNASSIGNED;
	}
	static String simplized(String st)
	{
		String stReturn = "";
		for (int i = 0; i < st.length(); i++)
		{
			char temp = st.charAt(i);
			int index = _tranditionSet.indexOf(temp);
			if (index != -1)
				stReturn += _simpleSet.charAt(index);
			else
				stReturn += temp;
		}
		return stReturn;
	}
}
