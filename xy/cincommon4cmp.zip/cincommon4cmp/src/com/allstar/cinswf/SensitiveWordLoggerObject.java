package com.allstar.cinswf;

import com.allstar.cinlogger.CinLoggerIObject;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinutil.CinUtil;

public class SensitiveWordLoggerObject implements CinLoggerIObject
{
	private static final String _tableName = "cin_senstivewordlog";

	private long _from = 0L;
	private long _to = 0L;
	private long _datetime = 0L;
	private String _message = null;
	private String _sensitiveword = null;
	private byte _type = 0;
	private byte _mode = 0;
	private int _treatment = 0;

	public SensitiveWordLoggerObject(long from, long to, String message, String sensitiveword, byte type, byte mode, int treatment)
	{
		_from = from;
		_to = to;
		_datetime = System.currentTimeMillis();
		_message = message;
		_sensitiveword = sensitiveword;
		_type = type;
		_mode = mode;
		_treatment = treatment;
	}

	@Override
	public CinMessage toMessage()
	{
		CinMessage msg = new CinMessage((byte) 1);
		msg.addHeader(new CinHeader((byte) 1, _from));
		msg.addHeader(new CinHeader((byte) 2, _to));
		msg.addHeader(new CinHeader((byte) 3, _datetime));
		try
		{
			msg.addHeader(new CinHeader((byte) 4, CinUtil.getBytes(_message.getBytes("UTF-8"), 255)));
		}
		catch (Exception ex)
		{
			msg.addHeader(new CinHeader((byte) 4, ""));
		}
		
		try
		{
			msg.addHeader(new CinHeader((byte) 5, CinUtil.getBytes(_sensitiveword.getBytes("UTF-8"), 255)));
		}
		catch (Exception ex)
		{
			msg.addHeader(new CinHeader((byte) 5, ""));
		}
		
		msg.addHeader(new CinHeader((byte) 6, _type));
		msg.addHeader(new CinHeader((byte) 7, _mode));
		msg.addHeader(new CinHeader((byte) 8, _treatment));

		return msg;
	}

	@Override
	public String TableName()
	{
		return _tableName;
	}

}
