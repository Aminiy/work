package com.allstar.cinswf;

import java.util.concurrent.ConcurrentHashMap;

public class CaseConverter
{
	private static String _bjSet = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ~!@#$%^&*()[]";
	private static String _qjSet = "１２３４５６７８９０ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ～！＠＃＄％…＆×（）【】";

	private static ConcurrentHashMap<Character, Character> _q2bMap;
	private static ConcurrentHashMap<Character, Character> _b2qMap;

	static void initialize()
	{
		_q2bMap = new ConcurrentHashMap<Character, Character>();
		_b2qMap = new ConcurrentHashMap<Character, Character>();
		String bjTemp = _bjSet.toLowerCase();
		String qjTemp = _qjSet.toLowerCase();
		for (int i = 0; i < _qjSet.length(); i++)
		{
			_q2bMap.put(_qjSet.charAt(i), bjTemp.charAt(i));
			_b2qMap.put(_bjSet.charAt(i), qjTemp.charAt(i));
		}
	}

	static char toQJ(char c)
	{
		int index = _bjSet.indexOf(c);
		if (index != -1)
			return _qjSet.charAt(index);
		else
			return Character.UNASSIGNED;
	}

	static String toQJ(String st)
	{
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < st.length(); i++)
		{
			sb.append(toQJ(st.charAt(i)));
		}
		return sb.toString();
	}

	static char toBJ(char c)
	{
		if (_q2bMap.containsKey(c))
			return _q2bMap.get(c);
		return c;
	}

	static String toBJ(String st)
	{
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < st.length(); i++)
		{
			sb.append(toBJ(st.charAt(i)));
		}
		return sb.toString();
	}
}
