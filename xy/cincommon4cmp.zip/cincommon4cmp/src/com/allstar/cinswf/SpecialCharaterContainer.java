package com.allstar.cinswf;

import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cintracer.CinTracer;

class SpecialCharaterContainer
{
	private static CinTracer _tracer = CinTracer.getInstance(SpecialCharaterContainer.class);
	private static SpecialCharaterContainer _instance;

	private ConcurrentHashMap<Character, Character> _map;

	private SpecialCharaterContainer()
	{
		update(".()`~～?{}[]|:;’<>,/、_《》『』#【】┼┽┾┿╀╁╂╃╄╅╆╇╈╉╊╋╪╫╬▏▎▍▕ㄧ︳±- \\\"!@$%^&*  	");
		_tracer.info("New SpecialString has been initialized");
	}

	boolean containSpecailCharater(char c)
	{
		return _map.containsKey(c);
	}

	void update(String s)
	{
		ConcurrentHashMap<Character, Character> map = new ConcurrentHashMap<Character, Character>();
		for (int i = 0; i < s.length(); i++)
		{
			map.put(s.charAt(i), s.charAt(i));
		}

		_map = map;

	}

	static void initialize()
	{
		if (_instance == null)
			_instance = new SpecialCharaterContainer();
	}

	static SpecialCharaterContainer getInstance()
	{
		return _instance;
	}
}
