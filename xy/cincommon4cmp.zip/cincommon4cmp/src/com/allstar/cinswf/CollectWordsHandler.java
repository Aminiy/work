package com.allstar.cinswf;

import java.util.ArrayList;

import com.allstar.cinconfig.cinswf.SensitiveWord;
import com.allstar.cinconfig.cinswf.SensitiveWordsFilterMode;

class CollectWordsHandler extends SenstiveWordsPrepareHandler
{
	@Override
	public SensitiveWord[] handle(SensitiveWord[] words)
	{
		ArrayList<SensitiveWord> list = new ArrayList<SensitiveWord>();
		for (int i = 0; i < words.length; i++)
		{
			switch (words[i].getMode())
			{
				case SensitiveWordsFilterMode.FILTERED:
					SensitiveWord ww = words[i].cloneWithoutWord(CaseConverter.toBJ(FanJianConverter.simplized(words[i].getWord())));
					list.add(ww);

					if (words[i].getRelatedWords() != null && !words[i].getRelatedWords().isEmpty())
					{
						String[] relatedWords = words[i].getRelatedWords().split(",");
						for (String relatedWord : relatedWords)
						{
							SensitiveWord w = new SensitiveWord(words[i].getId(), relatedWord, SensitiveWordsFilterMode.RELATEDWORD, "", words[i].getTreatment());
							list.add(w);
						}
					}
				break;
				case SensitiveWordsFilterMode.COMPOSITE:
					byte count = Byte.valueOf(words[i].getWord());
					String[] relatedWords = words[i].getRelatedWords().split(",");
					for (String relatedWord : relatedWords)
					{
						SensitiveWord w = words[i].cloneWithoutWord(relatedWord);
						w.setCount(count);
						list.add(w);
					}
				break;
				default:
					list.add(words[i]);
				break;
			}
		}
		if (_handler != null)
			return _handler.handle(list.toArray(new SensitiveWord[list.size()]));
		return list.toArray(new SensitiveWord[list.size()]);
	}
}
