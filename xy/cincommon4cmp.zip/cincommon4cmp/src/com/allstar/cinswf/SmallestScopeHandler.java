package com.allstar.cinswf;

import java.util.ArrayList;

import com.allstar.cinconfig.cinswf.SensitiveWord;

class SmallestScopeHandler extends SenstiveWordsPrepareHandler
{

	@Override
	public SensitiveWord[] handle(SensitiveWord[] words)
	{
		ArrayList<Integer> dupWords = new ArrayList<Integer>();
		for (int i = 0; i < words.length; i++)
		{
			for (int j = i + 1; j < words.length; j++)
			{
				int max = -1;
				int min = -1;
				if (words[i].getWord().length() > words[j].getWord().length())
				{
					max = i;
					min = j;
				}
				else
				{
					max = j;
					min = i;
				}
				if (words[max].getWord().indexOf(words[min].getWord()) >= 0 && !dupWords.contains(max))
				{
					dupWords.add(max);
				}
			}
		}
		SensitiveWord[] ret = new SensitiveWord[words.length - dupWords.size()];
		for (int i = 0, j = 0; i < ret.length && j < words.length; i++, j++)
		{
			while (dupWords.contains(j))
				j++;
			ret[i] = words[j].clone();
		}

		if (_handler != null)
			return _handler.handle(ret);
		return ret;
	}

}
