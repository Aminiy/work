package com.allstar.cinswf;

import java.util.ArrayList;

import com.allstar.cinconfig.cinswf.SensitiveWord;
import com.allstar.cinconfig.cinswf.SensitiveWordsFilterMode;

class EnhanceFilteredScopeHandler extends SenstiveWordsPrepareHandler
{

	@Override
	public SensitiveWord[] handle(SensitiveWord[] words)
	{
		ArrayList<SensitiveWord> list = new ArrayList<SensitiveWord>();
		for (SensitiveWord word : words)
		{
			if (word.getMode() == SensitiveWordsFilterMode.FILTERED)
			{
				ArrayList<SensitiveWord> temp = new ArrayList<SensitiveWord>();
				ArrayList<SensitiveWord> enhanceWord = enhanceScope(word, temp);
				for (SensitiveWord s : enhanceWord)
					list.add(s);
			}
			else
			{
				list.add(word);
			}

		}

		SensitiveWord[] ret = list.toArray(new SensitiveWord[list.size()]);
		if (_handler != null)
			return _handler.handle(ret);
		return ret;
	}

	private static ArrayList<SensitiveWord> enhanceScope(SensitiveWord word, ArrayList<SensitiveWord> list)
	{
		if (word.getWord().length() == 0)
			return list;

		char c1 = word.getWord().charAt(0);
		char c2 = Character.UNASSIGNED;// CaseConverter.toQJ(c1);
		if (c2 == Character.UNASSIGNED)
			c2 = FanJianConverter.traditionalized(c1);

		ArrayList<SensitiveWord> list1 = new ArrayList<SensitiveWord>();
		if (c2 != Character.UNASSIGNED && c1 != c2)
		{
			if (list.isEmpty())
			{
				list1.add(word.cloneWithoutWord(c2));
			}
			else
			{
				for (SensitiveWord s : list)
					list1.add(word.cloneWithoutWord(s.getWord() + c2));
			}
		}
		if (list.isEmpty())
		{
			list1.add(word.cloneWithoutWord(c1));
		}
		else
		{
			for (SensitiveWord s : list)
				list1.add(word.cloneWithoutWord(s.getWord() + c1));
		}
		return enhanceScope(word.cloneWithoutWord(word.getWord().substring(1)), list1);
	}
}
