package com.allstar.cinswf;

import com.allstar.cinconfig.cinswf.SensitiveWord;

abstract class SenstiveWordsPrepareHandler
{
	protected SenstiveWordsPrepareHandler _handler;

	public abstract SensitiveWord[] handle(SensitiveWord[] words);

	public void setSuccessor(SenstiveWordsPrepareHandler handler)
	{
		_handler = handler;
	}
}
