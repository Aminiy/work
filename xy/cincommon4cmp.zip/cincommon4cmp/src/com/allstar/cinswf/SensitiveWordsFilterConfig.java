package com.allstar.cinswf;

import com.allstar.cinconfig.CinConfigEntity;
import com.allstar.cinconfig.CinConfigInterface;
import com.allstar.cintracer.CinTracer;

class SensitiveWordsFilterConfig extends CinConfigInterface
{
	private static CinTracer _tracer = CinTracer.getInstance(SensitiveWordsFilterConfig.class);
	private static SensitiveWordsFilterConfig _instance;

	private String _specialString;

	private SensitiveWordsFilterConfig()
	{
		_tableName = "SenstiveWordsFilter";

		_specialString = ".()`~～?{}[]|:;’<>,/、_《》『』#【】┼┽┾┿╀╁╂╃╄╅╆╇╈╉╊╋╪╫╬▏▎▍▕ㄧ︳±- \"!@$%^&*  	￥＋┌└┐┘─│├┤┬┴	";

	}

	String getSpecialString()
	{
		return _specialString;
	}

	synchronized static void initialize()
	{
		if (_instance == null)
		{
			_instance = new SensitiveWordsFilterConfig();
			_instance.updateConfig();
		}
	}

	static SensitiveWordsFilterConfig getInstance()
	{
		return _instance;
	}

	@Override
	protected void setValues(CinConfigEntity config)
	{
		try
		{
			String specialString = config.get("SpecialString", _specialString);
			if (!_specialString.equals(specialString))
			{
				SpecialCharaterContainer.getInstance().update(specialString);
				_specialString = specialString;
				_tracer.warn("New SpecialString has been updated.");
			}

		}
		catch (Exception ex)
		{
			_tracer.error("Load Configuration Failed.", ex);
		}
	}
}
