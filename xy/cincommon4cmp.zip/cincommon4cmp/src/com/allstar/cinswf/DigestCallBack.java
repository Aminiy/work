/**
 * 
 */
package com.allstar.cinswf;


public abstract class DigestCallBack
{

	protected SensitiveWordsFilter senstiveWordsFilter;

	protected long from;
	protected long to;
	protected String content;

	/**
	 * 
	 * @param canSend
	 *            Can you send it?
	 */
	public abstract void invoke(boolean canSend);

	public void calSenstiveWord()
	{
		boolean isSenstiveWord = senstiveWordsFilter.containSenstiveWord(from, to, content);

		if (isSenstiveWord)
			invoke(false);
		else
			invoke(true);
	}

	public SensitiveWordsFilter getSenstiveWordsFilter()
	{
		return senstiveWordsFilter;
	}

	public void setSenstiveWordsFilter(SensitiveWordsFilter senstiveWordsFilter)
	{
		this.senstiveWordsFilter = senstiveWordsFilter;
	}

	public long getFrom()
	{
		return from;
	}

	public void setFrom(long from)
	{
		this.from = from;
	}

	public long getTo()
	{
		return to;
	}

	public void setTo(long to)
	{
		this.to = to;
	}

	public String getContent()
	{
		return content;
	}

	public void setContent(String content)
	{
		this.content = content;
	}

}
