package com.allstar.cinswf;


public class SenstiveWordsFilterManager
{
//	private static CinTracer _tracer = CinTracer.getInstance(SenstiveWordsFilterManager.class);
//	private static ConcurrentHashMap<Byte, SensitiveWordsFilter> _filters;

	public static void initialize() throws Exception
	{
		CaseConverter.initialize();
		SpecialCharaterContainer.initialize();
		SensitiveWordsFilterConfig.initialize();
	}

	public synchronized static SensitiveWordsFilter getFilter(byte type) throws Exception
	{
		SensitiveWordsFilter filter = new SensitiveWordsFilter(type);
		return filter;
	}
}
