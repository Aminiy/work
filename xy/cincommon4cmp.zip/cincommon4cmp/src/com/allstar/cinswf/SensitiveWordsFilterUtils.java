package com.allstar.cinswf;

class SensitiveWordsFilterUtils
{
	static boolean isEnglishLetter(char c)
	{
		return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
	}

	static boolean beginWithEnglishLetter(String s)
	{
		if (s.length() == 0)
			return false;
		return isEnglishLetter(s.charAt(0));
	}

	static boolean endWithEnglishLetter(String s)
	{
		if (s.length() == 0)
			return false;
		return isEnglishLetter(s.charAt(s.length() - 1));
	}
}
