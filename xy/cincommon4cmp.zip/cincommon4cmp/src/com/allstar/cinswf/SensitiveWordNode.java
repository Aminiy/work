package com.allstar.cinswf;

import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cinconfig.cinswf.SensitiveWord;

class SensitiveWordNode
{
	private char _value;
	private SensitiveWordNode _parentNode;
	private byte _level;
	private int _wordsCount;
	private ConcurrentHashMap<Integer, SensitiveWord> _words;
	private ConcurrentHashMap<Character, SensitiveWordNode> _map;

	SensitiveWordNode(char value, SensitiveWordNode parentNode)
	{
		_value = value;
		_parentNode = parentNode;
		_level = -1;
		_wordsCount = 0;
		_words = new ConcurrentHashMap<Integer, SensitiveWord>();
		_map = new ConcurrentHashMap<Character, SensitiveWordNode>();
	}

	synchronized SensitiveWordNode addChildNode(char childValue)
	{
		if (_map.containsKey(childValue))
			return _map.get(childValue);
		SensitiveWordNode childNode = new SensitiveWordNode(childValue, this);
		_map.put(childValue, childNode);
		return childNode;
	}

	void setLevel(byte level)
	{
		_level = level;
	}

	void addWord(SensitiveWord word)
	{
		if (!_words.contains(word.getId()))
		{
			_words.put(word.getId(), word);
			_wordsCount++;
		}
	}

	char getValue()
	{
		return _value;
	}

	SensitiveWordNode getParentNode()
	{
		return _parentNode;
	}

	byte getLevel()
	{
		return _level;
	}

	ConcurrentHashMap<Integer, SensitiveWord> getWords()
	{
		return _words;
	}

	ArrayList<SensitiveWordNode> containSenstiveWord(String str)
	{
		ArrayList<SensitiveWordNode> list = new ArrayList<SensitiveWordNode>();
		if (SpecialCharaterContainer.getInstance().containSpecailCharater(str.charAt(0)))
			return list;

		return containSenstiveWord(str, this, list);
	}

	private ArrayList<SensitiveWordNode> containSenstiveWord(String str, SensitiveWordNode parentNode, ArrayList<SensitiveWordNode> list)
	{
		if (isEOF() && !list.contains(this))
		{
			list.add(this);
		}

		if (str.length() == 0)
		{
			return list;
		}

		if (SpecialCharaterContainer.getInstance().containSpecailCharater(str.charAt(0)))
			return parentNode.containSenstiveWord(str.substring(1), parentNode, list);

		char c = CaseConverter.toBJ(str.charAt(0));
		SensitiveWordNode childNode = _map.get(c);
		if (childNode == null)
		{
			if (_value == Character.NON_SPACING_MARK)
				return list;

			return list;
		}

		return childNode.containSenstiveWord(str.substring(1), childNode, list);
	}

	private boolean isEOF()
	{
		return _wordsCount != 0;
	}

	void dispose()
	{
		ArrayList<SensitiveWordNode> list = new ArrayList<SensitiveWordNode>();
		for (SensitiveWordNode node : _map.values())
			list.add(node);
		_map.clear();

		_parentNode = null;

		for (SensitiveWordNode node : list)
		{
			node.dispose();
		}
	}

	@Override
	public String toString()
	{
		return toString("");
	}

	String toString(String parentValue)
	{
		StringBuilder sb = new StringBuilder();
		for (Entry<Character, SensitiveWordNode> node : _map.entrySet())
		{
			sb.append(node.getValue().toString(parentValue + _value));
		}
		if (sb.length() == 0)
		{
			sb.append(parentValue);
			sb.append(_value);
			sb.append("\r\n");
		}
		return sb.toString();
	}
}
