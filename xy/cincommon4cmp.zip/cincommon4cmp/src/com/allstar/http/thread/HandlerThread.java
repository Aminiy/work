package com.allstar.http.thread;

import java.util.concurrent.ConcurrentLinkedQueue;

import com.allstar.cintracer.CinTracer;

public class HandlerThread extends Thread {
	private static CinTracer _tracer = CinTracer.getInstance(HandlerThread.class);

	private int _key;
	private boolean _isRunning;
	private Object _syncRoot;
	private ConcurrentLinkedQueue<HandlerItem> _items;

	public HandlerThread(int key) {
		super("HandlerThread - " + key);
		_key = key;
		_isRunning = true;
		_syncRoot = new Object();
		_items = new ConcurrentLinkedQueue<HandlerItem>();
		start();
	}

	public void receiveHandler(HandlerItem connection) {
		_items.add(connection);
		synchronized (_syncRoot) {
			_syncRoot.notify();
		}
	}

	@Override
	public void run() {
		while (_isRunning) {
			try {
				synchronized (_syncRoot) {
					_syncRoot.wait(300);
				}
				HandlerItem item = _items.poll();
				while (item != null) {
					item.handle();
					item = _items.poll();
				}
			} catch (Exception ex) {
				_tracer.error("HandlerThread - " + _key + " run error.", ex);
			}
		}
	}
}