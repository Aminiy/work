package com.allstar.http.thread;

import com.allstar.http.common.HttpClientConfiguration;

public class HandlerThreadManager {
	// private static CinTracer _tracer = CinTracer.getInstance(HandlerThreadManager.class);

	private HandlerThread[] _threads;

	public HandlerThreadManager() {
		int threadCount = HttpClientConfiguration.getInstance().getHandlerThreadCount();
		_threads = new HandlerThread[threadCount];
		for (int i = 0; i < _threads.length; i++)
			_threads[i] = new HandlerThread(i);
	}

	public void dispatch(HandlerItem item) {
		int index = item.hashCode() % _threads.length;
		_threads[index].receiveHandler(item);
	}
}
