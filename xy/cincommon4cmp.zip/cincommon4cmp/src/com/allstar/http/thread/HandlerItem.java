package com.allstar.http.thread;

public interface HandlerItem {
	public void handle() throws Exception;
}
