package com.allstar.http.common;

import java.net.InetAddress;
import java.net.UnknownHostException;

import com.allstar.cintracer.CinTracer;
import com.allstar.http.connection.HttpConnection;
import com.allstar.http.message.HttpRequest;

public class HttpUtil
{
	private static CinTracer tracer = CinTracer.getInstance(HttpUtil.class);
	private static byte[] DefaultClientIp = {(byte) 0, (byte) 0, (byte) 0, (byte) 0};

	public static InetAddress getRemoteAddr(HttpConnection connection, HttpRequest request)
	{
		InetAddress addr = null;
		try
		{
			String clientiptring = getRemoteAddrStringTrim(connection, request);
			if (clientiptring != null)
				addr = InetAddress.getByName(clientiptring);
			else
				addr = InetAddress.getByAddress(DefaultClientIp);
		}
		catch (UnknownHostException e)
		{
			tracer.error("Remote addr parse error " + request.toString(), e);
		}
		return addr;
	}

	private static String getRemoteAddrStringTrim(HttpConnection connection, HttpRequest request)
	{
		String clientIpString = getRemoteAddrString(connection, request);
		if (clientIpString != null)
		{
			clientIpString = clientIpString.trim();
		}
		return clientIpString;
	}

	private static String getRemoteAddrString(HttpConnection connection, HttpRequest request)
	{
		try
		{
			String remoteAddr = null;
			remoteAddr = request.getHeaderValue("X-Forwarded-For");
			if (remoteAddr != null && remoteAddr.length() != 0)
			{
				if (remoteAddr.indexOf(',') == -1)
				{

					if (!remoteAddr.equals("unknown"))
					{
						return remoteAddr;
					}
					else
					{
						remoteAddr = null;
					}
				}
				else
				{
					String ip[] = remoteAddr.split(",");

					for (int i = 0; i < ip.length; i++)
					{
						if (!ip[i].equals("unknown"))
						{
							remoteAddr = ip[i];
							return remoteAddr;
						}
					}
					remoteAddr = null;
				}
			}

			if (remoteAddr == null)
			{
				remoteAddr = request.getHeaderValue("Proxy-Client-IP");
			}
			if (remoteAddr == null)
			{
				remoteAddr = request.getHeaderValue("WL-Proxy-Client-IP");
			}
			if (remoteAddr == null)
			{
				String socketstring = connection.getRemoteAddress().toString();
				remoteAddr = socketstring.substring(socketstring.lastIndexOf("/") + 1, socketstring.indexOf(":"));
			}
			return remoteAddr;

		}
		catch (Exception e)
		{
			tracer.error("Parse IP from Http request " + request.toString() + "failed", e);
			return null;
		}
	}
}
