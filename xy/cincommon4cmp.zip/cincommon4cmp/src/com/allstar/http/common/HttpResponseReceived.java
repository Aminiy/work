package com.allstar.http.common;

import com.allstar.http.message.HttpRequest;
import com.allstar.http.message.HttpResponse;
import com.allstar.http.thread.HandlerItem;

public abstract class HttpResponseReceived implements HandlerItem {
	private HttpResponse _response;

	public void setHttpResponse(HttpResponse response) {
		_response = response;
	}

	@Override
	public void handle() {
		onResponseReceived(_response);
	}

	public abstract void onResponseReceived(HttpResponse response);

	public abstract void onTimeout(HttpRequest request);
}
