package com.allstar.http.common;

import com.allstar.http.connection.HttpServerConnection;

public interface HttpConnectionCreated {
	public void onConnectionCreated(HttpServerConnection conn);
}
