package com.allstar.http.common;

import com.allstar.cinconfig.CinConfigEntity;
import com.allstar.cinconfig.CinConfigInterface;
import com.allstar.cintracer.CinTracer;

public class HttpClientConfiguration extends CinConfigInterface
{
	private static CinTracer _tracer = CinTracer.getInstance(HttpClientConfiguration.class);
	private static HttpClientConfiguration _instance;

	private long _sendTimeout;
	private long _checkTimeoutInterval;
	private long _selectorSleepTime;
	private int _concurrencyPerServer;
	private int _handlerThreadCount;

	// private long _idelTime;

	private HttpClientConfiguration()
	{
		_tableName = "HttpClient";
		_sendTimeout = 60 * 1000;
		_checkTimeoutInterval = 1000;
		_selectorSleepTime = 300;
		_concurrencyPerServer = 100;
		_handlerThreadCount = 30;
		// _idelTime = 30000;
		updateConfig();
	}

	@Override
	protected void setValues(CinConfigEntity config)
	{
		try
		{
			_sendTimeout = Integer.valueOf(config.get("SendTimeout", "60")) * 1000;
			_checkTimeoutInterval = Integer.valueOf(config.get("CheckTimeoutInterval", "1")) * 1000;
			_selectorSleepTime = Long.valueOf(config.get("SelectorSleepTime", "300"));
			_concurrencyPerServer = Integer.valueOf(config.get("ConcurrencyPerServer", "100"));
			_handlerThreadCount = Integer.valueOf(config.get("HandlerThreadCount", "30"));
			// _idelTime = Long.valueOf(CinConfig.getValue(_tableName,
			// "HandlerThreadCount", "30")) * 1000;
		}
		catch (Exception ex)
		{
			_tracer.error("HttpClientConfiguration setValues error", ex);
		}
	}

	public static HttpClientConfiguration getInstance()
	{
		if (_instance == null)
			_instance = new HttpClientConfiguration();
		return _instance;
	}

	public long getSendTimeout()
	{
		return _sendTimeout;
	}

	public long getCheckTimeoutInterval()
	{
		return _checkTimeoutInterval;
	}

	public long getSelectorSleepTime()
	{
		return _selectorSleepTime;
	}

	public int getConcurrencyPerServer()
	{
		return _concurrencyPerServer;
	}

	public int getHandlerThreadCount()
	{
		return _handlerThreadCount;
	}

	// public long getIdelTime() {
	// return _idelTime;
	// }
}
