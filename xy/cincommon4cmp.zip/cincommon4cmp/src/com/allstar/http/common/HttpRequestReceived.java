package com.allstar.http.common;

import com.allstar.http.connection.HttpServerConnection;
import com.allstar.http.message.HttpRequest;
import com.allstar.http.thread.HandlerItem;

public abstract class HttpRequestReceived implements HandlerItem {
	private HttpServerConnection _connection;
	private HttpRequest _request;

	public void setConnection(HttpServerConnection connection) {
		_connection = connection;
	}

	public void setRequest(HttpRequest request) {
		_request = request;
	}

	@Override
	public void handle() throws Exception {
		onRequestReceived(_connection, _request);
	}

	public abstract void onRequestReceived(HttpServerConnection connection, HttpRequest request) throws Exception;
}
