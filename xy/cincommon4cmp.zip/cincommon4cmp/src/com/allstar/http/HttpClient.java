package com.allstar.http;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cintracer.CinTracer;
import com.allstar.http.common.HttpClientConfiguration;
import com.allstar.http.common.HttpResponseReceived;
import com.allstar.http.connection.HttpClientConnectionManager;
import com.allstar.http.connection.HttpSelector;
import com.allstar.http.message.HttpRequest;
import com.allstar.http.thread.HandlerThreadManager;

public class HttpClient extends Thread {
	private static CinTracer _tracer = CinTracer.getInstance(HttpClient.class);
	private static HttpClient _instance;

	private boolean _isRunning;
	private ConcurrentHashMap<InetSocketAddress, HttpClientConnectionManager> _managers;
	private HttpSelector _selector;
	private HandlerThreadManager _handlerMgr;

	public static void initialize() {
		try {
			if (_instance == null)
				_instance = new HttpClient();
		} catch (Exception ex) {
			_tracer.error("HttpClient initialize error.", ex);
		}
	}

	public static HttpClient getInstance() {
		return _instance;
	}

	private HttpClient() throws IOException {
		super("HttpClientTimeout");
		_isRunning = true;
		HttpClientConfiguration.getInstance();
		_managers = new ConcurrentHashMap<InetSocketAddress, HttpClientConnectionManager>();
		_selector = new HttpSelector();
		_handlerMgr = new HandlerThreadManager();
		start();
	}

	private synchronized HttpClientConnectionManager getManager(InetSocketAddress key) throws IOException {
		HttpClientConnectionManager manager = _managers.get(key);
		if (manager == null)
			_managers.put(key, manager = new HttpClientConnectionManager(key, _selector, _handlerMgr));
		return manager;
	}

	public void sendRequest(HttpRequest request, HttpResponseReceived event) throws Exception {
		if (event == null)
			throw new NullPointerException("event can't be null.");
		InetSocketAddress address = new InetSocketAddress(request.getURL().getHost(), request.getURL().getPort() == -1 ? 80 : request.getURL().getPort());
		HttpClientConnectionManager manager = getManager(address);
		manager.sendRequest(request, event);
	}

	@Override
	public void run() {
		while (_isRunning) {
			try {
				Thread.sleep(HttpClientConfiguration.getInstance().getCheckTimeoutInterval());
				for (Entry<InetSocketAddress, HttpClientConnectionManager> entry : _managers.entrySet())
					entry.getValue().doTimeout();
			} catch (Exception ex) {
				_tracer.error("HttpClient run Error", ex);
			}
		}
	}
}