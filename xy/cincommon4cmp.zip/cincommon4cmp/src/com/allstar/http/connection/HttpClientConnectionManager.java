package com.allstar.http.connection;

import java.io.IOException;
import java.net.InetSocketAddress;

import com.allstar.cintracer.CinTracer;
import com.allstar.http.common.HttpClientConfiguration;
import com.allstar.http.common.HttpResponseReceived;
import com.allstar.http.message.HttpRequest;
import com.allstar.http.thread.HandlerThreadManager;

public class HttpClientConnectionManager {
	private static CinTracer _tracer = CinTracer.getInstance(HttpClientConnectionManager.class);

	private InetSocketAddress _key;
	private HttpSelector _selector;
	private HttpClientConnection[] _connetions;

	public HttpClientConnectionManager(InetSocketAddress key, HttpSelector selector, HandlerThreadManager threadMgr) throws IOException {
		_key = key;
		_selector = selector;
		_connetions = new HttpClientConnection[HttpClientConfiguration.getInstance().getConcurrencyPerServer()];
		for (int i = 0; i < _connetions.length; i++)
			_connetions[i] = new HttpClientConnection(_key, _selector, threadMgr);
	}

	private synchronized HttpClientConnection getHttpConnection(HttpResponseReceived event) {
		for (int i = 0; i < _connetions.length; i++)
			if (!_connetions[i].isBusy()) {
				_tracer.info("Get httpconnection " + i);
				_connetions[i].setHttpResponseReceived(event);
				return _connetions[i];
			}
		return null;
	}

	public boolean sendRequest(HttpRequest request, HttpResponseReceived event) throws Exception {
		HttpClientConnection conn = getHttpConnection(event);
		if (conn == null)
			throw new Exception("Can't find a free HttpConnection.");
		return conn.sendRequest(request);
	}

	public void doTimeout() {
		for (int i = 0; i < _connetions.length; i++) {
			if (!_connetions[i].isBusy())
				continue;
			_connetions[i].doTimeout();
		}
	}
}