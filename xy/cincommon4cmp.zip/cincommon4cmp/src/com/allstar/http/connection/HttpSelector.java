package com.allstar.http.connection;

import java.io.IOException;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.SocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.allstar.cintracer.CinTracer;
import com.allstar.http.common.HttpConnectionCreated;

public class HttpSelector extends Thread {
	private static CinTracer _tracer = CinTracer.getInstance(HttpSelector.class);

	private boolean _isRunning;
	private ConcurrentLinkedQueue<HttpSelectorItem> _items;
	private Selector _selector;

	public HttpSelector() throws IOException {
		super("HttpSelector");
		setDaemon(true);

		_isRunning = true;
		_items = new ConcurrentLinkedQueue<HttpSelectorItem>();
		_selector = Selector.open();
		start();
	}

	public void listen(SocketAddress address, HttpConnectionCreated event) throws Exception {
		ServerSocketChannel ssc = ServerSocketChannel.open();
		ssc.configureBlocking(false);
		ServerSocket ss = ssc.socket();
		ss.setReuseAddress(true);
		bindPort(ss, address);
		HttpSelectorItem item = new HttpSelectorItem(ssc, null, SelectionKey.OP_ACCEPT, event);
		_items.add(item);
		_tracer.special("Listening port " + address.toString() + " has been opened.");
	}

	private void bindPort(ServerSocket ss, SocketAddress address) throws Exception {
		boolean isBinded = false;
		while (!isBinded) {
			try {
				ss.bind(address);
				isBinded = true;
			} catch (BindException ex) {
				_tracer.error("BindPort Error. " + address.toString(), ex);
				Thread.sleep(3000);
			} catch (Exception ex) {
				throw ex;
			}
		}
	}

	public void registerHttpConnection(HttpSelectorItem item) {
		_items.add(item);
	}

	private void handleKey(SelectionKey key) throws Exception {
		try {
			if (key.isAcceptable()) {
				processAccept(key);
			} else if (key.isReadable()) {
				HttpConnection conn = (HttpConnection) key.attachment();
				conn.receiveData();
			} else {
				SocketChannel sc = (SocketChannel) key.channel();
				if (!sc.isConnected())
					throw new IOException();
			}
		} catch (IOException ex) {
			handleException(ex, key);
		} catch (Exception ex) {
			_tracer.error("HttpSelector handleKey Error", ex);
		}
	}

	private void processAccept(SelectionKey key) throws Exception {
		ServerSocketChannel ssc = (ServerSocketChannel) key.channel();
		SocketChannel sc = ssc.accept();
		sc.configureBlocking(false);
		HttpServerConnection conn = new HttpServerConnection(sc);
		if (key.attachment() != null) {
			HttpConnectionCreated cEvent = (HttpConnectionCreated) key.attachment();
			cEvent.onConnectionCreated(conn);
		}
		SelectionKey cKey = sc.register(_selector, SelectionKey.OP_READ);
		cKey.attach(conn);
	}

	private void handleException(Exception ex, SelectionKey key) throws Exception {
		// key.channel().close();
		// CinConnection conn = (CinConnection) key.attachment();
		// if (_logger.InfoTrace())
		// _logger.info("Maybe the connection has been disconnected. \r\n" + conn);
		// _disconnectEvent.onCinConnectionDisconnected((CinConnection) key.attachment());
	}

	@Override
	public void run() {
		while (_isRunning) {
			try {
				while (!_items.isEmpty()) {
					HttpSelectorItem item = _items.poll();
					SelectionKey key = null;
					if (item.getChannel().isOpen()) {
						key = item.getChannel().register(_selector, item.getOpt());
						if (item.getOpt() == SelectionKey.OP_ACCEPT) {
							if (item.getObject() != null)
								key.attach(item.getObject());
						} else {
							if (item.getConnection() != null)
								key.attach(item.getConnection());
						}
					}
				}

				if (_selector.select(300) == 0) {
					continue;
				}

				Iterator<SelectionKey> iter = _selector.selectedKeys().iterator();
				while (iter.hasNext()) {
					SelectionKey key = iter.next();
					iter.remove();
					if (key.isValid())
						handleKey(key);
				}
			} catch (Exception ex) {
				_tracer.error("HttpSelector run error.", ex);
			}
		}
	}
}
