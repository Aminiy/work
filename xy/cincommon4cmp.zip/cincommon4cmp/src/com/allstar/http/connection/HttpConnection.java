package com.allstar.http.connection;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import com.allstar.cintracer.CinTracer;

public abstract class HttpConnection
{
	private static CinTracer _tracer = CinTracer.getInstance(HttpConnection.class);

	protected SocketChannel _channel;
	private ByteBuffer _buffer;

	public HttpConnection(SocketChannel channel)
	{
		_channel = channel;
		_buffer = ByteBuffer.allocate(1024 * 8);
	}

	public void receiveData() throws Exception
	{
		try
		{
			int count = _channel.read(_buffer);
			if (count == -1)
			{
				_channel.close();
				return;
			}
			while (count > 0)
			{
				_buffer.flip();
				receiveData(_buffer);
				_buffer.clear();
				if (!_channel.isOpen())
					break;
				count = _channel.read(_buffer);
			}
		}
		catch (IOException ex)
		{
			try
			{
				if (_channel != null && _channel.isConnected())
					_channel.close();
				_tracer.info("Connection has been terminated by the peer set.");
			}
			catch (Exception e)
			{
				_tracer.error("HttpConnection onDataReceived Error.");
			}
		}
	}

	public SocketAddress getRemoteAddress()
	{
		return _channel.socket().getRemoteSocketAddress();
	}

	protected synchronized boolean sendData(ByteBuffer buf) throws Exception
	{
		while (buf.hasRemaining() && _channel.write(buf) != -1)
			;
		return true;
	}

	protected synchronized boolean sendData(String message) throws Exception
	{
		ByteBuffer data = getByteBuffer(message);
		while (data.hasRemaining() && _channel.write(data) != -1)
			;
		return true;
	}

	protected void close() throws IOException
	{
		_channel.close();
	}

	protected ByteBuffer getByteBuffer(String message) throws UnsupportedEncodingException
	{
		byte[] b = message.getBytes("utf-8");
		ByteBuffer buffer = ByteBuffer.allocate(b.length);
		buffer.put(b);
		buffer.flip();
		return buffer;
	}

	@Override
	public String toString()
	{
		if (_channel == null)
			return "Channel is null. ";
		Socket socket = _channel.socket();
		if (socket == null)
			return "Socket is null.";
		String l = socket.getLocalSocketAddress() == null ? "null" : socket.getLocalSocketAddress().toString();
		String r = socket.getRemoteSocketAddress() == null ? "null" : socket.getRemoteSocketAddress().toString();
		return "L" + l + " - R" + r;
	}

	protected abstract void receiveData(ByteBuffer buffer) throws Exception;
}
