package com.allstar.http.connection;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;

import com.allstar.cintracer.CinTracer;
import com.allstar.http.HttpServer;
import com.allstar.http.common.HttpRequestReceived;
import com.allstar.http.message.HttpMessage;
import com.allstar.http.message.HttpRequest;
import com.allstar.http.message.HttpResponse;
import com.allstar.http.message.HttpResponseCode;
import com.allstar.http.message.parser.HttpRequestParser;

public class HttpServerConnection extends HttpConnection
{
	private static CinTracer _tracer = CinTracer.getInstance(HttpServerConnection.class);

	private HttpRequestReceived _event;
	@SuppressWarnings("unused")
	private boolean _readyToClose;
	private HttpRequestParser _parser;

	public HttpServerConnection(SocketChannel channel)
	{
		super(channel);
		_parser = new HttpRequestParser(channel.socket().getLocalSocketAddress());
		_readyToClose = false;
	}

	public void setHttpRequestReceived(HttpRequestReceived event)
	{
		_event = event;
	}

	public synchronized boolean sendResponse(HttpResponse response)
	{
		try
		{
			sendData(response.toString());
			_tracer.info("Http response has been sent by " + toString() + "\r\n" + response.toString());
			// if (_readyToClose) // Do not need to keep-alive connection
			close();
			return true;
		}
		catch (Exception ex)
		{
			_tracer.error("Http response send failed by " + toString() + "\r\n" + response.toString());
			return false;
		}
	}

	public void close()
	{
		try
		{
			if (_channel != null && _channel.isOpen())
				_channel.close();
		}
		catch (IOException e)
		{
			_tracer.info("Close socket.  " + toString());
		}
	}

	@Override
	protected void receiveData(ByteBuffer buffer) throws Exception
	{
		ArrayList<HttpMessage> messages = _parser.parse(buffer);
		if (messages == null || messages.size() == 0)
			return;

		for (HttpMessage message : messages)
		{
			HttpRequest request = (HttpRequest) message;
			_tracer.info("Http request has been received from " + toString() + "\r\n" + request.toString());
			if (request.getHeaderValue("Connection") != null && request.getHeaderValue("Connection").trim().equalsIgnoreCase("close"))
				_readyToClose = true;
			else
				_readyToClose = false;

			if (_event == null)
			{
				HttpResponse response = new HttpResponse(HttpResponseCode.NOTFOUND, request);
				sendResponse(response);
			}
			else
			{
				_event.setConnection(this);
				_event.setRequest(request);
				HttpServer.getInstance().getHandlerThreadManager().dispatch(_event);
			}
		}
	}
}