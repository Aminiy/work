package com.allstar.http.connection;

import java.nio.channels.SelectableChannel;

public class HttpSelectorItem {
	private SelectableChannel _channel;
	private HttpConnection _connection;
	private int _opt;
	private Object _obj;

	HttpSelectorItem(SelectableChannel channel, HttpClientConnection connection, int opt) {
		this(channel, connection, opt, null);
	}

	HttpSelectorItem(SelectableChannel channel, HttpConnection connection, int opt, Object obj) {
		_channel = channel;
		_connection = connection;
		_opt = opt;
		_obj = obj;
	}

	public SelectableChannel getChannel() {
		return _channel;
	}

	public HttpConnection getConnection() {
		return _connection;
	}

	public int getOpt() {
		return _opt;
	}

	public Object getObject() {
		return _obj;
	}
}
