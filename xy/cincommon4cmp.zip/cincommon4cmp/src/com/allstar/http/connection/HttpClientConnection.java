package com.allstar.http.connection;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;

import com.allstar.cintracer.CinTracer;
import com.allstar.http.common.HttpClientConfiguration;
import com.allstar.http.common.HttpResponseReceived;
import com.allstar.http.message.HttpMessage;
import com.allstar.http.message.HttpRequest;
import com.allstar.http.message.HttpResponse;
import com.allstar.http.message.HttpResponseCode;
import com.allstar.http.message.parser.HttpResponseParser;
import com.allstar.http.thread.HandlerThreadManager;

class HttpClientConnection extends HttpConnection
{
	private static CinTracer _tracer = CinTracer.getInstance(HttpClientConnection.class);

	private Object _syncRoot;
	private InetSocketAddress _address;
	private HttpSelector _selector;
	private HttpResponseReceived _event;
	private HandlerThreadManager _threadMgr;
	private long _timeout;
	// private long _lastSocketTime;
	private HttpRequest _request;
	private HttpResponseParser _parser;

	public HttpClientConnection(InetSocketAddress address, HttpSelector selector, HandlerThreadManager threadMgr)
	{
		super(null);
		_syncRoot = new Object();
		_address = address;
		_selector = selector;
		_threadMgr = threadMgr;
		_parser = new HttpResponseParser();
		updateSendTimeout();
	}

	private void updateSendTimeout()
	{
		long now = System.currentTimeMillis();
		_timeout = now + HttpClientConfiguration.getInstance().getSendTimeout();
		// _lastSocketTime = now;
	}

	private void connect() throws Exception
	{
		try
		{
			// if (_lastSocketTime +
			// HttpClientConfiguration.getInstance().getIdelTime() <
			// System.currentTimeMillis() && _channel != null)
			// _channel.close();
			if (_channel == null)
				_channel = SocketChannel.open();
			if (_channel.isConnected())
				return;

			_channel = SocketChannel.open();
			_channel.configureBlocking(true);
			_channel.connect(_address);
			_channel.configureBlocking(false);
			updateSendTimeout();

			HttpSelectorItem item = new HttpSelectorItem(_channel, this, SelectionKey.OP_READ);
			_selector.registerHttpConnection(item);
			_tracer.info("Tcp connection has been established.  L" + _channel.socket().getLocalSocketAddress().toString() + " - R" + _channel.socket().getRemoteSocketAddress().toString());
		}
		catch (Exception ex)
		{
			_tracer.error("HttpClientConnection connect error.  Address: " + _address.toString(), ex);
			throw ex;
		}
	}

	public boolean isBusy()
	{
		return _event != null;
	}

	public void setHttpResponseReceived(HttpResponseReceived event)
	{
		_event = event;
	}

	public synchronized boolean sendRequest(HttpRequest request) throws Exception
	{
		_request = request;
		connect();
		if (request.isByteBody())
		{
			ByteBuffer buf = request.toBytes();
			sendData(buf);
			buf.flip();
			byte[] bytes = new byte[buf.limit()];
			buf.get(bytes, 0, bytes.length);
			_tracer.info("Http request has been sent by " + toString() + "\r\n" + new String(bytes, "US-ASCII"));
		}
		else
		{
			sendData(request.toString());
			_tracer.info("Http request has been sent by " + toString() + "\r\n" + request.toString());
		}
		updateSendTimeout();
		return true;
	}

	@Override
	protected void receiveData(ByteBuffer buffer) throws Exception
	{
		ArrayList<HttpMessage> messages = _parser.parse(buffer);
		if (_event == null || messages == null || messages.size() == 0)
			return;

		for (HttpMessage message : messages)
		{
			HttpResponse response = (HttpResponse) message;
			_tracer.info("Http response has been received from " + toString() + "\r\n" + response.toString());
			if (response.isResponseCode(HttpResponseCode.CONTINUE))
			{
				sendData(_request.getBody());
				return;
			}
			_timeout = Long.MAX_VALUE;
			if (_event == null)
				continue;
			synchronized (_syncRoot)
			{
				_event.setHttpResponse(response);
				_threadMgr.dispatch(_event);
				_event = null;
				_request = null;
				if (response.getConnection() != null && response.getConnection().equalsIgnoreCase("close"))
				{
					if (_channel != null && _channel.isOpen())
						_channel.close();
					_parser.reset();
				}
			}
		}
	}

	void doTimeout()
	{
		if (_timeout > System.currentTimeMillis())
			return;
		_tracer.warn("HttpRequest send time out.\r\n" + (_request == null ? "" : _request.toString()));
		synchronized (_syncRoot)
		{
			_event.onTimeout(_request);
			_event = null;
			_request = null;
		}
	}

}