package com.allstar.http.connection;


public class HttpServerConnectionManager {
	// private SocketAddress _address;
	// private HttpConnectionCreated _cEvent;
	// private HttpRequestReceived _qEvent;
	//
	// public HttpServerConnectionManager(SocketAddress address) {
	// _address = address;
	// }
	//
	// public void setHttpConnectionCreated(HttpConnectionCreated event) {
	// _cEvent = event;
	// }
	//
	// public void setHttpRequestReceived(HttpRequestReceived event) {
	// _qEvent = event;
	// }
}
