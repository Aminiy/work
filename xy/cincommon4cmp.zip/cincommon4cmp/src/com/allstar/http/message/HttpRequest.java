package com.allstar.http.message;

import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.HashMap;

public class HttpRequest extends HttpMessage
{
	private HttpMethod _method;
	private URL _url;
	private String _version;
	private HashMap<String, String> _query;

	// private HashMap<String, String> _form = new HashMap<String, String>();

	public HttpRequest(HttpMethod method, URL url)
	{
		this(method, url, "HTTP/1.1");
	}

	public HttpRequest(HttpMethod method, URL url, String version)
	{
		_keepAlive = false;
		_method = method;
		_url = url;
		_version = version;
		addHeader("Host", _url.getPort() == -1 ? _url.getHost() : _url.getHost() + ":" + _url.getPort());
		// addHeader("Host", _url.getHost());
		_query = new HashMap<String, String>();
		// addHeader("Connection", "Keep-Alive");
	}

	public HttpMethod getMethod()
	{
		return _method;
	}

	public String getVersion()
	{
		return _version;
	}

	public synchronized void setKeepAlive(boolean value)
	{
		_keepAlive = value;
		super.removeHeader("Connection");
		super.removeHeader("Expect");
		super.addHeader("Connection", "Keep-Alive");
		super.addHeader("Expect", "100-continue");
	}

	public URL getURL()
	{
		return _url;
	}

	public ByteBuffer toByteBuffer() throws Exception
	{
		return toByteBuffer("utf-8");
	}

	public ByteBuffer toByteBuffer(String charsetName) throws Exception
	{
		String request = toString();
		byte[] b = request.getBytes(charsetName);
		ByteBuffer buffer = ByteBuffer.allocate(b.length);
		buffer.put(b);
		buffer.flip();
		return buffer;
	}

	public void addQuery(String key, String value)
	{
		_query.put(key, value);
	}

	// public void addForm(String key, String value) {
	// _form.put(key, value);
	// }

	public String getQuery(String key)
	{
		return _query.get(key);
	}

	// public String getForm(String key) {
	// return _form.get(key);
	// }

	@Override
	public ByteBuffer toBytes()
	{
		StringBuilder sb = new StringBuilder();

		sb.append(_method.toString());
		sb.append(" ");
		sb.append(_url.getPath());
		if (_url.getQuery() != null)
		{
			sb.append("?");
			sb.append(_url.getQuery());
		}
		sb.append(" ");
		sb.append(_version);

		byte[] bytes = null;
		try
		{
			bytes = sb.toString().getBytes("US-ASCII");
		}
		catch (UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
		ByteBuffer buf1 = super.toBytes();
		ByteBuffer buf = ByteBuffer.allocate(bytes.length + buf1.limit());
		buf.put(bytes);
		buf.put(buf1);
		buf.flip();
		return buf;
	}

	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();

		sb.append(_method.toString());
		sb.append(" ");
		sb.append(_url.getPath());
		if (_url.getQuery() != null)
		{
			sb.append("?");
			sb.append(_url.getQuery());
		}
		sb.append(" ");
		sb.append(_version);

		sb.append(super.toString());
		return sb.toString();
	}
}
