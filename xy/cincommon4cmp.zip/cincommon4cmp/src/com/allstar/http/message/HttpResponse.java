package com.allstar.http.message;

import java.nio.ByteBuffer;

public class HttpResponse extends HttpMessage {
	private String _version;
	private HttpResponseCode _code;
	private String _text;

	public HttpResponse(HttpResponseCode code) {
		this("HTTP/1.1", code, code.toString());
	}

	public HttpResponse(HttpResponseCode code, HttpRequest request) {
		this("HTTP/1.1", code, code.toString());
		if (request.getConnectionHeader() != null)
			addHeader("Connection", request.getConnectionHeader());
	}

	public HttpResponse(HttpResponseCode code, String text) {
		this("HTTP/1.1", code, text);
	}

	public HttpResponse(String version, HttpResponseCode code, String text) {
		_version = version;
		_code = code;
		_text = text;
	}

	public String getHeaderValue(String headerKey) {
		return super.getHeaderValue(headerKey);
	}

	public String getConnection() {
		return super.getHeaderValue("Connection");
	}

	public boolean isResponseCode(HttpResponseCode code) {
		return code.getValue() == _code.getValue();
	}

	public HttpResponseCode getStatusCode() {
		return _code;
	}

	public ByteBuffer toByteBuffer() throws Exception {
		return toByteBuffer("utf-8");
	}

	public ByteBuffer toByteBuffer(String charsetName) throws Exception {
		String response = toString();
		byte[] b = response.getBytes(charsetName);
		ByteBuffer buffer = ByteBuffer.allocate(b.length);
		buffer.put(b);
		buffer.flip();
		return buffer;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(_version);
		sb.append(" ");
		sb.append(_code.getValue());
		sb.append(" ");
		sb.append(_text);

		sb.append(super.toString());
		return sb.toString();
	}
}
