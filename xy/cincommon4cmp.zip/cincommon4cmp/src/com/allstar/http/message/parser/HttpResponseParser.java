package com.allstar.http.message.parser;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.util.ArrayList;

import com.allstar.cintracer.CinTracer;
import com.allstar.http.message.HttpMessage;
import com.allstar.http.message.HttpResponse;
import com.allstar.http.message.HttpResponseCode;

public class HttpResponseParser extends HttpMessageParser
{
	private static CinTracer _tracer = CinTracer.getInstance(HttpResponseParser.class);

	private HttpResponse _response;
	private ByteBuffer _body;
	private CharBuffer charBuffer = null;

	private int spacecount = 0;// In the startline p1 Spaces
	private byte lastByte = 0;// To judge the header on the bytes
	private int entercount = 0;// Enter the number of
	long content_length = 0;// When no content - length head use

	private String potocol = null;
	private HttpResponseCode statueCode = null;
	private String statusText = null;

	private String key = "";
	private String value = "";

	public HttpResponseParser()
	{
		super();
		_body = ByteBuffer.allocate(32 * 1024);
	}

	private void addResponse(HttpResponse response, ArrayList<HttpMessage> responses)
	{
		if (response == null)
			return;
		responses.add(response);
	}

	@Override
	public void reset()
	{
		_response = null;
		super.reset();
	}

	@Override
	public ArrayList<HttpMessage> parse(ByteBuffer buffer)
	{
		ArrayList<HttpMessage> responses = new ArrayList<HttpMessage>();
		try
		{
			HttpResponse response = _response;
			while (buffer.hasRemaining())
			{
				byte b = buffer.get();
				switch (_type)
				{
					case StartLine:
						switch (b)
						{
							case 32:// Space
								_body.flip();
								charBuffer = charset.decode(_body);
								spacecount++;
								if (spacecount == 1)
									potocol = charBuffer.toString();
								else if (spacecount == 2)
									statueCode = HttpResponseCode.valueof(charBuffer.toString());
								else if (spacecount == 3)
									statusText = charBuffer.toString();
								_body.clear();
								charBuffer.clear();
							break;
							case 10:
								_type = HttpMessageParserType.Header;
								_body.clear();
							break;
							case 13:
								_body.flip();
								if (spacecount == 2)
									statusText = charset.decode(_body).toString();
								else
									statusText = statusText + " " + charset.decode(_body).toString();
								_body.clear();
								spacecount = 0;
							break;
							default:
								_body.put(b);
							break;
						}
						if (potocol != null && statueCode != null && statusText != null)
							response = new HttpResponse(potocol, statueCode, statusText);
					break;
					case Header:
						switch (b)
						{
							case 13:
								if (lastByte != 0 && lastByte != 10)// A is not
																	// zero
								// , and ends with a carriage return, receive
								// normal characters, is the value of the value
								{
									entercount = 0;
									_body.flip();
									value = charset.decode(_body).toString();
								}
								lastByte = b;
							break;
							case 10:// enter
								if (lastByte == 13)// Formed a set of return
													// operation
								{
									entercount++;
									if (entercount == 2)
									{
										_type = HttpMessageParserType.Body;
										entercount = 0;
										lastByte = 0;
									}
								}
								lastByte = b;
								_body.clear();
							break;
							case 58:// : before a key value
								_body.flip();
								key = charset.decode(_body).toString();
								_body.clear();
							break;
							default:
								_body.put(b);
								lastByte = b;
							break;
						}
						if (key != null && value != null)
						{
							response.addHeader(key, value);
							key = null;
							value = null;
						}
					break;
					case Body:
						if (response.containsHeader("content-length"))
						{
							int length = response.getContentLength();
							if (length == 0)
							{
								reset();
								addResponse(response, responses);
								break;
							}
							_body.put(b);
							if (_body.position() == length || (_body.position() + _bodyLength) == length)
							{
								_body.flip();
								response.addLine2Body(_body);
								_bodyLength = length;
								_body.clear();
								// addResponse(response, responses);
							}
							if (_body.position() == _body.limit())
							{
								_body.flip();
								response.addLine2Body(_body);
								_bodyLength += _body.limit();
								_body.clear();
							}
						}
						if (response.containsHeader("transfer-encoding"))
						{
							if (content_length != 0)
							{
								if (b != 10)
								{
									_body.put(b);
									if (_body.position() == content_length || (_body.position() + _bodyLength) == content_length)
									{
										_body.flip();
										response.addLine2Body(_body);
										_bodyLength = (int) content_length;
										_body.clear();
										// addResponse(response, responses);
									}
									if (_body.position() == _body.limit())
									{
										_body.flip();
										response.addLine2Body(_body);
										_bodyLength += _body.limit();
										_body.clear();
									}
								}
							}
							else
							{
								if (b == 13)
								{
									_body.flip();
									String count = charset.decode(_body).toString();
									content_length = Integer.parseInt(count, 16);
									_body.clear();
									break;
								}
								else
								{
									_body.put(b);
								}
							}
						}
				}
			}
			if (_type == HttpMessageParserType.Body && response != null && (response.getContentLength() == 0 || response.getContentLength() <= _bodyLength))
			{
				reset();
				addResponse(response, responses);
			}
			else
			{
				_response = response;
			}
			return responses;
		}
		catch (Exception ex)
		{
			_tracer.error("HttpResponseParser parse error.", ex);
			return null;
		}
	}
}
