package com.allstar.http.message.parser;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;

import com.allstar.http.message.HttpMessage;

public abstract class HttpMessageParser {
	protected HttpMessageParserType _type;
	protected int _bodyLength;
	protected Charset charset = Charset.forName("UTF-8");

	public HttpMessageParser() {
		_type = HttpMessageParserType.StartLine;
		_bodyLength = 0;
	}

	protected String readLine(ByteBuffer buffer) {
		if (buffer.position() >= buffer.limit())
			return null;

		StringBuilder sb = new StringBuilder();
		byte i = buffer.get();
		while (i != -1) {
			sb.append((char) i);
			if (i == 10) {
				break;
			} else {
				if (buffer.position() >= buffer.limit())
					break;
				i = buffer.get();
			}
		}
		return sb.toString();
	}

	protected String readBodyLine(ByteBuffer buffer) throws UnsupportedEncodingException {
		if (buffer.position() >= buffer.limit())
			return null;
		ByteBuffer buf = ByteBuffer.allocate(buffer.limit() - buffer.position());
		while (buffer.hasRemaining()) {
			byte i = buffer.get();
			buf.put(i);
			if (i == 10)
				break;
		}
		buf.flip();
		byte[] b = new byte[buf.limit()];
		buf.get(b, 0, b.length);
		String s = new String(b, "utf-8");
		return s;
	}

	public void reset() {
		_type = HttpMessageParserType.StartLine;
		_bodyLength = 0;
	}

	public abstract ArrayList<HttpMessage> parse(ByteBuffer buffer);
}
