package com.allstar.http.message;

public enum HttpMethod {
	GET("GET"), POST("POST"), KNOWN("KNOWN");

	private String _value;

	HttpMethod(String value) {
		_value = value;
	}

	public static HttpMethod valueof(String value) {
		for (HttpMethod method : HttpMethod.values())
			if (method.toString().equalsIgnoreCase(value))
				return method;
		return HttpMethod.KNOWN;
	}

	@Override
	public String toString() {
		return _value;
	}
}
