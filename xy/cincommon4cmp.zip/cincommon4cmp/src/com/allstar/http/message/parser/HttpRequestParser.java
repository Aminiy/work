package com.allstar.http.message.parser;

import java.net.SocketAddress;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.util.ArrayList;

import com.allstar.cintracer.CinTracer;
import com.allstar.http.message.HttpMessage;
import com.allstar.http.message.HttpMethod;
import com.allstar.http.message.HttpRequest;

public class HttpRequestParser extends HttpMessageParser
{
	private static CinTracer _tracer = CinTracer.getInstance(HttpRequestParser.class);

	private SocketAddress _address;
	private HttpRequest _request;
	private ByteBuffer _body;
	private CharBuffer charBuffer = null;

	private int spacecount = 0;
	private byte lastByte = 0;
	private int entercount = 0;

	private HttpMethod method = null;
	private URL url = null;
	private String protocolVersion = null;

	private String key = "";
	private String value = "";
	
	public HttpRequestParser(SocketAddress address)
	{
		super();
		_address = address;
		_body = ByteBuffer.allocate(32 * 1024);
	}

	@Override
	public ArrayList<HttpMessage> parse(ByteBuffer buffer)
	{
		ArrayList<HttpMessage> requests = new ArrayList<HttpMessage>();
		try
		{
			HttpRequest request = _request;
			while (buffer.hasRemaining())
			{
				byte b = buffer.get();
				switch (_type)
				{
					case StartLine:
						switch (b)
						{
							case 32:// Space
								_body.flip();
								charBuffer = charset.decode(_body);
								spacecount++;
								if (spacecount == 1)
									method = HttpMethod.valueof(charBuffer.toString());
								else
									if (spacecount == 2)
										url = new URL("http://" + _address.toString().substring(1) + charBuffer.toString());
								_body.clear();
							break;
							case 10:
								_type = HttpMessageParserType.Header;
								_body.clear();
							break;
							case 13:
								_body.flip();
								protocolVersion = charset.decode(_body).toString();
								_body.clear();
								spacecount = 0;
							break;
							default:
								_body.put(b);
							break;
						}
						if (method != null && url != null && protocolVersion != null)
						{
							request = new HttpRequest(method, url, protocolVersion);

							if (method == HttpMethod.GET)
							{
								if (request.getURL().getQuery() != null)
								{
									String[] queryFields = request.getURL().getQuery().split("&");
									for (String field : queryFields)
									{
										String[] keyValue = field.split("=");
										request.addQuery(keyValue[0], (keyValue.length < 2 || keyValue[1] == null) ? "" : keyValue[1]);
									}
								}
							}
						}
					break;
					case Header:
						switch (b)
						{
							case 13:
								if (lastByte != 0 && lastByte != 10)// A is not zero
								//, and ends with a carriage return, receive normal characters, is the value of the value
								{
									entercount = 0;
									_body.flip();
									value = charset.decode(_body).toString();
								}
								lastByte = b;
							break;
							case 10://enter
								if (lastByte == 13)// Formed a set of return operation
								{
									entercount++;
									if (entercount == 2)
									{
										_type = HttpMessageParserType.Body;
										entercount = 0;
										lastByte = 0;
									}
								}
								lastByte = b;
								_body.clear();
							break;
							case 58://: before a key value
								_body.flip();
								key = charset.decode(_body).toString();
								_body.clear();
							break;
							default:
								_body.put(b);
								lastByte = b;
							break;
						}
						if (key != null && value != null)
						{
							request.addHeader(key, value);
							key = null;
							value = null;
						}
					break;
					case Body:
						int length = request.getContentLength();
						if (length == 0)
						{
							reset();
							requests.add(request);
							break;
						}
						_body.put(b);
						if (_body.position() == length || (_body.position() + _bodyLength) == length)
						{
							_body.flip();
							request.addLine2Body(_body);
							_bodyLength = length;
							_body.clear();
//							requests.add(request);
						}
						if (_body.position() == _body.limit())
						{
							_body.flip();
							request.addLine2Body(_body);
							_bodyLength += _body.limit();
							_body.clear();
						}
					break;
				}
			}
			if (_type == HttpMessageParserType.Body && request != null && (request.getContentLength() == 0 || request.getContentLength() <= _bodyLength))
			{
				reset();
				requests.add(request);
			}
			else
			{
				_request = request;
			}
			return requests;
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
			_tracer.error("HttpRequestParser parse error. Request is " + (_request == null ? "No Request" : _request.toString()), ex);
			return null;
		}
	}
}