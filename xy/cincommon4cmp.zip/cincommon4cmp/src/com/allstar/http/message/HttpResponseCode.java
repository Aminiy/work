package com.allstar.http.message;

public enum HttpResponseCode {
	UNKOWN(0, ""), 
	CONTINUE(100, ""), 
	OK(200, "OK"), 
	NOCONTENT(204, "NOCONTENT"), 
	MOVEDPERMANENTLY(301, "Moved Permanently"), 
	FOUND(302, "Found"), 
	BADREQUEST(400, "Bad Request"), 
	UNAUTHORIZED(401, "Unauthorized"), 
	PAYMENTREQUIRED(402, "Payment Required"), 
	FORBIDDEN(403, "Forbidden"), 
	NOTFOUND(404, "Not Found"), 
	METHODNOTALLOWED(405, "Method Not Allowed"), 
	NOTACCEPTABLE(406, "Not Acceptable"), 
	PreconditionFailed(412, "Precondition Failed"), 
	BUSY(486, "Busy"), 
	InternalServerError(500, "Internal Server Error"), 
	NOTIMPLEMENTED(501, "Not Implemented"), 
	BADGATEWAY(502, "Bad Gateway"), 
	TIMEOUT(503, "Time Out");

	private int _value;
	private String _text;

	HttpResponseCode(int value, String text)
	{
		_value = value;
		_text = text;
	}

	public int getValue()
	{
		return _value;
	}

	public String getText()
	{
		return _text;
	}

	public static HttpResponseCode valueof(String value)
	{
		return valueof(Integer.valueOf(value));
	}

	public static HttpResponseCode valueof(int value)
	{
		for (HttpResponseCode code : HttpResponseCode.values())
			if (code.getValue() == value)
				return code;
		return HttpResponseCode.UNKOWN;
	}
}
