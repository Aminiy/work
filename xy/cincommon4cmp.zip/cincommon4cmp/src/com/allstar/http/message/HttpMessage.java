package com.allstar.http.message;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.util.HashMap;
import java.util.Map.Entry;

public class HttpMessage
{
	private HashMap<String, String> _headers;
	private ByteBuffer _body;
	private Object _obj;
	protected boolean _keepAlive;

	Charset charset = Charset.forName("UTF-8");
	CharsetDecoder decoder = charset.newDecoder();
	CharBuffer charBuffer = null;

	public HttpMessage()
	{
		_headers = new HashMap<String, String>();
		_keepAlive = false;
		_body = ByteBuffer.wrap("".getBytes());
		_obj = null;
	}
	
	public HashMap<String, String> getHeaders(){
		return _headers;
	}

	public void addHeader(String key, String value)
	{
		_headers.put(key.toLowerCase(), value);
	}

	public void addHeader(String key, int value)
	{
		_headers.put(key.toLowerCase(), String.valueOf(value));
	}

	public void removeHeader(String key)
	{
		_headers.remove(key.toLowerCase());

	}

	public void addBody(String str)
	{
		byte[] b = str.getBytes();
		ByteBuffer buffer = ByteBuffer.wrap(b);
		_body = ByteBuffer.allocate(buffer.limit());
		_body.put(buffer);
		_body.flip();
	}

	public void addBody(ByteBuffer buffer)
	{
		_body = ByteBuffer.allocate(buffer.limit());
		_body.put(buffer);
		_body.flip();
	}

	public void addLine2Body(ByteBuffer buffer)
	{
		if (_body.limit() == 0)
		{
			_body = ByteBuffer.allocate(buffer.limit());
			_body.put(buffer);
			_body.flip();
		}
		else
		{
			ByteBuffer temBuffer = _body;
			ByteBuffer newBuffer = ByteBuffer.allocate(temBuffer.limit() + buffer.limit());
			newBuffer.put(temBuffer);
			newBuffer.put(buffer);
			newBuffer.flip();
			_body = newBuffer;
			temBuffer = null;
		}
	}

	public String getHeaderValue(String key)
	{
		return _headers.get(key.toLowerCase());
	}

	public boolean containsHeader(String key)
	{
		return _headers.containsKey(key);
	}

	public boolean getKeepAlive()
	{
		return _keepAlive;
	}

	public int getContentLength()
	{
		if (!_headers.containsKey("content-length"))
			return 0;
		return Integer.valueOf(_headers.get("content-length").trim());
	}

	public String getConnectionHeader()
	{
		return _headers.get("connection");
	}

	public ByteBuffer getBody()
	{
		ByteBuffer buffer = ByteBuffer.allocate(_body.limit());
		buffer.put(_body);
		buffer.flip();
		_body.flip();
		return buffer;
	}

	public void setObj(Object obj)
	{
		_obj = obj;
	}

	public Object getObj()
	{
		return _obj;
	}

	public boolean isByteBody()
	{
		return _body != null;
	}

	public ByteBuffer toBytes()
	{
		StringBuilder sb = new StringBuilder();

		for (Entry<String, String> header : _headers.entrySet())
		{
			sb.append("\r\n");
			sb.append(header.getKey());
			sb.append(": ");
			sb.append(header.getValue());
		}
		sb.append("\r\n");

		if (_body != null)
		{
			if (!_headers.containsKey("content-length"))
			{
				sb.append("content-length: ");
				sb.append(_body.limit());
			}
			sb.append("\r\n\r\n");
		}
		else
		{
			sb.append("content-length: 0\r\n");
			sb.append("\r\n");
		}

		byte[] bytes = null;
		try
		{
			bytes = sb.toString().getBytes("utf-8");
		}
		catch (UnsupportedEncodingException e)
		{
			e.printStackTrace();
		}
		ByteBuffer buf = ByteBuffer.allocate(bytes.length + (_body == null ? 0 : _body.limit()));
		buf.put(bytes);
		if (_body != null)
		{
			buf.put(_body);
		}
		buf.flip();
		return buf;
	}

	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder();

		for (Entry<String, String> header : _headers.entrySet())
		{
			sb.append("\r\n");
			sb.append(header.getKey());
			sb.append(": ");
			sb.append(header.getValue());
		}
		sb.append("\r\n");

		if (_body != null && _body.limit() != 0)
		{
			if (!_headers.containsKey("content-length"))
			{
				sb.append("content-length: ");
				try
				{
					sb.append(_body.limit());
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
			sb.append("\r\n\r\n");
			if (!_keepAlive)
			{
				sb.append(charset.decode(_body).toString());
				_body.flip();
			}

		}
		else
		{
			sb.append("content-length: 0\r\n");
			sb.append("\r\n");
		}
		return sb.toString();
	}
}
