package com.allstar.http.message.parser;

enum HttpMessageParserType {
	StartLine, Header, Body
}
