package com.allstar.http;

import java.net.SocketAddress;
import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cintracer.CinTracer;
import com.allstar.http.common.HttpConnectionCreated;
import com.allstar.http.connection.HttpSelector;
import com.allstar.http.connection.HttpServerConnectionManager;
import com.allstar.http.thread.HandlerThreadManager;

public class HttpServer {
	private static CinTracer _tracer = CinTracer.getInstance(HttpServer.class);
	private static HttpServer _instance;

	private ConcurrentHashMap<SocketAddress, HttpServerConnectionManager> _managers;
	private HttpSelector _selector;
	private HandlerThreadManager _handlerMgr;

	public static void initialize() {
		try {
			if (_instance == null)
				_instance = new HttpServer();
		} catch (Exception ex) {
			_tracer.error("HttpServer initialize error.", ex);
		}
	}

	public static HttpServer getInstance() {
		return _instance;
	}

	public HandlerThreadManager getHandlerThreadManager() {
		return _handlerMgr;
	}

	private HttpServer() throws Exception {
		_managers = new ConcurrentHashMap<SocketAddress, HttpServerConnectionManager>();
		_selector = new HttpSelector();
		_handlerMgr = new HandlerThreadManager();
	}

	public synchronized void listen(SocketAddress address, HttpConnectionCreated event) throws Exception {
		if (_managers.containsKey(address))
			throw new Exception(address.toString() + " has been listened.");
		_selector.listen(address, event);
	}
}
