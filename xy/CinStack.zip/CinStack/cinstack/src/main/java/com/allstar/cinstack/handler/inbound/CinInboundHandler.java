/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinInboundHandler.java
 * @Package com.allstar.cinstack.handler.inbound
 * @date June 10, 2015 at 3:54:36 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.handler.inbound;

import io.netty.channel.ChannelInboundHandlerAdapter;

class CinInboundHandler extends ChannelInboundHandlerAdapter {
}
