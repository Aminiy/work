/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinConnection.java
 * @Package com.allstar.cinstack.connection
 * @date 09/06/2015 2:19:28 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.connection;

import com.allstar.cinstack.transaction.CinTransaction;

public interface CinDedicateConnectionEvent extends CinConnectionEvent {

	void onCinTransactionCreated(CinTransaction trans);
}