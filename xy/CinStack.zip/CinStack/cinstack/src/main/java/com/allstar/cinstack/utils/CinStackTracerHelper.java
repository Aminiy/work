/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinStackTracer.java
 * @Package com.allstar.cinstack.utils
 * @date June 9, 2015 10:45:59 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.utils;

import java.util.HashMap;
import java.util.Map.Entry;

import com.allstar.cinstack.common.CinStackTracer;
import com.allstar.cinstack.common.CinStackTracerFactory;
import com.allstar.cinstack.message.CinMessage;

public class CinStackTracerHelper {
	private static CinStackTracerFactory _factory;
	private static HashMap<Class<?>, CinStackTracerHelper> _tracers;

	private CinStackTracer _tracer;

	static {
		try {
			_tracers = new HashMap<Class<?>, CinStackTracerHelper>();
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	public static void registerCinStackTracerFactory(CinStackTracerFactory factory) {
		_factory = factory;
		for (Entry<Class<?>, CinStackTracerHelper> entry : _tracers.entrySet())
			entry.getValue().registerCinStackTracer(entry.getKey());
	}

	public static synchronized CinStackTracerHelper getInstance(Class<?> c) {
		CinStackTracerHelper tracer = _tracers.get(c);
		if (tracer == null) {
			tracer = new CinStackTracerHelper(c);
			_tracers.put(c, tracer);
		}
		return tracer;
	}

	private CinStackTracerHelper(Class<?> c) {
		registerCinStackTracer(c);
	}

	private void registerCinStackTracer(Class<?> c) {
		if (_factory != null && _tracer == null) {
			try {
				_tracer = _factory.createTracer(c);
			} catch (Throwable t) {
				t.printStackTrace();
			}
		}
	}

	public void debug(String info) {
		if (_tracer == null)
			return;
		try {
			_tracer.debug(info);
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	public void debug(String info, CinMessage msg) {
		if (_tracer == null)
			return;
		try {
			_tracer.debug(info, msg);
		} catch (Throwable th) {
			th.printStackTrace();
		}
	}

	public void info(String info) {
		if (_tracer == null)
			return;
		try {
			_tracer.info(info);
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	public void info(String info, CinMessage msg) {
		if (_tracer == null)
			return;
		try {
			_tracer.info(info, msg);
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	public void warn(String info) {
		if (_tracer == null)
			return;
		try {
			_tracer.warn(info);
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	public void warn(String info, Throwable t) {
		if (_tracer == null)
			return;
		try {
			_tracer.warn(info, t);
		} catch (Throwable th) {
			th.printStackTrace();
		}
	}

	public void warn(String info, CinMessage msg) {
		if (_tracer == null)
			return;
		try {
			_tracer.warn(info, msg);
		} catch (Throwable th) {
			th.printStackTrace();
		}
	}

	public void warn(String info, CinMessage msg, Throwable t) {
		if (_tracer == null)
			return;
		try {
			_tracer.warn(info, msg, t);
		} catch (Throwable th) {
			th.printStackTrace();
		}
	}

	public void error(String info) {
		if (_tracer == null)
			return;
		try {
			_tracer.error(info);
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	public void error(String info, Throwable t) {
		if (_tracer == null)
			return;
		try {
			_tracer.error(info, t);
		} catch (Throwable th) {
			th.printStackTrace();
		}
	}

	public void error(String info, CinMessage msg) {
		if (_tracer == null)
			return;
		try {
			_tracer.error(info, msg);
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	public void error(String info, CinMessage msg, Throwable t) {
		if (_tracer == null)
			return;
		try {
			_tracer.error(info, msg, t);
		} catch (Throwable th) {
			th.printStackTrace();
		}
	}
}
