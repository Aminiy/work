/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinStackCounter.java
 * @Package com.allstar.cinstack.common
 * @date April 7, 2016 at 1:56:28 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.common;

import com.allstar.cinstack.connection.CinConnection;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.transaction.CinTransaction;

public interface CinStackCounter {

	void countRequestReceived(CinRequest req);

	void countResponseReceived(CinTransaction trans);

	void countOutOfBoundingResonseReceived(CinResponse resp);

	void countRequestSent(CinTransaction trans);

	void countResponseSent(CinTransaction trans);

	void countRequestSentFailed(CinTransaction trans);

	void countResponseSentFailed(CinTransaction trans);

	void countRequestSentTimeout(CinTransaction trans);

	void countConnectionConnected(CinConnection conn);

	void countConnectionConnectFailed(CinConnection conn);

	void countConnectionDisconnected(CinConnection conn);

}
