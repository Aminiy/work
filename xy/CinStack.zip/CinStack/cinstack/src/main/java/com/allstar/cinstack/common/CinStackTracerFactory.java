/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinStackTracerFactory.java
 * @Package com.allstar.cinstack.common
 * @date 06/04/2016 6:25:28 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.common;

public interface CinStackTracerFactory {

	CinStackTracer createTracer(Class<?> c);

}
