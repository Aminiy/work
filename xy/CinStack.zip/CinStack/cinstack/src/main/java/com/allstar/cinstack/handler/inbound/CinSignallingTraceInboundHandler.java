/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinTextTracer.java
 * @Package com.allstar.cinstack.handler
 * @date June 9, 2015 at 10:09:18 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.handler.inbound;

import com.allstar.cinstack.connection.CinConnection;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.utils.CinStackTracerHelper;

import io.netty.channel.ChannelHandlerContext;

public class CinSignallingTraceInboundHandler extends CinInboundHandler {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinSignallingTraceInboundHandler.class);

	private CinConnection _conn;

	public CinSignallingTraceInboundHandler(CinConnection conn) {
		_conn = conn;
	}

	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
		_tracer.info("CinConnection has been connected. " + _conn.toString());
		_conn.doConnected();
		super.channelActive(ctx);
	}

	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
		_tracer.info("CinConnection has been disconnected. " + _conn.toString());
		_conn.doDisconnected();
		_conn = null;
		super.channelInactive(ctx);
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
		CinMessage message = (CinMessage) msg;
		if (message.isRequest())
			_tracer.info("CinRequest has been received." + ctx.channel().toString(), (CinRequest) message);
		else
			_tracer.info("CinResponse has been received." + ctx.channel().toString(), (CinResponse) message);
		super.channelRead(ctx, msg);
	}
}
