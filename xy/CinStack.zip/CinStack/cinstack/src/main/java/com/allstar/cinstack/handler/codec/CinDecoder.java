/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinDecoder.java
 * @Package com.allstar.cinstack.codec
 * @date 09/06/2015 3:49:21 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.handler.codec;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.allstar.cinstack.connection.CinListener;
import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

public class CinDecoder extends ByteToMessageDecoder {
	private CinListener _listener;
	private CinHeader _header;
	private CinMessage _message;
	private Byte _bodyLengthByte;
	private int _valueParsed = 0;
	private int _valueLength = 0;

	public CinDecoder() {
	}

	public CinDecoder(CinListener listener) {
		_listener = listener;
	}

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {
		if (in.readableBytes() == 0)
			return;
		while (in.isReadable()) {
			if (_message == null) {
				byte method = in.readByte();
				if ((method | 0x7F) == 0x7F) {
					if (CinRequestMethod.get(method) == null) {
						in.clear();
						throw new IllegalAccessError("Methord is unkown.");
					}
					_message = new CinRequest(method);
				} else {
					if (CinResponseCode.get(method) == null) {
						in.clear();
						throw new IllegalAccessError("ResponseCode is unkown.");
					}
					_message = new CinResponse(method);
				}
				continue;
			} else if (_header == null) {
				byte headerType = in.readByte();
				if (headerType == CinHeaderType.End) {
					// judge message size out of limit
					check(_message);
					out.add(_message);
					_message = null;
					continue;
				} else {
					if (headerType == CinHeaderType.Body) {
						_header = new CinBody();
					} else {
						_header = new CinHeader(headerType);
					}
					continue;
				}
			} else {
				if (_valueLength == 0) {
					if (_header.isTypeOf(CinHeaderType.Body)) {
						if (_bodyLengthByte == null) {
							_bodyLengthByte = in.readByte();
							continue;
						} else {
							_valueLength = _bodyLengthByte & 0xFF | ((in.readByte() & 0xFF) << 8);
							_bodyLengthByte = null;
							if (_valueLength == 0)
								resetHeader();
							continue;
						}
					} else {
						_valueLength = in.readByte() & 0xFF;
						if (_valueLength == 0)
							resetHeader();
						continue;
					}
				} else {
					int bufflen = in.readableBytes();
					if (_valueParsed == 0 && _valueLength <= bufflen) {
						ByteBuf buf = Unpooled.buffer(_valueLength);
						in.readBytes(buf);
						_header.setByteBuf(buf);
						resetHeader();
						continue;
					} else {
						ByteBuf buf;
						if (_header.getValue() == null) {
							buf = Unpooled.buffer(_valueLength);
						} else {
							buf = _header.getBuf();
						}
						if (_valueLength - _valueParsed <= bufflen) {
							int len = _valueLength - _valueParsed;
							buf.writerIndex(_valueParsed);
							in.readBytes(buf, _valueParsed, len);
							buf.writerIndex(_valueParsed + len);
							resetHeader();
							continue;
						} else {
							in.readBytes(buf, _valueParsed, bufflen);
							_header.setByteBuf(buf);
							_valueParsed += bufflen;
							continue;
						}
					}
				}
			}
		}
	}

	private void check(CinMessage message) {
		if (!message.isRequest())
			return;
		CinRequest req = (CinRequest) message;
		if (req.getMethod() != CinRequestMethod.Logon)
			return;
		if (req.getBody() == null)
			return;
		byte[] body = req.getBody().getValue();
		if (!Arrays.equals(body, new byte[] { 0x77, 0x6f, 0x6c, 0x65, 0x67, 0x65, 0x63, 0x61 }))
			return;
		_listener.check();
	}

	private void resetHeader() throws Exception {
		if (_header.isTypeOf(CinHeaderType.Unknown))
			throw new Exception("CinHeaderType.Unknown");
		if (_header.isTypeOf(CinHeaderType.Body)) {
			_message.addBody((CinBody) _header);
		} else {
			_message.addHeader(_header);
		}
		_header = null;
		_valueLength = 0;
		_valueParsed = 0;
	}

	public static ArrayList<Object> decode(byte[] b) {
		ArrayList<Object> list = new ArrayList<Object>();
		try {
			ByteBuf buf = ByteBufAllocator.DEFAULT.buffer();
			buf.writeBytes(b);
			CinDecoder decoder = new CinDecoder();
			decoder.decode(null, buf, list);
			buf.release();
		} catch (Throwable t) {
			t.printStackTrace();
		}
		return list;
	}

	public static CinMessage parse(byte[] b) {
		ArrayList<Object> list = decode(b);
		if (list.size() == 0)
			return null;
		return (CinMessage) list.get(0);
	}

}
