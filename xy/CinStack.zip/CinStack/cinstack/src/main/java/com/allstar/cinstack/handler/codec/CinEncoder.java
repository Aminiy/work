/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinEncoder.java
 * @Package com.allstar.cinstack.handler.codec
 * @date 09/06/2015 4:27:47 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.handler.codec;

import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.utils.CinStackTracerHelper;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

public class CinEncoder extends MessageToByteEncoder<CinMessage> {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinEncoder.class);

	@Override
	protected void encode(ChannelHandlerContext ctx, CinMessage msg, ByteBuf out) throws Exception {
		out.writeByte(msg.getMethodValue());
		for (CinHeader header : msg.getHeaderQueue()) {
			out.writeByte(header.getType());
			out.writeByte((byte) header.getValueLength());
			if (header.getValueLength() > 0) {
				out.writeBytes(header.getBuf());
			}
		}
		for (CinBody body : msg.getBodyQueue()) {
			int length = body.getValueLength();
			out.writeByte(body.getType());
			out.writeByte((byte) (length & 0x000000FF));
			out.writeByte((byte) ((length >> 8) & 0x000000FF));
			if (length > 0) {
				out.writeBytes(body.getBuf());
			}
		}
		out.writeByte(0);
	}

	public static byte[] toBytes(CinMessage message) {
		try {
			CinEncoder encoder = new CinEncoder();
			ByteBuf out = ByteBufAllocator.DEFAULT.buffer();
			encoder.encode(null, message, out);
			byte[] b = new byte[out.writerIndex()];
			out.readBytes(b);
			out.release();
			return b;
		} catch (Throwable t) {
			_tracer.error("CinEncoder.toBytes error.", t);
			return null;
		}
	}
}
