/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinHexTracer.java
 * @Package com.allstar.cinstack.handler
 * @date June 9, 2015 at 10:09:05 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.handler.inbound;

import com.allstar.cinstack.utils.CinStackTracerHelper;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.ChannelHandlerContext;

public class CinHexTraceInboundHandler extends CinInboundHandler {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinHexTraceInboundHandler.class);

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
		ByteBuf buf = (ByteBuf) msg;
		_tracer.info("CinConnection has received data." + ctx.channel().toString() + "\r\n" + ByteBufUtil.hexDump(buf));
		ctx.fireChannelRead(msg);
	}
}
