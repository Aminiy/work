/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinStackConfiguration.java
 * @Package com.allstar.cinstack
 * @date June 10, 2015, 5:20:19 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import com.allstar.cinstack.utils.CinStackTracerHelper;

public class CinStackConfiguration {
	private CinStackMode _mode;
	private boolean _enableHexTracer;
	private boolean _enableSignallingTracer;
	private int _workThreadCount;
	private String _keyStorePath;
	private String _keyStorePwd;

	private int _qLengthInCinMutiplexConnection;
	private int _lifeCycleOfCinMutiplexConnection;
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinStackConfiguration.class);

	public CinStackConfiguration() {
		_mode = CinStackMode.Mutiplex;
		_enableHexTracer = false;
		_enableSignallingTracer = true;
		//_workThreadCount = 0;
		_workThreadCount = readCinStackThreadCount();
		
		_qLengthInCinMutiplexConnection = 128;
		_lifeCycleOfCinMutiplexConnection = 9 * 60;
	}	

	public void setStackMode(CinStackMode mode) {
		_mode = mode;
	}

	public CinStackMode getStackMode() {
		return _mode;
	}

	public void setEnableHexTracer(boolean enable) {
		_enableHexTracer = enable;
	}

	public boolean getEnableHexTracer() {
		return _enableHexTracer;
	}

	public void setEnableSignallingTracer(boolean enable) {
		_enableSignallingTracer = enable;
	}

	public boolean getEnableSignallingTracer() {
		return _enableSignallingTracer;
	}

	public void setWorkThreadCount(int count) {
		_workThreadCount = count;
	}

	public int getWorkThreadCount() {
		return _workThreadCount;
	}

	public boolean getEnableSSL() {
		if (getKeyStorePath() == null)
			return false;
		if (getKeyStorePath() == "")
			return false;
		return true;
	}

	public void setKeyStorePath(String keyStorePath) {
		_keyStorePath = keyStorePath;
	}

	public String getKeyStorePath() {
		return _keyStorePath;
	}

	public void setKeyStorePwd(String pwd) {
		_keyStorePwd = pwd;
	}

	public String getKeyStorePwd() {
		return _keyStorePwd;
	}

	public void setQLengthInCinMutiplexConnection(int length) {
		_qLengthInCinMutiplexConnection = length;
	}

	public int getQLengthInCinMutiplexConnection() {
		return _qLengthInCinMutiplexConnection;
	}

	public void setLifeCycleOfCinMutiplexConnection(int seconds) {
		_lifeCycleOfCinMutiplexConnection = seconds;
	}

	public int getLifeCycleOfCinMutiplexConnection() {
		return _lifeCycleOfCinMutiplexConnection;
	}
	//Added this method to get workThreadCount value from servicesetting.properties file and set into _workThreadCountdata attribute 
	
	private static int readCinStackThreadCount() {

		FileInputStream fis = null;
		int workThreadCount=0;
		try
		{
			fis = new FileInputStream("servicesetting.properties");
			Properties properties = new Properties();
			properties.load(fis);
			if (properties.containsKey("workThreadCount"))
			{
			workThreadCount = Integer.parseInt(properties.getProperty("workThreadCount"));
 			}
 
		}
		catch (FileNotFoundException ex)
		{
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if (fis != null)
					fis.close();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		_tracer.info("CinStackConfiguration @@@@ workthread count value is " + workThreadCount);
		return workThreadCount;
		
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("CinStackMode: ");
		sb.append(getStackMode().toString());
		sb.append("; EnableHexTracer: ");
		sb.append(getEnableHexTracer());
		sb.append("; EnableSignallingTracer: ");
		sb.append(getEnableSignallingTracer());
		sb.append("; WorkerThreadCount: ");
		sb.append(getWorkThreadCount());
		sb.append("; EnableSSL: ");
		sb.append(getEnableSSL());
		sb.append("; KeyStorePath: ");
		sb.append(getKeyStorePath());
		sb.append("; KeyStorePwd: ");
		sb.append(getKeyStorePwd());
		sb.append("; QLengthInCinMutiplexConnection: ");
		sb.append(getQLengthInCinMutiplexConnection());
		sb.append("; LifeCycleOfCinMutiplexConnection: ");
		sb.append(getLifeCycleOfCinMutiplexConnection());
		return sb.toString();
	}
}
