/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinPipelineBuilder.java
 * @Package com.allstar.cinstack.utils
 * @date March 29, 2016 at 10:45:30 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.utils;

import com.allstar.cinstack.common.CinStackConfiguration;
import com.allstar.cinstack.connection.CinConnection;
import com.allstar.cinstack.connection.CinListener;
import com.allstar.cinstack.handler.CinTransactionHandler;
import com.allstar.cinstack.handler.codec.CinDecoder;
import com.allstar.cinstack.handler.codec.CinEncoder;
import com.allstar.cinstack.handler.inbound.CinHexTraceInboundHandler;
import com.allstar.cinstack.handler.inbound.CinSignallingTraceInboundHandler;
import com.allstar.cinstack.handler.outbound.CinHexTraceOutboundHandler;
import com.allstar.cinstack.handler.outbound.CinSignallingTraceOutboundHandler;

import io.netty.channel.ChannelPipeline;
import io.netty.handler.traffic.ChannelTrafficShapingHandler;

public class CinStackPipelineBuilder {

	public static void buildPipeline(ChannelPipeline line, CinStackConfiguration config, CinConnection conn, CinListener listener) {
		ChannelTrafficShapingHandler traffic = new ChannelTrafficShapingHandler(0);

		line.addLast(traffic);
		if (config.getEnableHexTracer())
			line.addLast(new CinHexTraceInboundHandler());
		line.addLast(new CinDecoder(listener));
		if (config.getEnableSignallingTracer())
			line.addLast(new CinSignallingTraceInboundHandler(conn));

		line.addLast(new CinTransactionHandler(conn));

		if (config.getEnableHexTracer())
			line.addLast(new CinHexTraceOutboundHandler());
		line.addLast(new CinEncoder());
		if (config.getEnableSignallingTracer())
			line.addLast(new CinSignallingTraceOutboundHandler());
		
		conn.registerTrafficCounter(traffic.trafficCounter());
	}
}
