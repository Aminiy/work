/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinStackCounterHelper.java
 * @Package com.allstar.cinstack.utils
 * @date April 7, 2016 at 1:58:17 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.utils;

import com.allstar.cinstack.common.CinStackCounter;
import com.allstar.cinstack.connection.CinConnection;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.transaction.CinTransaction;

public class CinStackCounterHelper {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinStackCounterHelper.class);

	private CinStackCounter _counter;

	public void registerCinStackCounter(CinStackCounter counter) {
		_counter = counter;
	}

	public void countRequestReceived(CinRequest req) {
		if (_counter == null)
			return;
		try {
			_counter.countRequestReceived(req);
		} catch (Throwable t) {
			_tracer.error("CinStackCounterHelper.countRequestReceived error.", req, t);
		}
	}

	public void countResponseReceived(CinTransaction trans) {
		if (_counter == null)
			return;
		try {
			_counter.countResponseReceived(trans);
		} catch (Throwable t) {
			_tracer.error("CinStackCounterHelper.countResponseReceived error.", trans.getRequest(), t);
		}
	}

	public void countOutOfBoundingResonseReceived(CinResponse resp) {
		if (_counter == null)
			return;
		try {
			_counter.countOutOfBoundingResonseReceived(resp);
		} catch (Throwable t) {
			_tracer.error("CinStackCounterHelper.countOutOfBoundingResonseReceived error.", resp, t);
		}
	}

	public void countRequestSent(CinTransaction trans) {
		if (_counter == null)
			return;
		try {
			_counter.countRequestSent(trans);
		} catch (Throwable t) {
			_tracer.error("CinStackCounterHelper.countRequestSent error.", trans.getRequest(), t);
		}
	}

	public void countResponseSent(CinTransaction trans) {
		if (_counter == null)
			return;
		try {
			_counter.countResponseSent(trans);
		} catch (Throwable t) {
			_tracer.error("CinStackCounterHelper.countResponseSent error.", trans.getRequest(), t);
		}
	}

	public void countRequestSentFailed(CinTransaction trans) {
		if (_counter == null)
			return;
		try {
			_counter.countRequestSentFailed(trans);
		} catch (Throwable t) {
			_tracer.error("CinStackCounterHelper.countRequestSentFailed error.", trans.getRequest(), t);
		}
	}

	public void countResponseSentFailed(CinTransaction trans) {
		if (_counter == null)
			return;
		try {
			_counter.countResponseSentFailed(trans);
		} catch (Throwable t) {
			_tracer.error("CinStackCounterHelper.countResponseSentFailed error.", trans.getRequest(), t);
		}
	}

	public void countRequestSentTimeout(CinTransaction trans) {
		if (_counter == null)
			return;
		try {
			_counter.countRequestSentTimeout(trans);
		} catch (Throwable t) {
			_tracer.error("CinStackCounterHelper.countRequestSentTimeout error.", trans.getRequest(), t);
		}
	}

	public void countConnectionConnected(CinConnection conn) {
		if (_counter == null)
			return;
		try {
			_counter.countConnectionConnected(conn);
		} catch (Throwable t) {
			_tracer.error("CinStackCounterHelper.countConnectionConnected error.", t);
		}
	}

	public void countConnectionConnectFailed(CinConnection conn) {
		if (_counter == null)
			return;
		try {
			_counter.countConnectionConnectFailed(conn);
		} catch (Throwable t) {
			_tracer.error("CinStackCounterHelper.countConnectionConnectFailed error.", t);
		}
	}

	public void countConnectionDisconnected(CinConnection conn) {
		if (_counter == null)
			return;
		try {
			_counter.countConnectionDisconnected(conn);
		} catch (Throwable t) {
			_tracer.error("CinStackCounterHelper.countConnectionDisconnected error.", t);
		}
	}
}
