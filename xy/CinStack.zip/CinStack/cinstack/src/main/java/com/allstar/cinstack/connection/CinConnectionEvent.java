/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinConnection.java
 * @Package com.allstar.cinstack.connection
 * @date 25/03/2016 3:39:28 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.connection;

public interface CinConnectionEvent {

	void onConnected(CinConnection conn, Object obj);

	void onConnectFailed(CinConnection conn, Object obj);

	void onDisconnected(CinConnection conn, Object obj);

}
