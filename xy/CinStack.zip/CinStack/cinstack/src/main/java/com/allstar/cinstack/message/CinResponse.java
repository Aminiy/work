/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinResponse.java
 * @Package com.allstar.cinstack.message
 * @date June 9, 2015 at 10:07:33 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.message;

import java.util.ArrayList;

public final class CinResponse extends CinMessage {

	public CinResponse(byte code) {
		super(code);
	}

	/**
	 * Only use for CinReponse in Http Response
	 *
	 * @param code
	 * @return
	 */
	public static CinResponse createResponse(byte code) {
		return new CinResponse(code);
	}

	/**
	 * According to the request to create response for OK constructor
	 *
	 * @param request
	 *            The original request
	 */
	public CinResponse(CinRequest request) {
		this(request, CinResponseCode.OK);
	}

	/**
	 * According to the request to create response function in the construction
	 * of the specified response code code at the same time
	 *
	 * @param request
	 * @param code
	 */
	public CinResponse(CinRequest request, byte code) {
		super(code);
	}

	/**
	 * The response code to get the reply
	 *
	 * @return
	 */
	public byte getStatusCode() {
		return super.getMethodValue();
	}

	/**
	 * Determine whether the response of the response code is the same as the
	 * parameters specified in the response code
	 *
	 * @param code
	 * @return true: if the code of this response is same as code in
	 *         parameter</br>
	 *         false: if not
	 */
	public boolean isResponseCode(byte code) {
		return super.getMethodValue() == code;
	}

	public CinResponse cloneSpecialHeader() {
		CinResponse response = new CinResponse(CinResponseCode.Pending);
		ArrayList<CinHeader> list = this.getHeaders();
		for (CinHeader header : list) {
			switch (header.getType()) {
			case CinHeaderType.From:
			case CinHeaderType.To:
			case CinHeaderType.CallId:
			case CinHeaderType.Csequence:
			case CinHeaderType.Fpid:
			case CinHeaderType.Tpid:
				response.addHeader(new CinHeader(header.getType(), header.getValue()));
				break;
			}
		}
		return response;
	}

	public void makeConsistency(CinRequest req) {
		if (From == null && req.From != null)
			addHeader(CinHeaderType.From, req.From.getBuf().array());
		if (To == null && req.To != null)
			addHeader(CinHeaderType.To, req.To.getBuf().array());
		if (CallId == null && req.CallId != null)
			addHeader(CinHeaderType.CallId, req.CallId.getBuf().array());
		if (Csequence == null && req.Csequence != null)
			addHeader(CinHeaderType.Csequence, req.Csequence.getBuf().array());
		if (Fpid == null && req.Fpid != null)
			addHeader(CinHeaderType.Fpid, req.Fpid.getBuf().array());
		if (Tpid == null && req.Tpid != null)
			addHeader(CinHeaderType.Tpid, req.Tpid.getBuf().array());
	}

	@Override
	public CinResponse clone() {
		CinResponse resp = new CinResponse(getStatusCode());
		ArrayList<CinHeader> list = this.getHeaders();
		ArrayList<CinBody> bodys = this.getBodys();

		for (CinHeader header : list) {
			if (!(header.isTypeOf(CinHeaderType.RecordRoute) || header.isTypeOf(CinHeaderType.Route)))
				resp.addHeader(new CinHeader(header.getType(), header.getValue()));
		}

		for (CinBody body : bodys) {
			resp.addBody(new CinBody(body.getValue()));
		}
		return resp;
	}

	@Override
	public boolean isRequest() {
		return false;
	}
}
