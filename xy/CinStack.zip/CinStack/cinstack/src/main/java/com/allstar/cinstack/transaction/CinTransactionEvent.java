/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinTransactionEvent.java
 * @Package com.allstar.cinstack.transaction
 * @date June 9, 2015 10:05:55 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.transaction;

public interface CinTransactionEvent {

	void onResponseReceived(CinTransaction trans);

	void onRequestSentTimeout(CinTransaction trans);

	void onRequestSentFailed(CinTransaction trans);

	// void onRequestSent(CinTransaction trans);

}
