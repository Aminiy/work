/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title ICinTransactionManager.java
 * @Package com.allstar.cinstack.transaction
 * @date June 9, 2015 at 4:29:39 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.transaction;

import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.utils.CinStackCounterHelper;
import com.allstar.cinstack.utils.CinStackTimer;
import com.allstar.cinstack.utils.CinStackTracerHelper;

public class CinTransactionManager implements Runnable {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinTransactionManager.class);

	private CinStackCounterHelper _counter;
	private boolean _isRunning;
	private ConcurrentHashMap<String, CinTransaction> _trans;
	private ConcurrentHashMap<Integer, LinkedList<CinTransaction>> _sortTrans;

	public CinTransactionManager(CinStackCounterHelper counter) {
		_counter = counter;
		_isRunning = true;
		_trans = new ConcurrentHashMap<String, CinTransaction>(16, 0.75f, 1);
		_sortTrans = new ConcurrentHashMap<Integer, LinkedList<CinTransaction>>(2, 0.75f, 1);
		CinStackTimer.getInstance().schedule(this, 1, TimeUnit.SECONDS);
	}

	public void close() {
		doTimeout(Long.MAX_VALUE);
		clear();
		_isRunning = false;
	}

	private synchronized void clear() {
		_trans.clear();
		_sortTrans.clear();
	}

	public CinTransaction createTransaction(CinRequest req) {
		return createTransaction(req, 60);
	}

	public CinTransaction createTransaction(CinRequest req, int timeout) {
		CinTransaction trans = new CinTransaction(req, timeout);
		return trans;
	}

	public CinTransaction getTransaction(String key) {
		return _trans.get(key);
	}

	public synchronized void addTransaction(CinTransaction trans) {
		_trans.put(trans.getKey(), trans);
		LinkedList<CinTransaction> q = _sortTrans.get(trans.getTimeout());
		if (q == null)
			_sortTrans.put(trans.getTimeout(), q = new LinkedList<CinTransaction>());
		if (q.offer(trans))
			_tracer.debug("CinTransaction has been added in the CinTransactionManager.\r\n" + trans.toString());
	}

	public synchronized void removeTransaction(String key) {
		CinTransaction trans = _trans.get(key);
		if (trans == null)
			return;
		LinkedList<CinTransaction> q = _sortTrans.get(trans.getTimeout());
		if (q != null)
			q.remove(trans);
		_trans.remove(key);
		_tracer.debug("CinTransaction has been removed in the CinTransactionManager.\r\n" + trans.toString());
	}

	private synchronized void doTimeout(long now) {
		LinkedList<CinTransaction> list = new LinkedList<CinTransaction>();
		for (LinkedList<CinTransaction> q : _sortTrans.values()) {
			for (CinTransaction trans : q)
				if (trans.isTimeout(now))
					list.add(trans);
				else
					break;
		}

		for (CinTransaction trans : list) {
			_tracer.warn("CinTransaction has been timeout. ", trans.getRequest());
			_counter.countRequestSentTimeout(trans);
			trans.doRequestSentTimeout();
			_sortTrans.get(trans.getTimeout()).remove(trans);
			_trans.remove(trans.getKey());
		}
	}

	public boolean isEmpty() {
		return _trans.isEmpty();
	}

	@Override
	public void run() {
		try {
			_tracer.debug("Start to Check Transaction Timeout.");
			doTimeout(System.currentTimeMillis());
			_tracer.debug("Finish to Check Transaction Timeout.");
		} catch (Throwable t) {
			_tracer.error("CinTransactionManager.run error.", t);
		} finally {
			if (_isRunning)
				CinStackTimer.getInstance().schedule(this, 1, TimeUnit.SECONDS);
		}
	}
}
