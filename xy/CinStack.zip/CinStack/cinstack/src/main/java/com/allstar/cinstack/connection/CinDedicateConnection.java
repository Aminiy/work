/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinConnection.java
 * @Package com.allstar.cinstack.connection
 * @date 11/06/2016 3:39:28 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.connection;

import java.net.InetSocketAddress;

import com.allstar.cinstack.common.CinStackConfiguration;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.utils.CinStackCounterHelper;
import com.allstar.cinstack.utils.CinStackTracerHelper;

import io.netty.channel.EventLoopGroup;

public class CinDedicateConnection extends CinConnection {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinDedicateConnection.class);

	public CinDedicateConnection(CinStackConfiguration config, EventLoopGroup group, CinStackCounterHelper counter) {
		super(config, group, counter);
	}

	public void connect(String ip, int port) {
		connect(ip, port);
	}

	public void connect(String ip, int port, Object obj) {
		connect(new InetSocketAddress(ip, port), obj);
	}

	public void connect(InetSocketAddress remote) {
		connect(remote, null);
	}

	public void connect(InetSocketAddress remote, Object obj) {
		super.setRemote(remote);
		super.connect(obj);
	}

	@Override
	public boolean checkConnectionStatus(CinTransaction trans) {
		return true;
	}

	@Override
	public void flushHolder() {
	}

	@Override
	public void cleanHolder() {
	}

	@Override
	public void doCinRequestReceived(CinRequest req) {
		getCounter().countRequestReceived(req);
		CinConnectionEvent event = getCinConnectionEvent();
		if (event != null && event instanceof CinDedicateConnectionEvent) {
			CinTransaction trans = getCinTransactionManager().createTransaction(req);
			trans.registerCinConnection(this);
			try {
				((CinDedicateConnectionEvent) event).onCinTransactionCreated(trans);
			} catch (Throwable t) {
				_tracer.error("CinDedicateConnection.doCinRequestReceived error.", req, t);
			}
		}
	}

	@Override
	public void doCinResponseReceived(CinResponse resp) {
		String key = resp.getKey();
		CinTransaction trans = getCinTransactionManager().getTransaction(key);
		if (trans == null) {
			getCounter().countOutOfBoundingResonseReceived(resp);
			_tracer.warn("Receive out of bounding response. Key: " + key);
		} else {
			getCinTransactionManager().removeTransaction(key);
			trans.doResponseReceived(resp);
			getCounter().countResponseReceived(trans);
		}
	}
}