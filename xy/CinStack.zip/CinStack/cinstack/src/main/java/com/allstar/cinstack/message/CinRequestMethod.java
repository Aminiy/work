/**
 * 
 */
package com.allstar.cinstack.message;

import java.lang.reflect.Field;
import java.util.HashMap;

/**
 * Enumeration of request method.
 * 
 * @see com.allstar.cintransaction.cinmessage.CinRequest
 * @author allstar
 * 
 */
public class CinRequestMethod {
	public static final byte Service = (byte) 0x01;
	public static final byte Message = (byte) 0x02;
	public static final byte Reply = (byte) 0x03;
	public static final byte ReadReply = (byte) 0x04;
	public static final byte KeepAlive = (byte) 0x05;
	public static final byte Logon = (byte) 0x07;
	public static final byte Notify = (byte) 0x0A;
	public static final byte Ask = (byte) 0x0B;
	public static final byte Typing = (byte) 0x0C;
	public static final byte Take = (byte) 0x0F;
	public static final byte Group = (byte) 0x10;
	public static final byte GroupMessage = (byte) 0x11;
	public static final byte Data = (byte) 0x15;
	public static final byte Verify = (byte) 0x17;
	public static final byte Report = (byte) 0x19;
	public static final byte PhoneBook = (byte) 0x1A;
	public static final byte Emoticon = (byte) 0x1B;
	public static final byte Video = (byte) 0x1C;
	public static final byte Sip = (byte) 0x1D;
	public static final byte PPService = (byte) 0x1E;
	public static final byte PPMessage = (byte) 0x1F;
	public static final byte RobotMessage = (byte) 0x20;

	public static final byte RMC = (byte) 0x21;
	public static final byte LocationSharing = (byte) 0x22;
	public static final byte TRACK = (byte) 0x23;
	
	public static final byte DPService = (byte) 0x30;
	public static final byte DPSub = (byte) 0x31;
	public static final byte DPUnSub = (byte) 0x32;
	public static final byte DPNotify = (byte) 0x33;
	public static final byte DPTake = (byte) 0x34;

	//JioMOney
	public static final byte JMTransaction = (byte) 0x40;
	public static final byte SIGNUP = (byte) 0x41;
	public static final byte WebPay = (byte) 0x42;
	public static final byte PSTNCall = (byte) 0x51;
	public static final byte PPRenewToken = (byte) 0x53;

	public static final byte Social = (byte) 0x62;
	public static final byte SMS = (byte) 0x63;
	public static final byte SocialNotify = (byte) 0x64;

	public static final byte HotBackup = (byte) 0x76;
	public static final byte Observation = (byte) 0x77;
	public static final byte Log = (byte) 0x78;
	public static final byte Trace = (byte) 0x79;
	public static final byte Monitoring = (byte) 0x7A;
	public static final byte RPC = (byte) 0x7b;
	public static final byte InnerService = (byte) 0x7C;
	public static final byte Config = (byte) 0x7D;
	public static final byte Unknown = (byte) 0X7E;

	private static HashMap<Byte, String> _map;
	static {
		try {
			Class<?> headertype = Class.forName(CinRequestMethod.class.getCanonicalName());
			Field[] fields = headertype.getFields();
			_map = new HashMap<Byte, String>();

			for (Field field : fields) {
				_map.put(Byte.valueOf(field.getByte(null)), field.getName());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Through the method of value for string expression
	 * 
	 * @param type
	 * @return Representation the method in String format
	 */
	public static String get(byte type) {
		return _map.get(type);
	}
}
