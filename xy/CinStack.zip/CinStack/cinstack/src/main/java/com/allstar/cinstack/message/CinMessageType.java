package com.allstar.cinstack.message;

/**
 * Enumeration of CinMessage, including request and response.
 * 
 * 
 */
public enum CinMessageType {
	CinRequest, CinResponse
}
