/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinTransactionCreateEvent.java
 * @Package com.allstar.cinstack.transaction
 * @date June 9, 2015 at 10:06:26 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.transaction;

public interface CinTransactionCreatedEvent {

	void onCinTransactionCreated(CinTransaction trans);

}
