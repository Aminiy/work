/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinTextTraceOutboundHandler.java
 * @Package com.allstar.cinstack.handler
 * @date June 10, 2015 at 10:06:24 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.handler.outbound;

import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.utils.CinStackTracerHelper;

import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.ChannelPromise;

public class CinSignallingTraceOutboundHandler extends ChannelOutboundHandlerAdapter {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinSignallingTraceOutboundHandler.class);

	@Override
	public void write(final ChannelHandlerContext ctx, final Object msg, ChannelPromise promise) throws Exception {
		promise.addListener(new ChannelFutureListener() {
			public void operationComplete(ChannelFuture future) throws Exception {
				CinMessage message = (CinMessage) msg;
				if (message.isRequest())
					_tracer.info("CinRequest has been sent. " + ctx.channel().toString(), message);
				else
					_tracer.info("CinResponse has been sent. " + ctx.channel().toString(), message);
			}
		});
		super.write(ctx, msg, promise);
	}
}
