/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinStack.java
 * @Package com.allstar.cinstack
 * @date June 9, 2015 10:04:14 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack;

import io.netty.channel.nio.NioEventLoopGroup;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.concurrent.Executors;
import com.allstar.cinstack.common.CinStackConfiguration;
import com.allstar.cinstack.common.CinStackCounter;
import com.allstar.cinstack.common.CinStackMode;
import com.allstar.cinstack.common.CinStackRouterEvent;
import com.allstar.cinstack.common.CinStackTracerFactory;
import com.allstar.cinstack.connection.CinDedicateConnection;
import com.allstar.cinstack.connection.CinDedicateConnectionEvent;
import com.allstar.cinstack.connection.CinListener;
import com.allstar.cinstack.connection.CinMutiplexConnection;
import com.allstar.cinstack.connection.CinMutiplexConnectionManager;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionCreatedEvent;
import com.allstar.cinstack.utils.CinStackCounterHelper;
import com.allstar.cinstack.utils.CinStackTracerHelper;

public class CinStack {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinStack.class);
	private static CinStack _instance;

	private CinStackConfiguration _config;
	private NioEventLoopGroup _group;
	private CinMutiplexConnectionManager _mConnMgr;
	private CinStackCounterHelper _counter;
	private CinListener _listener;
	private CinStackRouterEvent _routerEvent;

	static {
		CinStackConfiguration config = new CinStackConfiguration();
		config.setStackMode(CinStackMode.Mutiplex);
		_instance = new CinStack(config);
	}

	@Deprecated
	public static CinStack instance() {
		return _instance;
	}

	public static void registerCinStackTracerFactory(CinStackTracerFactory factory) {
		CinStackTracerHelper.registerCinStackTracerFactory(factory);
		_tracer.info("CinStackTracer has been registered.");
	}

	public CinStack(CinStackConfiguration config) {
		_config = config;
		_counter = new CinStackCounterHelper();
		_group = new NioEventLoopGroup(config.getWorkThreadCount());
		if (_config.getStackMode() == CinStackMode.Mutiplex)
			_mConnMgr = new CinMutiplexConnectionManager(_config, _group, _counter);
		_listener = new CinListener(_config, _group, _counter);
		Executors.newFixedThreadPool(1).execute(_listener);
		_tracer.info("CinStack has been initialized.\r\n" + _config.toString());
	}

	public void registerCinStackCounter(CinStackCounter counter) {
		_counter.registerCinStackCounter(counter);
		_tracer.info("CinStackCounter has been registered.");
	}

	public void registerCinStackRouterEvent(CinStackRouterEvent event) {
		_routerEvent = event;
	}

	public void listen(String ip, int port, CinDedicateConnectionEvent event) {
		listen(new InetSocketAddress(ip, port), event);
	}

	public void listen(final SocketAddress address, CinDedicateConnectionEvent event) {
		if (_config.getStackMode() != CinStackMode.Dedicate)
			throw new UnsupportedOperationException("The stack's mode MUST be Dedicate.");
		_listener.registerCinConnectionEvent(event);
		_listener.listen(address);
	}

	public void listen(String ip, int port, CinTransactionCreatedEvent event) {
		listen(new InetSocketAddress(ip, port), event);
	}

	public void listen(final SocketAddress address, CinTransactionCreatedEvent event) {
		if (_config.getStackMode() != CinStackMode.Mutiplex)
			throw new UnsupportedOperationException("The stack's mode MUST be Mutiplex.");
		_listener.registerCinTransactionCreatedEvent(event);
		_listener.listen(address);
	}

	public void registerCinTransactionCreatedEvent(byte method, CinTransactionCreatedEvent event) {
		if (_config.getStackMode() != CinStackMode.Mutiplex)
			throw new UnsupportedOperationException("The stack's mode MUST be Mutiplex.");
		_listener.registerCinTransactionCreatedEvent(method, event);
	}

	public synchronized CinDedicateConnection createCinDedicatConnection() {
		if (_config.getStackMode() != CinStackMode.Dedicate)
			throw new UnsupportedOperationException("The stack's mode MUST be Dedicate.");
		return new CinDedicateConnection(_config, _group, _counter);
	}

	public CinTransaction createTransaction(CinRequest req) {
		return createTransaction(req, 60);
	}

	public CinTransaction createTransaction(CinRequest req, int timeout) {
		InetSocketAddress remote = null;
		try {
			remote = _routerEvent.getAddress(req);
		} catch (Throwable t) {
			_tracer.error("CinStack.createTransaction error.", req, t);
		}
		if (remote == null)
			return null;
		return createTransaction(remote, req, timeout);
	}

	public CinTransaction createTransaction(InetSocketAddress remote, CinRequest req) {
		return createTransaction(remote, req, 60);
	}

	public CinTransaction createTransaction(InetSocketAddress remote, CinRequest req, int timeout) {
		if (_config.getStackMode() != CinStackMode.Mutiplex)
			throw new UnsupportedOperationException("The stack's mode MUST be Mutiplex.");
		CinMutiplexConnection conn = _mConnMgr.createCinMutiplexConnection(remote);
		CinTransaction trans = conn.createCinTransaction(req, timeout);
		return trans;
	}

	public void shutdown() {
		_group.shutdownGracefully();
	}
}
