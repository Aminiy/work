/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinHexTraceOutboundHandler.java
 * @Package com.allstar.cinstack.handler.outbound
 * @date June 10, 2015 at 10:09:56 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.handler.outbound;

import com.allstar.cinstack.utils.CinStackTracerHelper;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.ChannelPromise;

public class CinHexTraceOutboundHandler extends ChannelOutboundHandlerAdapter {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinHexTraceOutboundHandler.class);

	@Override
	public void write(final ChannelHandlerContext ctx, final Object msg, ChannelPromise promise) throws Exception {
		promise.addListener(new ChannelFutureListener() {
			public void operationComplete(ChannelFuture future) throws Exception {
				ByteBuf buf = (ByteBuf) msg;
				String hex = ByteBufUtil.hexDump(buf);
				_tracer.info("CinConnection has sent data. " + ctx.channel().toString() + "\r\n" + hex);
			}
		});
		super.write(ctx, msg, promise);
	}
}
