/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinTransaction.java
 * @Package com.allstar.cinstack.transaction
 * @date June 9, 2015 at 10:05:22 am
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.transaction;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicLong;

import com.allstar.cinstack.connection.CinConnection;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.utils.CinStackTracerHelper;

public class CinTransaction {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinTransaction.class);

	private static AtomicLong _cseq = new AtomicLong(0);
	public CinTransactionEvent Event;

	private CinRequest _req;
	private CinResponse _resp;
	private int _timeout;
	private CinConnection _conn;
	private long _generationTime;
	private long _sendRequestTime;
	private Object _attachment;
	private ArrayList<CinBody> _bodyList;
	@Deprecated
	private CinTransaction _innerTrans;

	CinTransaction(CinRequest req, int timeout) {
		_generationTime = System.currentTimeMillis();
		_req = req;
		_timeout = timeout;
	}

	public void registerCinConnection(CinConnection conn) {
		_conn = conn;
	}

	public CinRequest getRequest() {
		return _req;
	}

	public CinResponse getResponse() {
		return _resp;
	}

	public int getTimeout() {
		return _timeout;
	}

	public void setSendRequestTime(long time) {
		_sendRequestTime = time;
	}

	public long getSendRequestTime() {
		return _sendRequestTime;
	}

	public String getKey() {
		return _req.getKey();
	}

	public void doResponseReceived(CinResponse resp) {
		_resp = resp;
		if (_bodyList != null)
		{
			_resp.addBodys(_bodyList);
		}
		if (Event != null) {
			try {
				Event.onResponseReceived(this);
			} catch (Throwable t) {
				_tracer.error("CinTransaction.recieveResponse error.", resp, t);
			}
		}
	}

	public void doRequestSent() {
		// if (Event != null)
		// Event.onRequestSent(this);
	}

	public void doRequestSentFailed() {
		if (Event != null) {
			try {
				Event.onRequestSentFailed(this);
			} catch (Throwable t) {
				_tracer.error("CinTransaction.doRequestSentFailed error.", getRequest(), t);
			}
		}
	}

	public void doRequestSentTimeout() {
		if (Event != null) {
			try {
				Event.onRequestSentTimeout(this);
			} catch (Throwable t) {
				_tracer.error("CinTransaction.doRequestSentTimeout error.", getRequest(), t);
			}
		}
	}

	public void sendRequest() {
		if (_req == null)
			throw new IllegalArgumentException("Request can NOT be null.");
		_req.removeHeaders(CinHeaderType.Csequence);
		_req.addHeader(new CinHeader(CinHeaderType.Csequence, _cseq.incrementAndGet()));
		_conn.sendRequest(this);
	}

	public void sendResponse() {
		if (_resp == null)
			throw new IllegalArgumentException("Response can NOT be null.");
		_resp.makeConsistency(_req);
		_conn.sendResponse(this);
	}

	public void sendResponse(CinResponse resp) {
		_resp = resp;
		sendResponse();
	}

	public void sendResponse(byte code) {
		_resp = new CinResponse(_req, code);
		sendResponse();
	}

	public boolean isTimeout(long now) {
		return (getSendRequestTime() + _timeout * 1000) < now;
	}

	@Deprecated
	public void setStateTransaction(CinTransaction trans) {
		_innerTrans = trans;
	}

	@Deprecated
	public CinTransaction getStateTransaction() {
		return _innerTrans;
	}

	public void setAttachment(Object attachment) {
		_attachment = attachment;
	}

	public Object getAttachment() {
		return _attachment;
	}

	public void updateTransaction(){
		_generationTime = System.currentTimeMillis();
	}
	public void saveBodies(ArrayList<CinBody> bodies)
	{
		if (_bodyList == null)
		{
			_bodyList = new ArrayList<CinBody>();
		}
		_bodyList.addAll(bodies);
	}
	public String toString() {
		return "Key: " + getKey() + "; GenerationTime: " + _generationTime + "; SendTime: " + getSendRequestTime() + "; Timeout: " + getTimeout();
	}
}
