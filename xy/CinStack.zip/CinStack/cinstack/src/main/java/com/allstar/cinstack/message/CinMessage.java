/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinMessage.java
 * @Package com.allstar.cinstack.message
 * @date June 9, 2015 at 10:07:11 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.message;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.LinkedBlockingQueue;

public class CinMessage implements Cloneable {

	private LinkedBlockingQueue<CinHeader> _headers;
	private LinkedBlockingQueue<CinBody> _bodys;
	private byte _method;
	public CinHeader From;
	public CinHeader To;
	public CinHeader CallId;
	public CinHeader Csequence;
	public CinHeader Fpid;
	public CinHeader Tpid;
	public CinHeader Event;

	/**
	 * The constructor
	 *
	 * @param method
	 *            Signaling logo.Used to distinguish between the business type
	 */
	public CinMessage(byte method) {
		this._method = method;
		this._headers = new LinkedBlockingQueue<CinHeader>();
		this._bodys = new LinkedBlockingQueue<CinBody>();
	}

	public boolean isRequest() {
		return false;
	}

	/**
	 * To add a CinBody into CinMessage
	 *
	 * @param body
	 *            Signaling body body
	 */
	public void addBody(CinBody body) {
		if (body != null) {
			_bodys.add(body);
		}
	}

	public void addBody(String s) {
		addBody(s.getBytes(Charset.forName("utf-8")));
	}

	/**
	 * Will be as Body join CinMessage byte array
	 *
	 * @param bytes
	 */
	public void addBody(byte[] bytes) {
		if (bytes != null) {
			CinBody body = new CinBody(bytes);
			addBody(body);
		}
	}

	/**
	 * Add a list of the Body to Body of CinMessage list
	 *
	 * @param bodys
	 */
	public void addBodys(ArrayList<CinBody> bodys) {
		for (CinBody body : bodys) {
			addBody(body);
		}
	}

	public LinkedBlockingQueue<CinHeader> getHeaderQueue() {
		return this._headers;
	}

	public LinkedBlockingQueue<CinBody> getBodyQueue() {
		return this._bodys;
	}

	public void addHeader(byte type, long value) {
		addHeader(new CinHeader(type, value));
	}

	public void addHeader(byte type, String value) {
		addHeader(new CinHeader(type, value));
	}

	public void addHeader(byte type, byte[] value) {
		addHeader(new CinHeader(type, value));
	}

	/**
	 * Add a signaling head to CinMessage
	 *
	 * @param header
	 */
	public void addHeader(CinHeader header) {
		if (header != null) {
			switch (header.getType()) {
			case CinHeaderType.From: {
				this._headers.add(header);
				this.From = header;
			}
				break;
			case CinHeaderType.To: {
				this._headers.add(header);
				this.To = header;
			}
				break;
			case CinHeaderType.CallId: {
				this._headers.add(header);
				this.CallId = header;
			}
				break;
			case CinHeaderType.Csequence: {
				this._headers.add(header);
				this.Csequence = header;
				// do nothing.
			}
				break;
			case CinHeaderType.Fpid: {
				this._headers.add(header);
				this.Fpid = header;
			}
				break;
			case CinHeaderType.Tpid: {
				this._headers.add(header);
				this.Tpid = header;
			}
				break;
			case CinHeaderType.Event: {
				this._headers.add(header);
				this.Event = header;
			}
				break;
			default: {
				this._headers.add(header);
			}
				break;
			}
		}
	}

	/**
	 * The first to obtain a list of CinMessage CinBody elements
	 *
	 * @return
	 */
	public synchronized CinBody getBody() {
		try {
			return _bodys.peek();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * To get the CinMessage Body in the list
	 *
	 * @return
	 */
	public synchronized ArrayList<CinBody> getBodys() {
		ArrayList<CinBody> ret = new ArrayList<CinBody>();
		ret.addAll(_bodys);
		return ret;
	}

	/**
	 * According to the type to get the CinMessage signaling in the head
	 *
	 * @param headerType
	 *            Identify signaling head type
	 * @return If you have any more of the same type signaling the CinMessage
	 *         head, back to the first
	 */
	public synchronized CinHeader getHeader(byte headerType) {
		for (CinHeader header : _headers) {
			if (header.isTypeOf(headerType))
				return header;
		}
		return null;
	}

	/**
	 * To get the CinMessage all signaling in the head
	 *
	 * @return
	 */
	public synchronized ArrayList<CinHeader> getHeaders() {
		ArrayList<CinHeader> ret = new ArrayList<CinHeader>();
		ret.addAll(_headers);
		return ret;
	}

	/**
	 * Get the signal head list according to the type
	 *
	 * @param headerType
	 * @return
	 */
	public synchronized ArrayList<CinHeader> getHeaders(byte headerType) {
		ArrayList<CinHeader> ret = new ArrayList<CinHeader>();
		for (CinHeader header : _headers) {
			if (header.isTypeOf(headerType))
				ret.add(header);
		}
		return ret;
	}

	/**
	 * To get the CinMessage unique identifier.The logo for the upper
	 * CinTransaction positioning in the thread pool.</br>
	 *
	 * @param direction
	 *            Identify transaction request direction.True: the visit
	 *            request;False: visit request
	 * @return A string of characters that uniquely identifies a transaction
	 */
	public String getKey() {
		StringBuilder sb = new StringBuilder();

		for (CinHeader header : new CinHeader[] { this.From, this.To, this.CallId, this.Csequence, this.Fpid, this.Tpid }) {
			if (header != null && header.isNotNullValue()) {
				if (header.getType() != CinHeaderType.Fpid && header.getType() != CinHeaderType.Tpid)
					sb.append(header.getInt64());
				else
					sb.append(header.getHexString());
			}
			sb.append("-");
		}
		sb.setLength(sb.length() - 1);
		return sb.toString();
	}

	/**
	 * To get the CinMessage business signaling
	 *
	 * @return
	 */
	public byte getMethodValue() {
		return _method;
	}

	public boolean isMethod(byte method) {
		return this._method == method;
	}

	public boolean isEvent(byte event) {
		if (Event != null && Event.getValueLength() == 1) {
			return Event.getValue()[0] == event;
		}
		return false;
	}

	public boolean isEvent(Long event) {
		if (Event != null && Event.getValueLength() > 0) {
			return Event.getInt64() == event;
		}
		return false;
	}

	public void removeHeader(CinHeader header) {

		switch (header.getType()) {
		case CinHeaderType.From:
			From = null;
			break;
		case CinHeaderType.To:
			To = null;
			break;
		case CinHeaderType.Fpid:
			Fpid = null;
			break;
		case CinHeaderType.Tpid:
			Tpid = null;
			break;
		case CinHeaderType.CallId:
			CallId = null;
			break;
		case CinHeaderType.Csequence:
			Csequence = null;
			break;
		case CinHeaderType.Event:
			Event = null;
		default:
			break;
		}
		_headers.remove(header);
	}

	public void removeHeaders(byte headerType) {
		ArrayList<CinHeader> headers = this.getHeaders(headerType);
		for (CinHeader header : headers) {
			removeHeader(header);
		}
	}

	public synchronized void releaseBodys() {
		_bodys.clear();
	}

	public boolean containsHeader(byte typebyte) {
		return getHeader(typebyte) != null;
	}

	/**
	 * @param printBody
	 *            Whether to output Message string
	 * @return
	 */
	public String toString(boolean printBody) {
		StringBuffer sb = new StringBuffer();
		if (isRequest()) {
			sb.append("Method : ");
			sb.append(CinRequestMethod.get(this._method));
			sb.append("\r\n");
		} else {
			sb.append("ResponseCode : ");
			sb.append(CinResponseCode.get(this._method));
			sb.append("\r\n");
		}
		Iterator<CinHeader> fi = this.getHeaders().iterator();
		while (fi.hasNext())
			sb.append(fi.next().toString(printBody));
		Iterator<CinBody> bi = this.getBodys().iterator();
		while (bi.hasNext())
			sb.append(bi.next().toString());
		sb.setLength(sb.length() - 1);
		return sb.toString();
	}

	@Override
	public String toString() {
		return this.toString(true);
	}

	public String toHexString() {
		StringBuffer sb = new StringBuffer();
		if (isRequest()) {
			sb.append("Method : ");
			sb.append(CinRequestMethod.get(this._method));
			sb.append("\r\n");
		} else {
			sb.append("ResponseCode : ");
			sb.append(CinResponseCode.get(this._method));
			sb.append("\r\n");
		}
		Iterator<CinHeader> fi = this.getHeaders().iterator();
		while (fi.hasNext()) {
			sb.append(fi.next().toString(false));
		}
		Iterator<CinBody> bi = this.getBodys().iterator();
		while (bi.hasNext()) {
			sb.append(bi.next().toHexString());
		}
		return sb.toString();
	}

	public void setMethod(byte value) {
		_method = value;
	}
}
