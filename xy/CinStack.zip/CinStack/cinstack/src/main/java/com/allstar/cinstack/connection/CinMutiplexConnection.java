/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinConnection.java
 * @Package com.allstar.cinstack.connection
 * @date 25/03/2016 6:31:28 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.connection;

import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.concurrent.atomic.AtomicInteger;

import com.allstar.cinstack.common.CinStackConfiguration;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionCreatedEvent;
import com.allstar.cinstack.utils.CinStackCounterHelper;
import com.allstar.cinstack.utils.CinStackTracerHelper;

import io.netty.channel.EventLoopGroup;

public class CinMutiplexConnection extends CinConnection {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinMutiplexConnection.class);

	private long _expiredTime;
	private LinkedList<CinTransaction> _transHolder;
	private AtomicInteger _transCount;
	private HashMap<Byte, CinTransactionCreatedEvent> _events;

	public CinMutiplexConnection(CinStackConfiguration config, EventLoopGroup group, CinStackCounterHelper counter) {
		super(config, group, counter);
		_expiredTime = System.currentTimeMillis() + getConfig().getLifeCycleOfCinMutiplexConnection() * 1000;
		_transHolder = new LinkedList<CinTransaction>();
		_transCount = new AtomicInteger(0);
	}

	boolean isExpired() {
		return System.currentTimeMillis() > _expiredTime;
	}

	boolean isFinished() {
		if (System.currentTimeMillis() - _expiredTime > 60 * 1000 && getCinTransactionManager().isEmpty())
			return true;
		return getCinTransactionManager().isEmpty() && _transCount.get() == 0;
	}

	public void setRemote(InetSocketAddress remote) {
		super.setRemote(remote);
	}

	public void setEvents(HashMap<Byte, CinTransactionCreatedEvent> events) {
		_events = events;
	}

	@Override
	public CinTransaction createCinTransaction(CinRequest req, int timeout) {
		_transCount.incrementAndGet();
		return super.createCinTransaction(req, timeout);
	}

	@Override
	public boolean sendRequest(final CinTransaction trans) {
		boolean sent = super.sendRequest(trans);
		if (sent)
			_transCount.decrementAndGet();
		return sent;
	}

	@Override
	public boolean checkConnectionStatus(CinTransaction trans) {
		if (getChannel() != null && getChannel().isActive())
			return true;
		if (trans.getResponse() == null) {
			if (_transHolder.size() > getConfig().getQLengthInCinMutiplexConnection()) {
				CinTransaction t = _transHolder.poll();
				if (t != null) {
					getCounter().countRequestSentFailed(trans);
					_tracer.error("Drop transactions due to out of the maxinum length of queue. " + toString(), t.getRequest());
					t.doRequestSentFailed();
				}
			}
			_transHolder.add(trans);
		} else {
			_tracer.error("CinResponse send failed for disconnected connection. " + toString() + "\r\n" + trans.toString() + "\r\n" + trans.getRequest()
					+ "\r\n" + trans.getResponse());
		}
		return false;
	}

	@Override
	public void flushHolder() {
		CinTransaction trans = _transHolder.poll();
		while (trans != null) {
			sendRequest(trans);
			trans = _transHolder.poll();
		}
	}

	@Override
	public void cleanHolder() {
		CinTransaction trans = _transHolder.poll();
		while (trans != null) {
			getCounter().countRequestSentFailed(trans);
			_tracer.error("Drop transactions for disconnected connection." + toString() + "\r\n", trans.getRequest());
			trans.doRequestSentFailed();
			trans = _transHolder.poll();
		}
	}

	@Override
	public void doCinRequestReceived(CinRequest req) {
		getCounter().countRequestReceived(req);
		CinTransactionCreatedEvent event = _events.get(req.getMethod());
		if (event == null)
			event = getCinTransactionCreatedEvent();
		if (event != null) {
			CinTransaction trans = getCinTransactionManager().createTransaction(req);
			trans.registerCinConnection(this);
			event.onCinTransactionCreated(trans);
		}
	}

	@Override
	public void doCinResponseReceived(CinResponse resp) {
		String key = resp.getKey();
		CinTransaction trans = getCinTransactionManager().getTransaction(key);
		_tracer.info("--Response Is received--");
		if (trans == null) {
			getCounter().countOutOfBoundingResonseReceived(resp);
			_tracer.warn("Receive out of bounding response. Key: " + key);
		} else {
				if (resp.isResponseCode(CinResponseCode.Pending))
				{
					_tracer.info("--Pending Request- Transaction key-"+key);
					trans.updateTransaction();
					getCinTransactionManager().addTransaction(trans);
					trans.saveBodies(resp.getBodys());
					return;
				}
			getCinTransactionManager().removeTransaction(key);
			trans.doResponseReceived(resp);
			getCounter().countResponseReceived(trans);
		}
	}
}