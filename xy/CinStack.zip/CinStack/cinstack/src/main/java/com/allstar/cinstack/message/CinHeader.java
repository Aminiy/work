package com.allstar.cinstack.message;

import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.Unpooled;

public class CinHeader implements Cloneable, Serializable {
	private static final long serialVersionUID = 7495470026821683394L;
	private static Charset DEFAULT_CHARSET = Charset.forName("UTF-8");
	byte type;
	// byte[] value;
	ByteBuf value;

	/**
	 * Create CinHeader through headerId constructor
	 *
	 * @param type
	 * @see com.allstar.cinstack.message.CinHeader values
	 */
	public CinHeader(byte type) {
		this.setType(type);
	}

	/**
	 * Through the type and form of the value of the byte array to create
	 * CinHeader constructor
	 *
	 * @param type
	 * @param value
	 */
	public CinHeader(byte type, byte[] value) {
		this.setType(type);
		this.setValue(value);
	}

	public CinHeader(byte type, ByteBuf buf) {
		this.setType(type);
		this.setByteBuf(buf);
	}

	/**
	 * Through the type and value of type long create CinHeader constructor
	 *
	 * @param type
	 * @param value
	 */
	public CinHeader(byte type, long value) {
		this.setType(type);
		this.setInt64(value);
	}

	/**
	 * Through the type and the value of a String type to create CinHeader
	 * constructor
	 *
	 * @param type
	 * @param value
	 */
	public CinHeader(byte type, String value) {
		this.setType(type);
		this.setString(value);
	}

	/**
	 * Through the type and the value of the byte form create CinHeader
	 * constructor
	 *
	 * @param type
	 * @param value
	 */
	public CinHeader(byte type, byte value) {
		this(type, new byte[] { value });
	}

	/**
	 * To get the CinHeader numerical type Long expression
	 *
	 * @return Representation the value in Int64 format
	 */
	public long getInt64() {
		value.resetReaderIndex();
		if (value == null || value.readableBytes() > 8) {
			return -1;
		}
		byte[] buff = new byte[8];
		int i = 7;
		while (value.isReadable()) {
			buff[i--] = value.readByte();
		}
		return ByteBuffer.wrap(buff).getLong();
	}

	/**
	 * Print the CinHeader
	 *
	 * @param printBody
	 * @return Representation the value in combined Int64/String/HexString
	 *         format
	 */
	public String toString(boolean printBody) {
		StringBuffer sb = new StringBuffer();
		sb.append((this.getType() == CinHeaderType.Unknown) ? String.format("%02X", type)
				: CinHeaderType.get(this.getType()) + "[" + String.format("%02X", type) + "]");
		if (getValueLength() > 0) {
			sb.append(" : (Long)");
			sb.append(this.getInt64());
			sb.append("|(HexString)");
			value.resetReaderIndex();
			sb.append(ByteBufUtil.hexDump(this.value));
			if (printBody) {
				sb.append("|(String)");
				sb.append(this.getString());
			}
		} else {
			sb.append(" : (Null)");
		}
		sb.append("\n");
		return sb.toString();
	}

	public String toString() {
		return this.toString(true);
	}

	/**
	 * To get the CinHeader numerical type String expression
	 *
	 * @return Representation the value in String format
	 */
	public String getString() {
		if (this.getValueLength() > 0) {
			return value.toString(DEFAULT_CHARSET);
		} else {
			return "";
		}
	}

	/**
	 * Get the value of the CinHeader hexadecimal String type
	 *
	 * @return Representation the value in HexString format
	 */
	public String getHexString() {
		// StringBuffer sb = new StringBuffer();
		// if (getValueLength() > 0) {
		// while(value.isReadable()){
		// sb.append(String.format("%02X", value.readByte()));
		// }
		// }
		// return sb.toString();
		return this.value == null ? "" : ByteBufUtil.hexDump(this.value);
	}

	/**
	 * To judge whether the CinHeader value is empty
	 *
	 * @return Whether the value of the header is not null
	 */
	public boolean isNotNullValue() {
		return value != null;
	}

	/**
	 * Determine whether the CinHeader value is not empty
	 *
	 * @return Whether the value of the header is not null
	 */
	public boolean isNullValue() {
		return value == null;
	}

	/**
	 * Set the CinHeader type
	 *
	 * @param typebyte
	 */
	public void setType(byte typebyte) {
		this.type = typebyte;
	}

	/**
	 * Get the CinHeader type
	 *
	 * @return Type of this header
	 *
	 * @see CinHeaderType
	 */
	public byte getType() {
		return type;
	}

	/**
	 * Determine whether the CinHeader Type and parameters specified in the same
	 * Type
	 *
	 * @param headerType
	 * @return Whether this header has same type as indicated in parameter
	 */
	public boolean isTypeOf(byte headerType) {
		return headerType == this.type;
	}

	/**
	 * Set the value of the CinHeader
	 *
	 * @param value
	 */
	public void setValue(byte[] value) {
		if (value == null)
			return;
		if (value != null && value.length > 255) {
			this.value = null;
		} else {
			this.value = Unpooled.copiedBuffer(value);
		}
	}

	public void setByteBuf(ByteBuf buf) {
		this.value = buf;
	}

	/**
	 * Sets the parameters of the string in the form of byte array to the value
	 * of the CinHeader
	 *
	 * @param value
	 */
	public void setString(String value) {
		this.value = Unpooled.wrappedBuffer(value.getBytes(DEFAULT_CHARSET));
	}

	/**
	 * The parameter of the Long form of byte array type is set to the value of
	 * the CinHeader
	 *
	 * @param value
	 */
	public void setInt64(long value) {
		if (value != 0) {
			int zeros = Long.numberOfLeadingZeros(value);
			int length = 8 - zeros / 8;
			byte[] rawValue = new byte[length];
			for (int i = 0; i < length; i++) {
				rawValue[i] = (byte) (value >>> ((i) * 8));
			}
			this.setValue(rawValue);
		} else {
			this.setValue(new byte[] { (byte) 0 });
		}
	}

	/**
	 * To get the CinHeader value
	 *
	 * @return Representation of the value in byte array format
	 */
	public byte[] getValue() {
		return value == null ? null : value.array();
	}

	public ByteBuf getBuf() {
		return this.value;
	}

	/**
	 * Get the length of the value of the CinHeader
	 *
	 * @return The length of value of this header
	 */
	public int getValueLength() {
		if (value == null) {
			return 0;
		} else {
			value.resetReaderIndex();
			return value.readableBytes();
		}
	}

	@Override
	public CinHeader clone() {
		return new CinHeader(this.type, this.value == null ? null : this.value.copy());
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof CinHeader))
			return false;
		CinHeader header = (CinHeader) obj;
		if (header.getType() != type)
			return false;
		if (header.getBuf() == null && header.getBuf() != null) {
			return false;
		}
		return this.value.compareTo(header.value) == 0;
	}

}
