/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinMessageReader.java
 * @Package com.allstar.cinstack.handler.codec
 * @date 30/03/2016 4:07:51 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.handler.codec;

import java.util.List;

import com.allstar.cinstack.message.CinMessage;

@Deprecated
public class CinMessageReader {

	public static CinMessage parse(byte[] b) {
		List<Object> list = CinDecoder.decode(b);
		if (list == null || list.isEmpty())
			return null;
		return (CinMessage) list.get(0);
	}

	public CinMessage load(byte[] b) {
		List<Object> list = CinDecoder.decode(b);
		if (list == null || list.isEmpty())
			return null;
		return (CinMessage) list.get(0);
	}

}
