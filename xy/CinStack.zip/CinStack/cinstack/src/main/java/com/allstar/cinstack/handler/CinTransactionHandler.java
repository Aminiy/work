/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinTransactionHandler.java
 * @Package com.allstar.cinstack.handler.inbound
 * @date 09/06/2015 10:08:03 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.handler;

import com.allstar.cinstack.connection.CinConnection;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.utils.CinStackTracerHelper;

import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;

public class CinTransactionHandler extends ChannelDuplexHandler {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinTransactionHandler.class);

	private CinConnection _conn;

	public CinTransactionHandler(CinConnection conn) {
		_conn = conn;
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
		CinMessage message = (CinMessage) msg;
		if (message.isRequest()) {
			_conn.doCinRequestReceived((CinRequest) message);
		} else {
			_conn.doCinResponseReceived((CinResponse) message);
		}
	}

	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
		_conn = null;
		super.channelInactive(ctx);
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		_tracer.warn("CinConnection" + ctx.toString() + " encounters an exception.", cause);
		super.exceptionCaught(ctx, cause);
	}
}
