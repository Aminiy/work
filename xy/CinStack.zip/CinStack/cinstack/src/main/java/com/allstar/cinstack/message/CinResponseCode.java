/**
 * 
 */
package com.allstar.cinstack.message;

import java.lang.reflect.Field;
import java.util.HashMap;

/**
 * Enumeration of CinResponse code
 * 
 * @see com.allstar.cintransaction.cinmessage.CinResponse
 * 
 * @author allstar
 * 
 */
public class CinResponseCode {
	public static final byte OK = (byte) 0x80;
	public static final byte NotAvailable = (byte) 0x81;
	public static final byte Error = (byte) 0x82;
	public static final byte Busy = (byte) 0x83;
	public static final byte NotExist = (byte) 0x84;
	public static final byte NotSupport = (byte) 0x85;
	public static final byte NeedVerifycation = (byte) 0x86;
	public static final byte Trying = (byte) 0xB0;
	public static final byte Processing = (byte) 0xB1;
	public static final byte Pending = (byte) 0xB2;
	public static final byte ClientOffLine = (byte) 0xFD;
	public static final byte Unknown = (byte) 0xFE;

	private static HashMap<Byte, String> _map;
	static {
		try {
			Class<?> headertype = Class.forName(CinResponseCode.class.getCanonicalName());
			Field[] fields = headertype.getFields();
			_map = new HashMap<Byte, String>();

			for (Field field : fields) {
				_map.put(Byte.valueOf(field.getByte(null)), field.getName());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * According to the response code values to obtain the response code string
	 * expression
	 * 
	 * @param type
	 * @return Representation the response code in String format
	 */
	public static String get(byte type) {
		return _map.get(type);
	}
}
