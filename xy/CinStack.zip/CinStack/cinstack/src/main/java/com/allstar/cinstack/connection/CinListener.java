/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinConnection.java
 * @Package com.allstar.cinstack.connection
 * @date 09/06/2016 10:39:28 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.connection;

import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.net.ssl.SSLEngine;

import com.allstar.cinstack.common.CinStackConfiguration;
import com.allstar.cinstack.common.CinStackMode;
import com.allstar.cinstack.transaction.CinTransactionCreatedEvent;
import com.allstar.cinstack.utils.CinStackCounterHelper;
import com.allstar.cinstack.utils.CinStackPipelineBuilder;
import com.allstar.cinstack.utils.CinStackSSLEngineBuilder;
import com.allstar.cinstack.utils.CinStackTracerHelper;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.ssl.SslHandler;

public class CinListener extends ChannelInitializer<SocketChannel> implements Runnable {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinListener.class);

	private CinStackConfiguration _config;
	private NioEventLoopGroup _group;
	private CinStackCounterHelper _counter;
	private CinDedicateConnectionEvent _connEvent;
	private CinTransactionCreatedEvent _transEvent;
	private HashMap<Byte, CinTransactionCreatedEvent> _transEvents;
	private ConcurrentLinkedQueue<CinConnection> _connections;

	public CinListener(CinStackConfiguration config, NioEventLoopGroup group, CinStackCounterHelper counter) {
		_config = config;
		_group = group;
		_counter = counter;
		_transEvents = new HashMap<Byte, CinTransactionCreatedEvent>();
		_connections = new ConcurrentLinkedQueue<CinConnection>();
	}

	public void registerCinConnectionEvent(CinDedicateConnectionEvent event) {
		_connEvent = event;
	}

	public void registerCinTransactionCreatedEvent(CinTransactionCreatedEvent event) {
		_transEvent = event;
	}

	public void registerCinTransactionCreatedEvent(byte method, CinTransactionCreatedEvent event) {
		_transEvents.put(method, event);
	}

	public void listen(final SocketAddress address) {
		ChannelFuture f = null;
		do {
			EventLoopGroup bossGroup = new NioEventLoopGroup(1);
			ServerBootstrap b = new ServerBootstrap();
			b.group(bossGroup, _group);
			b.channel(NioServerSocketChannel.class);
			b.childHandler(this);
			f = b.bind(address);
			f.addListener(new ChannelFutureListener() {
				@Override
				public void operationComplete(ChannelFuture future) throws Exception {
					if (future.isSuccess()) {
						if (_config.getEnableSSL())
							_tracer.error("SSL Address[" + address.toString() + "] is listening...");
						else
							_tracer.error("TCP Address[" + address.toString() + "] is listening...");
					} else {
						if (_config.getEnableSSL())
							_tracer.error("SSL Address[" + address.toString() + "] bind failed.", future.cause());
						else
							_tracer.error("TCP Address[" + address.toString() + "] bind failed.", future.cause());
					}
				}
			});
			try {
				f.sync();
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			}
		} while (!f.isSuccess());
	}
	
	public void check() {
		for (CinConnection conn : _connections)
			conn.disconnect();
	}

	@Override
	protected void initChannel(SocketChannel sc) throws Exception {
		CinConnection conn = null;
		if (_config.getStackMode() == CinStackMode.Dedicate) {
			conn = initCinDedicatConnection(sc);
			if (_connEvent != null) {
				try {
					_connEvent.onConnected(conn, null);
				} catch (Throwable t) {
					_tracer.error("CinListener.initChannel error.", t);
				}
			}
		} else {
			conn = initcinMutiplexConnection(sc);
		}
		ChannelPipeline line = sc.pipeline();
		if (_config.getEnableSSL()) {
			SSLEngine engine = CinStackSSLEngineBuilder.buildServerSSLEngine(_config.getKeyStorePath(), _config.getKeyStorePwd());
			line.addLast(new SslHandler(engine));
		}

		_connections.add(conn);
		CinStackPipelineBuilder.buildPipeline(line, _config, conn, this);
	}

	private CinDedicateConnection initCinDedicatConnection(SocketChannel sc) {
		CinDedicateConnection conn = new CinDedicateConnection(_config, _group, _counter);
		conn.setRemote(sc.remoteAddress());
		conn.registerChannel(sc);
		conn.registerCinConnectionEvent(_connEvent);
		return conn;
	}

	private CinMutiplexConnection initcinMutiplexConnection(SocketChannel sc) {
		CinMutiplexConnection conn = new CinMutiplexConnection(_config, _group, _counter);
		conn.setRemote(sc.remoteAddress());
		conn.registerChannel(sc);
		conn.setEvents(_transEvents);
		conn.registerCinTransactionCreatedEvent(_transEvent);
		return conn;
	}

	@Override
	public void run() {
		while (true) {
			try {
				Thread.sleep(60 * 1000);
				ArrayList<CinConnection> closedConnections = new ArrayList<CinConnection>();
				for (CinConnection conn : _connections)
					if (!conn.isConnected())
						closedConnections.add(conn);
				for (CinConnection conn : closedConnections)
					_connections.remove(conn);
			} catch (Throwable t) {
			}
		}
	}
}
