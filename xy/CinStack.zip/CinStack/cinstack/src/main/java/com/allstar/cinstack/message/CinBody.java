package com.allstar.cinstack.message;

import io.netty.buffer.Unpooled;

public class CinBody extends CinHeader {
	private static final long serialVersionUID = -185949573787064002L;

	/**
	 * The constructor
	 */
	public CinBody() {
		super(CinHeaderType.Body);
	}

	/**
	 * By the value of the byte array form create CinBody constructor
	 *
	 * @param bodyValue
	 */
	public CinBody(byte[] bodyValue) {
		super(CinHeaderType.Body, bodyValue);
	}

	/**
	 * Create CinBody through the String form of the value of the constructor
	 *
	 * @param bodyValue
	 */
	public CinBody(String bodyValue) {
		super(CinHeaderType.Body, bodyValue);
	}

	/**
	 * Set the value of the CinBody
	 */
	public void setValue(byte[] value) {
		if (value == null) {
			this.value = null;
		} else if (value.length > 0xffff) {
			this.value = null;
		} else {
			this.value = Unpooled.copiedBuffer(value);
		}
	}

	public String toString() {
		if (getValueLength() > 255) {
			return "Body: TOOOOOOOOOOOOLOOOOOOONG";
		}
		return super.toString();
	}

	public String toHexString() {
		if (getValueLength() > 255) {
			return "Body: TOOOOOOOOOOOOLOOOOOOONG";
		}
		return super.toString(false);
	}
}
