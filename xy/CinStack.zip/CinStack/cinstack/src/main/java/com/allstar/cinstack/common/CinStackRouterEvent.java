/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinStackRouterEvent.java
 * @Package com.allstar.cinstack
 * @date 30/03/2017 3:13:41 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.common;

import java.net.InetSocketAddress;

import com.allstar.cinstack.message.CinRequest;

public interface CinStackRouterEvent {

	InetSocketAddress getAddress(CinRequest req);

}