/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinReqeust.java
 * @Package com.allstar.cinstack.message
 * @date June 9, 2015 at 10:07:24 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.message;

import java.util.ArrayList;

public final class CinRequest extends CinMessage {
	public CinRequest(byte method) {
		super(method);
	}

	public byte getMethod() {
		return super.getMethodValue();
	}

	/**
	 * Whether the type of the request for the parameters specified in the type
	 */
	public boolean isMethod(byte method) {
		return method == super.getMethodValue();
	}

	/**
	 * Copy a CinRequest, including Method, Headers and Bodys
	 */
	@Override
	public CinRequest clone() {
		CinRequest request = new CinRequest(this.getMethodValue());
		ArrayList<CinHeader> list = this.getHeaders();
		ArrayList<CinBody> bodys = this.getBodys();

		for (CinHeader header : list) {
			if (!(header.isTypeOf(CinHeaderType.RecordRoute) || header.isTypeOf(CinHeaderType.Route)))
				request.addHeader(new CinHeader(header.getType(), header.getValue()));
		}

		for (CinBody body : bodys) {
			request.addBody(new CinBody(body.getValue()));
		}
		return request;
	}

	/**
	 * Set the CinRequest Method for parameters of the specified value
	 *
	 * @param method
	 */
	public void setMethod(byte method) {
		super.setMethod(method);
	}

	@Override
	public boolean isRequest() {
		return true;
	}
}
