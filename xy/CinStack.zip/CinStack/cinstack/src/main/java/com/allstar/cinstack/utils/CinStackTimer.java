/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinStackTimer.java
 * @Package com.allstar.cinstack.utils
 * @date April 5, 2016 at 4:55:01 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.utils;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class CinStackTimer {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinStackTimer.class);
	private static CinStackTimer _instance;

	private ScheduledExecutorService _service;

	static {
		try {
			_instance = new CinStackTimer();
		} catch (Throwable t) {
			_tracer.error("CinStackTimer.static error.", t);
		}
	}

	public static CinStackTimer getInstance() {
		return _instance;
	}

	private CinStackTimer() {
		_service = Executors.newScheduledThreadPool(2);
	}

	public void scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit) {
		_service.scheduleAtFixedRate(command, initialDelay, period, unit);
	}

	public void schedule(Runnable command, long delay, TimeUnit unit) {
		_service.schedule(command, delay, unit);
	}
}
