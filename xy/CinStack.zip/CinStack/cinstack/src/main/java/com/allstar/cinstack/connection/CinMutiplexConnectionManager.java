/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinConnection.java
 * @Package com.allstar.cinstack.connection
 * @date 28/03/2016 10:29:18 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.connection;

import java.net.InetSocketAddress;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import com.allstar.cinstack.common.CinStackConfiguration;
import com.allstar.cinstack.utils.CinStackCounterHelper;
import com.allstar.cinstack.utils.CinStackTimer;
import com.allstar.cinstack.utils.CinStackTracerHelper;

import io.netty.channel.nio.NioEventLoopGroup;

public class CinMutiplexConnectionManager implements Runnable {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinMutiplexConnectionManager.class);

	private CinStackConfiguration _config;
	private NioEventLoopGroup _group;
	private CinStackCounterHelper _counter;
	private ConcurrentHashMap<String, CinMutiplexConnection> _connections;
	private LinkedList<CinMutiplexConnection> _closingConnections;

	public CinMutiplexConnectionManager(CinStackConfiguration config, NioEventLoopGroup group, CinStackCounterHelper counter) {
		_config = config;
		_group = group;
		_counter = counter;
		_connections = new ConcurrentHashMap<String, CinMutiplexConnection>();
		_closingConnections = new LinkedList<CinMutiplexConnection>();

		CinStackTimer.getInstance().scheduleAtFixedRate(this, 1, 1, TimeUnit.SECONDS);
	}

	public synchronized CinMutiplexConnection createCinMutiplexConnection(InetSocketAddress remote) {
		String key = remote.toString();
		CinMutiplexConnection conn = _connections.get(key);
		if (conn == null) {
			conn = new CinMutiplexConnection(_config, _group, _counter);
			conn.setRemote(remote);
			_connections.put(key, conn);
		}
		return conn;
	}

	@Override
	public void run() {
		while (true) {
			try {
				Thread.sleep(5 * 1000);
				for (Entry<String, CinMutiplexConnection> entry : _connections.entrySet()) {
					CinMutiplexConnection conn = entry.getValue();
					if (conn.isExpired())
						_closingConnections.add(conn);
				}

				LinkedList<CinMutiplexConnection> closedConnections = new LinkedList<CinMutiplexConnection>();
				for (CinMutiplexConnection conn : _closingConnections) {
					_connections.remove(conn.getRemote().toString(), conn);
					if (conn.isFinished())
						closedConnections.add(conn);
					else
						_tracer.info(conn + " is not finished. Waiting for the next round to disconnect.");
				}

				for (CinMutiplexConnection conn : closedConnections) {
					_closingConnections.remove(conn);
					conn.disconnect();
				}
				closedConnections.clear();
			} catch (Throwable t) {
				_tracer.error("CinMutiplexConnection.run error.", t);
			}
		}
	}
}
