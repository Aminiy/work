/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinStackTracer.java
 * @Package com.allstar.cinstack.common
 * @date April 6, 2016 at 6:08:56 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.common;

import com.allstar.cinstack.message.CinMessage;

public interface CinStackTracer {

	void debug(String info);

	void debug(String info, CinMessage msg);

	void info(String info);

	void info(String info, CinMessage msg);

	void warn(String info);

	void warn(String info, Throwable t);

	void warn(String info, CinMessage msg);

	void warn(String info, CinMessage msg, Throwable t);

	void error(String info);

	void error(String info, Throwable t);

	void error(String info, CinMessage msg);

	void error(String info, CinMessage msg, Throwable t);
}