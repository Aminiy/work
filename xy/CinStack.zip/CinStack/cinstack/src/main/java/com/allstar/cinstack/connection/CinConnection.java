/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinConnection.java
 * @Package com.allstar.cinstack.connection
 * @date 25/03/2016 3:39:28 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.connection;

import java.net.InetSocketAddress;

import javax.net.ssl.SSLEngine;

import com.allstar.cinstack.common.CinStackConfiguration;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionCreatedEvent;
import com.allstar.cinstack.transaction.CinTransactionManager;
import com.allstar.cinstack.utils.CinStackCounterHelper;
import com.allstar.cinstack.utils.CinStackPipelineBuilder;
import com.allstar.cinstack.utils.CinStackSSLEngineBuilder;
import com.allstar.cinstack.utils.CinStackTracerHelper;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.ssl.SslHandler;
import io.netty.handler.traffic.TrafficCounter;

public abstract class CinConnection {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinConnection.class);

	private CinStackConfiguration _config;
	private EventLoopGroup _group;
	private CinStackCounterHelper _counter;
	private InetSocketAddress _remote;
	private TrafficCounter _traffic;
	private Channel _channel;
	private CinConnectionEvent _connEvent;
	private CinTransactionCreatedEvent _transEvent;
	private CinTransactionManager _transMgr;
	private boolean _isConnecting;
	private Object _conectObj;
	private Object _disconnectObj;

	public CinConnection(CinStackConfiguration config, EventLoopGroup group, CinStackCounterHelper counter) {
		_config = config;
		_group = group;
		_transMgr = new CinTransactionManager(counter);
		_isConnecting = false;
		_counter = counter;
	}

	protected CinStackCounterHelper getCounter() {
		return _counter;
	}

	protected CinStackConfiguration getConfig() {
		return _config;
	}

	protected Channel getChannel() {
		return _channel;
	}

	protected CinConnectionEvent getCinConnectionEvent() {
		return _connEvent;
	}

	protected CinTransactionCreatedEvent getCinTransactionCreatedEvent() {
		return _transEvent;
	}

	protected CinTransactionManager getCinTransactionManager() {
		return _transMgr;
	}

	public boolean isConnected() {
		if (_channel == null)
			return false;
		return _channel.isActive();
	}

	public void registerTrafficCounter(TrafficCounter counter) {
		_traffic = counter;
	}

	public void registerChannel(Channel channel) {
		_channel = channel;
	}

	public void registerCinConnectionEvent(CinConnectionEvent event) {
		_connEvent = event;
	}

	public void registerCinTransactionCreatedEvent(CinTransactionCreatedEvent event) {
		_transEvent = event;
	}

	protected void setRemote(InetSocketAddress remote) {
		_remote = remote;
	}

	public InetSocketAddress getRemote() {
		return _remote;
	}

	protected synchronized void connect(final Object obj) {
		if ((_channel == null && _isConnecting) || (_channel != null && (_channel.isRegistered() || _channel.isOpen() || _channel.isActive())))
			return;
		_tracer.info("CinConnection is ready to connect. " + toString());
		final CinConnection conn = this;
		Bootstrap b = new Bootstrap();
		b.group(_group);
		b.channel(NioSocketChannel.class);
		b.handler(new ChannelInitializer<SocketChannel>() {
			@Override
			protected void initChannel(SocketChannel sc) throws Exception {
				_channel = sc;
				ChannelPipeline line = sc.pipeline();
				if (_config.getEnableSSL()) {
					SSLEngine engine = CinStackSSLEngineBuilder.buildClientSSLEngine(_config.getKeyStorePath(), _config.getKeyStorePwd());
					line.addLast(new SslHandler(engine));
				}

				CinStackPipelineBuilder.buildPipeline(line, _config, conn, null);
			}
		});
		b.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 6 * 1000);
		_conectObj = obj;
		_isConnecting = true;
		ChannelFuture f = b.connect(_remote);
		f.addListener(new ChannelFutureListener() {
			@Override
			public void operationComplete(ChannelFuture future) throws Exception {
				_isConnecting = false;
				if (!future.isSuccess()) {
					_tracer.error("CinConnection connected failed. " + conn.toString());
					doConnectFailed();
				}
			}
		});
	}

	public void disconnect() {
		disconnect(null);
	}

	public synchronized void disconnect(final Object obj) {
		if (_channel != null && _channel.isActive()) {
			final CinConnection conn = this;
			_disconnectObj = obj;
			ChannelFuture f = _channel.disconnect();
			f.addListener(new ChannelFutureListener() {
				public void operationComplete(ChannelFuture future) throws Exception {
					if (!future.isSuccess()) {
						_tracer.error("CinConnection disconected failed." + conn.toString());
					}
				}
			});
		}
	}

	public boolean sendRequest(final CinTransaction trans) {
		if (checkConnectionStatus(trans)) {
			final CinConnection conn = this;
			trans.setSendRequestTime(System.currentTimeMillis());
			if (trans.Event != null)
				getCinTransactionManager().addTransaction(trans);
			ChannelFuture f = getChannel().writeAndFlush(trans.getRequest());
			f.addListener(new ChannelFutureListener() {
				public void operationComplete(ChannelFuture future) throws Exception {
					if (future.isSuccess()) {
						_counter.countRequestSent(trans);
						trans.doRequestSent();
					} else {
						_counter.countRequestSentFailed(trans);
						if (conn instanceof CinDedicateConnection)
							_tracer.warn("Send Request Failed. " + conn.toString(), trans.getRequest());
						else
							_tracer.error("Send Request Failed. " + conn.toString(), trans.getRequest());
						getCinTransactionManager().removeTransaction(trans.getKey());
						trans.doRequestSentFailed();
					}
				}
			});
			return true;
		} else {
			connect(null);
			return false;
		}
	}

	public boolean sendResponse(final CinTransaction trans) {
		if (checkConnectionStatus(trans)) {
			final CinConnection conn = this;
			ChannelFuture f = getChannel().writeAndFlush(trans.getResponse());
			f.addListener(new ChannelFutureListener() {
				public void operationComplete(ChannelFuture future) throws Exception {
					CinResponse resp = trans.getResponse();
					if (future.isSuccess()) {
						_counter.countResponseSent(trans);
					} else {
						_counter.countResponseSentFailed(trans);
						if (conn instanceof CinDedicateConnection)
							_tracer.warn("Send Response Failed. " + conn.toString(), resp);
						else
							_tracer.error("Send Response Failed. " + conn.toString(), resp);
					}
				}
			});
			return true;
		} else {
			connect(null);
			return false;
		}
	}

	public CinTransaction createCinTransaction(CinRequest req) {
		return createCinTransaction(req, 60);
	}

	public CinTransaction createCinTransaction(CinRequest req, int timeout) {
		CinTransaction trans = _transMgr.createTransaction(req, timeout);
		trans.registerCinConnection(this);
		return trans;
	}

	public void doConnected() {
		_counter.countConnectionConnected(this);
		if (_connEvent != null) {
			try {
				_connEvent.onConnected(this, _conectObj);
			} catch (Throwable t) {
				_tracer.error("CinConnection.doConnected error.", t);
			}
		}
		flushHolder();
	}

	public void doConnectFailed() {
		_counter.countConnectionConnectFailed(this);
		cleanHolder();
		if (_connEvent != null) {
			try {
				_connEvent.onConnectFailed(this, _conectObj);
			} catch (Throwable t) {
				_tracer.error("CinConnection.doConnectFailed error.", t);
			}
		}
	}

	public void doDisconnected() {
		_counter.countConnectionDisconnected(this);
		_channel = null;
		_transMgr.close();
		cleanHolder();
		if (_connEvent != null) {
			try {
				_connEvent.onDisconnected(this, _disconnectObj);
			} catch (Throwable t) {
				_tracer.error("CinConnection.doDisconnected error.", t);
			}
		}
	}

	public long getUpTraffic() {
		return _traffic.cumulativeReadBytes();
	}

	public long getDownTraffic() {
		return _traffic.cumulativeWrittenBytes();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		if (_channel != null)
			sb.append(_channel.toString());
		if ((_channel == null || !_channel.isActive()) && _remote != null)
			sb.append(_remote.toString());
		return sb.toString();
	}

	public abstract void doCinRequestReceived(CinRequest req);

	public abstract void doCinResponseReceived(CinResponse resp);

	public abstract boolean checkConnectionStatus(CinTransaction trans);

	public abstract void flushHolder();

	public abstract void cleanHolder();
}