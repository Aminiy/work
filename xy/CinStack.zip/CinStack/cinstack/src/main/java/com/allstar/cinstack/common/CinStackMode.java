/**
 *
 * Copyright (c) 2015
 * All rights reserved.
 *
 * @Title CinStackMode.java
 * @Package com.allstar.cinstack
 * @date June 9, 2015 at 4:54:08 PM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.common;

public enum CinStackMode {
	Dedicate,
	Mutiplex
}
