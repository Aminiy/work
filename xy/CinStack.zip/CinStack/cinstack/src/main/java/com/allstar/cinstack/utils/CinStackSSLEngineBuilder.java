/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinSSLEngineBuilder.java
 * @Package com.allstar.cinstack.utils
 * @date March 30, 2016 at 10:28:18 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cinstack.utils;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.util.HashMap;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.TrustManagerFactory;

public class CinStackSSLEngineBuilder {
	private static CinStackTracerHelper _tracer = CinStackTracerHelper.getInstance(CinStackSSLEngineBuilder.class);
	private static HashMap<String, SSLContext> _serverContexts;
	private static HashMap<String, SSLContext> _clientContexts;

	static {
		try {
			_serverContexts = new HashMap<String, SSLContext>();
			_clientContexts = new HashMap<String, SSLContext>();
		} catch (Throwable t) {
			_tracer.error("CinSSLEngineBuilder.static error.", t);
		}
	}

	public static synchronized SSLEngine buildServerSSLEngine(String path, String pwd) {
		SSLEngine engine = null;
		try {
			String key = path + pwd == null ? "" : pwd;
			SSLContext context = _serverContexts.get(key);
			if (context == null) {
				char[] password = null;
				if (pwd != null)
					password = pwd.toCharArray();
				KeyStore ks = KeyStore.getInstance("JKS");
				ks.load(new FileInputStream(path), password);
				KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
				kmf.init(ks, password);
				context = SSLContext.getInstance("SSL");
				context.init(kmf.getKeyManagers(), null, null);
				_serverContexts.put(key, context);
			}
			engine = context.createSSLEngine();
			engine.setUseClientMode(false);
		} catch (Throwable t) {
			_tracer.error("CinSSLEngineBuilder.buildSSLEngine error.", t);
		}
		return engine;
	}

	public static synchronized SSLEngine buildClientSSLEngine(String path, String pwd) {
		SSLEngine engine = null;
		try {
			String key = path + pwd == null ? "" : pwd;
			SSLContext context = _clientContexts.get(key);
			if (context == null) {
				char[] password = null;
				if (pwd != null)
					password = pwd.toCharArray();
				KeyStore ks = KeyStore.getInstance("JKS");
				ks.load(new FileInputStream(path), password);
				TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
				tmf.init(ks);
				context = SSLContext.getInstance("SSL");
				context.init(null, tmf.getTrustManagers(), null);
				_clientContexts.put(key, context);
			}
			engine = context.createSSLEngine();
			engine.setUseClientMode(true);
		} catch (Throwable t) {
			_tracer.error("CinSSLEngineBuilder.buildSSLEngine error.", t);
		}
		return engine;
	}
}
