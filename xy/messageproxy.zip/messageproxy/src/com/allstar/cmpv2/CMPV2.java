package com.allstar.cmpv2;


public class CMPV2 {

	public static void main(String[] args) {
		try {
			CinMessageProxy.initialize();
			CinMessageProxy proxy = new CinMessageProxy();
			proxy.start();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
