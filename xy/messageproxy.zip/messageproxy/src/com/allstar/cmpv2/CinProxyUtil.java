package com.allstar.cmpv2;

import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Random;

import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.message.CinRequestMethod;

public class CinProxyUtil
{
	private final static Random randomserverkey = new Random();

	static byte[] getRandomkey()
	{
		byte[] svrkey = new byte[16];
		randomserverkey.nextBytes(svrkey);
		return svrkey;
	}

	public static boolean checkPwd(byte[] from, byte[] token, byte[] randomKey, byte[] clientPwd, byte[] serverPwd)
	{
		if (clientPwd == null || clientPwd.length != 32)
		{
			return false;
		}

		ByteBuffer toMd5 = ByteBuffer.allocate(64);
		toMd5.put(from);
		toMd5.put(token);
		toMd5.put(randomKey);
		MessageDigest md5 = null;
		try
		{
			md5 = MessageDigest.getInstance("MD5");
		}
		catch (NoSuchAlgorithmException ex)
		{
			return false;
		}
		byte[] result = md5.digest(Arrays.copyOfRange(toMd5.array(), 0, toMd5.position()));

		if (Arrays.equals(result, Arrays.copyOfRange(clientPwd, 0, 16)))
			return Arrays.equals(md5.digest(Arrays.copyOfRange(clientPwd, 16, 32)), serverPwd);

		return false;
	}

	public static CinServiceName getCinServiceName(byte method)
	{
		switch (method)
		{
			case CinRequestMethod.Take:
			case CinRequestMethod.Message:
			case CinRequestMethod.Reply:
			case CinRequestMethod.ReadReply:
			case CinRequestMethod.Typing:
				return CinServiceName.MessageCenter;
			case CinRequestMethod.PPMessage:
				return CinServiceName.MessageCenter4PublicPlatform;
			case CinRequestMethod.Logon:
			case CinRequestMethod.Ask:
				return CinServiceName.UserCacheCenter;
			case CinRequestMethod.Group:
			case CinRequestMethod.GroupMessage:
				return CinServiceName.GroupCenter;
			case CinRequestMethod.PhoneBook:
				return CinServiceName.PhoneBookCenter;
			case CinRequestMethod.DPService:
			case CinRequestMethod.DPTake:
			case CinRequestMethod.DPSub:
			case CinRequestMethod.DPUnSub:
				return CinServiceName.RobotDiscoveryPlatform;
			case CinRequestMethod.Report:
				return CinServiceName.ReportCenter;
			case CinRequestMethod.Emoticon:
				return CinServiceName.EmoticonCenter;
			case CinRequestMethod.Sip:
				return CinServiceName.SipRouter;
			case CinRequestMethod.PPService:
				return CinServiceName.PublicPlatform;
			case CinRequestMethod.RobotMessage:
				return CinServiceName.RobotMessageCenter;
			default:
				return null;
		}
	}
}
