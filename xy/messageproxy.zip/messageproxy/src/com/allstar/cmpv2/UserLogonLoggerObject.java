package com.allstar.cmpv2;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import com.allstar.cinlogger.CinLoggerIObject;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinutil.CinClientType;

public class UserLogonLoggerObject implements CinLoggerIObject
{
	private static final String _tableName = "cin_userlogon";

	private long _userid;
	private String _deviceid;
	private long _logonTime;
	private boolean _checkCredential;
	private CinClientType _clientType;
	private String _clientVersion;
	private InetAddress _clientIp;
	private Long _oem;
	private long _abilityLevel;
	private int _status;

	public UserLogonLoggerObject(long userid, String deviceid, long logonTime, boolean checkCredential, CinClientType clientType, String clientVersion, InetSocketAddress clientIp, long oem, long abilityLevel, int status)
	{
		_userid = userid;
		_deviceid = deviceid;
		_logonTime = logonTime;
		_checkCredential = checkCredential;
		_clientType = clientType;
		_clientVersion = clientVersion;
		try
		{
			_clientIp = InetAddress.getByName(clientIp.getHostString());
		}
		catch (UnknownHostException e)
		{
			e.printStackTrace();
		}
		_oem = oem;
		_abilityLevel = abilityLevel;
		_status = status;
	}

	@Override
	public String TableName()
	{
		return _tableName;
	}

	@Override
	public CinMessage toMessage()
	{
		CinMessage msg = new CinMessage((byte) 1);

		msg.addHeader(new CinHeader((byte) 1, _userid));
		msg.addHeader(new CinHeader((byte) 2, _deviceid));
		msg.addHeader(new CinHeader((byte) 3, _logonTime));
		msg.addHeader(new CinHeader((byte) 4, _checkCredential ? 1 : 0));
		msg.addHeader(new CinHeader((byte) 5, null == _clientType ? 0 : _clientType.getId()));
		msg.addHeader(new CinHeader((byte) 6, _clientVersion));
		msg.addHeader(new CinHeader((byte) 7, _clientIp.getAddress()));
		msg.addHeader(new CinHeader((byte) 8, _oem));
		msg.addHeader(new CinHeader((byte) 9, _abilityLevel));
		msg.addHeader(new CinHeader((byte) 10, _status));

		return msg;
	}
}
