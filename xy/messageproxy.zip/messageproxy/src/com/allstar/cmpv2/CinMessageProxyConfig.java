package com.allstar.cmpv2;

import java.net.InetAddress;
import java.nio.ByteBuffer;

import com.allstar.cinconfig.CinConfigEntity;
import com.allstar.cinconfig.CinConfigInterface;
import com.allstar.cintracer.CinTracer;

public class CinMessageProxyConfig extends CinConfigInterface
{
	private static CinTracer _tracer = CinTracer.getInstance(CinMessageProxyConfig.class);
	private static CinMessageProxyConfig _instance;

	private int _publicPort = 8080;
	private String _publicHost;
	private int _servicePort = 6000;
	private String _serviceHost;
	private byte[] _ServiceAddress;
	private int _clientConnectLogonTimeout = 60;
	private int _clientConnectIdleTimeout = 600;
	private int _mininumClientAbility = 0;
	private String _suggestionText4OldClient;
	private long _sqcTimeSpan = 60 * 1000;
	private int _sqcLimit = 120;
	private boolean isSupportCCToRCSA = false;
	public static boolean _isFilterSocial = true;
	public static boolean _isFilterPublicPlatform = true;
	private static boolean logSwitch;
	
	private CinMessageProxyConfig()
	{
	}

	public static CinMessageProxyConfig getIntance()
	{
		if (_instance == null)
		{
			_instance = new CinMessageProxyConfig();
			try
			{
				_instance.updateConfig();
			}
			catch (Exception ex)
			{
				_tracer.error("Cinfig Update Error", ex);
			}
		}
		return _instance;
	}

	public int servicePort()
	{
		return _servicePort;
	}

	public String serviceHost()
	{
		return _serviceHost;
	}

	public int publicPort()
	{
		return _publicPort;
	}

	public String publicHost()
	{
		return _publicHost;
	}

	int getClientConnectLogonTimeout()
	{
		return _clientConnectLogonTimeout;
	}

	int getClientConnectIdleTImeout()
	{
		return _clientConnectIdleTimeout;
	}

	public int getMininumClientAbility()
	{
		return _mininumClientAbility;
	}

	public String getSuggestionText4OldClient()
	{
		return _suggestionText4OldClient;
	}

	public long getSQCTimeSpan()
	{
		return _sqcTimeSpan;
	}

	public int getSQCTimeLimit()
	{
		return _sqcLimit;
	}

	@Override
	protected void setValues(CinConfigEntity config)
	{
		try
		{
			String timeout = config.get("ClientConnectionIdleTimeOut");
			if (!timeout.isEmpty())
			{
				_clientConnectIdleTimeout = Integer.valueOf(timeout);
			}

			timeout = config.get("ClientLogoningTimeOut");
			if (!timeout.isEmpty())
			{
				_clientConnectLogonTimeout = Integer.valueOf(timeout);
			}

			String[] publicIpEndPoint = config.get("PublicIpEndPoint").split(":");
			_publicPort = Integer.parseInt(publicIpEndPoint[1]);
			_publicHost = publicIpEndPoint[0];
			String[] ipEndPoint = config.get("ServiceIpEndPoint").split(":");
			_servicePort = Integer.parseInt(ipEndPoint[1]);
			_serviceHost = ipEndPoint[0];

			ByteBuffer serviceaddress = ByteBuffer.allocate(6);
			serviceaddress.put(InetAddress.getByName(_serviceHost).getAddress());
			serviceaddress.putShort(Short.valueOf(ipEndPoint[1]));
			_ServiceAddress = serviceaddress.array();

			_mininumClientAbility = Integer.parseInt(config.get("MinimumClientAbility"));
			_suggestionText4OldClient = config.get("SuggestionText4OldClient");

			_sqcTimeSpan = Long.parseLong(config.get("SQCTimeSpan")) * 1000;
			_sqcLimit = Integer.parseInt(config.get("SQCLimit"));
			_isFilterSocial = Integer.parseInt(config.get("isFilterSocial", "1")) != 0;
			_isFilterPublicPlatform = Integer.parseInt(config.get("isFilterPublicPlatform", "1")) != 0;

			isSupportCCToRCSA = Boolean.valueOf(config.get("IsSupportCCToRCSA", "FALSE"));
			logSwitch = Boolean.parseBoolean(config.get("logSwitch", "true").trim());
		}
		catch (Exception e)
		{
			_tracer.error("setValue Error", e);
			e.printStackTrace();
		}

	}

	public byte[] getServiceAddress()
	{
		return _ServiceAddress;
	}

	public boolean getIsSupportCCToRCSA()
	{
		return isSupportCCToRCSA;
	}

	public static boolean isLogSwitch() {
		return logSwitch;
	}

}
