package com.allstar.cmpv2;

import java.util.concurrent.ConcurrentHashMap;

public class RobotPIDManager
{
	// private static CinTracer _tracer =
	// CinTracer.getInstance(RobotPIDManager.class);
	private static RobotPIDManager _instance;

	private ConcurrentHashMap<Long, byte[]> _pids;

	private RobotPIDManager()
	{
		_pids = new ConcurrentHashMap<Long, byte[]>();
	}

	public static RobotPIDManager getInstance()
	{
		if (_instance == null)
			_instance = new RobotPIDManager();
		return _instance;
	}

	public byte[] getPid(long userId)
	{
		return _pids.get(userId);
	}

	public void putPid(long userId, byte[] pid)
	{
		_pids.put(userId, pid);
	}
}
