package com.allstar.cmpv2;

import com.allstar.cinsqc.CinSQCCounter;
import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.connection.CinConnection;
import com.allstar.cinstack.connection.CinDedicateConnectionEvent;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cintracer.CinTracer;
import com.allstar.cmpv2.cinmessagehandler.BlackRoom4OldClientHandler;
import com.allstar.cmpv2.cinmessagehandler.CinMessageUACHandler;
import com.allstar.cmpv2.cinmessagehandler.CinMessageUASHandler;
import com.allstar.cmpv2.cinmessagehandler.LogoffUACHandler;
import com.allstar.cmpv2.utils.CinMessageProxyCounters;

public class UserProxy implements CinDedicateConnectionEvent {
	private static CinTracer _tracer = CinTracer.getInstance(UserProxy.class);

	private int _token;
	private long _expiredTime;
	private UserProxyManager _manager;
	private CinStack _clientStack;
	private CinStack _serverStack;
	private CinConnection _connection;
	private UserInfo _userInfo;
	private ServerTransactionHolder _serverTransactionHolder;
	private int _callId;
	private int _cseq;
	private boolean _disposed;
	private CinSQCCounter _cinMessageSQC;

	private String clientIP;

	UserProxy(int token, UserProxyManager manager, CinStack clientStack, CinStack serverStack, CinConnection connection) {
		_token = token;
		_expiredTime = System.currentTimeMillis() + 30 * 1000;
		_manager = manager;
		_clientStack = clientStack;
		_serverStack = serverStack;
		_connection = connection;
		this.clientIP = connection.getRemote().getHostString();
		_userInfo = new UserInfo();
		_serverTransactionHolder = new ServerTransactionHolder(this);

		_callId = 1;
		_cseq = 1;
		_disposed = false;
		_cinMessageSQC = _manager.getCinMessageSQCMrg().getCounter();
		_connection.registerCinConnectionEvent(this);
		CinMessageProxyCounters.connectedUserIncrement();
	}

	public String getClientIP() {
		return clientIP;
	}

	public int getToken() {
		return _token;
	}

	public boolean isExpired(long time) {
		return time > _expiredTime;
	}

	public CinStack getCinClientStack() {
		return _clientStack;
	}

	public CinStack getCinServerStack() {
		return _serverStack;
	}

	public CinConnection getCinConnection() {
		return _connection;
	}

	public UserInfo getUserInfo() {
		return _userInfo;
	}

	public ServerTransactionHolder getServerTransactionHolder() {
		return _serverTransactionHolder;
	}

	public int getNextCallId() {
		return _callId++;
	}

	public int getNextCseq() {
		return _cseq++;
	}

	public synchronized void dispose() {
		if (_disposed)
			return;

		_connection.disconnect();
		_cinMessageSQC.release();

		CinMessageProxyCounters.connectedUserDecrement();
		if (_tracer.InfoTrace())
			_tracer.info("UserProxy has been disposed.  " + toString());
		_disposed = true;
	}

	public void receiveCinServerTransaction(CinTransaction transaction) {
		try {
			CinMessageUASHandler handler = CinMessageDispatcher.getCinMessageUASHandler(this, transaction);
			handler.handle();
		} catch (Exception ex) {
			_tracer.error("ReceiveCinServerTransaction Error", transaction.getRequest(), ex);
		}
	}

	@Override
	public void onCinTransactionCreated(CinTransaction trans) {
		CinRequest request = trans.getRequest();

		if (!_userInfo.isAuthorized() && !request.isMethod(CinRequestMethod.Logon)) {
			trans.sendResponse(CinResponseCode.NotAvailable);
			releaseCinConnection();
			return;
		}

		if (_userInfo.isAuthorized() && _userInfo.getPid() != null
				&& _userInfo.getPid().getClientAblity() < CinMessageProxyConfig.getIntance().getMininumClientAbility()) {
			BlackRoom4OldClientHandler handler = new BlackRoom4OldClientHandler(this, trans);
			handler.handle();
			return;
		}

		try {

			if (request.isMethod(CinRequestMethod.Social) || request.isMethod(CinRequestMethod.SocialNotify)) {
				// Whether to filter Social related signaling
				if (CinMessageProxyConfig._isFilterSocial) {
					_tracer.warn("Has filtered the Social Signal...");
					return;
				}
			}
			if (request.isMethod(CinRequestMethod.PPMessage) || request.isMethod(CinRequestMethod.PPService)) {
				// Whether to filter Social related signaling
				if (CinMessageProxyConfig._isFilterPublicPlatform) {
					_tracer.warn("Has filtered the PublicPlatform Signal...");
					return;
				}
			}
			CinMessageUACHandler handler = CinMessageDispatcher.getCinMessageUACHandler(this, trans);
			handler.handle();
		} catch (Exception ex) {
			ex.printStackTrace();
			_tracer.error("onTransactionCreated Error.\r\n" + getCinConnection() == null ? "No Connection Info." : getCinConnection().toString(),
					trans.getRequest(), ex);
		}
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Token: ").append(_token).append("\n");
		sb.append("UserId: ").append(_userInfo.getUid()).append("\n");
		sb.append("Pid: ").append(_userInfo.getPid() == null ? "NULL" : _userInfo.toString()).append("\n");
		sb.append("ClientIP: ").append(this.clientIP).append("\n");
		return sb.toString();
	}

	@Override
	public void onDisconnected(CinConnection conn, Object obj) {
		try {
			if (_userInfo.isAuthorized()) {
				LogoffUACHandler handler = new LogoffUACHandler();
				handler.setConnectionDisconnected(true);
				handler.initialize(this, null);
				handler.handle();
			}
		} catch (Exception ex) {
			_tracer.error("onCinConnectionDisconnected error", ex);
		} finally {
			_manager.removeUserProxy(_token);
			if (_tracer.InfoTrace())
				_tracer.info("onCinConnectionDisconnected RemoveUserProxy");
		}
	}

	public void releaseCinConnection() {
		_connection.disconnect();
	}

	@Override
	public void onConnectFailed(CinConnection conn, Object obj) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onConnected(CinConnection conn, Object obj) {
		// TODO Auto-generated method stub
		
	}
}
