package com.allstar.cmpv2;

import java.io.File;
import java.net.InetSocketAddress;

import com.allstar.cinrouter.CinRouter;
import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.common.CinStackConfiguration;
import com.allstar.cinstack.common.CinStackMode;
import com.allstar.cinstack.common.CinStackRouterEvent;
import com.allstar.cinstack.connection.CinDedicateConnectionEvent;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.transaction.CinTransactionCreatedEvent;
import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinCommonHelper;
import com.allstar.cmpv2.utils.CinStackCounterImpl;
import com.allstar.cmpv2.utils.CinStackTracerFactoryImpl;

final class CinMessageProxy {
	private static CinTracer _tracer = CinTracer.getInstance(CinMessageProxy.class);

	private CinStack _clientStack;
	private CinStack _serverStack;
	private UserProxyManager _manager;

	@SuppressWarnings("deprecation")
	CinMessageProxy() throws Exception {
		CinStack.registerCinStackTracerFactory(new CinStackTracerFactoryImpl());
		_manager = new UserProxyManager();
		_serverStack = CinStack.instance();
		_serverStack.registerCinStackCounter(new CinStackCounterImpl("ServerSide"));
		_serverStack.registerCinStackRouterEvent(new CinStackRouterEvent() {
			@Override
			public InetSocketAddress getAddress(CinRequest req) {
				return CinRouter.takeRoute(req);
			}
		});

		CinStackConfiguration config = new CinStackConfiguration();
		config.setStackMode(CinStackMode.Dedicate);
		File f = new File("./keystore.jks");
		if (f.exists())
			config.setKeyStorePath(f.getAbsolutePath());
		config.setKeyStorePwd("123456");
		_clientStack = new CinStack(config);
		_clientStack.registerCinStackCounter(new CinStackCounterImpl("ClientSide"));

		_manager.initialize(_clientStack, _serverStack);
	}

	static void initialize() throws Exception {
		CinCommonHelper.Initialize();
		CinMessageDispatcher.initialize();
	}

	void start() throws Exception {
		CinMessageProxyConfig config = CinMessageProxyConfig.getIntance();
		_serverStack.listen(config.serviceHost(), config.servicePort(), (CinTransactionCreatedEvent) _manager);
		_clientStack.listen(config.publicHost(), config.publicPort(), (CinDedicateConnectionEvent) _manager);
		_tracer.special("CinMessageProxy has been started successfully.");
	}

	void stop() throws Exception {
		_manager.dispose();
		_tracer.special("CinMessageProxy has been stopped successfully");
	}
}