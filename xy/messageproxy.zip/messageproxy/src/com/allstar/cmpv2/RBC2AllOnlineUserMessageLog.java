package com.allstar.cmpv2;

import com.allstar.cinlogger.CinLoggerIObject;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinMessage;

/**
 * FOR RBC.
 * 
 * Send RobotMessage to all online user. when user received. mark which user has
 * been received.
 * 
 * The entire network of online users to receive the robot message after recording that the user received the message
 * 
 */
public class RBC2AllOnlineUserMessageLog implements CinLoggerIObject {
	private static final String _tableName = "cin_rbcuserreceivemsglog";

	private long robotId;// robot message from which robot.
	private long userId;// the receiver user id
	private String messageId;
	private long receiveTime;

	public RBC2AllOnlineUserMessageLog(long _robotId, long _userId, String _messageId, long _receiveTime) {
		robotId = _robotId;
		userId = _userId;
		messageId = _messageId;
		receiveTime = _receiveTime;
	}

	@Override
	public CinMessage toMessage() {
		CinMessage msg = new CinMessage((byte) 1);

		msg.addHeader(new CinHeader((byte) 1, robotId));
		msg.addHeader(new CinHeader((byte) 2, userId));
		msg.addHeader(new CinHeader((byte) 3, messageId));
		msg.addHeader(new CinHeader((byte) 4, receiveTime));

		return msg;
	}

	@Override
	public String TableName() {
		return _tableName;
	}

}
