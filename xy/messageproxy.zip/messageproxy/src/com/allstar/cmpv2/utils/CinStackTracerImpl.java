/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinStackTracerImpl.java
 * @Package com.allstar.cmpv2
 * @date April 4, 2016 at 10:16:45 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cmpv2.utils;

import com.allstar.cinstack.common.CinStackTracer;
import com.allstar.cinstack.message.CinMessage;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cintracer.CinTracer;

public class CinStackTracerImpl implements CinStackTracer {
	private CinTracer _tracer;

	@SuppressWarnings("deprecation")
	public CinStackTracerImpl(Class<?> c) {
		_tracer = CinTracer.getInstance(c, true);
	}

	@Override
	public void debug(String info) {
	}

	@Override
	public void debug(String info, CinMessage msg) {
	}

	@Override
	public void info(String info) {
		_tracer.info(info);
	}

	@Override
	public void info(String info, CinMessage msg) {
		if (msg.isRequest() && ((CinRequest) msg).getMethod() == CinRequestMethod.Trace)
			return;
		_tracer.info(info, msg);
	}

	@Override
	public void warn(String info) {
		_tracer.warn(info);
	}

	@Override
	public void warn(String info, Throwable t) {
		_tracer.warn(info, t);
	}

	@Override
	public void warn(String info, CinMessage msg) {
		_tracer.warn(info, msg);
	}

	@Override
	public void warn(String info, CinMessage msg, Throwable t) {
		_tracer.warn(info, msg, t);
	}

	@Override
	public void error(String info) {
		_tracer.error(info);
	}

	@Override
	public void error(String info, Throwable t) {
		_tracer.error(info, t);
	}

	@Override
	public void error(String info, CinMessage msg) {
		_tracer.error(info, msg);
	}

	@Override
	public void error(String info, CinMessage msg, Throwable t) {
		_tracer.info(info, msg, t);
	}
}