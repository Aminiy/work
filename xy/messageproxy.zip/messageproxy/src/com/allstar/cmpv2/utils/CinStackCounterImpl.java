/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinStackCounterImpl.java
 * @Package com.allstar.cmpv2.utils
 * @date April 8, 2016 at 10:54:45 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cmpv2.utils;

import java.util.HashMap;

import com.allstar.cinstack.common.CinStackCounter;
import com.allstar.cinstack.connection.CinConnection;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinutil.CinCounter;

public class CinStackCounterImpl implements CinStackCounter {
	private String _side;
	private HashMap<String, CinCounter> _counters;

	public CinStackCounterImpl(String side) {
		_side = side;
		_counters = new HashMap<String, CinCounter>();
	}

	private synchronized CinCounter getCounter(String counterName) {
		CinCounter counter = _counters.get(counterName);
		if (counter == null) {
			counter = new CinCounter(counterName);
			_counters.put(counterName, counter);
		}
		return counter;
	}

	private String getCounterKey(byte method, CinHeader event, byte code, String desc) {
		StringBuilder sb = new StringBuilder();
		sb.append(_side);
		sb.append("_");
		sb.append(CinRequestMethod.get(method));
		sb.append("_");
		sb.append(event == null ? 0 : event.getInt64());
		sb.append("_");
		if (code != 0) {
			sb.append(CinResponseCode.get(code));
			sb.append("_");
		}
		sb.append(desc);
		return sb.toString();
	}

	@Override
	public void countRequestReceived(CinRequest req) {
		String name = getCounterKey(req.getMethod(), req.Event, (byte) 0, "RequestReceived");
		CinCounter counter = getCounter(name);
		counter.increment();
	}

	@Override
	public void countResponseReceived(CinTransaction trans) {
		String name = getCounterKey(trans.getRequest().getMethod(), trans.getRequest().Event, trans.getResponse().getStatusCode(), "ResponseReceived");
		CinCounter counter = getCounter(name);
		counter.increment();
	}

	@Override
	public void countOutOfBoundingResonseReceived(CinResponse resp) {
		String name = getCounterKey((byte) 0, resp.Event, resp.getStatusCode(), "OutOfBoundingResonseReceived");
		CinCounter counter = getCounter(name);
		counter.increment();
	}

	@Override
	public void countRequestSent(CinTransaction trans) {
		String name = getCounterKey(trans.getRequest().getMethod(), trans.getRequest().Event, (byte) 0, "RequestSent");
		CinCounter counter = getCounter(name);
		counter.increment();
	}

	@Override
	public void countResponseSent(CinTransaction trans) {
		String name = getCounterKey(trans.getRequest().getMethod(), trans.getRequest().Event, trans.getResponse().getStatusCode(), "ResponseSent");
		CinCounter counter = getCounter(name);
		counter.increment();
	}

	@Override
	public void countRequestSentFailed(CinTransaction trans) {
		String name = getCounterKey(trans.getRequest().getMethod(), trans.getRequest().Event, (byte) 0, "RequestSentFailed");
		CinCounter counter = getCounter(name);
		counter.increment();
	}

	@Override
	public void countResponseSentFailed(CinTransaction trans) {
		String name = getCounterKey(trans.getRequest().getMethod(), trans.getRequest().Event, trans.getResponse().getStatusCode(), "ResponseSentFailed");
		CinCounter counter = getCounter(name);
		counter.increment();
	}

	@Override
	public void countRequestSentTimeout(CinTransaction trans) {
		String name = getCounterKey(trans.getRequest().getMethod(), trans.getRequest().Event, (byte) 0, "RequestSentTimeout");
		CinCounter counter = getCounter(name);
		counter.increment();
	}

	@Override
	public void countConnectionConnected(CinConnection conn) {
		String name = _side + "_" + "Connected";
		CinCounter counter = getCounter(name);
		counter.increment();
	}

	@Override
	public void countConnectionConnectFailed(CinConnection conn) {
		String name = _side + "_" + "ConnectFailed";
		CinCounter counter = getCounter(name);
		counter.increment();
	}

	@Override
	public void countConnectionDisconnected(CinConnection conn) {
		String name = _side + "_" + "Disconnected";
		CinCounter counter = getCounter(name);
		counter.increment();
	}
}
