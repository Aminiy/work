package com.allstar.cmpv2.utils;

import com.allstar.cinutil.CinCounter;

public class CinMessageProxyCounters {
	private static CinCounter ConnectedUserCount = new CinCounter("ConnectedUserCount");
	private static CinCounter LogonedUserCount = new CinCounter("LogonedUserCount");

	public static void connectedUserIncrement() {
		ConnectedUserCount.increment();
	}

	public static void logonedUserIncrement() {
		LogonedUserCount.increment();
	}

	public static void connectedUserDecrement() {
		ConnectedUserCount.decrement();
	}

	public static void logonedUserDecrement() {
		LogonedUserCount.decrement();
	}
}
