/**
 *
 * Copyright (c) 2016
 * All rights reserved.
 *
 * @Title CinStackTracerFactoryImpl.java
 * @Package com.allstar.cmpv2
 * @date April 4, 2016 at 10:26:45 AM
 * @version V1.0
 * @Description 
 *
 */

package com.allstar.cmpv2.utils;

import com.allstar.cinstack.common.CinStackTracer;
import com.allstar.cinstack.common.CinStackTracerFactory;

public class CinStackTracerFactoryImpl implements CinStackTracerFactory {

	@Override
	public CinStackTracer createTracer(Class<?> c) {
		return new CinStackTracerImpl(c);
	}

}
