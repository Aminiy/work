package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cmpv2.RobotPIDManager;

public class Challenge01UACHandler extends CinMessageUACHandler {

	private boolean _retry;

	public Challenge01UACHandler() {
		super();
		_retry = false;
	}

	@Override
	public void handle() throws Exception {
		CinRequest request = _clientTransaction.getRequest();
		byte[] pid = RobotPIDManager.getInstance().getPid(request.To.getInt64());
		if (pid == null) {
			reTry();
			return;
		}
		CinRequest serverRequest = super.createServerRequest(request);
		serverRequest.addHeader(new CinHeader(CinHeaderType.Tpid, pid));
		CinRouter.setRoute(serverRequest, CinServiceName.MessageProxy);
		CinTransaction tran = _userProxy.getCinServerStack().createTransaction(serverRequest);
		tran.Event = this;
		tran.sendRequest();
	}

	@Override
	public void onResponseReceived(CinTransaction trans) {
		CinResponse response = trans.getResponse();
		if (!response.isResponseCode(CinResponseCode.OK)) {
			reTry();
			return;
		}
		super.onResponseReceived(trans);
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans) {
		reTry();
	}

	@Override
	public void onRequestSentFailed(CinTransaction trans) {
		reTry();
	}

	private void reTry() {
		if (_retry) {
			_clientTransaction.sendResponse(CinResponseCode.Busy);
			return;
		}
		GetPidUACHandler handler = new GetPidUACHandler(_clientTransaction.getRequest().To.getInt64(), this);
		handler.initialize(_userProxy, _clientTransaction);
		handler.handle();
		_retry = true;
	}
}