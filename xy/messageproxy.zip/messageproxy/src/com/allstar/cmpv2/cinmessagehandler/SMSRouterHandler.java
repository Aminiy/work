package com.allstar.cmpv2.cinmessagehandler;


public class SMSRouterHandler extends CinMessageUACHandler
{
	// @Override
	// protected CinRequest createServerRequest(CinRequest request)
	// {
	// return super.createServerRequest(request,
	// CinServiceName.CinSmsBaseCenter);
	// }
}
