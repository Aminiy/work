package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.event.CinLogonEvent;

public class LogoffUACHandler extends CinMessageUACHandler
{

	private static final int DISCONNECT = 10;
	private static final int USERLOGOFF = 11;
	
	// Call this constructor and set the parameter to TRUE when the UCC sends a LOGOFF because the connection is down
	private boolean isConnectionDisconnected = false;

	/**
	 * This method is called when the UCC sends a LOGOFF because the connection is disconnected and the parameter is set to TRUE
	 * 
	 * @param isConnectionDisconnected
	 */
	public void setConnectionDisconnected(boolean isConnectionDisconnected)
	{
		this.isConnectionDisconnected = isConnectionDisconnected;
	}

	@Override
	public void handle() throws Exception
	{
		_userProxy.getUserInfo().setAuthorized(false);
		CinRequest request = new CinRequest(CinRequestMethod.Logon);
		request.addHeader(new CinHeader(CinHeaderType.Event, CinLogonEvent.LOGOFF));
		CinRequest serverRequest = createServerRequest(request);
		serverRequest.addHeader(new CinHeader(CinHeaderType.Type, _userProxy.getUserInfo().getPid().getClientTypeId()));
		if (!isConnectionDisconnected)
			serverRequest.addHeader(new CinHeader(CinHeaderType.ServerKey, 1));
		CinTransaction tran = _userProxy.getCinServerStack().createTransaction(serverRequest);
		tran.Event = this;
		tran.sendRequest();

		UserLogUACHandler handler = new UserLogUACHandler();
		handler.initialize(_userProxy, null);

		// Logoff due to broken connection
		if (isConnectionDisconnected)
			handler.setLogoffreason(DISCONNECT);
		else
			// Logoff initiated by the user
			handler.setLogoffreason(USERLOGOFF);

		handler.handle();
	}

	@Override
	public void onResponseReceived(CinTransaction trans)
	{
		CinResponse response = trans.getResponse();
		if (response.isResponseCode(CinResponseCode.OK))
		{
			if (null != _clientTransaction)
			{
				_clientTransaction.sendResponse(CinResponseCode.OK);
			}
		}

	}
}