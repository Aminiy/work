package com.allstar.cmpv2.cinmessagehandler;

public class THCRouterHandler extends CinMessageUACHandler
{
	// @Override
	// public CinRequest createServerRequest(CinRequest request) {
	// CinRequest req = super.createServerRequest(request,
	// CinServiceName.ThemeCenter);
	// return req;
	// }
}
