package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.transaction.CinTransaction;

public class GetCredentialUACHandler extends CinMessageUACHandler {

	@Override
	public void handle() throws Exception {
		CinRequest serverRequest = createServerRequest(_clientTransaction.getRequest());
		CinTransaction tran = _userProxy.getCinServerStack().createTransaction(serverRequest);
		tran.Event = this;
		tran.sendRequest();
	}

	@Override
	protected CinRequest createServerRequest(CinRequest request) {
		CinRequest serverRequest = super.createServerRequest(request);
		serverRequest.addHeader(new CinHeader(CinHeaderType.Key, _userProxy.getUserInfo().getRandomkey()));
		serverRequest.addHeader(new CinHeader(CinHeaderType.Password, _clientTransaction.getRequest().getHeader(CinHeaderType.Password)
				.getValue()));
		serverRequest.removeHeaders(CinHeaderType.Route);
		CinRouter.setRoute(serverRequest, CinServiceName.UserCacheCenter);
		return serverRequest;
	}
}