package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionEvent;
import com.allstar.cmpv2.CinProxyUtil;
import com.allstar.cmpv2.UserProxy;

public class CinMessageUACHandler implements CinTransactionEvent
{

	protected UserProxy _userProxy;
	protected CinTransaction _clientTransaction;
	protected CinTransaction _serverTransaction;

	public void handle() throws Exception
	{
		// client request--->server request
		CinRequest serverRequest = createServerRequest(_clientTransaction.getRequest());
		_serverTransaction = _userProxy.getCinServerStack().createTransaction(serverRequest);
		_serverTransaction.Event = this;
		_serverTransaction.sendRequest();
	}

	public void initialize(UserProxy userProxy, CinTransaction transaction)
	{
		_userProxy = userProxy;
		_clientTransaction = transaction;
	}

	protected CinRequest createServerRequest(CinRequest request)
	{
		CinServiceName serviceName = CinProxyUtil.getCinServiceName(request.getMethod());
		return createServerRequest(request, serviceName);
	}

	protected CinRequest createServerRequest(CinRequest request, CinServiceName serviceName)
	{
		CinRequest serverRequest = request.clone();
		serverRequest.removeHeaders(CinHeaderType.From);
		serverRequest.addHeader(new CinHeader(CinHeaderType.From, _userProxy.getUserInfo().getUid()));
			serverRequest.addHeader(new CinHeader(CinHeaderType.FMobileNo, _userProxy.getUserInfo().getMobileNo()));
		serverRequest.addHeader(new CinHeader(CinHeaderType.Fpid, _userProxy.getUserInfo().getPid().getBytes()));
		serverRequest.addHeader(new CinHeader(CinHeaderType.ServerData, _userProxy.getUserInfo().getEncrypt_key()));
		serverRequest.addHeader(new CinHeader(CinHeaderType.Language, _userProxy.getUserInfo().getLanguage()));
		serverRequest.addHeader(new CinHeader(CinHeaderType.FVersion, _userProxy.getUserInfo().getClientVersion()));
		serverRequest.addHeader(new CinHeader(CinHeaderType.FClientIP, _userProxy.getClientIP()));
		serverRequest.removeHeaders(CinHeaderType.CallId);
		serverRequest.addHeader(new CinHeader(CinHeaderType.CallId, _userProxy.getNextCallId()));

		if (serviceName != null)
			CinRouter.setRoute(serverRequest, serviceName);

		return serverRequest;
	}

	protected CinResponse createClientResponse(byte code)
	{
		CinResponse clientResponse = new CinResponse(_clientTransaction.getRequest(), code);
		return clientResponse;
	}

	@Override
	public void onResponseReceived(CinTransaction trans)
	{
		CinResponse response = trans.getResponse();

		CinResponse clientResponse = createClientResponse(response.getStatusCode());
		for (CinHeader header : response.getHeaders())
		{
			if (header.isTypeOf(CinHeaderType.From) || header.isTypeOf(CinHeaderType.Fpid) || header.isTypeOf(CinHeaderType.To) || header.isTypeOf(CinHeaderType.Tpid) || header.isTypeOf(CinHeaderType.CallId) || header.isTypeOf(CinHeaderType.Csequence))
				continue;
			clientResponse.addHeader(header);
		}
		if (response.getBody() != null)
			clientResponse.addBodys(response.getBodys());
		_clientTransaction.sendResponse(clientResponse);
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans)
	{
	}

	@Override
	public void onRequestSentFailed(CinTransaction trans)
	{
		_clientTransaction.sendResponse(CinResponseCode.Busy);
	}
}
