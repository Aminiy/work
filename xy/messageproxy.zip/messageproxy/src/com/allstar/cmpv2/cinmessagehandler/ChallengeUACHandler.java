package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cintracer.CinTracer;
import com.allstar.cmpv2.CinMessageProxyConfig;

public class ChallengeUACHandler extends CinMessageUACHandler {
	private static CinTracer _tracer = CinTracer.getInstance(ChallengeUACHandler.class);

	@Override
	public void handle() throws Exception {
		CinRequest request = _clientTransaction.getRequest();
		if (_userProxy.getUserInfo().isAuthorized()) {
			_userProxy.getUserInfo().cleanRandomKey();
		} else {
			long uid = request.From.getInt64();
			_tracer.info("Userid in ChallengeUACHandler:"+uid, uid);
			byte language = _clientTransaction.getRequest().getHeader(CinHeaderType.Language).getValue()[0];
			_tracer.info("language:"+language, uid);
			_tracer.info("token:"+_userProxy.getToken(), uid);
			_userProxy.getUserInfo().setUid(uid);
			_userProxy.getUserInfo().setLanguage(language);
			_userProxy.getUserInfo().setPid(CinMessageProxyConfig.getIntance().serviceHost(),
					CinMessageProxyConfig.getIntance().servicePort(), _userProxy.getToken());
			_userProxy.getUserInfo().getPid().setClientLanguage(language);
		}

		CinResponse response = createClientResponse(CinResponseCode.OK);
		response.addHeader(new CinHeader(CinHeaderType.Key, _userProxy.getUserInfo().getRandomkey()));
		_tracer.info("ChallengeUACHandler Key:"+_userProxy.getUserInfo().getRandomkey(), request.From.getInt64());
		_clientTransaction.sendResponse(response);
	}
}
