package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;

public class MultipleMessageUACHandler extends CinMessageUACHandler {
	@Override
	public void handle() throws Exception {
		_clientTransaction.sendResponse(CinResponseCode.OK);

		for (CinHeader header : _clientTransaction.getRequest().getHeaders(CinHeaderType.Index)) {
			CinRequest serverRequest = createServerRequest(_clientTransaction.getRequest());
			serverRequest.removeHeaders(CinHeaderType.To);
			serverRequest.addHeader(new CinHeader(CinHeaderType.To, header.getValue()));
			_serverTransaction = _userProxy.getCinServerStack().createTransaction(serverRequest);
			_serverTransaction.Event = this;
			_serverTransaction.sendRequest();
		}
	}

	@Override
	public void onResponseReceived(CinTransaction trans) {
	}
}