package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.message.CinRequest;

public class SocialRouterHandler extends CinMessageUACHandler
{
	@Override
	protected CinRequest createServerRequest(CinRequest request)
	{
		return super.createServerRequest(request, CinServiceName.SocialCenter);
	}
}
