package com.allstar.cmpv2.cinmessagehandler;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.allstar.cinlogger.CinLogger;
import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.connection.CinConnection;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinClientType;
import com.allstar.cmpv2.CinMessageProxyConfig;
import com.allstar.cmpv2.UserInfo;
import com.allstar.cmpv2.UserLogonLoggerObject;

public class CheckCredentialUACHandler extends CinMessageUACHandler
{
	private static CinTracer _tracer = CinTracer.getInstance(CheckCredentialUACHandler.class);

	private Long oem = 0L;

	@Override
	public void handle() throws Exception
	{
		_clientTransaction.getRequest().releaseBodys();
		setUserInfo(_userProxy.getUserInfo());
		_tracer.info("CheckCredentialUACHandler Started at : " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()) + " For User Id " + _userProxy.getUserInfo().getUid());
		super.handle();
		_tracer.info("CheckCredentialUACHandler Ended at : " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()) + " For User Id " + _userProxy.getUserInfo().getUid());
	}

	@Override
	protected CinRequest createServerRequest(CinRequest request)
	{
		CinRequest serverRequest = super.createServerRequest(request);
		try
		{
			serverRequest.addHeader(new CinHeader(CinHeaderType.Index, _userProxy.getCinConnection().getRemote().toString()));
		}
		catch (Exception ex)
		{
			_tracer.error("Get Remote IP Error.  " + _userProxy.getCinConnection().getRemote().toString(), ex);
		}
		serverRequest.removeHeaders(CinHeaderType.RecordRoute);
		CinRouter.setRoute(serverRequest, CinServiceName.UserCacheCenter);
		return serverRequest;
	}

	@Override
	public void onResponseReceived(CinTransaction trans)
	{
		CinResponse response = trans.getResponse();
		if (!response.isResponseCode(CinResponseCode.OK))
		{
			_clientTransaction.sendResponse(response.getStatusCode());
			_userProxy.releaseCinConnection();
			String deviceid = null;
			if (trans.getRequest().containsHeader(CinHeaderType.DeviceToken))
			{
				deviceid = trans.getRequest().getHeader(CinHeaderType.DeviceToken).getString();
			}

			log4Logon(trans.getRequest(), deviceid, 0);
			return;
		}

		UserInfo user = _userProxy.getUserInfo();
		if (!user.isAuthorized())
			user.setAuthorized(true);
		user.setLogonTime(System.currentTimeMillis());
		user.setCheckCredential(true);
		if (response.containsHeader(CinHeaderType.MobileNo))
			user.setMobileNo(response.getHeader(CinHeaderType.MobileNo).getString());
		if (response.containsHeader(CinHeaderType.Status))
			user.getPid().setClientAbility(((Long) response.getHeader(CinHeaderType.Status).getInt64()).intValue());
		if (response.containsHeader(CinHeaderType.Type))
			user.getPid().setClientType(response.getHeader(CinHeaderType.Type).getValue()[0]);
		if (response.containsHeader(CinHeaderType.Name))
			user.setOEM(response.getHeader(CinHeaderType.Name).getInt64());
		if (response.containsHeader(CinHeaderType.Version))
			user.setClientVersion(response.getHeader(CinHeaderType.Version).getString());
		if (response.containsHeader(CinHeaderType.ServerData))
			user.setEncrypt_key(response.getHeader(CinHeaderType.ServerData).getValue());

		CinResponse clientResponse = new CinResponse(_clientTransaction.getRequest());
		clientResponse.addHeader(response.getHeader(CinHeaderType.Expire));
		clientResponse.addHeader(response.getHeader(CinHeaderType.Credential));
		clientResponse.addHeader(response.getHeader(CinHeaderType.DateTime));
		if (response.containsHeader(CinHeaderType.Key))
			clientResponse.addHeader(response.getHeader(CinHeaderType.Key));
		if (response.getBody() != null)
			clientResponse.addBodys(response.getBodys());
		_clientTransaction.sendResponse(clientResponse);
		String deviceid = null;
		if (trans.getRequest().containsHeader(CinHeaderType.DeviceToken))
		{
			deviceid = trans.getRequest().getHeader(CinHeaderType.DeviceToken).getString();
		}
		log4Logon(trans.getRequest(), deviceid, 1);
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans)
	{
		super.onRequestSentTimeout(trans);

		String deviceid = null;
		if (trans.getRequest().containsHeader(CinHeaderType.DeviceToken))
		{
			deviceid = trans.getRequest().getHeader(CinHeaderType.DeviceToken).getString();
		}
		log4Logon(trans.getRequest(), deviceid, 0);
	}

	@Override
	public void onRequestSentFailed(CinTransaction trans)
	{
		super.onRequestSentFailed(trans);

		String deviceid = null;
		if (trans.getRequest().containsHeader(CinHeaderType.DeviceToken))
		{
			deviceid = trans.getRequest().getHeader(CinHeaderType.DeviceToken).getString();
		}
		log4Logon(trans.getRequest(), deviceid, 0);
	}

	private void setUserInfo(UserInfo user)
	{
		byte clientType = 0;
		String clientVersion = "";
		// long oem = 0L;
		int clientAbility = 0;
		byte language = -1;
		try
		{
			if (_clientTransaction.getRequest().getHeader(CinHeaderType.Status) != null)
				oem = _clientTransaction.getRequest().getHeader(CinHeaderType.Status).getInt64();
			if (_clientTransaction.getRequest().getHeader(CinHeaderType.Type) != null)
				clientType = _clientTransaction.getRequest().getHeader(CinHeaderType.Type).getValue()[0];
			if (CinClientType.getType((byte) clientType) == CinClientType.unknown)
				clientType = CinClientType.unknown.getId();
			if (_clientTransaction.getRequest().getHeader(CinHeaderType.Version) != null)
				clientVersion = _clientTransaction.getRequest().getHeader(CinHeaderType.Version).getString();
			if (_clientTransaction.getRequest().getHeader(CinHeaderType.Capacity) != null)
				clientAbility = (int) _clientTransaction.getRequest().getHeader(CinHeaderType.Capacity).getInt64();
			if (_clientTransaction.getRequest().containsHeader(CinHeaderType.Language))
				language = _clientTransaction.getRequest().getHeader(CinHeaderType.Language).getValue()[0];
		}
		catch (Exception ex)
		{
			clientType = CinClientType.get("unknown").getId();
		}
		CinRequest request = _clientTransaction.getRequest();
		long uid = request.From.getInt64();

		user.setUid(uid);
		user.setPid(CinMessageProxyConfig.getIntance().serviceHost(), CinMessageProxyConfig.getIntance().servicePort(), _userProxy.getToken());

		user.getPid().setClientType(clientType);
		// user.getPid().setClientVersion(clientVersion);

		if (language != -1)
		{
			user.setLanguage(language);
			user.getPid().setClientLanguage(language);
		}

		user.setClientVersion(clientVersion);
		user.setOEM(oem);
		user.getPid().setClientAbility(clientAbility);
	}

	/**
	 * Log user Logon log
	 * 
	 * @param result
	 *            1: success, 0: failed
	 */
	private void log4Logon(CinRequest request, String deviceid, int result)
	{
		try
		{
			if (CinMessageProxyConfig.isLogSwitch())
			{
				// Record Logon log
				UserInfo user = _userProxy.getUserInfo();
				CinConnection connection = _userProxy.getCinConnection();
				CinClientType clientType = user.getPid().getClientType();
				long clientAbility = _userProxy.getUserInfo().getPid().getClientAblity();
				UserLogonLoggerObject obj = new UserLogonLoggerObject(user.getUid(), deviceid, System.currentTimeMillis(), true, clientType, user.getClientVersion(), connection.getRemote(), oem, clientAbility, result);
				CinLogger.getInstance().send(obj);
			}
		}
		catch (Exception e)
		{
			_tracer.error("Write Logon log is error.", request, e);
		}
	}
}
