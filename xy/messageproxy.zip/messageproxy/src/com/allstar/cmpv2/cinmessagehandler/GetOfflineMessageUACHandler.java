package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;

public class GetOfflineMessageUACHandler extends CinMessageUACHandler
{
	@Override
	public void handle() throws Exception
	{
		// _userProxy.getUserInfo().setClientReady(true);
		// _userProxy.getServerTransactionHolder().flushServerTransactions();
		//
		// CinRequest serverRequest =
		// createServerRequest(_clientTransaction.request());
		// serverRequest.removeHeaders(CinHeaderType.Route);
		// serverRequest.addHeader(new CinHeader(CinHeaderType.Type,
		// _userProxy.getUserInfo().getPid().getClientTypeId()));
		// CinRouter.setRoute(serverRequest,
		// CinServiceName.OfflineMessageCenter);
		// _serverTransaction =
		// _userProxy.getCinServerStack().createTransaction(serverRequest);
		// _serverTransaction.TransactionEvent = this;
		// _serverTransaction.SendRequest();

		// Temporarily written in this way, in order to receive the client CMP sent Message, remember to change
		_clientTransaction.sendResponse(CinResponseCode.OK);
	}

	@Override
	public void onResponseReceived(CinTransaction trans)
	{
		super.onResponseReceived(trans);
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans)
	{
		super.onRequestSentTimeout(trans);
	}

	@Override
	public void onRequestSentFailed(CinTransaction trans)
	{
		super.onRequestSentFailed(trans);
	}
}
