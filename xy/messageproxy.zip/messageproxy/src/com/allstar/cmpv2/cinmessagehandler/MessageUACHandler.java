package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cmpv2.CinMessageProxyConfig;
import com.allstar.event.CinSipEvent;

public class MessageUACHandler extends CinMessageUACHandler
{
	private void ccToRCSA()
	{
		if (!CinMessageProxyConfig.getIntance().getIsSupportCCToRCSA())
		{
			return;
		}

		CinRequest ccRequest = createServerRequest(_clientTransaction.getRequest());
		ccRequest.setMethod(CinRequestMethod.Sip);
		ccRequest.removeHeaders(CinHeaderType.Event);
		ccRequest.addHeader(new CinHeader(CinHeaderType.Event, CinSipEvent.Message));
		ccRequest.removeHeaders(CinHeaderType.Route);
		CinRouter.setRoute(ccRequest, CinServiceName.RCSAdapter);
		CinTransaction tx = _userProxy.getCinServerStack().createTransaction(ccRequest);
		tx.sendRequest();
	}

	@Override
	public void handle() throws Exception
	{
		// First keep the original logic
		super.handle();
		ccToRCSA();
	}

	@Override
	public void onResponseReceived(CinTransaction trans)
	{
		super.onResponseReceived(trans);
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans)
	{
		super.onRequestSentTimeout(trans);
	}

	@Override
	public void onRequestSentFailed(CinTransaction trans)
	{
		super.onRequestSentFailed(trans);
	}
}
