package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinlogger.CinLogger;
import com.allstar.cinstack.connection.CinConnection;
import com.allstar.cinutil.CinClientType;
import com.allstar.cmpv2.CinMessageProxyConfig;
import com.allstar.cmpv2.UserInfo;
import com.allstar.cmpv2.UserLogLoggerObject;

class UserLogUACHandler extends CinMessageUACHandler {
	private static CinLogger _tracer = CinLogger.getInstance();
	private int logoffreason = 0;

	public void handle() {
		UserInfo user = _userProxy.getUserInfo();
		CinConnection connection = _userProxy.getCinConnection();

		CinClientType clientType = user.getPid().getClientType();
		long clientAbility = _userProxy.getUserInfo().getPid().getClientAblity();
		
		if (CinMessageProxyConfig.isLogSwitch())
		{
			UserLogLoggerObject obj = new UserLogLoggerObject(user.getUid(), user.getLogonTime(), System.currentTimeMillis(), user.isCheckCredential(), clientType,
					user.getClientVersion(), connection.getRemote(), clientAbility, connection.getUpTraffic(), connection.getDownTraffic(),
					logoffreason, user.getOEM());
			_tracer.send(obj);
		}
	}

	public void setLogoffreason(int logoffreason) {
		this.logoffreason = logoffreason;
	}

}
