package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;

public class NoToHeaderGroupUACHandler extends CinMessageUACHandler {

	@Override
	protected CinRequest createServerRequest(CinRequest request) {
		CinRequest serverRequest = super.createServerRequest(request);
		serverRequest.removeHeaders(CinHeaderType.To);
		serverRequest.addHeader(new CinHeader(CinHeaderType.To, serverRequest.From.getValue()));
		serverRequest.addHeader(new CinHeader(CinHeaderType.Tpid, serverRequest.Fpid.getValue()));
		return serverRequest;
	}
}
