package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinstack.message.CinRequest;
import com.allstar.cintracer.CinTracer;

public class TypingUASHandler extends CinMessageUASHandler {
	private static CinTracer _tracer = CinTracer.getInstance(TypingUASHandler.class);

	@Override
	public void handle() throws Exception {
		if (!isClientReady()) {
			_tracer.info("The request from server has been hold.", _serverTransaction.getRequest());
			_userProxy.getServerTransactionHolder().holdServerTransaction(_serverTransaction);
			return;
		}

		CinRequest clientRequest = getClientRequest(_serverTransaction.getRequest());
		_clientTransaction = _userProxy.getCinConnection().createCinTransaction(clientRequest);
		_clientTransaction.sendRequest();
	}
}
