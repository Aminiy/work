package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.transaction.CinTransaction;

public class KeepAliveUACHandler extends CinMessageUACHandler
{
	@Override
	public void handle() throws Exception
	{
		CinRequest serverRequest = createServerRequest(_clientTransaction.getRequest());
		serverRequest.addHeader(new CinHeader(CinHeaderType.Type, _userProxy.getUserInfo().getPid().getClientTypeId()));
		_serverTransaction = _userProxy.getCinServerStack().createTransaction(serverRequest);
		_serverTransaction.Event = this;
		_serverTransaction.sendRequest();
	}

	@Override
	public void onResponseReceived(CinTransaction trans)
	{
		super.onResponseReceived(trans);
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans)
	{
		super.onRequestSentTimeout(trans);
	}

	@Override
	public void onRequestSentFailed(CinTransaction trans)
	{
		super.onRequestSentFailed(trans);
	}
}
