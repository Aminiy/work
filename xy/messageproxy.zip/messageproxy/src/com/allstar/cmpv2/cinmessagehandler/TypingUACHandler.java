package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponseCode;

public class TypingUACHandler extends CinMessageUACHandler {

	@Override
	public void handle() throws Exception {
		_clientTransaction.sendResponse(CinResponseCode.OK);

		CinRequest serverRequest = createServerRequest(_clientTransaction.getRequest());
		_serverTransaction = _userProxy.getCinServerStack().createTransaction(serverRequest);
		_serverTransaction.sendRequest();
	}
}
