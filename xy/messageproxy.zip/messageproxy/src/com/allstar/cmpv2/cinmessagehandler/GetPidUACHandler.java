package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cintracer.CinTracer;
import com.allstar.cmpv2.RobotPIDManager;

public class GetPidUACHandler extends CinMessageUACHandler
{
	private static CinTracer _tracer = CinTracer.getInstance(GetPidUACHandler.class);
	private static final byte Event_GetPid = 0x01;

	private long _userId;
	private Challenge01UACHandler _handler;

	public GetPidUACHandler(long userId, Challenge01UACHandler handler)
	{
		_userId = userId;
		_handler = handler;
	}

	@Override
	public void handle()
	{
		CinRequest req = new CinRequest(CinRequestMethod.Service);
		req.addHeader(new CinHeader(CinHeaderType.From, _userId));
		req.addHeader(new CinHeader(CinHeaderType.Event, Event_GetPid));
		CinRouter.setRoute(req, CinServiceName.UserCacheCenter);
		CinTransaction tran = _userProxy.getCinServerStack().createTransaction(req);
		tran.Event = this;
		tran.sendRequest();
	}

	@Override
	public void onResponseReceived(CinTransaction trans)
	{
		CinResponse response = trans.getResponse();
		try
		{
			if (response.isResponseCode(CinResponseCode.OK))
				RobotPIDManager.getInstance().putPid(_userId, response.getHeader(CinHeaderType.ServerPid).getValue());
			_handler.handle();
		}
		catch (Exception ex)
		{
			_tracer.error("GetPidUACHandler.onResponseReceived error.", ex);
		}
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans)
	{
		_tracer.warn("GetPid Timeout", trans.getRequest());
	}

	@Override
	public void onRequestSentFailed(CinTransaction trans)
	{
		_tracer.warn("GetPid Send Failed", trans.getRequest());
	}
}
