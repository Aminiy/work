package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinrouter.CinRouter;
import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cmpv2.CinProxyUtil;

public class AskUACHandler extends CinMessageUACHandler {

	@Override
	protected CinRequest createServerRequest(CinRequest request) {
		CinRequest serverRequest = request.clone();
		serverRequest.removeHeaders(CinHeaderType.From);
		serverRequest.removeHeaders(CinHeaderType.To);
		serverRequest.addHeader(new CinHeader(CinHeaderType.To, _userProxy.getUserInfo().getUid()));
		serverRequest.addHeader(new CinHeader(CinHeaderType.Tpid, _userProxy.getUserInfo().getPid().getBytes()));
		serverRequest.addHeader(new CinHeader(CinHeaderType.Language, _userProxy.getUserInfo().getLanguage()));
		serverRequest.addHeader(new CinHeader(CinHeaderType.From, request.To.getValue()));
		serverRequest.removeHeaders(CinHeaderType.CallId);
		serverRequest.addHeader(new CinHeader(CinHeaderType.CallId, _userProxy.getNextCallId()));

		CinServiceName serviceName = CinProxyUtil.getCinServiceName(request.getMethod());
		if (serviceName != null)
			CinRouter.setRoute(serverRequest, serviceName);
		return serverRequest;
	}
}
