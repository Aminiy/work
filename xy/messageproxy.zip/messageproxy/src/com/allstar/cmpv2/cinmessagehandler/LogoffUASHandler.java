package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;

public class LogoffUASHandler extends CinMessageUASHandler
{

	@Override
	public void handle() throws Exception
	{
		_userProxy.getUserInfo().setAuthorized(false);
		_serverTransaction.sendResponse(CinResponseCode.OK);

		UserLogUACHandler handler = new UserLogUACHandler();
		handler.initialize(_userProxy, null);

		// Reason for LogOff
		if (_serverTransaction.getRequest().containsHeader(CinHeaderType.ServerData))
		{
			handler.setLogoffreason((int) _serverTransaction.getRequest().getHeader(CinHeaderType.ServerData).getInt64());
		}
		handler.handle();

		// No Status header, said only broken link, not to the client Logoff signaling
		if (_serverTransaction.getRequest().containsHeader(CinHeaderType.Status))
		{
			CinRequest clientRequest = getClientRequest(_serverTransaction.getRequest());
			_clientTransaction = _userProxy.getCinConnection().createCinTransaction(clientRequest);
			_clientTransaction.sendRequest();
		}
		_userProxy.releaseCinConnection();
	}

	@Override
	public void onResponseReceived(CinTransaction trans)
	{
	}
}