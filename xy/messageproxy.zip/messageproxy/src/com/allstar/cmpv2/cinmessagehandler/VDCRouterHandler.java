package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.event.CinVideoEvent;

public class VDCRouterHandler extends CinMessageUACHandler
{
	@Override
	public CinRequest createServerRequest(CinRequest request)
	{
		CinHeader event = request.getHeader(CinHeaderType.Event);
 
		switch((int)event.getInt64()) 
		{

		case CinVideoEvent.CreateSession :
		case CinVideoEvent.GetCallingSession :
		case CinVideoEvent.CheckP2PCallEligibility :
		case CinVideoEvent.GetStunTurnServerInfo :
		case CinVideoEvent.CreatRoom:
		case CinVideoEvent.CheckKurentoEligibility:
		case CinVideoEvent.JoinRoom:
		case CinVideoEvent.KurnetoActiveParticipant:	
		case CinVideoEvent.QuitVideoRoom:
		case CinVideoEvent.DissolutionGroup:	
			return super.createServerRequest(request, CinServiceName.VideoCenterSystem);		
		default :
			boolean HdCall=	request.containsHeader(CinHeaderType.CallType)?request.getHeader(CinHeaderType.CallType).getInt64()==4:false;
			boolean KurentoCall= request.containsHeader(CinHeaderType.CallType)?request.getHeader(CinHeaderType.CallType).getInt64()==6?true:request.getHeader(CinHeaderType.CallType).getInt64()==7:false;
			if(HdCall){
				return super.createServerRequest(request, CinServiceName.HdVideoCenter);
			}else if(KurentoCall){
				return super.createServerRequest(request, CinServiceName.VideoRoomSystem);
			}
			else
			{ 
				return super.createServerRequest(request, CinServiceName.VideoCenter);
			}	
		}
	}
}
