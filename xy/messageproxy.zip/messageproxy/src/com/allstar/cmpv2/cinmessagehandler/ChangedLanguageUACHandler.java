package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinrouter.CinServiceName;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cintracer.CinTracer;

public class ChangedLanguageUACHandler extends CinMessageUACHandler {
	private final static CinTracer LOGGER = CinTracer.getInstance(ChangedLanguageUACHandler.class);

	private byte language;

	@Override
	public void handle() throws Exception {
		if (!_clientTransaction.getRequest().containsHeader(CinHeaderType.Language)) {
			_clientTransaction.sendResponse(CinResponseCode.Error);
			return;
		}

		this.language = _clientTransaction.getRequest().getHeader(CinHeaderType.Language).getValue()[0];
		// _userProxy.getUserInfo().setLanguage(language);

		super.handle();
	}

	@Override
	protected CinRequest createServerRequest(CinRequest request) {
		return super.createServerRequest(_clientTransaction.getRequest(), CinServiceName.UserCacheCenter);
	}

	@Override
	public void onResponseReceived(CinTransaction trans) {
		CinResponse response = trans.getResponse();
		try {
			if (response.isResponseCode(CinResponseCode.OK)) {
				_userProxy.getUserInfo().setLanguage(this.language);
				// According to the actual situation, modify the PID risk is very large, so temporarily not to modify the language information in the PID
				// _userProxy.getUserInfo().getPid()
				// .setClientLanguage(language);
			}

		} catch (Exception e) {
			LOGGER.error("ChangedLanguage refresh User proxy languange ", _clientTransaction.getRequest(), e);
		}

		super.onResponseReceived(trans);
	}
}
