package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionEvent;
import com.allstar.cintracer.CinTracer;
import com.allstar.cmpv2.UserProxy;
import com.allstar.event.CinVideoEvent;

public class CinMessageUASHandler implements CinTransactionEvent {
	private static CinTracer _tracer = CinTracer.getInstance(CinMessageUASHandler.class);

	protected UserProxy _userProxy;
	protected CinTransaction _serverTransaction;
	protected CinTransaction _clientTransaction;

	public void handle() throws Exception {
		if (!isClientReady()) {
			_tracer.info("The request from server has been hold.", _serverTransaction.getRequest());
			_userProxy.getServerTransactionHolder().holdServerTransaction(_serverTransaction);
			return;
		}

		CinRequest clientRequest = getClientRequest(_serverTransaction.getRequest());
		
		if (_serverTransaction.getRequest().isMethod(CinRequestMethod.Video) && _serverTransaction.getRequest().isEvent((byte) CinVideoEvent.NotifyToAddedMember)) {
			_tracer.info("CinRequestMethod is Video:: CinMessageUASHandler and Event is: "+ _serverTransaction.getRequest().Event.getInt64());
			_clientTransaction = _userProxy.getCinConnection().createCinTransaction(clientRequest, 1);
		} else {
			_clientTransaction = _userProxy.getCinConnection().createCinTransaction(clientRequest);
		}

		if (_clientTransaction == null) {
			_tracer.info("_clientTransaction is null in CinMessageUASHandler");
		}
		_clientTransaction.Event = this;
		_clientTransaction.sendRequest();
	}

	public void initialize(UserProxy userProxy, CinTransaction transaction) {
		_userProxy = userProxy;
		_serverTransaction = transaction;
	}

	protected CinRequest getClientRequest(CinRequest request) {
		CinRequest clientRequst = request.clone();
		clientRequst.removeHeaders(CinHeaderType.Fpid);
		clientRequst.removeHeaders(CinHeaderType.Tpid);
		if (!clientRequst.containsHeader(CinHeaderType.CallId))
			clientRequst.addHeader(new CinHeader(CinHeaderType.CallId, _userProxy.getNextCallId()));
		return clientRequst;
	}

	protected boolean isClientReady() {
		return _userProxy.getUserInfo().isClientReady();
	}

	@Override
	public void onResponseReceived(CinTransaction trans) {
		CinResponse response = trans.getResponse();
		CinResponse serverResponse = new CinResponse(_serverTransaction.getRequest(), response.getStatusCode());
		if (!serverResponse.isResponseCode(CinResponseCode.OK)) {
			_tracer.info("Not OK Response in CinMessageUASHandler from Client:: " + trans.getRequest());
		}
		for (CinHeader header : response.getHeaders()) {
			if (header.isTypeOf(CinHeaderType.From) || header.isTypeOf(CinHeaderType.To) || header.isTypeOf(CinHeaderType.CallId)
					|| header.isTypeOf(CinHeaderType.Csequence))
				continue;
			serverResponse.addHeader(header);
		}
		if (response.getBody() != null)
			serverResponse.addBodys(response.getBodys());
		_serverTransaction.sendResponse(serverResponse);
	}

	@Override
	public void onRequestSentFailed(CinTransaction trans) {
		try {
			_tracer.info("CinMessageUASHandler ClientOffLine:: " + trans.getRequest());
			_userProxy.releaseCinConnection();
			_serverTransaction.sendResponse(CinResponseCode.ClientOffLine);
		} catch (Exception ex) {
			_tracer.error("OnSendFailed", ex);
		}
	}

	@Override
	public void onRequestSentTimeout(CinTransaction trans) {
		_tracer.info("Time out in CinMessageUASHandler from Client:: " + trans.getRequest());
		_serverTransaction.sendResponse(CinResponseCode.NotAvailable);
	}

}
