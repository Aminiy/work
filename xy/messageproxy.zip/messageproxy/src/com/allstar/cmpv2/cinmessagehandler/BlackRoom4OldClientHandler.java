package com.allstar.cmpv2.cinmessagehandler;

import com.allstar.cinstack.message.CinBody;
import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinUtil;
import com.allstar.cmpv2.CinMessageProxyConfig;
import com.allstar.cmpv2.UserProxy;

public class BlackRoom4OldClientHandler {
	private static CinTracer _tracer = CinTracer.getInstance(BlackRoom4OldClientHandler.class);
	private static final long GET_OFFLINE_MESSAGE = 0x01;

	private UserProxy _userProxy;
	private CinTransaction _transaction;

	public BlackRoom4OldClientHandler(UserProxy userProxy, CinTransaction transaction) {
		_userProxy = userProxy;
		_transaction = transaction;
	}

	public void handle() {
		try {
			if (_tracer.InfoTrace()) {
				StringBuilder sb = new StringBuilder();
				sb.append("User ");
				sb.append(_userProxy.getUserInfo().getUid());
				sb.append(" falls into black room. Client Ability: ");
				sb.append(_userProxy.getUserInfo().getPid().getClientAblity());
				_tracer.info(sb.toString());
			}
			CinRequest request = _transaction.getRequest();
			if (request.isMethod(CinRequestMethod.Service)
					|| (request.isMethod(CinRequestMethod.Message) && request.Event != null && request.Event.getInt64() == GET_OFFLINE_MESSAGE)) {
				_transaction.sendResponse(CinResponseCode.OK);
				if ((request.isMethod(CinRequestMethod.Message) && request.Event != null && request.Event.getInt64() == GET_OFFLINE_MESSAGE)) {
					CinRequest request1 = new CinRequest(CinRequestMethod.Message);
					request1.addHeader(new CinHeader(CinHeaderType.From, 10000000L));
					request1.addHeader(new CinHeader(CinHeaderType.DateTime, System.currentTimeMillis()));
					request1.addHeader(new CinHeader(CinHeaderType.MessageID, CinUtil.getUUID().array()));
					request1.addHeader(new CinHeader(CinHeaderType.To, _userProxy.getUserInfo().getUid()));
					request1.addHeader(new CinHeader(CinHeaderType.MobileNo, 1000L));
					request1.addBody(new CinBody(CinMessageProxyConfig.getIntance().getSuggestionText4OldClient()));
					_userProxy.getCinConnection().createCinTransaction(request1).sendRequest();
				}
			}
		} catch (Exception ex) {
			_tracer.error("BlackRoom4OldClient Error", ex);
		}
	}
}
