package com.allstar.cmpv2;

import java.util.concurrent.ConcurrentHashMap;

import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cintracer.CinTracer;
import com.allstar.cmpv2.cinmessagehandler.ActivationRouterHandler;
import com.allstar.cmpv2.cinmessagehandler.AskUACHandler;
import com.allstar.cmpv2.cinmessagehandler.ChallengeUACHandler;
import com.allstar.cmpv2.cinmessagehandler.ChangedLanguageUACHandler;
import com.allstar.cmpv2.cinmessagehandler.CheckCredentialUACHandler;
import com.allstar.cmpv2.cinmessagehandler.CinMessageUACHandler;
import com.allstar.cmpv2.cinmessagehandler.CinMessageUASHandler;
import com.allstar.cmpv2.cinmessagehandler.CollectMessageRouterHandler;
import com.allstar.cmpv2.cinmessagehandler.ContactRouterHandler;
import com.allstar.cmpv2.cinmessagehandler.DTCRouterHandler;
import com.allstar.cmpv2.cinmessagehandler.GroupTypingUACHandler;
import com.allstar.cmpv2.cinmessagehandler.JioMoneyProxyRouterHandler;
import com.allstar.cmpv2.cinmessagehandler.KeepAliveUACHandler;
import com.allstar.cmpv2.cinmessagehandler.LogoffUACHandler;
import com.allstar.cmpv2.cinmessagehandler.LogoffUASHandler;
import com.allstar.cmpv2.cinmessagehandler.LogonUACHandler;
import com.allstar.cmpv2.cinmessagehandler.MSC4PPRouterHandler;
import com.allstar.cmpv2.cinmessagehandler.MSCRouterHandler;
import com.allstar.cmpv2.cinmessagehandler.MessageOfflineRouterHandler;
import com.allstar.cmpv2.cinmessagehandler.MessageReceiptsRouterHandler;
import com.allstar.cmpv2.cinmessagehandler.MessageUACHandler;
import com.allstar.cmpv2.cinmessagehandler.NoToHeaderGroupUACHandler;
import com.allstar.cmpv2.cinmessagehandler.POCRouterHandler;
import com.allstar.cmpv2.cinmessagehandler.PublicformServiceHandler;
import com.allstar.cmpv2.cinmessagehandler.QuerySmsLeftQuotaHandler;
import com.allstar.cmpv2.cinmessagehandler.RMCRouterHandler;
import com.allstar.cmpv2.cinmessagehandler.SocialRouterHandler;
import com.allstar.cmpv2.cinmessagehandler.TRACKRouterHandler;
import com.allstar.cmpv2.cinmessagehandler.TypingUACHandler;
import com.allstar.cmpv2.cinmessagehandler.TypingUASHandler;
import com.allstar.cmpv2.cinmessagehandler.UCCRouterHandler;
import com.allstar.cmpv2.cinmessagehandler.VDCRouterHandler;
import com.allstar.event.CinLogonEvent;

@SuppressWarnings("rawtypes")
class CinMessageDispatcher {
	private static CinTracer _tracer = CinTracer.getInstance(CinMessageDispatcher.class);

	private static ConcurrentHashMap<Integer, Class> _uacMap;
	private static ConcurrentHashMap<Integer, Class> _uasMap;

	CinMessageDispatcher() {
	}

	static void initialize() {
		_uacMap = new ConcurrentHashMap<Integer, Class>();
		addUACMap(CinRequestMethod.Logon, CinLogonEvent.CHALLENGE, ChallengeUACHandler.class);
		addUACMap(CinRequestMethod.Logon, CinLogonEvent.LOGON, LogonUACHandler.class);
		addUACMap(CinRequestMethod.Logon, CinLogonEvent.CHECKCREDENTIAL, CheckCredentialUACHandler.class);
		addUACMap(CinRequestMethod.Logon, CinLogonEvent.KEEP_ALIVE, KeepAliveUACHandler.class);
		addUACMap(CinRequestMethod.Logon, CinLogonEvent.LOGOFF, LogoffUACHandler.class);

		addUACMap(CinRequestMethod.Take, 0x01, UCCRouterHandler.class);
		addUACMap(CinRequestMethod.Take, 0x02, UCCRouterHandler.class);

		addUACMap(CinRequestMethod.Group, 0x00, NoToHeaderGroupUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x01, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x02, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x03, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x04, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x06, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x07, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x08, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x05, NoToHeaderGroupUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x09, NoToHeaderGroupUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x0a, CinMessageUACHandler.class);
		// addUACMap(CinRequestMethod.Group, 0x80, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x16, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x17, CinMessageUACHandler.class);

		addUACMap(CinRequestMethod.Group, 0x20, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x21, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x22, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x23, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x24, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x25, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x26, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x27, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x28, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x29, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x30, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x31, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x32, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x33, CinMessageUACHandler.class);
		addUACMap(CinRequestMethod.Group, 0x35, CinMessageUACHandler.class);

		addUACMap(CinRequestMethod.Message, 0x01, MessageUACHandler.class);
		addUACMap(CinRequestMethod.Message, 0x03, MessageOfflineRouterHandler.class);
		addUACMap(CinRequestMethod.Message, 0x04, MessageOfflineRouterHandler.class);
		addUACMap(CinRequestMethod.Message, 0x07, MessageOfflineRouterHandler.class);
		addUACMap(CinRequestMethod.Message, 0x09, MessageOfflineRouterHandler.class);
		addUACMap(CinRequestMethod.Message, 0x0A, MessageOfflineRouterHandler.class);
		addUACMap(CinRequestMethod.Message, 0x0D, MessageOfflineRouterHandler.class);

		
		addUACMap(CinRequestMethod.Message, 0x10, MessageReceiptsRouterHandler.class);
		addUACMap(CinRequestMethod.Message, 0x11, MessageReceiptsRouterHandler.class);
		addUACMap(CinRequestMethod.Message, 0x14, MessageOfflineRouterHandler.class);

		addUACMap(CinRequestMethod.Message, 0x1A, MessageOfflineRouterHandler.class);
		addUACMap(CinRequestMethod.Message, 0x1C, MessageOfflineRouterHandler.class);
		addUACMap(CinRequestMethod.Reply, 0x00, MessageUACHandler.class);
		addUACMap(CinRequestMethod.ReadReply, 0x00, MessageUACHandler.class);

		for (int i = 0x01; i <= 0x03; i++)
			addUACMap(CinRequestMethod.PPMessage, i, MessageUACHandler.class);

		addUACMap(CinRequestMethod.Ask, 0x00, AskUACHandler.class);
		addUACMap(CinRequestMethod.Ask, 0x02, UCCRouterHandler.class);
		addUACMap(CinRequestMethod.Typing, 0x00, TypingUACHandler.class);
		addUACMap(CinRequestMethod.Typing, 0x01, GroupTypingUACHandler.class);

		// addUACMap(CinRequestMethod.SMS, 0x10, SMSRouterHandler.class);
		// addUACMap(CinRequestMethod.SMS, 0x11, SMSRouterHandler.class);

		for (int i = 0x01; i <= 0xFF; i++) {
			addUACMap(CinRequestMethod.PPService, i, PublicformServiceHandler.class);
		}

		for (int i = 0x01; i <= 0x07; i++) {
			addUACMap(CinRequestMethod.Service, i, ContactRouterHandler.class);
		}

		addUACMap(CinRequestMethod.RMC, 0x01, RMCRouterHandler.class);
		addUACMap(CinRequestMethod.RMC, 0x02, RMCRouterHandler.class);
		addUACMap(CinRequestMethod.RMC, 0x03, RMCRouterHandler.class);
		addUACMap(CinRequestMethod.RMC, 0x04, RMCRouterHandler.class);
		addUACMap(CinRequestMethod.RMC, 0x05, RMCRouterHandler.class);
		addUACMap(CinRequestMethod.RMC, 0x06, RMCRouterHandler.class);

		addUACMap(CinRequestMethod.TRACK, 0x01, TRACKRouterHandler.class);
		addUACMap(CinRequestMethod.TRACK, 0x02, TRACKRouterHandler.class);
		addUACMap(CinRequestMethod.TRACK, 0x03, TRACKRouterHandler.class);
		addUACMap(CinRequestMethod.TRACK, 0x04, TRACKRouterHandler.class);

		addUACMap(CinRequestMethod.Service, 0x08, UCCRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x09, POCRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x0A, POCRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x0C, ActivationRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x0D, ActivationRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x10, ContactRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x11, POCRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x12, ContactRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x13, ContactRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x14, ContactRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x15, ContactRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x18, ContactRouterHandler.class);
		// router to SOC
		addUACMap(CinRequestMethod.Service, 0x16, SocialRouterHandler.class);

		for (int i = 0x20; i < 0x30; i++) {
			addUACMap(CinRequestMethod.Service, i, UCCRouterHandler.class);
		}

		addUACMap(CinRequestMethod.Service, 0x40, QuerySmsLeftQuotaHandler.class);
		addUACMap(CinRequestMethod.Service, 0x41, ChangedLanguageUACHandler.class);

		// SetPushToken
		addUACMap(CinRequestMethod.Service, 0x42, UCCRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x43, UCCRouterHandler.class);
		
		addUACMap(CinRequestMethod.Service, 0x50, JioMoneyProxyRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x51, JioMoneyProxyRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x52, JioMoneyProxyRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x53, JioMoneyProxyRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x54, JioMoneyProxyRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x55, JioMoneyProxyRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x56, JioMoneyProxyRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x57, JioMoneyProxyRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x58, JioMoneyProxyRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x59, JioMoneyProxyRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x5A, JioMoneyProxyRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x5B, JioMoneyProxyRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x5C, JioMoneyProxyRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x5E, JioMoneyProxyRouterHandler.class);

		addUACMap(CinRequestMethod.Service, 0x61, CollectMessageRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x62, CollectMessageRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x63, CollectMessageRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x64, CollectMessageRouterHandler.class);
		addUACMap(CinRequestMethod.Service, 0x65, CollectMessageRouterHandler.class);
		//New Handler for POC
		addUACMap(CinRequestMethod.Service, 0x66, POCRouterHandler.class);
		//added a new handler mapping for MessageCenter4PublicPlatform
		
		addUACMap(CinRequestMethod.Service, 0x71, MSC4PPRouterHandler.class);

		// for (int i = 0x70; i < 0x7A; i++)
		// {
		// addUACMap(CinRequestMethod.Service, i, THCRouterHandler.class);
		// }

		addUACMap(CinRequestMethod.Verify, 0x02, MSCRouterHandler.class);
		for (int i = 0x01; i < 0x2F; i++) {
			addUACMap(CinRequestMethod.Data, i, DTCRouterHandler.class);
		}

		for (int i = 0x01; i < 0x39; i++) {
			addUACMap(CinRequestMethod.Video, i, VDCRouterHandler.class);
		}

		for (int i = 0x01; i < 0x30; i++) {
			addUACMap(CinRequestMethod.Social, i, SocialRouterHandler.class);
		}

		_uasMap = new ConcurrentHashMap<Integer, Class>();
		addUASMap(CinRequestMethod.Typing, 0x00, TypingUASHandler.class);
		addUASMap(CinRequestMethod.Typing, 0x01, TypingUASHandler.class);
		addUASMap(CinRequestMethod.Logon, CinLogonEvent.LOGOFF, LogoffUASHandler.class);
	}

	private static void addUACMap(byte method, long eventValue, Class c) {
		CinHeader event = new CinHeader(CinHeaderType.Event, eventValue);
		CinMessageHandlerKey key = new CinMessageHandlerKey(method, event);
		if (_uacMap.containsKey(key.hashCode())) {
			_tracer.error("The following handler can't be added, because the key already exist in the UACMap.\r\n" + key.toString());
		} else {
			_uacMap.put(key.hashCode(), c);
		}
	}

	private static void addUASMap(byte method, long eventValue, Class c) {
		CinHeader event = new CinHeader(CinHeaderType.Event, eventValue);
		CinMessageHandlerKey key = new CinMessageHandlerKey(method, event);
		if (_uasMap.containsKey(key.hashCode())) {
			_tracer.error("The following handler can't be added, because the key already exist in the UASMap.\r\n" + key.toString());
		} else {
			_uasMap.put(key.hashCode(), c);
		}
	}

	static CinMessageUACHandler getCinMessageUACHandler(UserProxy userProxy, CinTransaction transaction) throws Exception {
		CinRequest request = transaction.getRequest();
		int key = new CinMessageHandlerKey(request).hashCode();
		Class c = _uacMap.get(key);
		CinMessageUACHandler handler;
		if (c != null) {
			handler = (CinMessageUACHandler) c.newInstance();
			handler.initialize(userProxy, transaction);
			return handler;
		}

		key = new CinMessageHandlerKey(request.getMethod(), null).hashCode();
		c = _uacMap.get(key);
		if (c != null) {
			handler = (CinMessageUACHandler) c.newInstance();
			handler.initialize(userProxy, transaction);
			return handler;
		}

		handler = new CinMessageUACHandler();
		handler.initialize(userProxy, transaction);
		return handler;
	}

	static CinMessageUASHandler getCinMessageUASHandler(UserProxy userProxy, CinTransaction transaction) throws Exception {
		CinRequest request = transaction.getRequest();
		int key = new CinMessageHandlerKey(request).hashCode();
		Class c = _uasMap.get(key);
		CinMessageUASHandler handler;
		if (c != null) {
			handler = (CinMessageUASHandler) c.newInstance();
			handler.initialize(userProxy, transaction);
			return handler;
		}

		key = new CinMessageHandlerKey(request.getMethod(), null).hashCode();
		c = _uasMap.get(key);
		if (c != null) {
			handler = (CinMessageUASHandler) c.newInstance();
			handler.initialize(userProxy, transaction);
			return handler;
		}

		handler = new CinMessageUASHandler();
		handler.initialize(userProxy, transaction);
		return handler;
	}
}
