package com.allstar.cmpv2;

import java.util.concurrent.ConcurrentLinkedQueue;

import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cintracer.CinTracer;

public class ServerTransactionHolder {
	private static CinTracer _tracer = CinTracer.getInstance(ServerTransactionHolder.class);

	private UserProxy _userProxy;
	private ConcurrentLinkedQueue<CinTransaction> _transactions;

	ServerTransactionHolder(UserProxy userProxy) {
		_userProxy = userProxy;
		_transactions = new ConcurrentLinkedQueue<CinTransaction>();
	}

	public boolean holdServerTransaction(CinTransaction transaction) {
		if (!_userProxy.getUserInfo().isClientReady()) {
			_transactions.add(transaction);
			return true;
		}
		return false;
	}

	public void flushServerTransactions() {
		while (!_transactions.isEmpty()) {
			try {
				CinTransaction transaction = _transactions.poll();
				_userProxy.receiveCinServerTransaction(transaction);
			} catch (Exception ex) {
				_tracer.error("FlushServerTransactions Error.", ex);
			}
		}
	}
}
