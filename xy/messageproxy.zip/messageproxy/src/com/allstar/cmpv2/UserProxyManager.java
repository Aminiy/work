package com.allstar.cmpv2;

import java.util.concurrent.ConcurrentLinkedQueue;

import com.allstar.cinlogger.CinLogger;
import com.allstar.cinsqc.CinSQCCounterManager;
import com.allstar.cinstack.CinStack;
import com.allstar.cinstack.connection.CinConnection;
import com.allstar.cinstack.connection.CinDedicateConnectionEvent;
import com.allstar.cinstack.handler.codec.CinDecoder;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;
import com.allstar.cinstack.message.CinResponse;
import com.allstar.cinstack.message.CinResponseCode;
import com.allstar.cinstack.transaction.CinTransaction;
import com.allstar.cinstack.transaction.CinTransactionCreatedEvent;
import com.allstar.cinstack.transaction.CinTransactionEvent;
import com.allstar.cintracer.CinTracer;
import com.allstar.cinutil.CinLinkedList;
import com.allstar.cinutil.CinLinkedNode;
import com.allstar.cinutil.CinPersonalId;
import com.allstar.event.CinInnerServiceEvent;

public class UserProxyManager extends Thread implements CinDedicateConnectionEvent, CinTransactionCreatedEvent
{
	private static CinLogger logger = CinLogger.getInstance();
	private static CinTracer _tracer = CinTracer.getInstance(UserProxyManager.class);
	//Updated maxusercount to 200000  for scalability
	//private static final int MAXUSERCOUNT = 100000;
	private static final int MAXUSERCOUNT = 200000;
	public static ConcurrentLinkedQueue<CinRequest> requestQueue = new ConcurrentLinkedQueue<CinRequest>();
	private boolean _disposed;
	private boolean _isRunning;
	private ConcurrentLinkedQueue<UserProxy> _notLogonUsers;
	private CinStack _clientStack;
	private CinStack _serverStack;
	private CinSQCCounterManager _cinMessageSQCMgr;

	private CinLinkedList<Integer> _tokenList;
	private UserProxy[] _userProxies;

	UserProxyManager()
	{
		super("UserProxyManager");
		_disposed = false;
		_isRunning = true;
		_notLogonUsers = new ConcurrentLinkedQueue<UserProxy>();
		_tokenList = createTokenList(MAXUSERCOUNT);
		_userProxies = new UserProxy[MAXUSERCOUNT];
		_cinMessageSQCMgr = new CinSQCCounterManager(CinMessageProxyConfig.getIntance().getSQCTimeSpan(), CinMessageProxyConfig.getIntance().getSQCTimeLimit(), MAXUSERCOUNT);
		start();
	}

	void initialize(CinStack clientStack, CinStack serverStack)
	{
		_clientStack = clientStack;
		_serverStack = serverStack;
	}

	UserProxy GetUserProxy(CinPersonalId pid)
	{
		int connectionId = pid.getConnectionId();
		UserProxy proxy = _userProxies[connectionId];
		if (proxy != null && proxy.getUserInfo() != null && proxy.getUserInfo().getPid() != null && pid.equals(proxy.getUserInfo().getPid()))
		{
			return proxy;
		}
		return null;
	}

	CinSQCCounterManager getCinMessageSQCMrg()
	{
		return _cinMessageSQCMgr;
	}

	UserProxy getUserProxy(CinConnection connection)
	{
		CinLinkedNode<Integer> token = _tokenList.takeAwayFirst();
		if (token == null)
			return null;

		_userProxies[token.object()] = new UserProxy(token.object(), this, _clientStack, _serverStack, connection);
		if (_tracer.InfoTrace())
			_tracer.info("New UserProxy has been created.  " + _userProxies[token.object()].toString());
		return _userProxies[token.object()];
	}

	synchronized void removeUserProxy(int token)
	{
		try
		{
			UserProxy userProxy = _userProxies[token];
			if (userProxy == null)
				return;

			userProxy.dispose();
			_userProxies[token] = null;
			_tokenList.put(token);
			if (_tracer.InfoTrace())
				_tracer.info("UserProxy has been removed. " + userProxy);
		}
		catch (Exception ex)
		{
			_tracer.error("RemoveUserProxy Error " + token, ex);
		}
	}

	private CinLinkedList<Integer> createTokenList(int length)
	{
		CinLinkedList<Integer> tokenList = new CinLinkedList<Integer>();
		for (int i = 0; i < length; i++)
		{
			tokenList.put(i);
		}
		tokenList.moveToHead();
		return tokenList;
	}

	private static boolean checkIsNeedResponse(CinRequest request)
	{
		boolean result = false;
		byte method = request.getMethod();
		switch (method)
		{
			case CinRequestMethod.RobotMessage:
			{
				result = true;
				break;
			}
			default:
				result = false;
		}
		return result;
	}

	void dispose()
	{
		if (_disposed)
			return;

		_isRunning = false;
		_disposed = true;
	}

	@Override
	public void run()
	{
		while (_isRunning)
		{
			try
			{
				Thread.sleep(10 * 1000);
				long current = System.currentTimeMillis();
				while (!_notLogonUsers.isEmpty())
				{
					UserProxy userProxy = _notLogonUsers.peek();
					if (!userProxy.isExpired(current))
						break;

					_notLogonUsers.poll();
					if (!userProxy.getUserInfo().isAuthorized())
					{
						removeUserProxy(userProxy.getToken());
						if (_tracer.InfoTrace())
							_tracer.info("UserProxy unauthorized RemoveUserProxy");
					}
				}

				// Send the whole network message - the log only for robotmessagecenter (RBC)
				while (requestQueue != null && requestQueue.size() > 0)
				{
					CinRequest request = requestQueue.poll();
					final boolean isNeedResponse = checkIsNeedResponse(request);
					for (final UserProxy userProxy : _userProxies)
					{
						CinRequest req = request.clone();
						try
						{
							if (userProxy != null && userProxy.getUserInfo().isAuthorized())
							{
								if (isNeedResponse)
								{
									CinTransaction trans = userProxy.getCinConnection().createCinTransaction(req);
									trans.Event = new CinTransactionEvent()
									{
										@Override
										public void onRequestSentTimeout(CinTransaction trans)
										{
										}

										@Override
										public void onRequestSentFailed(CinTransaction trans)
										{
										}

										@Override
										public void onResponseReceived(CinTransaction trans)
										{
											// user get it, save a log.
											CinResponse response = trans.getResponse();
											if (response.isResponseCode(CinResponseCode.OK))
											{
												if (trans.getRequest().getMethod() == CinRequestMethod.RobotMessage)
												{
													RBC2AllOnlineUserMessageLog obj = new RBC2AllOnlineUserMessageLog(trans.getRequest().From.getInt64(), userProxy.getUserInfo().getUid(), trans.getRequest().getHeader(CinHeaderType.MessageID).getHexString(), System.currentTimeMillis());
													logger.send(obj);
												}
											}
										}
									};
									trans.sendRequest();
								}
								else
								{
									userProxy.getCinConnection().createCinTransaction(req).sendRequest();
								}
							}
						}
						catch (Exception e)
						{
							// Preventing connection errors affect subsequent users receiving messages
							_tracer.error("--->>Send All online Message to " + userProxy.getUserInfo().getUid(), req, e);
						}
					}
				}
			}
			catch (Exception ex)
			{
				_tracer.error("Kick off unAuthorized User Thread Error", ex);
			}
		}
	}

	@Override
	public void onCinTransactionCreated(CinTransaction trans)
	{
		CinRequest request = trans.getRequest();
		if (request == null)
			return;

		if (request.isMethod(CinRequestMethod.InnerService) && request.isEvent((byte) CinInnerServiceEvent.SendRequestToAllOnlineUser))
		{
			// CMP to all online users, the request does not contain TO and TPID header
			requestQueue.add((CinRequest) CinDecoder.parse(request.getBody().getValue()));
			trans.sendResponse(CinResponseCode.OK);
			return;
		}

		if (request.To == null || request.Tpid == null)
		{
			trans.sendResponse(CinResponseCode.ClientOffLine);
			return;
		}

		CinPersonalId pid = CinPersonalId.parse(request.getHeader(CinHeaderType.Tpid).getValue());
		UserProxy userProxy = GetUserProxy(pid);
		if (userProxy == null)
		{
			trans.sendResponse(CinResponseCode.ClientOffLine);
			return;
		}
		userProxy.receiveCinServerTransaction(trans);
	}

	@Override
	public void onConnected(CinConnection connection, Object obj)
	{
		UserProxy userPorxy = getUserProxy(connection);
		if (userPorxy == null)
		{
			_tracer.error("Exceed max capability. ConnectionKey: " + connection.toString());
			connection.disconnect();
			return;
		}
		_notLogonUsers.add(userPorxy);
		if (_tracer.InfoTrace())
			_tracer.info("Current Not LogonUsers connection Count: " + _notLogonUsers.size());
	}

	@Override
	public void onConnectFailed(CinConnection conn, Object obj)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void onDisconnected(CinConnection conn, Object obj)
	{
		// TODO Auto-generated method stub

	}
}