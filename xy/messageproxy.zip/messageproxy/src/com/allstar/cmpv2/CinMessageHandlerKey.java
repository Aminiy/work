package com.allstar.cmpv2;

import java.nio.ByteBuffer;

import com.allstar.cinstack.message.CinHeader;
import com.allstar.cinstack.message.CinHeaderType;
import com.allstar.cinstack.message.CinRequest;
import com.allstar.cinstack.message.CinRequestMethod;

public class CinMessageHandlerKey {
	private byte _method;
	private CinHeader _event;

	public CinMessageHandlerKey(CinRequest request) {
		this(request.getMethod(), request.Event);
	}

	public CinMessageHandlerKey(byte method, CinHeader event) {
		_method = method;
		if (event == null)
			_event = new CinHeader(CinHeaderType.Event, 0);
		else
			_event = event;
	}

	public int getInt64(byte[] value) {
		if (value.length > 8)
			return -1;
		byte[] buff = new byte[8];
		int i = 7;
		for (byte b : value) {
			buff[i--] = b;
		}
		return ByteBuffer.wrap(buff).getInt();
	}

	@Override
	public int hashCode() {
		return (ByteBuffer.wrap(new byte[] { (byte) 0x00, (byte) 0x00, (byte) 0x00, _method }).getInt() << 16) + (int) _event.getInt64();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Method: ");
		sb.append(CinRequestMethod.get(_method));
		sb.append(";  Event: ");
		if (_event != null)
			sb.append(_event.getHexString());
		else
			sb.append("null");
		sb.append("; Key: ");
		sb.append(hashCode());
		return sb.toString();
	}
}
